local  sumpGrp = FXGroup:new();
local  downStreams = FXGroup:new();
local  upStreams = FXGroup:new();
local  drainGrp = FXGroup:new();
local size;
local isCompliant = true;
local degree;
local arr = {}
local arr2 = {}
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("BuildingStorey");
	-- CheckEngine.BindCheckFunc("CheckRuleGrp");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end
function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_4_DESIGN_OF_SUMP_FOR_DRAIN_INTERSECTION")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	size = tonumber(ConditionValues[2]);
	degree = tonumber(ConditionValues[6]);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			sumpGrp = sumpGrp + v
			sumpGrp = sumpGrp:Unique()
		end
		if (k == 3) then
			downStreams = downStreams + v
			downStreams = downStreams:Unique()
		end
		if (k == 4) then
			upStreams = upStreams + v
			upStreams = upStreams:Unique()
		end
		if (k == 5) then
			drainGrp = drainGrp + v
			drainGrp = drainGrp:Unique()
		end
	end
end

function CheckRule(Building)
	local slabs = Building:GetDescendants("Slab");
	local flag = false;
	local i = 0;
	if #downStreams == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Downstream Drain is not provided.")
	end
	if #upStreams == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Upstream Drain is not provided.")
	end
	if #drainGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Drain is not provided.")
	end
	if #downStreams ~= 0 and #upStreams ~= 0 and #drainGrp ~= 0 then
		slabs:ForEach(function(slab)
			local sumpObj;
			sumpGrp:ForEach(function( obj )
				if FXClashDetection.IsCollided(slab,obj) then
					sumpObj = obj;
				end
			end)
			if sumpObj ~= nil then
				local sumpOBB = FXGeom.GetBoundingOBB(sumpObj);
				local sumpBox = FXGeom.GetBoundingBox(sumpObj);
				local zPntSump = sumpBox:HighPos();
				local center = sumpOBB:GetPos();
				local cntrPnt = sumpBox:MidPos();
				-----------------------------------Angle------------------------------
				upStreams:ForEach(function(uStream)
					if FXClashDetection.IsCollided(sumpObj,uStream) then
						local box = FXGeom.GetBoundingBox(uStream);
						local obb = FXGeom.GetBoundingOBB(uStream);
						local centerPoint = obb:GetPos();
						local cntrlineUp = FXPUB.GetProjectionCenterLineTemp(uStream)
						local cntrPnt1 = FXUtility.CenterPoint(cntrlineUp:GetStartPoint(),cntrlineUp:GetEndPoint());
						if box:x_range() > box:y_range() then
							drainGrp:ForEach(function( drain )
								if FXClashDetection.IsCollided(sumpObj,drain) then
									local box1 = FXGeom.GetBoundingBox(drain)

									if box1:y_range() > box1:x_range() then
										local Angle = GetAngle(drain,sumpObj,center,cntrlineUp)
									end
								end
							end)
						else
							if box:y_range() > box:x_range() then
								drainGrp:ForEach(function( drain )
									if FXClashDetection.IsCollided(sumpObj,drain) then
										local box1 = FXGeom.GetBoundingBox(drain)

										if box1:x_range() > box1:y_range() then
											local Angle = GetAngle(drain,sumpObj,center,cntrlineUp)
										end
									end
								end)
							end
						end

					end
				end)

				---------------------------------------Sump Width---------------------------------
				downStreams:ForEach(function(dStream)
					if FXClashDetection.IsCollided(sumpObj,dStream) then
						local cntr = sumpBox:MidPos()
						local centerline = FXMeasure.GetProjectionCenterLine(dStream)
						local startPnt = Point3D(centerline:GetStartPoint().x, centerline:GetStartPoint().y, centerline:GetStartPoint().z);
						local endPnt = Point3D(centerline:GetEndPoint().x, centerline:GetEndPoint().y, centerline:GetEndPoint().z-300);

						local longestline,widthValue,display = GetInternalElementWidth(endPnt,dStream)

						local longestline1,widthValue1,display1 = GetInternalElementWidth(cntr,sumpObj)
						local pnt1 = Point3D(longestline1:GetStartPoint().x, longestline1:GetStartPoint().y, longestline1:GetStartPoint().z+1000)
						local pnt2 = Point3D(longestline1:GetEndPoint().x, longestline1:GetEndPoint().y, longestline1:GetEndPoint().z+1000)
						local PlyLine  = PolyLine3D(TRUE);
				   		PlyLine:AddPoint(longestline1:GetStartPoint());
				   		PlyLine:AddPoint(pnt1);
				   		PlyLine:AddPoint(pnt2);
				   		PlyLine:AddPoint(longestline1:GetEndPoint());

			   			i = i +1
						arr[i] = dStream;
						arr2[i] = widthValue;
						-- print(widthValue1.."<"..widthValue*size)
						if widthValue1 < widthValue * size then
							local arrow = DoubleArrow(longestline:GetStartPoint(),longestline:GetEndPoint())
							local arrow2 = DoubleArrow(pnt1,pnt2)
							-- FXUtility.DisplaySolid_Error(sumpObj,"The minimum internal width of the "..sumpObj:GetAttri("Name").." is less than 1.5 times the width of the "..dStream:GetAttri("Name"))
							-- CheckReport.AddRelatedGeometry_Error(arrow,"ss")
							-- CheckReport.AddRelatedGeometry_Error(arrow2)
							FXUtility.DisplaySolid_Error(dStream,"Internal Width = "..widthValue.."mm",arrow2);
							CheckReport.AddRelatedGeometry_Error(PlyLine)
							CheckReport.AddRelatedObj(sumpObj,"Internal Width = "..widthValue1.."mm")
							isCompliant = false;
						end

						-------------------------------Invert Elevation----------------------
						local Pnt1 = Point3D(endPnt.x, endPnt.y,endPnt.z)
						local Pnt2 
						local line

						local minuser = 0
						while minuser ~= 10000 do
							minuser = minuser + 1
							Pnt2 = Point3D ( endPnt.x, endPnt.y,endPnt.z - minuser )
							line = Line3D ( Pnt1 , Pnt2 )
							local node = FXUtility.CreateNodeFrom( line )

							if FXClashDetection.IsCollided( node , dStream ) then
								break;
							end

							FXClashDetection.DeleteNode( node )
						end
						
						local invertDepth = tonumber(sumpObj:GetAuxAttri("Dimensions.Sump Internal Depth"));
						local Point1 = Point3D(zPntSump.x, zPntSump.y, zPntSump.z - invertDepth);

						local pnt1 = line:GetStartPoint()
						local pnt2 = line:GetEndPoint()

						if Point1.z < pnt2.z then
							FXUtility.DisplaySolid_Error(dStream,"The invert level of "..dStream:GetAttri("Name").." is higher than the invert level of "..sumpObj:GetAttri("Name"),dStream)
							isCompliant = false;
						end

					end
				end)

				if isCompliant == true then
					local longestline,widthValue1,display1 = GetInternalElementWidth(cntrPnt,sumpObj);
					local pnt1 = Point3D(longestline:GetStartPoint().x, longestline:GetStartPoint().y, longestline:GetStartPoint().z+1000)
					local pnt2 = Point3D(longestline:GetEndPoint().x, longestline:GetEndPoint().y, longestline:GetEndPoint().z+1000)

					local PlyLine  = PolyLine3D(TRUE);
			   		PlyLine:AddPoint(longestline:GetStartPoint());
			   		PlyLine:AddPoint(pnt1);
			   		PlyLine:AddPoint(pnt2);
			   		PlyLine:AddPoint(longestline:GetEndPoint());

					local arrow = DoubleArrow(pnt1, pnt2)
					FXUtility.DisplaySolid_Info(sumpObj,sumpObj:GetAttri("Name").." is provided with sufficient size and design.",arrow);
					CheckReport.AddRelatedGeometry_Info(PlyLine)
					for k,dStream in pairs(arr) do
						CheckReport.AddRelatedObj(dStream,"Internal Width = "..arr2[i].."mm")
					end
					drainGrp:ForEach(function(pipe)
						if FXClashDetection.IsCollided(sumpObj,pipe) then
							CheckReport.AddRelatedObj(pipe,pipe:GetAttri("Name"))
						end
					end)
					downStreams:ForEach(function(downPipe)
						if FXClashDetection.IsCollided(sumpObj,downPipe) then
							CheckReport.AddRelatedObj(downPipe,downPipe:GetAttri("Name"))
						end
					end)
					upStreams:ForEach(function(upPipe)
						if FXClashDetection.IsCollided(sumpObj,upPipe) then
							CheckReport.AddRelatedObj(upPipe,upPipe:GetAttri("Name"))
						end
					end)
				end
			else
				drainGrp:ForEach(function(drain)
					if FXClashDetection.IsCollided(drain,slab) then
						FXUtility.DisplaySolid_Error(drain,"Sump is not provided. ")
					end
				end)
				downStreams:ForEach(function(drain)
					if FXClashDetection.IsCollided(drain,slab) then
						CheckReport.AddRelatedObj(drain,drain:GetAttri("Name"))
					end
				end)
				upStreams:ForEach(function(drain)
					if FXClashDetection.IsCollided(drain,slab) then
						CheckReport.AddRelatedObj(drain,drain:GetAttri("Name"))
					end
				end)
			end
		end)
	end
end

function GetLongestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetInternalElementWidth(Point,Element)
	local i = 1;
	local width = 0;
	local Pnt1;
	local Pnt2;
	local eleBox = FXGeom.GetBoundingBox(Element);

	if eleBox:x_range() > eleBox:y_range() then
		Pnt1 = Point3D(Point.x+10, Point.y,Point.z)
		Pnt2 = Point3D(Point.x-10, Point.y,Point.z)
	else
		Pnt1 = Point3D(Point.x, Point.y+10,Point.z)
		Pnt2 = Point3D(Point.x, Point.y-10,Point.z)
	end
	
	local line = Line3D(Pnt1, Pnt2);
	while i > 0 do -- to get the width of the trench 			
		width = width + 1 ;
		local extended = FXMeasure.CreateFaceFromEdge(line, width); -- makes the line fatter everyloop incrementing 1mm
		local extendedNode = FXUtility.CreateNodeFrom(extended); -- node for the face, to make it work with IsCollided 
			if FXClashDetection.IsCollided ( extendedNode , Element ) then
				i = i - 1 	
				FXClashDetection.DeleteNode ( extendedNode );				
			end
		FXClashDetection.DeleteNode ( extendedNode );  -- always delete a node after using
	end

	local ElementWidth = width * 2
	local showWidth = FXMeasure.CreateFaceFromEdge(line, width);
	local outer = FXMeasure.GetOuterEdge( showWidth );
	local Line = GetLongestLine(outer)

	return Line, ElementWidth,showWidth;
end

function GetAngle(Element1,Element2,CenterPnt,cntrlineUp)
	local cntrline = FXPUB.GetProjectionCenterLineTemp(Element1)
	local cntrPnt2 = FXUtility.CenterPoint(cntrline:GetStartPoint(),cntrline:GetEndPoint());

	local startpnt = Point3D(cntrline:GetStartPoint().x, cntrline:GetStartPoint().y, cntrline:GetStartPoint().z)
	local endpnt = Point3D(cntrline:GetEndPoint().x, cntrline:GetEndPoint().y, cntrline:GetEndPoint().z)

	local distance1 = CenterPnt:Distance_Pnt(startpnt);
	local distance2 = CenterPnt:Distance_Pnt(endpnt);

	local vec1 =cntrlineUp:GetVector();
	local vec2 = cntrline:GetVector(); 
	local angle  = vec1:Angle(vec2);

	if distance1 < distance2 then
		if FXUtility.Round(endpnt.x,0) < FXUtility.Round(startpnt.x,0) then
			local angleVal = FXUtility.Round((angle * 180) / math.pi);
			if angleVal < degree then
				local newVal = math.floor(FXUtility.Round(-(angle * 180) / math.pi)+180);
				if newVal > degree then
					FXUtility.DisplaySolid_Error(Element1,Element1:GetAttri("Name").." entering the "..Element2:GetAttri("Name").." at an angle of "..newVal.." degrees ",Element1)
					isCompliant = false;
				end
			else
				FXUtility.DisplaySolid_Error(Element1,Element1:GetAttri("Name").." entering the "..Element2:GetAttri("Name").." at an angle of "..angleVal.." degrees ",Element1)
				isCompliant = false;
			end
		end
	else
		if distance2 < distance1 then
			if FXUtility.Round(startpnt.x,0) < FXUtility.Round(endPnt.x,0) then
				local angleVal = FXUtility.Round((angle * 180) / math.pi);
				if angleVal < degree then
					local newVal = math.floor(FXUtility.Round(-(angle * 180) / math.pi)+180);
					if newVal > degree then
						FXUtility.DisplaySolid_Error(Element1,Element1:GetAttri("Name").." entering the "..Element2:GetAttri("Name").." at an angle of "..newVal.." degrees ",Element1)
						isCompliant = false;
					end
				else
					FXUtility.DisplaySolid_Error(Element1,Element1:GetAttri("Name").." entering the "..Element2:GetAttri("Name").." at an angle of "..angleVal.." degrees ",Element1)
					isCompliant = false;
				end
			end
		end
	end
end