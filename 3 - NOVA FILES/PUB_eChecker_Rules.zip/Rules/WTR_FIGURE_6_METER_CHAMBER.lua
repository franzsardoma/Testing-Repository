local WaterMeter = FXGroup.new();
local Valves = FXGroup.new();
local ValvesInMeterChamber = FXGroup.new();
local WaterMeterCheck = false;
local MeterChamberSpace;
local MeterChamber = FXGroup.new();
local MeterObject;

local v1 = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("System")
	CheckEngine.BindCheckFunc("GetSystem")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("CheckRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "WTR_FIGURE_6_HEIGHT_OF_METER_CHAMBER_WITHOUT_VALVE");

    --local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	--local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	--SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	--local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	--minHeight = ConditionValues[2];

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);		
	for k,v in pairs(GrpObjs) do
		if (k == 5) then
			MeterChamber =  MeterChamber + v;
		end
		-- if (k == 7) then			    
		-- 	v2 = v2 + v;
		-- end			
	end	
end


function CheckRule(Building)
	if(#MeterChamber ~= 0)then
		MeterChamber:ForEach(function(MeterChamberElement) 
			MeterChamberSpace = MeterChamberElement;
		end)
		 
		local BuildingStoreyGroup = Building:GetDescendants("BuildingStorey");
		BuildingStoreyGroup:ForEach(function(BuildingStoreyElement)
			MeterChamber:ForEach(function(MeterElement)

				WaterMeter:ForEach(function(WaterMeterObject)
					if(FXClashDetection.IsCollided(MeterElement,WaterMeterObject) == true)then
						WaterMeterCheck = true;
						MeterChamberSpace = MeterElement; 
						MeterObject = WaterMeterObject;
					end
				end)

				Valves:ForEach(function(ValvesObject)
					if(FXClashDetection.IsCollided(MeterElement,ValvesObject) == true)then
						ValvesInMeterChamber:Add(ValvesObject);
					end
				end)
			end)
		end)

		if(#ValvesInMeterChamber == 0)then 
			if(WaterMeterCheck == true)then
				local ConnectedWallsGroup = MeterChamberSpace:GetConnectedWall();
				-- local isWallOkay = false;
				-- local Point1;
				-- local Point2;
				-- local WallOBB;
				-- local WallBox;
				-- local WallMaxPntZ;
				
				-- if(#ConnectedWallsGroup ~= 0)then 
				-- 	ConnectedWallsGroup:ForEach(function(WallElement)
				-- 		-- WallOBB = FXGeom.GetBoundingOBB(WallElement);
				-- 		-- WallBox = FXGeom.GetBoundingBox(WallElement);
				-- 		-- WallMaxPntZ = WallOBB:MaxPnt().z;
				-- 		-- Point1 = Point3D(WallOBB:MaxPnt().x,WallOBB:MaxPnt().y,WallBox:HighPos().z);
				-- 		-- Point2 = Point3D(WallOBB:MaxPnt().x,WallOBB:MaxPnt().y,WallBox:LowPos().z);

				-- 		-- if(WallMaxPntZ <= 700)then
				-- 		-- 	isWallOkay = true;
				-- 		-- end

				-- 		WallObject = WallElement;
				-- 	end)
				-- end

				

				local SpaceOBB = FXGeom.GetBoundingOBB(MeterChamberSpace);
				local SpaceBox = FXGeom.GetBoundingBox(MeterChamberSpace);
				local SpaceHeight = SpaceOBB:MaxPnt().z;
				local Point1 = Point3D(SpaceOBB:MaxPnt().x,SpaceOBB:MaxPnt().y,SpaceBox:HighPos().z);
				local Point2 = Point3D(SpaceOBB:MaxPnt().x,SpaceOBB:MaxPnt().y,SpaceBox:LowPos().z);

				-- SpaceHeight

				local Line = Line3D(Point1,Point2);
				-- local distance = Line:Length();
				local Pnt1, Pnt2;

				local Spaceyrange = SpaceBox:y_range();
				local Spacexrange = SpaceBox:x_range();

				if(Spaceyrange > Spacexrange)then
					if(Line:GetStartPoint().y > 0)then
						Pnt1 = Point3D(Line:GetStartPoint().x,SpaceBox:HighPos().y+200,Line:GetStartPoint().z);
						Pnt2 = Point3D(Line:GetEndPoint().x,SpaceBox:HighPos().y+200,Line:GetEndPoint().z);
					else
						Pnt1 = Point3D(Line:GetStartPoint().x,SpaceBox:LowPos().y-200,Line:GetStartPoint().z);
						Pnt2 = Point3D(Line:GetEndPoint().x,SpaceBox:LowPos().y-200,Line:GetEndPoint().z);
					end
				else
					if(Line:GetStartPoint().x > 0)then
						Pnt1 = Point3D(SpaceBox:HighPos().x+200,Line:GetStartPoint().y,Line:GetStartPoint().z);
						Pnt2 = Point3D(SpaceBox:HighPos().x+200,Line:GetEndPoint().y,Line:GetEndPoint().z);
					else
						Pnt1 = Point3D(SpaceBox:LowPos().x-200,Line:GetStartPoint().y,Line:GetStartPoint().z);
						Pnt2 = Point3D(SpaceBox:LowPos().x-200,Line:GetEndPoint().y,Line:GetEndPoint().z);
					end
				end

				local arrowGeom = DoubleArrow(Pnt1, Pnt2);
				local polyline = PolyLine3D(TRUE);
				polyline:AddPoint(Line:GetStartPoint());
				polyline:AddPoint(Pnt1);

				if(SpaceHeight <= 700)then 
					FXUtility.DisplaySolid_Info(MeterChamberSpace,SpaceHeight.."mm",arrowGeom);
					CheckReport.AddRelatedGeometry_Solid(polyline);
				else
					FXUtility.DisplaySolid_Error(MeterChamberSpace,SpaceHeight.."mm",arrowGeom);
					CheckReport.AddRelatedGeometry_Error(polyline);
				end

				ConnectedWallsGroup:ForEach(function(WallObject)
					CheckReport.AddRelatedObj(WallObject,WallObject:GetAttri("Name"));	
				end)
				CheckReport.AddRelatedObj(MeterObject,MeterObject:GetAttri("Name"));
			else
				FXUtility.DisplaySolid_Error(Building,"No Water Meter found.");	
			end
		else
			FXUtility.DisplaySolid_Warning(MeterChamberSpace,"There are valves present.");
			ValvesInMeterChamber:ForEach(function(ValvePresent) 
				CheckReport.AddRelatedObj(ValvePresent,ValvePresent:GetAttri("Name"));
			end)
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"No Meter Chamber found.");
	end
end


function GetSystem(System)
	local FlowControllerGroup = System:GetDescendants("FlowController");
	FlowControllerGroup:ForEach(function(FlowControllerElement)
		if(FXUtility.HasPatterInString(FlowControllerElement:GetAttri("Name"),"Water Meter") == true or FXUtility.HasPatterInString(FlowControllerElement:GetAttri("Name"),"Water_Meter") == true)then 
			WaterMeter:Add(FlowControllerElement);
		else 
			Valves:Add(FlowControllerElement);
		end
	end)
end