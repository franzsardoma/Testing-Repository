local grpSewerConnections = FXGroup:new();
local grpPublicSewers = FXGroup:new();
local grpJunctions = FXGroup:new();
local grpChambers = FXGroup:new();
local grpHouseUnits = FXGroup:new();
local conValue;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_1_C_MAXIMUM_LATERAL_DISTANCE")
	
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjs) do
		if (k == 5) then
			grpSewerConnections = grpSewerConnections + v;
			grpSewerConnections = grpSewerConnections:Unique();
		end
		if (k == 6) then
			grpPublicSewers = grpPublicSewers + v;
			grpPublicSewers = grpPublicSewers:Unique();
		end
		if (k == 7) then
			grpJunctions = grpJunctions + v;
			grpJunctions = grpJunctions:Unique();
		end
		if (k == 8) then
			grpChambers = grpChambers + v;
			grpChambers = grpChambers:Unique();
		end
		if (k == 9) then
			grpHouseUnits = grpHouseUnits + v;
			grpHouseUnits = grpHouseUnits:Unique();
		end
	end

	for k,v in pairs(ConditionValues) do -- get the condition values
		if (k == 2) then
			conValue = tonumber(v);
		end
	end
	
end

function checkRule( Building )
	local flag = true;
	local grpFlowFittings = Building:GetDescendants("FlowFitting")
	grpJunctions = grpJunctions + getTeeJunction(grpFlowFittings)
	grpFlowFittings = grpFlowFittings - grpJunctions
	local grpFlowSegments = Building:GetDescendants("FlowSegment")
	grpFlowSegments = (grpFlowSegments - grpSewerConnections) - grpPublicSewers
	grpFlowFittings = grpFlowFittings + grpFlowSegments

	if (#grpPublicSewers== 0) then
		CheckReport.Warning( Building, "Public sewer is not provided." )
		flag = false;
	end

	if(#grpChambers == 0) then
		CheckReport.Warning( Building, "No Inspection Chamber to check" )
		flag = false;
	end
	-- print(#grpSewerConnections)
	if (#grpSewerConnections == 0) then
		CheckReport.Warning( Building, "Sewer Connection is not provided." )
		flag = false;
	end
	-- print(#grpHouseUnits)
	if (#grpHouseUnits == 0) then
		CheckReport.Warning( Building, "Housing Unit is not provided." )
		flag = false;
	end

	if (#grpJunctions == 0) then
		CheckReport.Warning( Building, "Junction is not provided." )
		flag = false;
	end
	-- print(#grpChambers)
	if(#grpChambers == 0) then
		CheckReport.Warning( Building, "No Inspection Chamber to check" )
		flag = false;
	end

	if(flag == true) then

		grpHouseUnits:ForEach(function ( HouseUnitEle )
			local HouseUnitBOX = FXGeom.GetBoundingBox(HouseUnitEle)
			local Chamber = getChamber(HouseUnitEle)
			local Junction = getConnectedJunction(Chamber, grpFlowFittings)
			local ChamberBOX = FXGeom.GetBoundingBox(Chamber)
			local ChamberPnt = Point3D(ChamberBOX:MidPos().x, ChamberBOX:MidPos().y, HouseUnitBOX:HighPos().z)
			-- print(Junction ~= nil)
			if(Junction ~= nil) then
				local JunctionPnt = FXGeom.GetBoundingOBB(Junction):GetPos()
				local PropertyLinePnt = getPropertyLinePnt(HouseUnitBOX, JunctionPnt, ChamberBOX)
				local arrow = DoubleArrow(PropertyLinePnt, ChamberPnt)
				local Distance = PropertyLinePnt:Distance_Pnt(ChamberPnt)

				if(Distance <= conValue) then
					FXUtility.DisplaySolid_Info(Building, "Last Inspection Chamber: Distance = "..Distance.."mm; Compliant",arrow);
				else
					FXUtility.DisplaySolid_Error(Building, "Last Inspection Chamber: Distance = "..Distance.."mm; Inspection Chamber is beyond maximum lateral distance",arrow);
				end

				if (FXUtility.HasPatterInString(Junction:GetAttri("Name"),"Raised Junction") or FXUtility.HasPatterInString(Junction:GetAttri("Name"),"Y Junction")) then
					FXUtility.DisplaySolid_Info(Junction, "Y Junction or Raised Junction is provided");
					CheckReport.AddRelatedObj(Junction, Junction:GetAttri("Name"))
				else
					FXUtility.DisplaySolid_Error(Junction, "Y Junction or Raised Junction is not provided");
					CheckReport.AddRelatedObj(Junction, Junction:GetAttri("Name"))
				end
			end
		end)
	end
end

function getPropertyLinePnt(HouseUnitBOX, JunctionPnt, ChamberBOX)
	local FinalPnt;
	local dist1 = JunctionPnt:Distance_Pnt(Point3D(HouseUnitBOX:HighPos().x, HouseUnitBOX:MidPos().y, HouseUnitBOX:HighPos().z))
	local dist2 = JunctionPnt:Distance_Pnt(Point3D(HouseUnitBOX:LowPos().x, HouseUnitBOX:MidPos().y, HouseUnitBOX:HighPos().z))
	local dist3 = JunctionPnt:Distance_Pnt(Point3D(HouseUnitBOX:MidPos().x, HouseUnitBOX:HighPos().y, HouseUnitBOX:HighPos().z))
	local dist4 = JunctionPnt:Distance_Pnt(Point3D(HouseUnitBOX:MidPos().x, HouseUnitBOX:LowPos().y, HouseUnitBOX:HighPos().z))
	local dist;

	if(dist1 > dist2) then
		dist = dist2
		FinalPnt = Point3D(HouseUnitBOX:LowPos().x, ChamberBOX:MidPos().y, HouseUnitBOX:HighPos().z)
	else
		dist = dist1
		FinalPnt = Point3D(HouseUnitBOX:HighPos().x, ChamberBOX:MidPos().y, HouseUnitBOX:HighPos().z)
	end
	if(dist > dist3) then
		dist = dist3
		FinalPnt = Point3D(ChamberBOX:MidPos().x, HouseUnitBOX:HighPos().y, HouseUnitBOX:HighPos().z)
	end
	if(dist > dist4) then
		FinalPnt = Point3D(ChamberBOX:MidPos().x, HouseUnitBOX:LowPos().y, HouseUnitBOX:HighPos().z)
	end

	return FinalPnt
end

function getTeeJunction( grpFlowFittings )
	local grpTeeJunction = FXGroup:new()

	grpFlowFittings:ForEach(function ( FittingEle )
		if (FXUtility.HasPatterInString(FittingEle:GetAttri("Name"),"Tee Junction")) then
			grpTeeJunction:Add(FittingEle)
		end
	end)
	return grpTeeJunction;
end

function getChamber( HouseUnit )
	local Chamber
	local flag = false;

	grpChambers:ForEach(function ( ChamberEle )
		if flag == true then
			return;
		end
		if(FXClashDetection.IsCollided(HouseUnit,ChamberEle))then
			Chamber = ChamberEle
			flag = true
		end
	end)
	return Chamber
end

function getConnectedJunction( Chamber, grpFlowFittings )
	local flag = false;
	local Junction;

	grpSewerConnections:ForEach(function( SewerConnEle )
		if flag == true then
			return;
		end
		if(CheckSewerConnChamber( Chamber, SewerConnEle, grpFlowFittings )) then
			grpJunctions:ForEach(function ( JunctionEle )
				if flag == true then
					return;
				end
				if(CheckSewerConnChamber( JunctionEle, SewerConnEle, (grpFlowFittings + grpSewerConnections) )) then
					Junction = JunctionEle;
					flag = true
				end
			end)
		end
	end)
	return Junction;
end

function CheckSewerConnChamber( Chamber, obj, grpFlowFittings )
	local flag = false
	local connectedFitting = FXGroup:new();

	if(FXClashDetection.IsCollided(Chamber,obj))then
		flag = true
	else
		grpFlowFittings:ForEach(function ( FlowFitting )
			if flag == true then
				return;
			end
			if(FXClashDetection.IsCollided(FlowFitting,obj))then
				if (FXClashDetection.IsCollided(FlowFitting, Chamber)) then
					flag = true;
					return;
				end
				connectedFitting:Add(FlowFitting);
			end
		end)
	end

	if flag == false then
		grpFlowFittings = grpFlowFittings - connectedFitting;

		connectedFitting:ForEach(function ( connObj )
			if flag == true then
				return;
			end
			if (CheckSewerConnChamber( Chamber, connObj, grpFlowFittings )) then
				flag = true;
			end
		end)
	end

	return flag;
end
