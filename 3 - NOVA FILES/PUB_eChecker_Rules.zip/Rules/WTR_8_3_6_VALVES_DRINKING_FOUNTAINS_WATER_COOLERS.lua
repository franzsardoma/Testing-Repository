local Water_Cooler = FXGroup.new();
local Drinking_Fountain = FXGroup.new();
local Double_Check_Valves = FXGroup.new();
local wc_Connected = true;
local df_Connected = true;

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end
function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_8_3_6_VALVES_DRINKING_FOUNTAINS_WATER_COOLERS")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			Water_Cooler = Water_Cooler + v;
			Water_Cooler = Water_Cooler:Unique();
		end
	end
	for k,v in pairs(GrpObjs) do
		if (k == 3) then
			Drinking_Fountain = Drinking_Fountain + v;
			Drinking_Fountain = Drinking_Fountain:Unique();
		end
	end
	for k,v in pairs(GrpObjs) do
		if (k == 4) then
			Double_Check_Valves = Double_Check_Valves + v;
			Double_Check_Valves = Double_Check_Valves:Unique();
		end
	end
end

function CheckRule( Building )
	local WATER_COOLER = {}
	local DRINKING_FOUNTAIN = {};
	local Valve = {};
	local flag = true;

	if(#Water_Cooler ~= 0 or #Drinking_Fountain ~= 0)then
		if (#Double_Check_Valves ~= 0) then
			Double_Check_Valves:ForEach(function ( valve )
				--( Water Cooler -> Checking )--
				Water_Cooler:ForEach(function ( waterCooler )
					if (FXPUB.IsObjsConnected(valve, waterCooler)) then
						flag = true;
						table.insert(WATER_COOLER,waterCooler)
						table.insert(Valve,valve)
					end
				end)
				--( Drinking Fountain -> Checking )--
				Drinking_Fountain:ForEach(function ( drinkingFountain )
					if (FXPUB.IsObjsConnected(valve, drinkingFountain)) then
						flag = true;
						table.insert(DRINKING_FOUNTAIN,drinkingFountain)
						table.insert(Valve,valve)
					end
				end)
			end)
		else
			flag = false;
			Water_Cooler:ForEach(function ( wc )
				FXUtility.DisplaySolid_Error(wc, "Hooded Jet or Double Check Valve are not provided.")
			end)
			Drinking_Fountain:ForEach(function ( df )
				FXUtility.DisplaySolid_Error(df, "Hooded Jet or Double Check Valve are not provided.")
			end)
			
		end
	else
		FXUtility.DisplaySolid_Warning(Building, "Water Cooler or Drinking fountain are not provided.")
	end

	if (flag == true) then
		for i = 1, #WATER_COOLER do
			FXUtility.DisplaySolid_Info(WATER_COOLER[i], "Hooded Jet or Double Check Valve are provided.")
			CheckReport.AddRelatedObj(Valve[i], Valve[i]:GetAttri("ObjectType"))
		end
		for i = 1, #DRINKING_FOUNTAIN do
			FXUtility.DisplaySolid_Info(DRINKING_FOUNTAIN[i], "Hooded Jet or Double Check Valve are provided.")
			CheckReport.AddRelatedObj(Valve[i], Valve[i]:GetAttri("ObjectType"))
		end
	end
end