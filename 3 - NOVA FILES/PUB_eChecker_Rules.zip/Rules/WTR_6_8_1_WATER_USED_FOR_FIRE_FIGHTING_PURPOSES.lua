local FireFightingServPipeGrp = FXGroup.new()
local FireFightingDistPipeGrp = FXGroup.new()
local DistPipeGrp = FXGroup.new()
local ServicePipeGrp = FXGroup.new()
local PotableWaterStorageTankGrp = FXGroup.new()
local CombinedWaterStorageTankGrp = FXGroup.new()
local FirefightingWaterStorageTankGrp = FXGroup.new()

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_8_1_WATER_USED_FOR_FIRE_FIGHTING_PURPOSES")
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpBuildingObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpBuildingObjs) do -- Checking in System
		if (k == 2) then
			FireFightingServPipeGrp = FireFightingServPipeGrp + v
			FireFightingServPipeGrp = FireFightingServPipeGrp:Unique()
		end
		if (k == 3) then
			FireFightingDistPipeGrp = FireFightingDistPipeGrp + v
			FireFightingDistPipeGrp = FireFightingDistPipeGrp:Unique()
		end
		if (k == 4) then
			DistPipeGrp = DistPipeGrp + v
			DistPipeGrp = DistPipeGrp:Unique()
		end
		if (k == 5) then
			ServicePipeGrp = ServicePipeGrp + v
			ServicePipeGrp = ServicePipeGrp:Unique()
		end
		if (k == 6) then
			PotableWaterStorageTankGrp = PotableWaterStorageTankGrp + v
			PotableWaterStorageTankGrp = PotableWaterStorageTankGrp:Unique()
		end
		if (k == 7) then
			CombinedWaterStorageTankGrp = CombinedWaterStorageTankGrp + v
			CombinedWaterStorageTankGrp = CombinedWaterStorageTankGrp:Unique()
		end
		if (k == 8) then
			FirefightingWaterStorageTankGrp = FirefightingWaterStorageTankGrp + v
			FirefightingWaterStorageTankGrp = FirefightingWaterStorageTankGrp:Unique()
		end	
	end
end

function CheckRule(Building)
    local connected = false;
    local ffserviceconnected = false;
    local ffdistributionconnected = false;
    local pipeconnected;
    local pipeconnected2;
    local servicepipe;
    local distpipe;
    local pubServicePipeGrp = FXGroup.new()
    local DistributionPipeGrp = FXGroup.new()
    
    ServicePipeGrp:ForEach(function(pipeEle)
    	if pipeEle:GetAuxAttri("Entity.Description") == "Service" then
    		pubServicePipeGrp:Add(pipeEle)
    	end
    end)

    DistPipeGrp:ForEach(function(pipeEle)
    	if pipeEle:GetAuxAttri("Entity.Description") == "Distribution" then
    		DistributionPipeGrp:Add(pipeEle)
    	end
    end)

    if #CombinedWaterStorageTankGrp ~= 0 then
    	CombinedWaterStorageTankGrp:ForEach(function(tankEle)
	    	FireFightingDistPipeGrp:ForEach(function(pipeEle)
	 			if FXPUB.IsObjsConnected(tankEle, pipeEle,2) then
	 				connected = true;
	 				pipeconnected = pipeEle;
	 				return
	 			end
	 		end)

	 		if connected then
		    	FXUtility.DisplaySolid_Error(tankEle:GetParent(),pipeconnected:GetAttri("Name") .. ":Connected to " .. tankEle:GetAttri("Name"));
		    	CheckReport.AddRelatedObj(tankEle,tankEle:GetAttri("Name"));
		    	FireFightingDistPipeGrp:ForEach(function(pipeEle)
		    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
		    	end)
    		end
	 	end)
    end

    if #FirefightingWaterStorageTankGrp ~= 0 then
    	FirefightingWaterStorageTankGrp:ForEach(function(tankEle)
	    	FireFightingServPipeGrp:ForEach(function(pipeEle)
	 			if FXPUB.IsObjsConnected(tankEle, pipeEle,2) then
	 				ffserviceconnected = true;
	 				pipeconnected = pipeEle;
	 				return
	 			end
	 		end)

	 		FireFightingDistPipeGrp:ForEach(function(pipeEle)
	 			if FXPUB.IsObjsConnected(tankEle, pipeEle,2) then
	 				ffdistributionconnected = true;
	 				pipeconnected2 = pipeEle;
	 				return
	 			end
	 		end)

	 		if ffserviceconnected and ffdistributionconnected then
	 			FXUtility.DisplaySolid_Info(tankEle:GetParent(),pipeconnected:GetAttri("Name") .. " and " .. pipeconnected2:GetAttri("Name") .. ":Connected to " .. tankEle:GetAttri("Name"));
	 			CheckReport.AddRelatedObj(tankEle,tankEle:GetAttri("Name"));
		    	FireFightingServPipeGrp:ForEach(function(pipeEle)
		    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
		    	end)

		    	FireFightingDistPipeGrp:ForEach(function(pipeEle)
		    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
		    	end)
 			end
	 	end)

    else
	    if #PotableWaterStorageTankGrp ~= 0 then
	    	PotableWaterStorageTankGrp:ForEach(function(tankEle)
		    	if #FireFightingServPipeGrp ~= 0 then
			    	FireFightingServPipeGrp:ForEach(function(pipeEle)
		 				pubServicePipeGrp:ForEach(function(servicePipeEle)
		 					if FXPUB.IsObjsConnected(pipeEle, servicePipeEle,2) then
		 						connected = true;
		 						pipeconnected = pipeEle;
		 						servicepipe = servicePipeEle;
		 						return
		 					end
		 				end)
		 			end)

		 			if connected then
				    	FXUtility.DisplaySolid_Info(tankEle:GetParent(),pipeconnected:GetAttri("Name") .. ":Connected to " .. servicepipe:GetAttri("Name"));
				    	FireFightingServPipeGrp:ForEach(function(pipeEle)
				    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
				    	end)

				    	pubServicePipeGrp:ForEach(function(pipeEle)
				    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
				    	end)
				    end
		 		else

			 		if #FireFightingDistPipeGrp ~= 0 then
			 			FireFightingDistPipeGrp:ForEach(function(pipeEle)
			 				DistributionPipeGrp:ForEach(function(pipeEle2)
			 					if FXPUB.IsObjsConnected(pipeEle, pipeEle2,2) then
			 						connected = true;
			 						pipeconnected = pipeEle;
			 						distpipe = pipeEle2;
			 						return
			 					end
			 				end)
			 			end)

			 			if connected then
					    	FXUtility.DisplaySolid_Error(tankEle:GetParent(),pipeconnected:GetAttri("Name") .. ":Connected to " .. distpipe:GetAttri("Name"));
					    	FireFightingDistPipeGrp:ForEach(function(pipeEle)
					    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
					    	end)

					    	DistributionPipeGrp:ForEach(function(pipeEle)
					    		CheckReport.AddRelatedObj(pipeEle,pipeEle:GetAttri("Name"));
					    	end)
					    end
			 		end
			 	end
			end)
	 	end
    end
end