local SothernmRL;
local NorthernmRL;
local SiteLocation;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_2_3_1_2_RECLAMATION_LEVEL");
	local SiteEle = Building:GetParent():GetAuxAttri("Other.Project Location");

	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	local ConditionValue0 = FXRule.ParseValues(parsedXml, "Condition0");
	local ConditionValue1 = FXRule.ParseValues(parsedXml, "Condition1");
	
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				if( v1["property"] == "Project Address" ) then 
					if( FXRule.EvaluateRule("STRING", v1["operator"], v1["value"], SiteEle) ) then
						SiteLocation = SiteEle;
					end
				end
			end
		end
	end
	
	for k,v in pairs(ConditionValue0) do
		if (k == 3) then
			SothernmRL = tonumber(v);
		end
	end
	
	for k,v in pairs(ConditionValue1) do
		if (k == 3) then
			NorthernmRL = tonumber(v);
		end
	end

	return tblValues;
end

function checkRule(Building)

	
	local SiteEle = Building:GetParent();
	local LowPos = FXGeom.GetBoundingBox(SiteEle):LowPos().z;
	local grpTopo = FXGroup.new();
	grpTopo:Add(SiteEle);
	local proj = FXMeasure.GetProjection(grpTopo, LowPos);
	local strSouthern = FXUtility.HasPatterInString(SiteLocation,"southern");
	local strNorthern = FXUtility.HasPatterInString(SiteLocation,"northern");

	if( SiteLocation == nil or SiteLocation == "" ) then
		FXUtility.DisplaySolid_Warning(Building, "Project Location not specified");
		return;
	end
	
	if( strSouthern == false and strNorthern == false ) then
		FXUtility.DisplaySolid_Warning(Building, "Project Location does not match.");
		return;
	end
	

	if strSouthern and LowPos >= SothernmRL then 
		FXUtility.DisplaySolid_Info(Building, "Reclamation Level: "..(LowPos/1000).." m; "..SiteLocation);
		CheckReport.AddRelatedGeometry_SupportedInfo(proj) -- Added projection for mRL
		FXUtility.DisplaySolid_Info(Building, "Reclamation Level: is above required mRL.");
	elseif strNorthern and LowPos >= NorthernmRL then 
		FXUtility.DisplaySolid_Info(Building, "Reclamation Level: "..(LowPos/1000).." m; "..SiteLocation);
		CheckReport.AddRelatedGeometry_SupportedInfo(proj) -- Added projection for mRL
		FXUtility.DisplaySolid_Info(Building, "Reclamation Level: is above required mRL.");
	else
		FXUtility.DisplaySolid_Error(Building, "Reclamation Level: "..(LowPos/1000).." m; "..SiteLocation);
		CheckReport.AddRelatedGeometry_SupportedInfo(proj) -- Added projection for mRL
		FXUtility.DisplaySolid_Error(Building, "Reclamation Level is below required mRL.");
	end
end