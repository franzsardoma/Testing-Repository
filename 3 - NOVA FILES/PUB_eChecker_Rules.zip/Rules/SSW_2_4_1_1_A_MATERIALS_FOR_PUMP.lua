local Pump = FXGroup:new()
local pumpCondi

function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_2_4_1_1_A_MATERIALS_FOR_PUMP")
    local systemTypes = FXRule.ParseValues(parsedXml, "SystemType") 
   	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

    pumpCondi = tostring(Condition1[1])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if ( k == 2 ) then
				Pump = Pump + v
				Pump = Pump:Unique()
			end
		end
	end
end

function CheckRule(Building)

	local pumpArray = {}
	local pumpTable = FXGroup.new()
	local isCompliant = true

	if CheckWarning(Building) then

		if CheckPumpCount(Building) then

			Pump:ForEach(function(pumpEle)

				local Material = CheckObjMaterial(pumpEle,pumpCondi)

				if Material ~= nil then

					if Material then

						isCompliant = true
						pumpTable:Add(pumpEle)
					else
							
						isCompliant = false
						FXUtility.DisplaySolid_Error(pumpEle, pumpEle:GetAttri("Name").. ":Material:" ..pumpEle:GetAuxAttri("Materials and Finishes(Type).Material"))
						CheckReport.AddRelatedObj(pumpEle, pumpEle:GetAttri("Name"))
					end	
				else

					isCompliant = false
					FXUtility.DisplaySolid_Warning(pumpEle,"Material is not provided")
				end
			end)

			if isCompliant then

				table.insert(pumpArray,pumpTable)
			end	

			if isCompliant then

				for k=1, #pumpArray do

					pumpArray[k]:ForEach(function( paEle )

						FXUtility.DisplaySolid_Info(paEle, paEle:GetAttri("Name").. ":Material:" ..paEle:GetAuxAttri("Materials and Finishes(Type).Material"))
						CheckReport.AddRelatedObj(paEle, paEle:GetAttri("Name"))
					end)
				end
			end
		end
	end
end

function CheckWarning( Building )

	local Warning = true

	if ( #Pump == 0 ) then

		FXUtility.DisplaySolid_Warning(Building,"Pump is not provided")	
		Warning = false
	end

	return Warning
end

function CheckPumpCount( Building )

	local Count = true

	if ( #Pump == 1 ) then

		FXUtility.DisplaySolid_Warning(Building,"There is only one pump provided")	
		Count = false
	end

	return Count
end

function CheckObjMaterial(obj, material)
	
	if ( type(material) == "string" ) then

		local objMaterial
		local strTable = FXPUB.Split(material,",")
		local objFilter = obj:GetAuxAttri("Materials and Finishes.Material")
		local objFilter2 = obj:GetAuxAttri("Materials and Finishes(Type).Material")
		local objFilter3 = obj:GetAuxAttri("Material.Layer.0.material")

		if ( objFilter ~= nil ) then

			objMaterial = objFilter
		elseif ( objFilter2 ~= nil ) then

			objMaterial = objFilter2
		elseif ( objFilter3 ~= nil ) then

			objMaterial = objFilter3
		end

		for i = 1,#strTable,1 do
			if ( objMaterial ~= nil ) and ( FXUtility.HasPatterInString(objMaterial,strTable[i]) ) then
				return true, objMaterial
			else
				if ( objMaterial == nil ) then
					print("<> GetObjMaterial: material is nil")
				end
			end
		end

		return false, objMaterial
	end
end