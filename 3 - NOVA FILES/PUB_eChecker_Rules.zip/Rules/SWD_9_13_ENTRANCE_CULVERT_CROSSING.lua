local grpEntranceCulverts = FXGroup:new()
local grpGratings = FXGroup:new()
local grpCulverts = FXGroup:new()
local grpHingedGratings = FXGroup:new()
local operatorEntranceCulvert = "="
local DepthValueEntranceCulvert = 0
local operatorCulvert = "="
local DepthValueCulvert = 0
local ENTRANCECULVERT = {}
local CULVERT = {}

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_13_ENTRANCE_CULVERT_CROSSING")
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpEntranceCulverts = grpEntranceCulverts + v;
			grpEntranceCulverts = grpEntranceCulverts:Unique();
		end
		if (k == 3) then
			grpGratings = grpGratings + v;
			grpGratings = grpGratings:Unique();
		end
		if (k == 4) then
			grpCulverts = grpCulverts + v;
			grpCulverts = grpCulverts:Unique();
		end
		if (k == 5) then
			grpHingedGratings = grpHingedGratings + v;
			grpHingedGratings = grpHingedGratings:Unique();
		end
	end
	grpGratings = grpGratings - grpHingedGratings

	operatorEntranceCulvert = ConditionValues1[2]
	DepthValueEntranceCulvert = tonumber(ConditionValues1[3]);
	operatorCulvert = ConditionValues2[2]
	DepthValueCulvert = tonumber(ConditionValues2[3]);

	local tblValues = FXRule.filterTableValues(parsedXml, proj);

	local Values1 = {}
	local Values3 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
			if(k == 3) then
				table.insert(Values3, v1["value"])
			end
		end
	end

	ENTRANCECULVERT = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			ENTRANCECULVERT = ENTRANCECULVERT.." or "..v
		end
	end

	CULVERT = Values3[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			CULVERT = CULVERT.." or "..v
		end
	end

end

function CheckWarning( Building )
	local flag = true
	
	if(#grpCulverts == 0) then
		CheckReport.Warning( Building, CULVERT.." is not provided." )
		flag = false
	end

	if(#grpEntranceCulverts == 0) then
		CheckReport.Warning( Building, ENTRANCECULVERT.." is not provided." )
		flag = false
	end
	return flag;
end

function checkRule(Building)
	if CheckWarning( Building ) then
		local IsErrorNotFound = true
		local ARRComCulvert = {}
		local ARRgrpGratings = {}
		local ARRgrpEntrance = {}
		local ARRarrGrating = {}

		grpCulverts:ForEach(function ( Culvert )
			local depth = getDepth( Culvert )
			-- print(depth)
			if FXRule.EvaluateNumber( operatorCulvert , depth, DepthValueCulvert) then
				local flg, grpConnGratings = CheckHingedGrating( Culvert )
				if flg then
					table.insert(ARRComCulvert, Culvert)
					table.insert(ARRgrpGratings, grpConnGratings)
				else
					IsErrorNotFound = false
					FXUtility.DisplaySolid_Error(Culvert, Culvert:GetAttri("ObjectType").." is shallower than ".. DepthValueCulvert .." mm depth, Hinged Grating is not provided. ")
					CheckReport.AddRelatedObj(Culvert, Culvert:GetAttri("ObjectType"))
				end
			elseif FXRule.EvaluateNumber( operatorEntranceCulvert , depth, DepthValueEntranceCulvert) then
				local flg, grpConnEntranceCulvert, ARRGrating = CheckGrating( Culvert )
				if flg then
					table.insert(ARRgrpEntrance, grpConnEntranceCulvert)
					table.insert(ARRarrGrating, ARRGrating)
				else
					IsErrorNotFound = false
				end
			else
				FXUtility.DisplaySolid_Warning(Building, "Condition Values in Rule Parameters are Conflict")
			end
		end)

		if IsErrorNotFound then
			for k,Culvert in pairs(ARRComCulvert) do
				FXUtility.DisplaySolid_Info(Culvert, Culvert:GetAttri("ObjectType").." is shallower than ".. DepthValueCulvert .." mm depth, Hinged Grating is provided. ")
				CheckReport.AddRelatedObj(Culvert, Culvert:GetAttri("ObjectType"))
				ARRgrpGratings[k]:ForEach(function ( ConnGrating )
					CheckReport.AddRelatedObj(ConnGrating, ConnGrating:GetAttri("ObjectType"))
				end)
			end

			for k,grpConnEntranceCulvert in pairs(ARRgrpEntrance) do
				local arr = ARRarrGrating[k]
				local i = 1
				grpConnEntranceCulvert:ForEach(function ( ConnEntranceCulvert )
					FXUtility.DisplaySolid_Info(ConnEntranceCulvert, ConnEntranceCulvert:GetAttri("ObjectType").." is greater than ".. DepthValueEntranceCulvert .." mm depth, "..arr[i]:GetAttri("ObjectType").." is provided. ")
					CheckReport.AddRelatedObj(ConnEntranceCulvert, ConnEntranceCulvert:GetAttri("ObjectType"))
					CheckReport.AddRelatedObj(arr[i], arr[i]:GetAttri("ObjectType"))
					i = i + 1
				end)
			end
		end
	end
end

function CheckGrating( Culvert )
	local IsErrorNotFound = true
	local grpConnEntranceCulvert = FXGroup:new()
	local grpConnGrating = FXGroup:new()
	local ARRGrating = {}

	grpEntranceCulverts:ForEach(function ( EntranceCulvert )
		if(FXClashDetection.IsCollided(EntranceCulvert, Culvert))then
			grpConnEntranceCulvert:Add(EntranceCulvert)
		end
	end)

	grpConnEntranceCulvert:ForEach(function ( ConnEntranceCulvert )
		local flag = false
		grpGratings:ForEach(function ( Grating )
			if(FXClashDetection.IsCollided(Grating, ConnEntranceCulvert))then
				flag = true
				table.insert(ARRGrating, Grating)
			end
		end)
		if flag == false then
			IsErrorNotFound = false
			FXUtility.DisplaySolid_Error(ConnEntranceCulvert, ConnEntranceCulvert:GetAttri("ObjectType").." is greater than 600mm depth, Grating is not provided. ")
			CheckReport.AddRelatedObj(ConnEntranceCulvert, ConnEntranceCulvert:GetAttri("ObjectType"))
		end
	end)

	return IsErrorNotFound, grpConnEntranceCulvert, ARRGrating;
end

function CheckHingedGrating( Culvert )
	local flag = false
	local isthereGrating = false
	local grpNode = FXGroup:new()
	local BOX = FXGeom.GetBoundingBox(Culvert)
	local Node = FXUtility.CreateNodeFrom(BOX);
	local ARRprj = {}
	local grpObjs = FXGroup:new()
	
	grpHingedGratings:ForEach(function ( Grating )
		if(FXClashDetection.IsCollided(Grating, Node))then
			local BOXGrating = FXGeom.GetBoundingBox(Grating)
			local NodeGrating = FXUtility.CreateNodeFrom(BOXGrating);
			local prj = FXMeasure.GetObjProjection(NodeGrating, 0);
			table.insert(ARRprj, prj)
			FXClashDetection.DeleteNode(NodeGrating);
			isthereGrating = true
			grpObjs:Add(Grating)
		end
	end)
	FXClashDetection.DeleteNode(Node);

	if isthereGrating then
		local prjGratings =  FXUtility.MergeProjection(ARRprj, FXGeom.GetBoundingBox(Culvert):HighPos().z);
		local prjCulvert = FXMeasure.GetObjProjection(Culvert, 0);
		local lengthGratings = FXUtility.Round(GetLongestLine(FXMeasure.GetOuterEdge(prjGratings)):Length());
		local lengthCulvert = FXUtility.Round(GetLongestLine(FXMeasure.GetOuterEdge(prjCulvert)):Length());
		
		if ((lengthCulvert - lengthGratings) <= 20) == false then
			FXUtility.DisplaySolid_Warning( Culvert, Culvert:GetAttri("ObjectType").." is not totaly covered by Grating or Gratings",prjGratings )
			CheckReport.AddRelatedObj(Culvert, Culvert:GetAttri("ObjectType"))
		end
	end
	return isthereGrating, grpObjs;
end

function getDepth( Culvert )
	local depth = 0
	local BOX = FXGeom.GetBoundingBox(Culvert)
	local TopZ = BOX:HighPos().z
	local MidPnt = BOX:MidPos()
	local LowZ = BOX:LowPos().z
	local LowPnt = MidPnt;

	while tonumber(LowZ) < tonumber(LowPnt.z) do
		LowPnt = Point3D(LowPnt.x , LowPnt.y, LowPnt.z - 1);
		local depthLine = Line3D(MidPnt , LowPnt);
		local depthLineNode = FXUtility.CreateNodeFrom(depthLine);

		if(FXClashDetection.IsCollided(depthLineNode, Culvert))then
			FXClashDetection.DeleteNode(depthLineNode);
			break;
		end
		FXClashDetection.DeleteNode(depthLineNode);
	end
	depth = TopZ - LowPnt.z

	return tonumber(depth);
end

function GetLongestLine( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end