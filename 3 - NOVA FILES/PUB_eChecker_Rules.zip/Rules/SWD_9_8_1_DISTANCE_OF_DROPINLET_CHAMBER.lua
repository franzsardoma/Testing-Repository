local dropInletGrp = FXGroup:new();
local slabGrp = FXGroup:new();
local slabSidewalk = FXGroup:new();
local slabRoadway = FXGroup:new();
local maximumDistance = 6000;
local maximumDistance2 = 3000;
local standard = FXGroup:new()
local enhance = FXGroup:new()
local siteAny = FXGroup:new()
local siteProne = FXGroup:new()
local isCompliant = true;
local arrObj1 = {}
local arrObj2 = {}
local arrObj3 = {}
local arrObj4 = {}
local arrObj5 = {}

function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("BuildingStorey");
	-- CheckEngine.BindCheckFunc("CheckRuleGrp");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end
function XMLParser(Storey)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_8_1_DISTANCE_OF_DROPINLET_CHAMBER")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystems = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	-- minHeight = ConditionValues[2];
	if GrpObjSystems ~= nil then
		for k,v in pairs(GrpObjSystems) do
			if (k == 2) then
				standard = standard + v
				standard = standard:Unique()
			end
			if (k == 3) then
				enhance = enhance + v
				enhance = enhance:Unique()
			end
			if (k == 4) then
				slabGrp = slabGrp + v
				slabGrp = slabGrp:Unique()
			end
			if (k == 5) then
				siteAny = siteAny + v
				siteAny = siteAny:Unique()
			end
			if (k == 6) then
				siteProne = siteProne + v
				siteProne = siteProne:Unique()
			end
		end
	else
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				standard = standard + v
				standard = standard:Unique()
			end
			if (k == 3) then
				enhance = enhance + v
				enhance = enhance:Unique()
			end
			if (k == 4) then
				slabGrp = slabGrp + v
				slabGrp = slabGrp:Unique()
			end
			if (k == 5) then
				siteAny = siteAny + v
				siteAny = siteAny:Unique()
			end
			if (k == 6) then
				siteProne = siteProne + v
				siteProne = siteProne:Unique()
			end
		end
	end
end

function CheckRule(Building)
	local i = 0
	local check = true
	local project = Building:GetParent():GetParent()
	local Site = project:GetChildren("Site")
	local SiteLocation;
	Site:ForEach(function(site)
		SiteLocation = site:GetAuxAttri("Other.Project Development Type")
	end)

	if SiteLocation == nil then
		check = false
	end

	if #standard == 0 and #enhance == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Drop-Inlet Chamber is not provided.")
	elseif check == false then
		FXUtility.DisplaySolid_Warning(Building,"Site Location is not provided.")
	else
		dropInletGrp = standard + enhance;
		local slabs = Building:GetDescendants("Slab")
		local SidewalkGrp = FXGroup:new();

		----------------------------------------------------
		local newGrp = FXGroup:new();
		local i = 0;
		if SiteLocation == "Flood Prone Area" then
			slabGrp:ForEach(function(slab)
				local proj = FXMeasure.GetObjProjection(slab,0.0);
				local outer = FXMeasure.GetOuterEdge(proj);
				local face = outer:Face3D();
				local points = outer:GetPointNumber();
				local Line = GetLongestLine(outer);
				local pnt1 = Line:GetStartPoint();
				local nearest;
				local ele;
				local cntP
				local dist
				local arrow
				local near
				local grpSub = FXGroup:new()
				local name = slab:GetAttri("Name")
				if FXUtility.HasPatterInString(name,"Curve Road Carriageway") then

					dropInletGrp:ForEach(function(inlet)
						if FXUtility.HasPatterInString(inlet:GetAttri("Name"),"Enhance") then
							nearest, ele = NearestInlet( inlet,slab,grpSub,pnt1,nearest,ele);
						end
					end)
					while #grpSub ~= 0 do
						arrow, grpSub, ele, near, dist, cntP = getDArrow( grpSub, ele, cntP )
						
						if #grpSub ~= 1 then
							local rounded = FXUtility.Round(near,0);
							local isOkay = FXPUB.GetTolerance(maximumDistance2, rounded);
							if arrow ~= nil then
								local dist2 = Line3D(dist:GetStartPoint(), cntP)
								local dist3 = Line3D(dist:GetEndPoint(), cntP)
								if rounded > maximumDistance2 then
									if isOkay == false then
										isCompliant = false;
										FXUtility.DisplaySolid_Error(slab,slab:GetAttri("Name").." on "..SiteLocation);
										CheckReport.AddRelatedObj(ele,ele:GetAttri("Name")..": Spacing is = "..rounded.." mm");
										CheckReport.AddRelatedGeometry_Error(dist);
										CheckReport.AddRelatedGeometry_Error(dist2);
										CheckReport.AddRelatedGeometry_Error(dist3);
									else
										i = i + 1
										arrObj1[i] = slab
										arrObj2[i] = ele
										arrObj3[i] = dist
										arrObj4[i] = rounded
										arrObj5[i] = cntP
									end
								else
									i = i + 1
									arrObj1[i] = slab
									arrObj2[i] = ele
									arrObj3[i] = dist
									arrObj4[i] = rounded
									arrObj5[i] = cntP
								end
							end
						else -- if inlet chamber is 2 left
							if dist ~= nil then
								local radius = Line3D(dist:GetStartPoint(), cntP)
								local arc = FXMeasure.GetArcLength(radius:Length(), dist:Length())
								local arrow = DoubleArrow(dist:GetStartPoint(), dist:GetEndPoint())
								local dist2 = Line3D(dist:GetStartPoint(), cntP)
								local dist3 = Line3D(dist:GetEndPoint(), cntP)
								local rounded = FXUtility.Round(arc,0);
								local isOkay = FXPUB.GetTolerance(maximumDistance2, rounded);
								if arrow ~= nil then
									if rounded > maximumDistance2 then
										isCompliant = false;
										if isOkay == false then
											FXUtility.DisplaySolid_Error(slab,slab:GetAttri("Name").." on "..SiteLocation);
											CheckReport.AddRelatedObj(ele,ele:GetAttri("Name")..": Spacing is = "..rounded.." mm");
											CheckReport.AddRelatedGeometry_Error(dist);
											CheckReport.AddRelatedGeometry_Error(dist2);
											CheckReport.AddRelatedGeometry_Error(dist3);
										else
											i = i + 1
											arrObj1[i] = slab
											arrObj2[i] = ele
											arrObj3[i] = dist
											arrObj4[i] = rounded
											arrObj5[i] = cntP
										end
									else
										i = i + 1
										arrObj1[i] = slab
										arrObj2[i] = ele
										arrObj3[i] = dist
										arrObj4[i] = rounded
										arrObj5[i] = cntP
									end
								end
							end
						end
					end
				else -- For Straight RoadCarriageway

					dropInletGrp:ForEach(function(inlet)
						nearest, ele = NearestInlet( inlet,slab,grpSub,pnt1,nearest,ele);
					end)

					while #grpSub ~= 0 do
						local arrow
						arrow, grpSub, ele, near, dist, cntP = getDArrow( grpSub, ele, cntP)
						local rounded = FXUtility.Round(near,0);
						if arrow ~= nil then
							if rounded > maximumDistance then
								FXUtility.DisplaySolid_Error(slab,slab:GetAttri("Name").." on "..SiteLocation);
								CheckReport.AddRelatedObj(ele,ele:GetAttri("Name")..": Spacing is = "..rounded.." mm");
								CheckReport.AddRelatedGeometry_Error(arrow);
							else
								i = i + 1
								arrObj1[i] = slab
								arrObj2[i] = ele
								arrObj3[i] = arrow
								arrObj4[i] = rounded
							end
						end
					end
				end
			end)
		else
			slabGrp:ForEach(function(slab)
				local proj = FXMeasure.GetObjProjection(slab,0.0);
				local outer = FXMeasure.GetOuterEdge(proj);
				local face = outer:Face3D();
				local points = outer:GetPointNumber();
				local Line = GetLongestLine(outer);
				local pnt1 = Line:GetStartPoint();
				local nearest;
				local ele;
				local dist
				local arrow
				local near
				local cntP
				local grpSub = FXGroup:new()
				local name = slab:GetAttri("Name")
				if FXUtility.HasPatterInString(name,"Curve Road Carriageway") then
					
					dropInletGrp:ForEach(function(inlet)
						nearest, ele = NearestInlet( inlet,slab,grpSub,pnt1,nearest,ele);
					end)
					while #grpSub ~= 0 do
						arrow, grpSub, ele, near, dist, cntP = getDArrow( grpSub, ele, cntP )
						
						if #grpSub ~= 1 then
							local rounded = FXUtility.Round(near,0);
							local isOkay = FXPUB.GetTolerance(maximumDistance2, rounded);
							if dist ~= nil then
								local arrow = DoubleArrow(dist:GetStartPoint(), dist:GetEndPoint())
								local dist2 = Line3D(dist:GetStartPoint(), cntP)
								local dist3 = Line3D(dist:GetEndPoint(), cntP)
								if rounded > maximumDistance2 then
									if isOkay == false then
										isCompliant = false;
										FXUtility.DisplaySolid_Error(slab,slab:GetAttri("Name").." on "..SiteLocation);
										CheckReport.AddRelatedObj(ele,ele:GetAttri("Name")..": Spacing is = "..rounded.." mm");
										CheckReport.AddRelatedGeometry_Error(dist);
										CheckReport.AddRelatedGeometry_Error(dist2);
										CheckReport.AddRelatedGeometry_Error(dist3);
									else
										i = i + 1
										arrObj1[i] = slab
										arrObj2[i] = ele
										arrObj3[i] = dist
										arrObj4[i] = rounded
										arrObj5[i] = cntP
									end
								else
									i = i + 1
									arrObj1[i] = slab
									arrObj2[i] = ele
									arrObj3[i] = dist
									arrObj4[i] = rounded
									arrObj5[i] = cntP
								end
							end
						else -- if inlet chamber is 2 left
							if dist ~= nil then
								local radius = Line3D(dist:GetStartPoint(), cntP)
								local arc = FXMeasure.GetArcLength(radius:Length(), dist:Length())
								local arrow = DoubleArrow(dist:GetStartPoint(), dist:GetEndPoint())
								local dist2 = Line3D(dist:GetStartPoint(), cntP)
								local dist3 = Line3D(dist:GetEndPoint(), cntP)
								local rounded = FXUtility.Round(arc,0);
								local isOkay = FXPUB.GetTolerance(maximumDistance2, rounded);
								if arrow ~= nil then
									if rounded > maximumDistance2 then
										isCompliant = false;
										if isOkay == false then
											FXUtility.DisplaySolid_Error(slab,slab:GetAttri("Name").." on "..SiteLocation);
											CheckReport.AddRelatedObj(ele,ele:GetAttri("Name")..": Spacing is = "..rounded.." mm");
											CheckReport.AddRelatedGeometry_Error(dist);
											CheckReport.AddRelatedGeometry_Error(dist2);
											CheckReport.AddRelatedGeometry_Error(dist3);
										else
											i = i + 1
											arrObj1[i] = slab
											arrObj2[i] = ele
											arrObj3[i] = dist
											arrObj4[i] = rounded
											arrObj5[i] = cntP
										end
									else
										i = i + 1
										arrObj1[i] = slab
										arrObj2[i] = ele
										arrObj3[i] = dist
										arrObj4[i] = rounded
										arrObj5[i] = cntP
									end
								end
							end
						end
					end
				else -- For Straight RoadCarriageway
					dropInletGrp:ForEach(function(inlet)
						nearest, ele = NearestInlet( inlet,slab,grpSub,pnt1,nearest,ele);
					end)

					while #grpSub ~= 0 do
						local arrow
						arrow, grpSub, ele, near, dist, cntP = getDArrow( grpSub, ele, cntP)
						local rounded = FXUtility.Round(near,0);
						if arrow ~= nil then
							if rounded > maximumDistance then
								isCompliant = false;
								FXUtility.DisplaySolid_Error(slab,slab:GetAttri("Name").." on "..SiteLocation);
								CheckReport.AddRelatedObj(ele,ele:GetAttri("Name")..": Spacing is = "..rounded.." mm");
								CheckReport.AddRelatedGeometry_Error(arrow);
							else
								i = i + 1
								arrObj1[i] = slab
								arrObj2[i] = ele
								arrObj3[i] = arrow
								arrObj4[i] = rounded
							end
						end
					end
				end
			end)
		end

		if isCompliant then
			for k,slab in pairs(arrObj1) do
				if arrObj5[k] ~= nil then
					local dist2 = Line3D(arrObj3[k]:GetStartPoint(), arrObj5[k])
					local dist3 = Line3D(arrObj3[k]:GetEndPoint(), arrObj5[k])
					FXUtility.DisplaySolid_Info(slab,slab:GetAttri("Name").." on "..SiteLocation);
					CheckReport.AddRelatedObj(arrObj2[k],arrObj2[k]:GetAttri("Name")..": Spacing is = "..arrObj4[k].." mm");
					CheckReport.AddRelatedGeometry_Solid(arrObj3[k]);
					CheckReport.AddRelatedGeometry_Solid(dist2);
					CheckReport.AddRelatedGeometry_Solid(dist3);
				else -- For Straight RoadCarriageway
					FXUtility.DisplaySolid_Info(slab,slab:GetAttri("Name").." on "..SiteLocation);
					CheckReport.AddRelatedObj(arrObj2[k],arrObj2[k]:GetAttri("Name")..": Spacing is = "..arrObj4[k].." mm");
					CheckReport.AddRelatedGeometry_Solid(arrObj3[k]);
				end
			end
		end
	end
end
function GetLongestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetPoint( outerEdge, pnt )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-1) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		local cntPnt = FXUtility.CenterPoint(Line:GetStartPoint(), Line:GetEndPoint())

		local nearLine = Line3D(pnt, cntPnt)

		if( dist == nil or dist:Length() > nearLine:Length() ) then
			dist = nearLine;
		end
	end

	return dist:GetEndPoint();
end

function getDArrow( grpSub, ele, cntP )
	local arrow
	local Object
	local nearest = 0
	local near = 0
	local gDistance1
	local gDistance2
	local dist
	local boxChmber = FXGeom.GetBoundingBox(ele);
	local cntPnt1 = boxChmber:MidPos();

	local topFace = FXMeasure.GetTopFace(ele)
	local outerEdge = FXMeasure.GetOuterEdge(topFace)
	local cntPnt = GetPoint(outerEdge,cntPnt1)

	grpSub:Sub(ele)

	grpSub:ForEach(function ( Subele )
		local boxChmber = FXGeom.GetBoundingBox(Subele);
		local cntPnt2 = boxChmber:MidPos();

		local topFace = FXMeasure.GetTopFace(Subele)
		local outerEdge = FXMeasure.GetOuterEdge(topFace)
		local midPnt = GetPoint(outerEdge,cntPnt2)

		local Point1 = Point3D(cntPnt.x,cntPnt.y,cntPnt.z)
		local Point2 = Point3D(midPnt.x,midPnt.y,midPnt.z)
		local lDistance = Line3D(Point1,Point2)

		 if nearest == 0 or nearest > tonumber(lDistance:Length()) then
		 	nearest = tonumber(lDistance:Length())
		 	 if cntPnt1.y == cntPnt2.y or cntPnt1.x == cntPnt2.x then
		 	 	local Point1 = Point3D(cntPnt1.x,cntPnt1.y,cntPnt1.z+500)
				local Point2 = Point3D(cntPnt2.x,cntPnt2.y,cntPnt2.z+500)
				local lDistance = Line3D(Point1,Point2)
		 	 	arrow = DoubleArrow(lDistance:GetStartPoint(), lDistance:GetEndPoint())
				Object = Subele
				nearest = tonumber(lDistance:Length())
				return arrow, grpSub, Object, nearest, dist, cntP;
		 	 else
		 	 	if #grpSub ~= 1 then
		 	 		gDistance1 = lDistance
					Object = Subele
				else
					dist = lDistance
					Object = Subele
					return arrow, grpSub, Object, nearest, dist, cntP;
				end
			end
		 end
	end)

	if gDistance1 ~= nil then
		local near = 0
		grpSub:ForEach(function ( Subele )
			local boxChmber = FXGeom.GetBoundingBox(Subele);
			local cntPnt1 = boxChmber:MidPos();

			local topFace = FXMeasure.GetTopFace(Subele)
			local outerEdge = FXMeasure.GetOuterEdge(topFace)
			local midPnt = GetPoint(outerEdge,cntPnt1)
			
			local Point3 = Point3D(midPnt.x,midPnt.y,midPnt.z)
			local lDistance = Line3D(gDistance1:GetEndPoint(), Point3)

			if lDistance:GetStartPoint() ~= lDistance:GetEndPoint() then
				if gDistance1:GetStartPoint() ~= lDistance:GetStartPoint() then
					if near == 0 or near > tonumber(lDistance:Length()) then
				 		near = tonumber(lDistance:Length())
						if cntPnt.y ~= midPnt.y or cntPnt.x ~= midPnt.x  then
							gDistance2 = lDistance
						end
					end
				end
			end
		end)

		if gDistance2 ~= nil then
			if cntP == nil then
				cntP = FXMeasure.GetPolygonCenterFromThreePoints(gDistance1:GetStartPoint(), gDistance1:GetEndPoint(), gDistance2:GetEndPoint())
			end
			local radius = Line3D(gDistance1:GetStartPoint(), cntP)
			nearest = FXMeasure.GetArcLength(radius:Length(), gDistance1:Length())
			arrow = DoubleArrow(gDistance1:GetStartPoint(), gDistance1:GetEndPoint())
			dist = gDistance1
		end
	end
	return arrow, grpSub, Object, nearest, dist, cntP;
end

function NearestInlet( inlet,Element1,grpSub,pnt1,nearest,ele )
	if FXClashDetection.IsCollided(Element1,inlet) then
		grpSub:Add(inlet)
		local obb = FXGeom.GetBoundingOBB(inlet)
		local pnt2 = obb:GetPos();
		local dist = pnt1:Distance_Pnt(pnt2);
		if nearest == nil then
			nearest = dist;
			ele = inlet;
		else
			if nearest > dist then
				nearest = dist;
				ele = inlet;
			end
		end
	end
	return nearest,ele;
end