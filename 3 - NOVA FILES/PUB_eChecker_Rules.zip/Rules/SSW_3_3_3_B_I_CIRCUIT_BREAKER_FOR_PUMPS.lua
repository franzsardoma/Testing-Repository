--[[
	Title: SSW 3.3.3 (b) (i) - LUA Code
	Created by: Wilcelle Tapagñan (DEV/LUA)
	Date: 01/22/2019
	Sprint: Sprint 4.2
	Modified by: insert your name here (in the future purpose)
]]--
local Pump = FXGroup:new()
local circuitB
local fusedS
local cBreak
local fSwitch
local systemTypes

function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_3_B_I_CIRCUIT_BREAKER_FOR_PUMPS")
    systemTypes = FXRule.ParseValues(parsedXml, "SystemType")
   	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")
    local Condition2 = FXRule.ParseValues(parsedXml, "Condition2")

    cBreak = tostring(Condition1[1])
    fSwitch = tostring(Condition2[1])
	circuitB = tostring(Condition1[2])
	fusedS = tostring(Condition2[2])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do --the RI's Element Type 1 Operator is N.A. (Unable to parse the value from Element Type 1 on the html)
			if ( k == 2 ) then
				Pump = Pump + v
				Pump = Pump:Unique()
			end
		end
	end
end

function CheckRule(Building)

	local Pump2 = Building:GetDescendants("FlowMovingDevice")
	local isCompliant = true
	local pumpArr = {}
	local pumpGrp = FXGroup.new()

	if CheckWarning(Pump2,Building) then

		Pump2:ForEach(function(pumpEle)

			local cirBreak = pumpEle:GetAuxAttri("Mechanical.Circuit Breaker")
			local fusSwitch = pumpEle:GetAuxAttri("Mechanical.Fused Switch")
			local pumpName = pumpEle:GetAttri("Name")
			local falseVal = " false"

			if ( cirBreak and fusSwitch ) ~= nil then

				if ( (FXUtility.HasPatterInString(cirBreak,circuitB)) or (FXUtility.HasPatterInString(fusSwitch,fusedS)) ) == true then
					
					isCompliant = true
					pumpGrp:Add(pumpEle)
				else

					isCompliant = false
							
					if (FXUtility.HasPatterInString(pumpName,"Duty Pump")) then -----Duty

						if ( (FXUtility.HasPatterInString(fusSwitch,falseVal)) ) == false then

							FXUtility.DisplaySolid_Error(pumpEle,pumpEle:GetAttri("ObjectType")..": Fused Switch is not provided")
						elseif ( (FXUtility.HasPatterInString(cirBreak,falseVal)) ) == false then
									
							FXUtility.DisplaySolid_Error(pumpEle,pumpEle:GetAttri("ObjectType")..": Circuit Breaker is not provided")
						end
					elseif (FXUtility.HasPatterInString(pumpName,"Standby Pump")) then ----Standby

						if ( (FXUtility.HasPatterInString(cirBreak,falseVal)) ) == false then

							FXUtility.DisplaySolid_Error(pumpEle,pumpEle:GetAttri("ObjectType")..": Circuit Breaker is not provided")
						elseif ( (FXUtility.HasPatterInString(fusSwitch,falseVal)) ) == false then
									
							FXUtility.DisplaySolid_Error(pumpEle,pumpEle:GetAttri("ObjectType")..": Fused Switch is not provided")
						end
					end
				end
			else

				FXUtility.DisplaySolid_Warning(pumpEle,pumpEle:GetAttri("ObjectType")..": Fused Switch or Circuit Breaker is not provided")
			end
		end)

		if isCompliant then

			table.insert(pumpArr,pumpGrp)
		end

		if isCompliant then

			for k=1, #pumpArr do

				pumpArr[k]:ForEach(function(pumpEle)
					
						local cirBreak2 = pumpEle:GetAuxAttri("Mechanical.Circuit Breaker")
						local fusSwitch2 = pumpEle:GetAuxAttri("Mechanical.Fused Switch")
						local pumpName2 = pumpEle:GetAttri("Name")

					if (FXUtility.HasPatterInString(pumpName2,"Duty Pump")) then -----Duty

						if ( (FXUtility.HasPatterInString(fusSwitch2,fusedS)) ) == true then

							FXUtility.DisplaySolid_Info(pumpEle,pumpEle:GetAttri("ObjectType")..": Fused Switch is provided")
						elseif ( (FXUtility.HasPatterInString(cirBreak2,circuitB)) ) == true then
										
							FXUtility.DisplaySolid_Info(pumpEle,pumpEle:GetAttri("ObjectType")..": Circuit Breaker is provided")
						end
					elseif (FXUtility.HasPatterInString(pumpName2,"Standby Pump")) then ----Standby

						if ( (FXUtility.HasPatterInString(cirBreak2,circuitB)) ) == true then

							FXUtility.DisplaySolid_Info(pumpEle,pumpEle:GetAttri("ObjectType")..": Circuit Breaker is provided")
						elseif ( (FXUtility.HasPatterInString(fusSwitch2,fusedS)) ) == true then
										
							FXUtility.DisplaySolid_Info(pumpEle,pumpEle:GetAttri("ObjectType")..": Fused Switch is provided")
						end
					end
				end)
			end
		end
	end
end

function CheckWarning(Pump2,Building)

	local noWarning = true

	if (#Pump2 == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Pump is not provided")	
		noWarning = false
	end

	return noWarning
end