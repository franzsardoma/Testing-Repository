-- Author:Mohammad Derick Pauig
local grpRamp = FXGroup.new()
local grpCutDrain = FXGroup.new()
local grpSurfDrain = FXGroup.new()
local grppipe = FXGroup.new()



function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_4_10_1_B_III_CUT_OFF_DRAINS_ON_RAMPS")

	 local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	-- local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 3 then
			grpCutDrain = grpCutDrain + v
			grpCutDrain = grpCutDrain:Unique()			
		end
		if k == 4 then
			grpSurfDrain = grpSurfDrain + v
			grpSurfDrain = grpSurfDrain:Unique()			
		end	
		if k == 5 then
			grppipe = grppipe + v
			grppipe = grppipe:Unique()			
		end			
	end
end

function checkRule(Building)
	local grpStoreyCheck = FXGroup.new()
	-- local grpDCE = Building:GetDescendants("DistributionChamberElement")
	local grpStorey = Building:GetDescendants("BuildingStorey")
	grpStorey:ForEach(function (BuildingStorey)
		local name1 = BuildingStorey:GetAttri("Name")
		if FXUtility.HasPatterInString(name1,"Basement") or FXUtility.HasPatterInString(name1,"Tunnel") or FXUtility.HasPatterInString(name1,"Underground") then
			grpRamp = grpRamp + BuildingStorey:GetDescendants("Ramp")
			grpStoreyCheck:Add(BuildingStorey)
		end
	end)
	
	
	-- grpDCE:ForEach(function (dce)
	-- 	local name = dce:GetAttri("Name")
	-- 	if FXUtility.HasPatterInString(name,"Cut") then
	-- 		grpCutDrain:Add(dce)
	-- 	end
	-- 	if FXUtility.HasPatterInString(name,"Surface") then
	-- 		grpSurfDrain:Add(dce)
	-- 	end
	-- end)
	print(#grpCutDrain .."cut")
	print(#grpSurfDrain .."surf")
	print(#grppipe .."pipe")
	if #grpStoreyCheck ~= 0 then
		if #grpRamp ~= 0 then
			grpRamp:ForEach(function (ramp)
				local cutCol = FXGroup.new()
				local cutLow
				local cutHigh
				local pointer
				local flag = false
				
				grpCutDrain:ForEach(function (cut)
					if FXClashDetection.IsCollided(ramp,cut) then
						cutCol:Add(cut)
					end
				end)

				if #cutCol == 2 then
					cutCol:ForEach(function(cutEle)
						if pointer == nil then
							pointer = cutEle
						else

							local pointerObb = FXGeom. GetBoundingOBB(pointer)
							local cutEleObb = FXGeom. GetBoundingOBB(cutEle)

							local point = pointerObb:GetPos()
							local pointCut = cutEleObb:GetPos()
							if point.z > pointCut.z then
								cutHigh = pointer
								cutLow = cutEle
							else
								cutHigh = cutEle
								cutLow = pointer
							end
						end
					end)
				elseif #cutCol == 1 then
					cutCol:ForEach(function(cutEle)
						local rampObb = FXGeom. GetBoundingOBB(ramp)
						print("H")
						local cutEleObb = FXGeom. GetBoundingOBB(cutEle)
						local rampPoint = rampObb:GetPos()
						local pointCut = cutEleObb:GetPos()
						if rampPoint.z < pointCut.z then
							FXUtility.DisplaySolid_Error(ramp,"Cut-Off Drain is not provided at Base Offset of "..ramp:GetAttri("Name")..".")
							return false
						else
							FXUtility.DisplaySolid_Error(ramp,"Cut-Off Drain is not provided at Top Offset of "..ramp:GetAttri("Name")..".")
							
						end
					end)
					return false
				elseif #cutCol == 0 then
					FXUtility.DisplaySolid_Error(ramp,"Cut-Off Drain is not provided at Base Offset and Top Offset of "..ramp:GetAttri("Name")..".")
					return false
				end
				
				if FXPUB.IsObjsConnected(cutLow,cutHigh,10) == false then
					local count = 0
					grpSurfDrain:ForEach(function (sur)
						if FXClashDetection.IsCollided(cutHigh,sur) then
							count= count + 1
						end
					end)

					if count > 0 then
						flag= true
					else
						FXUtility.DisplaySolid_Error(ramp,cutHigh:GetAttri("Name").." is not connected to Surface Water Drain")
					end	

				 	
					-- local conpipe = FXPUB.GetConnectedObj( cutLow, "FlowSegment", "Name", "Pipe", 50)
					-- print("je")
					if #grppipe ~= 0 then
						grppipe:ForEach(function (pipe)
							local name2 = pipe:GetAuxAttri("Entity.Description")
							-- print(name2)
							if FXUtility.HasPatterInString(name2,"Drain Pipe") then
								if FXClashDetection.IsCollided(cutLow,pipe) then
									flag = true
								else
							 		FXUtility.DisplaySolid_Error(ramp,cutLow:GetAttri("Name").." is not connected to Drainage System")
								end
							end
						end)
					else
						FXUtility.DisplaySolid_Error(ramp,cutLow:GetAttri("Name").." is not connected to Drainage System")
					end

					if flag == true then
						FXUtility.DisplaySolid_Info(ramp,"Cut-off Drain found and connected to designated drainage system.")
						return false
					end
				else
					FXUtility.DisplaySolid_Error(ramp,"Link connection found between upper "..cutHigh:GetAttri("Name").." and lower "..cutLow:GetAttri("Name")..".")
					return false
				end
			end)
		else
			grpStoreyCheck:ForEach(function (BuildingStorey)
				FXUtility.DisplaySolid_Warning(BuildingStorey,"Ramp is not Provided in "..BuildingStorey:GetAttri("Name"))
				return false
			end)
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Basement or Tunnel or Underground level is not provided.")
	end
end


function ChamberToChamberIsConnected(Chamber1,Chamber2,Cnt)
	local cha1Container = Chamber1:GetParent()
	local cha2Container = Chamber2:GetParent()
	local grpPipe = cha1Container:GetDescendants("FlowSegment")
	local grpFitting = cha1Container:GetDescendants("FlowFitting")
	
	grpPipe = grpPipe + cha2Container:GetDescendants("FlowSegment")
	grpFitting = grpFitting + cha2Container:GetDescendants("FlowFitting")

	grpPipe = grpPipe:Unique()
	grpFitting = grpFitting:Unique()
	
	local grpCollided1 = FXGroup.new()
	local grpCollided2 = FXGroup.new()
	local isConnected = false

	grpPipe:ForEach(function (pipe)
		if FXClashDetection.IsCollided(Chamber1,pipe) then
			grpCollided1:Add(pipe)
		end
		if FXClashDetection.IsCollided(Chamber2,pipe) then
			grpCollided2:Add(pipe)
		end
	end)

	grpFitting:ForEach(function (fitting)
		if FXClashDetection.IsCollided(Chamber1,fitting) then
			grpCollided1:Add(fitting)
		end
		if FXClashDetection.IsCollided(Chamber2,fitting) then
			grpCollided2:Add(fitting)
		end
	end)

	grpCollided1:ForEach(function (col1)
		grpCollided2:ForEach(function (col2)
			if FXPUB.IsTwoObjsConnected(col1,col2,Cnt) == true then
				isConnected = true
			end
		end)
	end)
	return isConnected
end