local minDepth
local operator
local externalPipe = FXGroup.new()
local expipeObj
local expipeProp 
local ObjProperty
local ObjValue
local xpipePropTbl = {}
local xpipeValTbl = {}
local xpipeTypTbl = {}

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_4_4_UNDERGROUND_LAYOUT_PIPE")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building)
	local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	operator = Condition1[2]
	minDepth = tonumber(Condition1[3])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do --Starting with 0 when counting index
			if (k == 2) then
				externalPipe = externalPipe + v
				externalPipe = externalPipe:Unique()
			end	

			for k,v in pairs(tblValues) do --doesn't start with 0 when counting index
				for k1,v1 in pairs(v) do
					if (k == 1) then
						ObjType =  v1["type"]
						ObjProperty = v1["property"]
						ObjValue = v1["value"]
						table.insert(xpipeTypTbl, ObjType)						
						table.insert(xpipePropTbl, ObjProperty)
						table.insert(xpipeValTbl, ObjValue)
					end
				end
			end
		end
	end
end

function checkRule(Building)

	local storey = Building:GetDescendants("BuildingStorey")
	local site = Building:GetParent()
	local slabGrp = FXGroup.new() 
	local xpipeGrp = FXGroup.new()
	local slabGrp2 = FXGroup.new()
	local expipeArr = {}
	local isCompliant = true
	local expipeTable
	local Distance
	local arrowGeom	
	local pntTerminal
	local distance = 0
	local pipeProj

	storey:ForEach(function(storeyEle)

		if FXUtility.IsFirstStorey(storeyEle) then

			local firstStoreyElevation = storeyEle:Elevation()

			externalPipe:ForEach(function( expipe )

				if ( FXUtility.HasPatterInString(expipe.Type,xpipeTypTbl[1]) ) then
						xpipeGrp:Add(expipe)
				end
				if ( FXUtility.HasPatterInString(expipe.Type,xpipeTypTbl[2]) ) then
						slabGrp:Add(expipe)
				end
			end)
						
			slabGrp:ForEach(function(slab)

				local slabObj = slab:GetAttri("ObjectType")

				if ( FXUtility.HasPatterInString(slabObj, "Concrete") == true ) then
					slabGrp2:Add(slab)
				end
			end)

			if CheckWarning(xpipeGrp,Building) then
				if CheckWarningSlab(slabGrp2,Building) then
				
					xpipeGrp:ForEach(function(pipeEle)
						local pipeBox = FXGeom.GetBoundingOBB(pipeEle)
						local maxPntZValue = pipeBox:MaxPnt().z
						local slabPos
						local slabLow
	 					local pipeLow = FXGeom.GetBoundingBox(pipeEle):LowPos().z
	 					local slabPipedis = slabPos - pipeLow

						if maxPntZValue < firstStoreyElevation then

							slabGrp2:ForEach(function(slabEle)

	 							slabPos = FXGeom.GetBoundingBox(slabEle):HighPos().z

							end)

							local slabProj = FXMeasure.GetProjection(slabGrp2,slabPos)
	 						local slabOuter = FXMeasure.GetOuterEdge(slabProj)
	 						local slabFace = slabOuter:Face3D()
 							local slabExtrude = slabFace:ExtrudedFace(Vector(0, 0, -slabPipedis)) 							
	 						local slabNode = FXUtility.CreateNodeFrom(slabExtrude)

	 						if FXClashDetection.IsCollided(slabNode,pipeEle) then

								local distLine = FXMeasure.Distance(pipeEle, site)
								Distance = FXUtility.Round(distLine:Length(), 2)
								arrowGeom =  DoubleArrow(distLine:GetStartPoint(), distLine:GetEndPoint())

								if ( FXRule.EvaluateNumber(operator, Distance, minDepth) ) == true then

									isCompliant = true
									expipeTable = pipeEle
								else

									isCompliant = false
									CheckResult(storeyEle, isCompliant, pipeEle, Distance, arrowGeom)
								end
	 						end

	 						FXClashDetection.DeleteNode(slabNode)
						end
					end)

					if isCompliant then

						table.insert(expipeArr,expipeTable)
					end

					if isCompliant then

						for k=1, #expipeArr do
									
							FXUtility.DisplaySolid_Info(storeyEle, "Distance of top of "..expipeArr[k]:GetAttri("ObjectType").." to ground level is " ..Distance.. " which is greater than or equal to 500mm")		
							CheckReport.AddRelatedGeometry_Solid(arrowGeom, "Arrow3D")
						end	
					end
				end
			end
		end
	end)
end

function CheckWarning(xpipeGrp,Building)

	local Warning = true

	if ( #xpipeGrp == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"External Pipe is not provided")	
		Warning = false
	end

	return Warning
end

function CheckWarningSlab(slabGrp2,Building)

	local Warning = true

	if ( #slabGrp2 == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"Outside Slab is not provided")	
		Warning = false
	end

	return Warning
end

function CheckResult(storeyEle, isCompliant, pipeEle, Distance, arrowGeom)

	if isCompliant == false then
	
		FXUtility.DisplaySolid_Error(storeyEle, "Distance of top of "..pipeEle:GetAttri("ObjectType").." to ground level is " ..Distance.. " which is below 500mm")
		CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")

	end
end

