local pipeSegmentGrp = FXGroup.new()
function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end
function XMLParser(Building)
	
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_9_A_SEWER_AND_FLEXIBLE_JOINTS")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	-- isRemovable = ConditionValues[1]; -- for Condition Values 

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)		
	for k,v in pairs(GrpObjs1) do
		if (k == 2) then
			pipeSegmentGrp =   pipeSegmentGrp + v;
			pipeSegmentGrp = pipeSegmentGrp:Unique()
		end	
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 2) then
				ObjProp = v1["property"]
				ObjValue = v1["value"]
			end
		end
		for k1,v1 in pairs(v) do
			if (k == 1) then
				ObjProp1 = v1["property"]
				ObjValue1 = v1["value"]
				ObjType1 = v1["type"]
			end
		end
	end
end

function checkRule(Building)
	local pipeSegmentCounter = 0
	local flexFittingCounter= 0
	local flexFittingGrp = FXGroup.new()
	local pipeGrp = FXGroup.new()
	local flag = true
	local check = true
	
	if #pipeSegmentGrp == 0 or pipeSegmentGrp == nil then
		FXUtility.DisplaySolid_Warning(Building,"Sewer Pipe is not provided. ")
		check = false
	end
	if check then
		pipeSegmentGrp:ForEach(function ( pipeSegmentObj )

			local FittingGrp = pipeSegmentObj:GetConnectedFitting()
			FittingGrp:ForEach(function ( FittingObj )

				if ( FXUtility.HasPatterInString( FittingObj:GetAttri(ObjProp), ObjValue ) ) then
					flexFittingGrp:Add(FittingObj)
					flexFittingCounter = flexFittingCounter + 1					
				else
					pipeGrp:Add(pipeSegmentObj)
					flag = false
				end
			end)
			pipeSegmentCounter = pipeSegmentCounter + 1
		end)

		if ( flag == false ) then
			pipeGrp:ForEach(function ( pipeGrpObj )
				FXUtility.DisplaySolid_Error(pipeGrpObj, "Flexible joint is not provided.")
				CheckReport.AddRelatedObj(pipeGrpObj, pipeGrpObj:GetAttri("Name"))
			end)
		else
			if ( flexFittingCounter == 1 ) then
				flexFittingGrp:ForEach(function ( flexFitting )
					FXUtility.DisplaySolid_Error(flexFitting, "Only one flexible joint found.")
				end)
			elseif ( flexFittingCounter ~= 0 ) then
				flexFittingGrp:ForEach(function ( flexFitting )
					FXUtility.DisplaySolid_Info(flexFitting, "Flexible joint is provided.")
					CheckReport.AddRelatedObj(flexFitting, flexFitting:GetAttri("Name"))
				end)
			end		
		end
	end
end