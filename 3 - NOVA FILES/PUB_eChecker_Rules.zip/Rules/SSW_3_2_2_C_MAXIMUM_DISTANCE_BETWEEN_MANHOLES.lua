--[[
	Implemented By: Aires Marco Ladaga --/--/--
	Modified by: Aires Marco Ladaga 02/01/2019
]]
local grpManhole = FXGroup:new();
local grpPublicSewer = FXGroup:new();

local maximumDisOperator;
local maximumDis;

function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_C_MAXIMUM_DISTANCE_BETWEEN_MANHOLES")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	maximumDisOperator = ConditionValues[2]; -- for Condition Values 
	maximumDis = tonumber(ConditionValues[3]); -- for Condition Values 

	for k,v in pairs(GrpObjs) do -- Checking in System
		if (k == 2) then
			grpManhole = grpManhole + v
			grpManhole = grpManhole:Unique()
		end	
	end

	-- for k,v in pairs(GrpBuildingObjs) do -- Checking in Building
	-- 	if (k == 6) then
	-- 		grpChamber = grpChamber + v
	-- 	end
	-- end
end

function CheckRule(Building)
	local grpSewerline = Building:GetDescendants ("FlowSegment")
	local isErrorfound = false
	local x = 0
	local comObj1Arr = {}
	local comObj2Arr = {}
	local comPolyArr = {}
	local comDArrowArr = {}
	local comDis = {}

	if #grpSewerline > 0 then
		grpSewerline:ForEach (function ( obj )
			if FXUtility.HasPatterInString( obj:GetAuxAttri("Entity.ObjectType") ,"Public Sewer") then
				grpPublicSewer:Add(obj)
			end
		end)
	end

	local hasTwoOrMoreManholes = true

	if #grpManhole == 1 then
		FXUtility.DisplaySolid_Warning ( Building , "Only one manhole provided.")
		hasTwoOrMoreManholes = false

	elseif #grpManhole < 1 then
		FXUtility.DisplaySolid_Warning ( Building , "No manhole provided.")
		hasTwoOrMoreManholes = false
	end

	if hasTwoOrMoreManholes then
		-- local isThereManholeConnected = false
		grpManhole:ForEach (function ( manholeObj1)

			grpManhole:ForEach (function ( manholeObj2 )

				if manholeObj1.Id ~= manholeObj2.Id then
				
					grpPublicSewer:ForEach(function ( publicSewerObj )	
							-- print ( FXPUB.IsConnectedChamberElement( Building , publicSewerObj , manholeObj1 ) )
							-- print ( FXPUB.IsConnectedChamberElement( Building , publicSewerObj , manholeObj2 ) )
						if  FXPUB.IsConnectedChamberElement( Building , publicSewerObj , manholeObj1 ) and FXPUB.IsConnectedChamberElement( Building , publicSewerObj , manholeObj2 ) then	
						-- if  FXClashDetection.IsCollided( publicSewerObj , manholeObj1) and FXClashDetection.IsCollided( publicSewerObj, manholeObj2 ) then	
							local polyLine = PolyLine3D(TRUE)
							print ("awd")
							local topFace1 = FXMeasure.GetTopFace(manholeObj1)	
							local facePnts1 = FXMeasure.GetOuterEdge(topFace1)
							local pointNumbers1 = facePnts1:GetPointNumber()						

							local topFace2 = FXMeasure.GetTopFace(manholeObj2)	
							local facePnts2 = FXMeasure.GetOuterEdge(topFace2)
							local pointNumbers2 = facePnts2:GetPointNumber()
					
							local longestLine1 = getFaceDiagonalLine( facePnts1 , pointNumbers1 )
							local longestLine2 = getFaceDiagonalLine( facePnts2 , pointNumbers2 )

							local manhole1CenterPnt = FXUtility.CenterPoint( longestLine1:GetStartPoint() , longestLine1:GetEndPoint() );
							local manhole2CenterPnt = FXUtility.CenterPoint( longestLine2:GetStartPoint() , longestLine2:GetEndPoint() );
							-- local manholeCenterPnt = Point3D((longestLine:GetStartPoint().x + longestLine:GetEndPoint().x)/2,(longestLine:GetStartPoint().y + longestLine:GetEndPoint().y)/2, (longestLine:GetStartPoint().z + longestLine:GetEndPoint().z)/2);
							local distance = Line3D ( manhole1CenterPnt , manhole2CenterPnt ) : Length()

							local boxManhole1 = FXGeom.GetBoundingBox(manholeObj1);
							local boxManhole2 = FXGeom.GetBoundingBox(manholeObj2);

							local pnt1 = Point3D ( manhole1CenterPnt.x , manhole1CenterPnt.y , boxManhole1:HighPos().z + 300 )
							local pnt2 = Point3D ( manhole2CenterPnt.x , manhole2CenterPnt.y , boxManhole2:HighPos().z + 300 )
		
							polyLine:AddPoint( manhole1CenterPnt );
							polyLine:AddPoint( pnt1 );
							polyLine:AddPoint( pnt2 );
							polyLine:AddPoint( manhole2CenterPnt );
							local doubleArrow = DoubleArrow ( pnt1 , pnt2 )
	
							if  FXRule.EvaluateNumber( maximumDisOperator , distance , maximumDis ) then
							-- if   distance < maximumDis  then
								x = x + 1
								comObj1Arr[x] = manholeObj1
								comObj2Arr[x] = manholeObj2
								comDArrowArr[x] = doubleArrow
								comPolyArr[x] = polyLine
								comDis[x] = distance
							else
								FXUtility.DisplaySolid_Error( manholeObj1 , manholeObj1:GetAuxAttri("Entity.ObjectType").. ":Distance = ".. distance .." mm to "..manholeObj2:GetAuxAttri("Entity.ObjectType") , doubleArrow )
								CheckReport.AddRelatedGeometry_Error( polyLine );
								CheckReport.AddRelatedObj( manholeObj1 , manholeObj1:GetAuxAttri("Entity.ObjectType"))
								CheckReport.AddRelatedObj( manholeObj2 , manholeObj2:GetAuxAttri("Entity.ObjectType"))
								isErrorfound = true
							end
						end						
					end)
				end
			end)	
		end)
	end
	if isErrorfound == false then
		local y = 1
		while y ~= x+1 do
			FXUtility.DisplaySolid_Info( comObj1Arr[y] ,  comObj1Arr[y]:GetAuxAttri("Entity.ObjectType").. ":Distance = ".. comDis[y] .." mm to " .. comObj2Arr[y]:GetAuxAttri("Entity.ObjectType") , comDArrowArr[y] )
			CheckReport.AddRelatedGeometry_Info( comPolyArr[y] );
			CheckReport.AddRelatedObj( comObj1Arr[y] , comObj1Arr[y]:GetAuxAttri("Entity.ObjectType"))
			CheckReport.AddRelatedObj( comObj2Arr[y] , comObj2Arr[y]:GetAuxAttri("Entity.ObjectType"))
			y = y + 1
		end
	end
end

function getFaceDiagonalLine( points , pointNumbers )
	local z = 1;
	local longestDiagonalLine
	while z < pointNumbers do 		
		local arrowPnt1 = points:GetPoint(z);
		local arrowPnt2 = points:GetPoint(1);
		local thisLine = Line3D( arrowPnt1, arrowPnt2)
		if ( longestDiagonalLine == nil or longestDiagonalLine:Length() < thisLine:Length() )then
			longestDiagonalLine = thisLine;
		end	
		z = z + 1	
	end
	return longestDiagonalLine ;
end