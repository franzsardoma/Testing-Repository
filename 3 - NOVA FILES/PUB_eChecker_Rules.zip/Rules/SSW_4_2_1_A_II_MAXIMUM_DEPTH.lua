local grpPipe = FXGroup:new()
local grpManhole = FXGroup:new()
local Manhole = {}
local Pipe = {}
local Geom = {}
local LengthArr = {}
local flag = true;
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_4_2_1_A_II_MAXIMUM_DEPTH")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpPipe = grpPipe + v;
				grpPipe = grpPipe:Unique();
			end
			if (k == 3) then
				grpManhole = grpManhole + v;
				grpManhole = grpManhole:Unique();
			end
		end
	end
end

function checkRule(Building)
	local manholeNode
	local pipeNode
	local node
	print("Pipe ".. #grpPipe .. " Manhole " .. #grpManhole)
	if (#grpManhole == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Manhole is not provided.");
		return false;
	elseif (#grpPipe == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Discharge Pipe is not provided.");
		return false;
	end
	if(#grpManhole ~= 0 and #grpPipe ~= 0) then
		grpManhole:ForEach(function ( manhole )
			local bottomFace = FXMeasure.GetBottomFace(manhole);
			local outerEdge = FXMeasure.GetOuterEdge(bottomFace);
			local lineArr = GetSideLines(outerEdge);
			local manholeHeight = FXGeom.GetBoundingBox(manhole):HighPos().z - FXGeom.GetBoundingBox(manhole):LowPos().z 

			local nodeManhole = FXGroup:new()
			for i=1 , #lineArr , 1 do
				local extended = toFace(FXMeasure.CreateFaceFromEdge(lineArr[i],1));
				local faceExtrude = extended:ExtrudedFace(Vector(0,0,manholeHeight));
				node = FXUtility.CreateNodeFrom(faceExtrude);
					nodeManhole:Add(node)
			end

			nodeManhole:ForEach(function ( NodeManhole )
				grpPipe:ForEach(function ( pipe )
					if FXClashDetection.IsCollided(NodeManhole,pipe) then
						local manholeElevation	= FXGeom.GetBoundingBox(manhole):HighPos().z
						local manholeprj = FXMeasure.GetObjProjection(manhole, manholeElevation+1);

						local pipeElevation	= FXGeom.GetBoundingBox(pipe):LowPos().z;
						local pipeprj = FXMeasure.GetObjProjection(pipe, pipeElevation+1);

						manholeNode = FXUtility.CreateNodeFrom(manholeprj);
						pipeNode = FXUtility.CreateNodeFrom(pipeprj);

						local  distance = FXMeasure.Distance(manholeNode, pipeNode)
						local length = distance:Length();
						local arrowGeom = DoubleArrow(distance:GetStartPoint(),distance:GetEndPoint());

						if (length <=1500) then
							table.insert(Manhole,manhole);
							table.insert(Pipe,pipe);
							table.insert(Geom,arrowGeom);
							table.insert(LengthArr,FXUtility.Round(length))
						else
							FXUtility.DisplaySolid_Error(manhole, "Discharge pipe Depth: " .. length .. "mm", arrowGeom, pipe);
							CheckReport.AddRelatedObj(manhole, manhole:GetAttri("ObjectType"))
							flag = false;
						end
					end
				end)
			end)
			FXClashDetection.DeleteNode(node);
		end)
	end
	if flag then
		for i=1,#Manhole,1 do
			FXUtility.DisplaySolid_Info(Manhole[i], "Discharge pipe Depth: " .. LengthArr[i] .."mm", Geom[i], Pipe[i]);
			CheckReport.AddRelatedObj(Manhole[i], Manhole[i]:GetAttri("ObjectType"))
		end
	end
end


function toFace( obj )
	local edges = FXMeasure.GetOuterEdge(obj);
	local face = edges:Face3D();
	return face;
end


function GetSideLines( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local linesArr = {};

	for i=0,(PolyLinePointNumber-2) do
		local tempLine = Line3D( outerEdge:GetPoint(i) ,outerEdge:GetPoint(i+1) )
		table.insert( linesArr , tempLine )
	end
	return linesArr
end