--[[-----------------------------------------------------

Author: Mike Agustin 

Rule ID: WTR Figures 9 & 10 
Rule Name: Height of vertical and horizontal  sub-meters in service duct 

All copyrights to novasolutions 
--]]-----------------------------------------------------

local groupStopCock = FXGroup:new()
local groupSubMeter = FXGroup:new()
local groupServiceDuct= FXGroup:new()
local groupSlab = FXGroup:new()
local allowedHeight = 1100
local highestSubMeter = nil
local x = 0
local isErrorFound = false
local comStoreyArr = {}
local comTerminalArr = {}
local comResultArr = {}
local comArrowArr = {}
local comPolyArr = {}
local types = {}

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("MakeGroupUnique")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("CheckRule")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("DisplayCompliant")
	CheckEngine.RunCheckPipeline()
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_9_10_SUBMETER_HEIGHT")

	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	-- local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	-- local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3");
	local tblValues = FXRule.filterTableValues(parsedXml,Building)
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(tblValues) do    
		for k1,v1 in pairs(v) do
			table.insert( types , v1["value"] )
		end
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 2) then
			groupServiceDuct = groupServiceDuct + v
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 3) then
			groupSlab = groupSlab + v
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 4) then
			groupSubMeter = groupSubMeter + v
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 5) then
			groupStopCock = groupStopCock + v
		end	
	end
end


function GetStopCock(element)
	local name = element:GetAuxAttri("Entity.ObjectType");
	-- print ( types [ 1 ])
	-- print ( types[2])
	local stopCock = nil	
	if (FXUtility.HasPatterInString(name, types[4])) then
		local elementGlobalId = element:GetAttri("GlobalId");	    
		groupStopCock:Filter(function(control)		
			local controlGlobalId = control:GetAttri("GlobalId");
			if (FXUtility.HasPatterInString(controlGlobalId, elementGlobalId)) then
				stopCock = control;			
			end	
		end)
	else
		local elements = element:GetConnectedElement();	    
		elements:ForEach(function(item)		
			local itemName = item:GetAuxAttri("Entity.ObjectType");
			if (FXUtility.HasPatterInString(itemName,types[4])) then
				print("Item>>>!!!! " .. itemName)
				groupStopCock:Filter(function(sc)		
					local itemGlobalId = item:GetAttri("GlobalId");
					local scGlobalId = sc:GetAttri("GlobalId");
					if (FXUtility.HasPatterInString(scGlobalId, itemGlobalId)) then
						stopCock = sc;			
					end	
				end)		
			end	
		end)
    end	
	return stopCock;
end


function GetSlab()	
	local floor = nil;	
	groupSlab:ForEach(function(slab)
		if (FXUtility.HasPatterInString(slab:GetAuxAttri("Entity.PredefinedType"),"floor")) then		
			if floor == nil then
				floor = slab;
			end
		end
	end)	
	return floor;
end


function GetRelatedElements(terminal)
	local element1 = nil
	local element2 = nil	
	local elements = terminal:GetConnectedElement();
	elements:ForEach(function(elem)				    						
		if(element1 == nil) then				    				    					
			element1 = elem; 
		else					
			element2 = elem;
		end
	end)
	return element1, element2;
end


function GetHeight(storey, element1, element2, controller)

	if (controller ~= nil) then

			local cntrlBBox = FXGeom.GetBoundingBox(controller)
			local cntrlOBB = FXGeom.GetBoundingOBB(controller);
			local distance = FXRelation.Distance(element1, element2);
			local Pnt1, Pnt2

			local cntrlyrange = cntrlBBox:y_range();
			local cntrlxrange = cntrlBBox:x_range();


			if (controller ~= nil and element2 ~= nil) then

				if cntrlyrange > cntrlxrange then

					if distance:GetStartPoint().y > 0 then
						Pnt1 = Point3D(distance:GetStartPoint().x,cntrlBBox:HighPos().y+100,distance:GetStartPoint().z)
						Pnt2 = Point3D(distance:GetEndPoint().x,cntrlBBox:HighPos().y+100,distance:GetEndPoint().z)
					else
						Pnt1 = Point3D(distance:GetStartPoint().x,cntrlBBox:LowPos().y-100,distance:GetStartPoint().z)
						Pnt2 = Point3D(distance:GetEndPoint().x,cntrlBBox:LowPos().y-100,distance:GetEndPoint().z)
					end
				else
					if distance:GetStartPoint().x > 0 then
						Pnt1 = Point3D(cntrlBBox:HighPos().x+100,distance:GetStartPoint().y,distance:GetStartPoint().z)
						Pnt2 = Point3D(cntrlBBox:HighPos().x+100,distance:GetEndPoint().y,distance:GetEndPoint().z)
					else
						Pnt1 = Point3D(cntrlBBox:LowPos().x-100,distance:GetStartPoint().y,distance:GetStartPoint().z)
						Pnt2 = Point3D(cntrlBBox:LowPos().x-100,distance:GetEndPoint().y,distance:GetEndPoint().z)
					end

				end

			end

			local arrowGeom = DoubleArrow(Pnt1, Pnt2);
			local polyline = PolyLine3D(TRUE);
			polyline:AddPoint(distance:GetStartPoint())
			polyline:AddPoint(Pnt1)

			local result = FXUtility.Round(distance:Length());	
			return result, arrowGeom, polyline;

	end
end


function CheckResult(storey, terminal, result, arrow, polyline)	
	print("Distance " .. result)
	if result == allowedHeight then				
		x = x + 1
		comStoreyArr[x] = storey
		comResultArr[x] = result
		comTerminalArr[x] = terminal
		comArrowArr[x] = arrow
		comPolyArr[x] = polyline
	else				
		FXUtility.DisplaySolid_Error(storey, result.." mm ; "..terminal:GetAuxAttri("Entity.ObjectType"));
		CheckReport.AddRelatedObj(terminal, terminal:GetAuxAttri("Entity.ObjectType"));	
		CheckReport.AddRelatedGeometry_Error(arrow, result);
		CheckReport.AddRelatedGeometry_Error(polyline);		
		isErrorFound = true		
	end
end


function IsHighestSubMeterExist()
	local isHighestMeterExist = false;
	local subMeter;
	groupSubMeter:ForEach(function(meter)
		if subMeter == nil then
			subMeter = meter
		else
			if FXGeom.GetBoundingBox(meter):HighPos().z > 
				FXGeom.GetBoundingBox(subMeter):HighPos().z then
				subMeter = meter
				isHighestMeterExist = true;
			end
		end
	end)
	highestSubMeter = subMeter;
	return isHighestMeterExist;
end


function GetPipeCenterLineNode(pipe)
	local pipeOBB = FXGeom.GetBoundingOBB(pipe);
	local pipeCenterPnt = pipeOBB:GetPos();
	local pipeMinPnt = pipeOBB:MinPnt();
	local pipeMaxPnt = pipeOBB:MaxPnt(); 
	local pipeCenterLine = Line3D(Point3D(pipeMinPnt.x, pipeCenterPnt.y, pipeCenterPnt.z), 
 	                       Point3D(pipeMaxPnt.x, pipeCenterPnt.y, pipeCenterPnt.z));

	-- displays the centerline
	-- FXUtility.DisplaySolid_Error(pipe,"centerline", pipeCenterLine);
	
	local pipeCenterLineNode = FXUtility.CreateNodeFrom(pipeCenterLine);
	return pipeCenterLineNode
end

 
function GetTargetSegment(subMeter)
	local segment = nil;
	local element1, element2 = GetRelatedElements(subMeter);
	if (FXUtility.HasPatterInString(element1.Type,"FlowSegment")) then
		segment = element1;			
	elseif (FXUtility.HasPatterInString(element2.Type,"FlowSegment")) then
		segment = element2;
	end
	return segment;
end


function CheckRule(BuildingStorey)
	local isHighestMeterExist = IsHighestSubMeterExist();
	print(isHighestMeterExist)
	if (isHighestMeterExist == true) then		
		local segment = GetTargetSegment(highestSubMeter);
		local controller = GetStopCock(segment);
		local floor = GetSlab();
		
		if (floor ~= nil) and (segment ~= nil) and (controller ~= nil) then
			local pipeCenterLineNode = GetPipeCenterLineNode(segment);			   
			local result, arrow, polyline = GetHeight(BuildingStorey, pipeCenterLineNode, floor, controller);
			CheckResult(BuildingStorey, highestSubMeter, result, arrow, polyline);				
		end
	else		
		if(#groupSubMeter ~= 0 and #groupSlab ~= 0) then
			groupSubMeter:ForEach(function(sm)

				local segment = GetTargetSegment(sm);
				local controller = GetStopCock(segment);
				local floor = GetSlab();
				
				if (floor ~= nil) and (segment ~= nil) and (controller ~= nil) then			   
					local result, arrow, polyline = GetHeight(BuildingStorey, segment, floor, controller);
					CheckResult(BuildingStorey, sm, result, arrow, polyline);					
				end
			end)
		end
	end
end  


function MakeGroupUnique(BuildingStorey)
   
	groupSubMeter = groupSubMeter:Unique();
	if(#groupSubMeter ~= 0) then
		print("Sub Meter -> "..#groupSubMeter)		
	else
		print("No Sub Meter found.")
		FXUtility.DisplaySolid_Warning(BuildingStorey, "Sub Meter is not provided.")
	end
	
	groupStopCock = groupStopCock:Unique();
    if(#groupStopCock ~= 0) then    
		print("Stopcock -> "..#groupStopCock)		
	else
		print("No Stopcock found")
		FXUtility.DisplaySolid_Warning(BuildingStorey, "Stopcock is not provided.")
	end
	
	groupServiceDuct = groupServiceDuct:Unique();
	if(#groupServiceDuct ~= 0) then    
		print("Service Duct -> "..#groupServiceDuct)	
	else
		print("No Service Duct found.")
		FXUtility.DisplaySolid_Warning(BuildingStorey, "Service Duct is not provided.")
	end		

	groupSlab = groupSlab:Unique();
	if(#groupSlab ~= 0) then    
		print("Slab -> "..#groupSlab)	
	else
		print("No Slab found.")
		FXUtility.DisplaySolid_Warning(BuildingStorey, "Slab is not provided.")
	end	
end


function DisplayCompliant( Building )
	if isErrorFound == false then
		local y = 1
		while y ~= x + 1 do 
			FXUtility.DisplaySolid_Info(comStoreyArr[y], comResultArr[y].." mm ; "..comTerminalArr[y]:GetAuxAttri("Entity.ObjectType"));
			CheckReport.AddRelatedObj(comTerminalArr[y], comTerminalArr[y]:GetAuxAttri("Entity.ObjectType"));
			CheckReport.AddRelatedGeometry_Solid(comArrowArr[y], comResultArr[y]);
			CheckReport.AddRelatedGeometry_Solid(comPolyArr[y]);
			y = y + 1
		end
	end
end