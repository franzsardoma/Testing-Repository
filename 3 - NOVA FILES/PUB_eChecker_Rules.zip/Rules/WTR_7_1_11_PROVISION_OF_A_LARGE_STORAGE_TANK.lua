local grpTank = FXGroup.new()
local grpInlet = FXGroup.new()
local grpOutlet = FXGroup.new()

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_11_PROVISION_OF_A_LARGE_STORAGE_TANK")
	
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	-- maximumDis = ConditionValues[2]; -- for Condition Values 

	for k,v in pairs(GrpBuildingObjs) do -- Checking in System
		if (k == 2) then
			grpTank = grpTank + v
		end	
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if (k == 3) then
			grpInlet = grpInlet + v
			grpInlet = grpInlet:Unique()
		end	
	end

	for k,v in pairs(GrpObjs) do -- Checking in Building
		if (k == 4) then
			grpOutlet = grpOutlet + v
			grpOutlet = grpOutlet:Unique()
		end
	end
end


function CheckRule(Building)
	local flag = true
	print (#grpTank .. " - " ..#grpOutlet.." - "..#grpInlet)
	if #grpTank < 1 then
		FXUtility.DisplaySolid_Warning ( Building , "No Water Storage Tank Found." )
		flag = false
	end

	if flag then
		grpTank : ForEach ( function ( tankObj )
			local isErrorFound = false

			local tankBox =  FXGeom.GetBoundingBox( tankObj ) 
			local boxNode = FXClashDetection.CreateNode();
			
			FXClashDetection.AddGeometry( boxNode , tankBox );
			local boxProjection = FXMeasure.GetObjProjection( boxNode , tankBox:HighPos().z  )
			FXClashDetection.DeleteNode( boxNode );

			local boxProjectionPnts = FXMeasure.GetOuterEdge ( boxProjection )
			local pointNum = boxProjectionPnts : GetPointNumber()

			local inletCollidedLine 
			local outletCollidedLine
			local collidedInlet
			local collidedOutlet

			local boxHeight = tankBox:HighPos().z - tankBox:LowPos().z 

			grpInlet : ForEach ( function ( inletObj )
				if inletCollidedLine == nil and FXPUB.IsObjsConnected ( inletObj , tankObj , 3 ) then -- to make sure its connected to the tank
					inletCollidedLine , collidedInlet = LineToFaceExtrudeIsCollidedWithObj ( boxProjectionPnts , pointNum , inletObj , boxHeight )
				end
			end)

			grpOutlet : ForEach ( function ( outletObj )
				if outletCollidedLine == nil and FXPUB.IsObjsConnected ( outletObj , tankObj , 3 ) then -- to make sure its connected to the tank
					outletCollidedLine , collidedOutlet = LineToFaceExtrudeIsCollidedWithObj ( boxProjectionPnts , pointNum , outletObj , boxHeight )
				end
			end)

			local flag2 = true
			if inletCollidedLine == nil then
				FXUtility.DisplaySolid_Error ( tankObj , "No Inlet Pipe found connected in the Water Storage Tank." )
				flag2 = false
			end

			if outletCollidedLine == nil then
				FXUtility.DisplaySolid_Error ( tankObj , "No Outlet Pipe found connected in the Water Storage Tank." )
				flag2 = false
			end
			-- FXUtility.DisplaySolid_Error ( Building , " inlet " , inletCollidedLine )	
			-- FXUtility.DisplaySolid_Info ( Building , " outlet " , outletCollidedLine )	
			if flag2 then
				if FXUtility.IsParallel( inletCollidedLine , outletCollidedLine ) then -- if parallel then its either on opposite sides or on the same side
					local inletFatLine = FXMeasure.CreateFaceFromEdge( inletCollidedLine , 1 );
					local inletPnts = FXMeasure.GetOuterEdge( inletFatLine )
					local inletFace = inletPnts:Face3D()
					local inletExtrudedFace = inletFace:ExtrudedFace(Vector(0,0,1) );  -- Two faces dont collided, so one of the face needs to extrude for them to collide
					local inletNode = FXUtility.CreateNodeFrom( inletExtrudedFace );

					local outletFatLine = FXMeasure.CreateFaceFromEdge( outletCollidedLine , 1 );
					local outletNode = FXUtility.CreateNodeFrom( outletFatLine );

					if FXClashDetection.IsCollided( inletNode , outletNode ) then
						isErrorFound = true  ----------------------------------------------------  IT means the Inlet and outlet are in the same Water Tank
					else
						local inletLowPos = FXGeom.GetBoundingBox( collidedInlet ) : LowPos().z
						local outletLowPos = FXGeom.GetBoundingBox( collidedOutlet ) : LowPos().z

						if inletLowPos > outletLowPos then -- Inlet is always above outlet
							isErrorFound = false
						else
							isErrorFound = true
						end
					end

					FXClashDetection.DeleteNode( inletNode );
					FXClashDetection.DeleteNode( outletNode );
				else
					isErrorFound = true -------------------------------------------------- Inlet and outlet are not on opposite sides, thats why its not Parallel
				end

				-- FXUtility.DisplaySolid_Error ( Building , " inlet " , inletLineCollidedBoxLine )	
				-- FXUtility.DisplaySolid_Info ( Building , " outlet " , outletLineCollidedBoxLine )

				if isErrorFound then
					FXUtility.DisplaySolid_Error ( tankObj , "Inlet Pipe and Outlet Pipe is found connected but not diagonally opposite at different side face in the Water Storage Tank." )
				elseif isErrorFound == false then
					FXUtility.DisplaySolid_Info ( tankObj ,  "Inlet Pipe and Outlet Pipe is found connected in the Water Storage Tank.")
				end	
			end
		end)
	end
end


function LineToFaceExtrudeIsCollidedWithObj( points , pointNumbers , obj , range ) -- get the collided object, from extruding each side of the line of BBbox Tank projection
	local collidedLine = nil

	local z = 0 
	while z < pointNumbers - 1 do 		
		local arrowPnt1 = points:GetPoint(z);
		local arrowPnt2 = points:GetPoint(z+1);
		local thisLine = Line3D( arrowPnt1, arrowPnt2)

		local newFatterLine = FXMeasure.CreateFaceFromEdge( thisLine , 300 );

		local outerEdge = FXMeasure.GetOuterEdge( newFatterLine )
		local newFace = outerEdge:Face3D()

		local extrudedFace = newFace:ExtrudedFace(Vector(0,0,-range) );
		
		local nodeExtrude = FXUtility.CreateNodeFrom( extrudedFace );

		if FXClashDetection.IsCollided( nodeExtrude , obj ) then
			collidedLine = thisLine;	
		end	

		z = z + 1	
		FXClashDetection.DeleteNode( nodeExtrude );
	end

	return collidedLine , obj
end