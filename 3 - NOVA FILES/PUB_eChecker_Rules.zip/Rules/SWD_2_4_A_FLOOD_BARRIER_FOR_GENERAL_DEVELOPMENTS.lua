local FloodBarrierGrp=FXGroup.new();



function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  -- print("LUA " .. path())
  local parsedXml = FXPUB.ParseXml(path(), "SWD_2_4_A_FLOOD_BARRIER_FOR_GENERAL_DEVELOPMENTS")

  -- local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
  -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
  -- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
  -- for k,v in pairs(tbl) do
  --  if k == 5 then
  --    tblSpace = v
  --  end
  -- end
  -- local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
  local xmlObjs = FXRule.filterObjects(parsedXml, Building);
  for k,v in pairs(xmlObjs) do -- get the model objects
    if k == 2 then
      FloodBarrierGrp = FloodBarrierGrp + v
      FloodBarrierGrp = FloodBarrierGrp:Unique()      
    end    
  end
end

function checkRule(Building)
  -- print(#FloodBarrierGrp)
  -- local BuildingElementProxyGrp = Building:GetDescendants("BuildingElementProxy");
  
  local BuildingStoreyToCheckGrp=FXGroup.new();
  local project = Building:GetAuxAttri("Other.Project Development Type")
  print(project)
  
  -- BuildingElementProxyGrp:ForEach(function(FloodBarrier)
  --   local name = string.lower(FloodBarrier:GetAttri("Name"))
  --   if(string.find(name,"flood barrier") ~=nil) then 
  --     FloodBarrierGrp:Add(FloodBarrier);  
  --   end
  -- end)  

  if FXUtility.HasPatterInString(project,"General Development") then
    local BuildingStoreyGroup =  Building:GetDescendants("BuildingStorey");
    BuildingStoreyGroup:ForEach(function(buildingstoreyElement)
      local name =buildingstoreyElement:GetAttri("Name")
      
      if FXUtility.HasPatterInString(name,"First Storey") == true or FXUtility.HasPatterInString(name,"First Level") == true or FXUtility.HasPatterInString(name,"Level 1") == true or FXUtility.HasPatterInString(name,"1st Storey") == true or FXUtility.HasPatterInString(name,"1st Level") == true or FXUtility.HasPatterInString(name,"First Floor") == true or FXUtility.HasPatterInString(name,"Compound") == true then 
        BuildingStoreyToCheckGrp:Add(buildingstoreyElement);  
      end
    end)

    local grpBar = FXGroup.new()
    local grpLowBar = FXGroup.new()
    FloodBarrierGrp:ForEach(function ( bar )
      local parent = bar:GetParent(BuildingStorey)
      local name1 = parent:GetAttri("Name")
      if FXUtility.HasPatterInString(name1,"First Storey") == true or FXUtility.HasPatterInString(name1,"First Level") == true or FXUtility.HasPatterInString(name1,"Level 1") == true or FXUtility.HasPatterInString(name1,"1st Storey") == true or FXUtility.HasPatterInString(name1,"1st Level") == true or FXUtility.HasPatterInString(name1,"First Floor") == true or FXUtility.HasPatterInString(name1,"Compound") == true then 
        grpBar:Add(bar);
      else
        grpLowBar:Add(bar);
      end
    end)
    if #BuildingStoreyToCheckGrp ~= 0 then
      BuildingStoreyToCheckGrp:ForEach(function(buildingstoreytocheckElement)
        local OpeningEleGrp = buildingstoreytocheckElement:GetDescendants("OpeningElement");
        local externalDoorGrp = FXGroup.new();

        OpeningEleGrp:ForEach(function(openingEle)
          local DoorGrp = buildingstoreytocheckElement:GetDescendants("Door"); 
          DoorGrp:ForEach(function(doorElement)
            local isExternal = doorElement:GetAuxAttri("Pset_DoorCommon.IsExternal");
            if(isExternal == "true") then
              externalDoorGrp:Add(doorElement);
            end  
          end)
        end)
     -- print(#grpLowBar)
        local grpLowProDoor = FXGroup.new()
        local unprotectedDoorGrp = FXGroup.new()
        local protectedDoorGrp = FXGroup.new()
        local num = buildingstoreytocheckElement:GetAuxAttri("Identity Data.Name");
        if #externalDoorGrp ~= 0 then
          if(#grpBar == 0 and #grpLowBar == 0) then
            print("g")
             externalDoorGrp:ForEach(function ( door )
              FXUtility.DisplaySolid_Error(door,"No Flood Barriers installed on all entry/exit point at ground/platform "..num..".");
            end)
          else
            externalDoorGrp:ForEach(function(extDoor)
              local IsCollided = false;
              if #grpLowBar ~= 0 then
                grpLowBar:ForEach(function ( low )
                  local number = extDoor:GetAuxAttri("Identity Data.Mark");
                  if FXClashDetection.IsCollided(low,extDoor) then
                    FXUtility.DisplaySolid_Error(extDoor,low:GetAttri("Name").." installed at entry/exit point "..number .." below ground/platform "..num..".");
                  else
                    if #grpBar ~= 0 then
                      grpBar:ForEach(function(floodbarrier)  
                        local IsCollided = FXClashDetection.IsCollided(floodbarrier,extDoor);
                        if (IsCollided == true) then
                          protectedDoorGrp:Add(extDoor);
                          FXUtility.DisplaySolid_Info(extDoor,floodbarrier:GetAttri("Name").." are installed on all entry/exit point at ground/platform "..num..".");
                        else
                          unprotectedDoorGrp:Add(extDoor);
                        end 
                      end)
                    else
                      unprotectedDoorGrp:Add(extDoor)
                    end
                  end
                end)
              else
                grpBar:ForEach(function(floodbarrier)  
                  local IsCollided = FXClashDetection.IsCollided(floodbarrier,extDoor);
                  if (IsCollided == true) then
                    protectedDoorGrp:Add(extDoor);
                    FXUtility.DisplaySolid_Info(extDoor,floodbarrier:GetAttri("Name").." are installed on all entry/exit point at ground/platform "..num..".");
                  else
                    unprotectedDoorGrp:Add(extDoor);
                  end 
                end)
              end
              -- if IsCollided == false then
              --   unprotectedDoorGrp:Add(extDoor);
              -- end 
            end)
          end
          
      print(#unprotectedDoorGrp)
          if(#protectedDoorGrp == #externalDoorGrp) then
            print("Yes")
          else
            if(#unprotectedDoorGrp == #externalDoorGrp) then
              unprotectedDoorGrp:ForEach(function ( door )
                FXUtility.DisplaySolid_Error(door,"No Flood Barriers installed on all entry/exit point at ground/platform "..num..".");
              end)
            else
              unprotectedDoorGrp:ForEach(function(unprotectedDoorEle)
                local number = unprotectedDoorEle:GetAuxAttri("Identity Data.Mark");
                local num = buildingstoreytocheckElement:GetAuxAttri("Identity Data.Name");
                FXUtility.DisplaySolid_Error(unprotectedDoorEle,"No Flood Barriers installed on entry/exit point " .. number .." at ground/platform "..num..".");   
              end)
              protectedDoorGrp:ForEach(function(protectedDoorEle)
                local number = protectedDoorEle:GetAuxAttri("Identity Data.Mark");
                local num = buildingstoreytocheckElement:GetAuxAttri("Identity Data.Name");
                FXUtility.DisplaySolid_Info(protectedDoorEle,"Flood Barriers installed on entry/exit point " .. number .." at ground/platform "..num..".");   
              end)
            end
          end
        else
           FXUtility.DisplaySolid_Warning(buildingstoreytocheckElement,"External Door is not provided."); 
        end
      end)
    else
      FXUtility.DisplaySolid_Warning(Building,"Platform Level is not provided."); 
    end
  else
    FXUtility.DisplaySolid_Warning(Building,"Project Development Type not specified as General Development."); 
  end
end		






 