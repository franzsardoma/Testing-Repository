local JunctionGroup 		= FXGroup.new();
local SewerConnectionGroup	= FXGroup.new();
local PublicSewerLineGroup 	= FXGroup.new();
local inspectionChamberGrp 	= FXGroup.new();
local minDiameter 			= 150.00; 
local systemTypes;
local diameter;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_2_N_DRAIN_LINE_CONNECTION_TO_SEWER");

    local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	
	--minHeight = ConditionValues[2];
	minDiameter = tonumber(ConditionValues[2])

	-- local GrpObjs = FXRule.filterObjects(parsedXml, System);	
	if( GrpObjsSystem ~= nil ) then	
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				SewerConnectionGroup =  SewerConnectionGroup + v;
				SewerConnectionGroup =  SewerConnectionGroup:Unique();
			end	
			if (k == 3) then	
				inspectionChamberGrp = inspectionChamberGrp + v;
				inspectionChamberGrp =  inspectionChamberGrp:Unique();
			end	
			if (k == 4) then			    
				PublicSewerLineGroup = PublicSewerLineGroup + v;
				PublicSewerLineGroup =  PublicSewerLineGroup:Unique();
			end
			if (k == 5) then			    
				JunctionGroup = JunctionGroup + v;
				JunctionGroup =  JunctionGroup:Unique();
			end		
		end	
	end
end

function checkRule(Building) -- hardcoded

	if(#inspectionChamberGrp ~= 0 and #SewerConnectionGroup ~= 0 and #PublicSewerLineGroup ~= 0)then		
		local sewerLineDiameter;
		PublicSewerLineGroup:ForEach(function (sewer)
			sewerLineDiameter = FXUtility.Round(sewer:GetAuxAttri("Mechanical.Diameter"),2);
		end)
		
		local Condition1,Pipe1 = isConnected(inspectionChamberGrp);

		if(Condition1)then
			local Condition2,Pipe2 = isObjectConnected(PublicSewerLineGroup);
			if(Condition2)then
				-- print(#JunctionGroup);
				if(#JunctionGroup ~= 0)then
					local Condition3,JunctionObject = isJunctionConnected(JunctionGroup);
					if(Condition3)then
						local Pass = CheckJunctionDiamter(JunctionGroup);
						SewerConnectionGroup:ForEach(function (drainLine)
							local drainLineDiameter = FXUtility.Round(drainLine:GetAuxAttri("Mechanical.Diameter"),2)
							local pipeName = drainLine:GetAttri("Name");
							local pipeDesc = drainLine:GetAttri("Description");
							if(drainLineDiameter == minDiameter and sewerLineDiameter == minDiameter and Pass == true)then
								FXUtility.DisplaySolid_Info(drainLine,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. drainLineDiameter .. " mm");
								CheckReport.AddRelatedObj(JunctionObject,"Y Junction/Raised Junction is provided");
							else
								FXUtility.DisplaySolid_Error(drainLine,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. drainLineDiameter .. " mm");
								-- CheckReport.AddRelatedObj(JunctionObject,"Y Junction/Raised Junction is provided");
							end
						end)
					else
						FXUtility.DisplaySolid_Warning(JunctionObject,"No connection to junction");	
					end
				else
					FXUtility.DisplaySolid_Error(Building,"Y Junction/Raised Junction is not provided");
				end
			else
				FXUtility.DisplaySolid_Warning(Pipe2,"No connection to sewer line or last IC");
			end
		else
			FXUtility.DisplaySolid_Warning(Pipe1,"No connection to sewer line or last IC");
		end
	else
		if #inspectionChamberGrp == 0 then
			FXUtility.DisplaySolid_Warning(Building,"Inspection Chamber is not provided.");
		end
		if #SewerConnectionGroup == 0 then
			FXUtility.DisplaySolid_Warning(Building,"Sewer Connection is not provided.");
		end
		if #PublicSewerLineGroup == 0 then
			FXUtility.DisplaySolid_Warning(Building,"Public Sewer Line is not provided.");
		end
	end
end


function CheckJunctionDiamter(Group)
	local flag = false;
	Group:ForEach(function (junction)
		local CheckDiameter = FXUtility.Round(junction:GetAuxAttri("Dimensions.Nominal Diameter"),2);
		if(CheckDiameter == minDiameter)then
			flag = true;
		end
	end)
	return flag;
end

function isConnected(Group)
	local BaseSewerConnection;
	local BaseSewerConnectionID;
	local PipeIsConnected = false;
	if(#Group ~= 0)then
		Group:ForEach(function(Element) 
			SewerConnectionGroup:ForEach(function(Sewer)
				if(FXClashDetection.IsCollided(Element,Sewer) == true)then 
					BaseSewerConnection = Sewer;
					BaseSewerConnectionID = Sewer.Id;
				else
					local ConnectedSewerFitting = Sewer:GetConnectedFitting();
					if(#ConnectedSewerFitting ~= 0)then
						ConnectedSewerFitting:ForEach(function(SewerFitting)
							if(FXClashDetection.IsCollided(Element,SewerFitting) == true)then 
								BaseSewerConnection = Sewer;
								BaseSewerConnectionID = Sewer.Id;

							end 
						end)
					end
				end
			end)
		end)

		if(BaseSewerConnection ~= nil and BaseSewerConnectionID ~= nil)then
			SewerConnectionGroup:ForEach(function(Sewer2)
				if(sewerElement ~= BaseSewerConnectionID)then
					print(Sewer2.Id .. " " ..BaseSewerConnection.Id)
					if(FXPUB.IsObjsConnected(Sewer2,BaseSewerConnection,10))then 
						PipeIsConnected = true;
					end
					print("****")
				end
			end)
		end
	end
	return PipeIsConnected;
end

function isObjectConnected(Group)
	if(#Group ~= nil)then 
		local Connection = false;
		local Pipe;
		Group:ForEach(function (Element)
			SewerConnectionGroup:ForEach(function(Object) 
				if(FXPUB.IsObjsConnected(Object,Element))then 
					Connection = true;
					Pipe = Object;
				else
					Pipe = Object;
					Connection = false;
				end
			end)
		end)
		return Connection,Pipe;
	end
end

function isJunctionConnected(Group)
	if(#Group ~= nil)then 
		local Connection = false;
		local Junction;
		Group:ForEach(function (Element)
			SewerConnectionGroup:ForEach(function(Object) 
				if(FXPUB.IsObjsConnected(Object,Element))then 
					Connection = true;
					Junction = Element;
				else
					Junction = Element;
					Connection = false;
				end
			end)
		end)
		return Connection,Junction;
	end
end

