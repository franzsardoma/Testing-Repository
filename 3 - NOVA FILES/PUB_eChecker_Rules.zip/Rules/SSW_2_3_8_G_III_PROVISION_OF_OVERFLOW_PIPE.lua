-- Author:Mohammad Derick Pauig


local grpOverflow = FXGroup.new()
local grpStorage = FXGroup.new()


function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_8_G_III_PROVISION_OF_OVERFLOW_PIPE")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	--local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpOverflow = grpOverflow + v
			grpOverflow = grpOverflow:Unique()			
		end
		if k == 3 then
			grpStorage = grpStorage + v
			grpStorage = grpStorage:Unique()			
		end			
	end
end

function checkRule(Building)
	print(#grpOverflow.."Over")
	print(#grpStorage.."Sto")
	local grpCom = FXGroup.new()
	local isNonCom
	
	if #grpStorage ~= 0 then
		grpStorage:ForEach(function ( Sto )
			local flag = false
			
			if #grpOverflow ~= 0 then
				grpOverflow:ForEach(function (	over )	
					if FXPUB.IsObjsConnected(Sto,over,2) then
						flag = true
						if NonCom ~= true then
							FXUtility.DisplaySolid_Info(Sto,"An "..over:GetAuxAttri("Entity.Description").." is provided for the "..Sto:GetAttri("Name")..".")
							grpCom:Add(over)
						end
					end
				end)
			else
				isNonCom = true
				FXUtility.DisplaySolid_Error(Sto,"Overflow Pipe is not provided for the "..Sto:GetAttri("Name")..".")
			end

			if flag ~= true then
				isNonCom = true
				FXUtility.DisplaySolid_Error(Sto,"Overflow Pipe is not provided for the "..Sto:GetAttri("Name")..".")
			end
			
			grpOverflow = grpOverflow - grpCom
		end)
	else
		FXUtility.DisplaySolid_Warning(Building,"Sewage Treatment Plant is not provided.")
	end
end