local UrinalGrp = FXGroup.new();
local UrinalTrapGrp = FXGroup.new();

function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_3_3_D_URINAL_TRAP_QUANTITY");
  -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
  SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2) then
      UrinalGrp = UrinalGrp + v;
      UrinalGrp = UrinalGrp:Unique();
    end
    if (k == 3) then
      UrinalTrapGrp = UrinalTrapGrp + v;
      UrinalTrapGrp = UrinalTrapGrp:Unique();
    end
  end
end
local urinal;
local urinalTrap;
function checkRule(Building)
  if #UrinalGrp ~= 0 then
    local urinalCountLimit = #UrinalTrapGrp * 10;
    local isConnected = false;
    local connectedGrp = FXGroup.new()
    if #UrinalTrapGrp ~= 0 then
      UrinalTrapGrp:ForEach(function(urinaltrapEle)
        urinalTrap = urinaltrapEle;
      end)
      if (#UrinalGrp <=urinalCountLimit) then 
        UrinalTrapGrp:ForEach(function(urinaltrapEle)
          UrinalGrp:ForEach(function(urinalEle)
            local connected =FXPUB.IsObjsConnected(urinalEle, urinaltrapEle,50)
            if connected then
              isConnected = true;
              connectedGrp:Add(urinalEle)
              urinal = urinalEle;
            else
              isConnected = false;
              urinal = urinalEle;
            end  
          end)
        end)

        if isConnected then
          FXUtility.DisplaySolid_Info(urinalTrap:GetParent(),#UrinalTrapGrp .. " Urinal Trap is provided:Urinals = " .. #UrinalGrp);
          CheckReport.AddRelatedObj(urinalTrap,urinalTrap:GetAttri("Name"))

          UrinalGrp:ForEach(function(urinalEle)
            CheckReport.AddRelatedObj(urinalEle,urinalEle:GetAttri("Name"))   
          end)
        else
          isCompliant = false
          FXUtility.DisplaySolid_Warning(urinal,"Urinal not connected to urinal trap")
        end  
      else
        isCompliant = false
        FXUtility.DisplaySolid_Error(urinalTrap:GetParent(),#UrinalTrapGrp .. " Urinal Trap is provided:Urinals = " .. #UrinalGrp);
        UrinalTrapGrp:ForEach(function(trapEle)
          CheckReport.AddRelatedObj( trapEle,trapEle:GetAttri("Name"))
        end)
        UrinalGrp:ForEach(function(urinalEle)
          CheckReport.AddRelatedObj( urinalEle,urinalEle:GetAttri("Name"))
        end)
      end
    else
      UrinalGrp:ForEach(function(urinalEle)
        urinal = urinalEle
      end)
      FXUtility.DisplaySolid_Error(urinal:GetParent(),"Urinal Trap is not provided:Urinals = ".. #UrinalGrp);
      UrinalGrp:ForEach(function(urinalEle)
        CheckReport.AddRelatedObj( urinalEle,urinalEle:GetAttri("Name"))
      end)
    end
  else
    FXUtility.DisplaySolid_Warning(Building,"Urinal is not provided.")  
  end
end   