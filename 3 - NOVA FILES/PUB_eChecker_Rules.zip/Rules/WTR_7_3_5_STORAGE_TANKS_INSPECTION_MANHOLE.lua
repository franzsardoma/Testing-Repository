local grpLadder = FXGroup.new()
local grpFlowStorageDevice = FXGroup.new()
local grpDoor = FXGroup.new()

local conditionTrapDoor

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_3_5_STORAGE_TANKS_INSPECTION_MANHOLE")

	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	conditionTrapDoor = ConditionValues[2];
	-- conditionInspectionManhole = ConditionValues[4];

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 2) then
			grpFlowStorageDevice = grpFlowStorageDevice + v
			grpFlowStorageDevice = grpFlowStorageDevice : Unique()
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 3) then
			grpDoor = grpDoor + v
			grpDoor = grpDoor : Unique() 
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 5) then
			grpLadder = grpLadder + v
			grpLadder = grpLadder : Unique()
		end	
	end
end


function CheckRule(Building)
	local i = 0
	local comFlowStorage = {}
	local comDoor  = {}
	local comProj  = {}
	local comIsAbove = {}
	-- local comCheckingLine = {}

	local isErrorFound = false
	local flag = true
	print ( #grpFlowStorageDevice .. " - " .. #grpDoor .. " - "..#grpLadder)
	if #grpFlowStorageDevice == 0 then	
		FXUtility.DisplaySolid_Warning ( Building , "Storage tank is not provided." )
		flag = false
	end

	if flag then
		grpFlowStorageDevice : ForEach ( function ( storageObj )
			local storageBox = FXGeom.GetBoundingBox( storageObj )
			local storey = getStorey(storageObj) 
			local storeyName = storey : GetAttri("Name") -- TO CHECK IF ITS ON ROOF OR NOT, GRPDOOR COVER OBJTYPE WILL DIFFER

			local flag2 = true
			local collidedLadder
			local collidedDoor
			local isRoofLevel = false

			if FXUtility.HasPatterInString( storeyName ,"Roof") then
				isRoofLevel = true
			end

			if #grpLadder > 0 then
				grpLadder : ForEach ( function ( ladder )
					if FXClashDetection.IsCollided( storageObj , ladder ) then
						collidedLadder = ladder
					end
				end)
			end

			if #grpDoor > 0 then
				grpDoor : ForEach ( function ( door )
					if FXClashDetection.IsCollided( storageObj , door ) then
						collidedDoor = door
					end
				end)
			end

			if collidedLadder == nil then
				FXUtility.DisplaySolid_Warning ( storageObj , "Ladder in storage not provided.")
				flag2 = false
			end 

			if collidedDoor == nil then
				flag2 = false
				if isRoofLevel == true then -- if roof level trapDoor should be installed, if not Inspection manhole should be installed.
					FXUtility.DisplaySolid_Error ( storageObj , "Trap door is not provided.")

				elseif isRoofLevel == false then
					FXUtility.DisplaySolid_Error ( storageObj , "Inspection manhole is not provided.")
				end

			else
				if isRoofLevel == true and FXUtility.HasPatterInString( collidedDoor:GetAuxAttri("Entity.ObjectType") , conditionTrapDoor ) == false then 
					FXUtility.DisplaySolid_Error ( storageObj , "Trap door is not provided.")
					flag2 = false
				end
			end

			
			if flag2 then 
				local ladderBox = FXGeom.GetBoundingBox( collidedLadder ) 
				local node = FXUtility.CreateNodeFrom( ladderBox );
		  		local ladderProject = FXMeasure.GetObjProjection( node , storageBox:HighPos().z )
		  		FXClashDetection.DeleteNode( node );
				
				local ladderLine = projLongestLine ( ladderProject )  -- get the width line of ladder
				
				local node1 = FXUtility.CreateNodeFrom( storageBox );
		  		local storageBoxProject = FXMeasure.GetObjProjection( node1 , storageBox:HighPos().z )
		  		FXClashDetection.DeleteNode( node1 );

		  		local closestNotParallelToLadderLine , closestParallelToLadderLine = getParallelAndNotLinesFromProjLines ( ladderLine , storageBoxProject ) 
		  		-- closest Parallel and closest not parallel line of LadderWidth line 

		  		local sideLineWidth       = closestNotParallelToLadderLine : Length() / 3 -- 1/3 length of not parallel Line
		  		local ladderSideLineWidth = closestParallelToLadderLine : Length() / 3 -- 1/3 length of parallel Line


		  		local div3Poins1 = SetSamplePoint ( closestParallelToLadderLine : GetStartPoint() , closestParallelToLadderLine : GetEndPoint() , ladderSideLineWidth )--get closest parallel 1/3 line
		  		local div3LinesParallel1 = Line3D ( div3Poins1[1] , div3Poins1[2] ) 
		  		local div3LinesParallel2 = Line3D ( div3Poins1[2] , div3Poins1[3] ) -- center parallel 
		  		local div3LinesParallel3 = Line3D ( div3Poins1[3] , closestParallelToLadderLine : GetEndPoint() )

		  		local arrLines = {}
		  		arrLines[1] = div3LinesParallel1
		  		arrLines[2] = div3LinesParallel2
		  		arrLines[3] = div3LinesParallel3

		  		local closestLineFromLadderLine = lineClosestLine ( ladderLine , arrLines ) -- get the closest line of the 3 by distancing centerPoints

		  		if closestLineFromLadderLine ~= nil then
		  			local newLine = FXGFA.ShrinkageLine( closestLineFromLadderLine , - div3LinesParallel2 : Length() )
		  			local fatten = FXMeasure.CreateFaceFromEdge( newLine , sideLineWidth * 2 );
					local outerPrj = FXMeasure.GetOuterEdge( fatten );
					local newface = outerPrj:Face3D()
					local extruded = newface:ExtrudedFace(Vector(0, 0, 50));

					local nodeThis = FXUtility.CreateNodeFrom( extruded );

					if isRoofLevel then
				  		if FXClashDetection.IsCollided( nodeThis , collidedDoor )  then
							i = i + 1
							comFlowStorage[i] = storageObj
							comDoor[i] = collidedDoor
							comProj[i] = fatten
							comIsAbove[i] = "true"
							-- comCheckingLine[i] = ladderLine
						else
							FXUtility.DisplaySolid_Error ( storageObj , "Floor Trap is away from ladder of storage tank." , fatten )
							CheckReport.AddRelatedObj ( storageObj , storageObj:GetAuxAttri("Entity.ObjectType") )
							CheckReport.AddRelatedObj ( collidedDoor , collidedDoor:GetAuxAttri("Entity.ObjectType") )
						end 
					else
						if FXClashDetection.IsCollided( nodeThis , collidedDoor ) then
							i = i + 1
							comFlowStorage[i] = storageObj
							comDoor[i] = collidedDoor
							comProj[i] = fatten
							comIsAbove[i] = "false"
							-- comCheckingLine[i] = ladderLine
						else
							FXUtility.DisplaySolid_Error ( storageObj , "Inspection manhole is away from ladder of storage tank." , fatten )
							CheckReport.AddRelatedObj ( storageObj , storageObj:GetAuxAttri("Entity.ObjectType") )
							CheckReport.AddRelatedObj ( collidedDoor , collidedDoor:GetAuxAttri("Entity.ObjectType") )
						end 
					end

					FXClashDetection.DeleteNode( nodeThis );
				end

			end
		end)

		if isErrorFound == false then
			local x = 1
			while x ~= i+1 do
				if comIsAbove[x] == "true" then
					FXUtility.DisplaySolid_Info ( comFlowStorage[x] , "Trap door near the ladder of storage tank  found.", comProj[x] )
					CheckReport.AddRelatedObj ( comFlowStorage[x] , comFlowStorage[x]:GetAuxAttri("Entity.ObjectType") )
					CheckReport.AddRelatedObj ( comDoor[x] , comDoor[x]:GetAuxAttri("Entity.ObjectType") )
					-- CheckReport.AddRelatedGeometry_Solid ( comCheckingLine[x] )
					x = x + 1
				elseif comIsAbove[x] == "false" then
					FXUtility.DisplaySolid_Info ( comFlowStorage[x] , "Inspection manhole is near the ladder of storage tank.", comProj[x] )
					CheckReport.AddRelatedObj ( comFlowStorage[x] , comFlowStorage[x]:GetAuxAttri("Entity.ObjectType") )
					CheckReport.AddRelatedObj ( comDoor[x] , comDoor[x]:GetAuxAttri("Entity.ObjectType") )
					-- CheckReport.AddRelatedGeometry_Solid ( comCheckingLine[x] )
					x = x + 1
				end
			end
		end
	end
end


function getStorey( obj )	
	if obj:GetParent().Type == "BuildingStorey" then
		return obj:GetParent()

	elseif obj:GetParent() :GetParent().Type == "BuildingStorey" then
		return obj:GetParent() :GetParent()

	elseif obj:GetParent() :GetParent() :GetParent().Type == "BuildingStorey" then
		return obj:GetParent() :GetParent() :GetParent()
	else
		return nil
	end
end


function projLongestLine( projection )
	local outerPrj = FXMeasure.GetOuterEdge( projection );
    local noOfEdgePnt = outerPrj:GetPointNumber();  
    local longestLine
    
    for i = 0, noOfEdgePnt -2, 1  do 
    	local pnt1  		    = outerPrj:GetPoint( i );
		local pnt2		 	    = outerPrj:GetPoint( i + 1 );
		local thisLine      	= Line3D( pnt1 , pnt2 );
		
		if longestLine == nil or longestLine:Length() < thisLine:Length() then
			longestLine = thisLine
		end
    end

    return longestLine
end


function getParallelAndNotLinesFromProjLines( line , projection )
	local outerPrj = FXMeasure.GetOuterEdge( projection );
    local noOfEdgePnt = outerPrj:GetPointNumber();  

    local nearestLine -- not parallel Line
    local dis

    local nearestLine1 -- parallel Line
    local dis1

     for i = 0, noOfEdgePnt -2, 1  do 
    	local pnt1  		    = outerPrj:GetPoint( i );
		local pnt2		 	    = outerPrj:GetPoint( i + 1 );
		local thisLine      	= Line3D( pnt1 , pnt2 );
		
		if FXUtility.IsParallel( line , thisLine ) == false then
			local nodeLine1 = FXUtility.CreateNodeFrom( line );
			local nodeLine2 = FXUtility.CreateNodeFrom( thisLine );
			local distance = FXMeasure.Distance ( nodeLine1 , nodeLine2 )
			FXClashDetection.DeleteNode( nodeLine1 );
			FXClashDetection.DeleteNode( nodeLine2 );

			if dis == nil or distance:Length() < dis then
				nearestLine = thisLine
				dis = distance:Length()
			end

		elseif FXUtility.IsParallel( line , thisLine ) then
			local nodeLine1 = FXUtility.CreateNodeFrom( line );
			local nodeLine2 = FXUtility.CreateNodeFrom( thisLine );
			local distance = FXMeasure.Distance ( nodeLine1 , nodeLine2 )
			FXClashDetection.DeleteNode( nodeLine1 );
			FXClashDetection.DeleteNode( nodeLine2 );

			if dis1 == nil or distance:Length() < dis1 then
				nearestLine1 = thisLine
				dis1 = distance:Length()
			end			
		end
    end

    return nearestLine , nearestLine1
end


function SetSamplePoint( StartPoint,EndPoint,MatrixUnitWidth)
	local SamplePoints = {};
	if(StartPoint~=nil and EndPoint~= nil) then
		local Line = EndPoint:Sub_Pnt(StartPoint);
		if(Line~=nil) then
			local LineVec = Vector(Line.x,Line.y,Line.z);
			if(LineVec ~= nil) then
				LineVec:Normalize();
				local SamplePointNumber = math.floor((Line3D(StartPoint,EndPoint):Length())/MatrixUnitWidth);
				if(SamplePointNumber ~= nil) then
					for i=0,SamplePointNumber-1 do
						SamplePoints[#SamplePoints+1] = StartPoint:Add_Vec(Vector(i*MatrixUnitWidth*LineVec.x,i*MatrixUnitWidth*LineVec.y,i*MatrixUnitWidth*LineVec.z))
					end
				end
			end
			SamplePoints.Vector = LineVec;
		end
	end
	return SamplePoints;
end


function lineClosestLine( line , arrLines )
	local closestDis
	local closestLine
	local x = 0 
	local pnt = FXUtility.CenterPoint( line:GetStartPoint() , line:GetEndPoint() )		

	while x < #arrLines do
		x = x + 1	
		local StartPoint = arrLines[x]:GetStartPoint() 
		local EndPoint =  arrLines[x]:GetEndPoint()

		local thisPnt = FXUtility.CenterPoint( StartPoint, EndPoint )
		local Distance = tonumber(pnt:Distance_Pnt( thisPnt ))

		if closestDis == nil or closestDis > Distance then
			closestDis	=  Distance
			closestLine	 = arrLines	[x]	
		end
	end

	return closestLine	
end


-- function SetLineLengthEqualToOtherLineLength( line1 , line2 )
-- 	local line1Length = line1 : Length()
-- 	local line2Length = line2 : Length()
-- 	local newLine

-- 	if line1Length > line2Length then
-- 		local dif = line1Length - line2Length
-- 		newLine = FXGFA.ShrinkageLine( line1 , dif/2 )

-- 	elseif line1Length < line2Length then
-- 		local dif = line2Length - line1Length
-- 		newLine = FXGFA.ShrinkageLine( line1 , - dif/2 )
-- 	end

-- 	return newLine
-- end


-- function isLineCollidedToLine( line1 , line2 )
-- 	local bool = false
-- 	local fatLine1 = FXMeasure.CreateFaceFromEdge( line1 , 100 );
-- 	local outerPrj1 = FXMeasure.GetOuterEdge( fatLine1 );
-- 	local newface1= outerPrj1:Face3D()
-- 	local extruded1 = newface1:ExtrudedFace(Vector(0, 0, 50));


-- 	local fatLine2 = FXMeasure.CreateFaceFromEdge( line2 , 100 );
-- 	local outerPrj2 = FXMeasure.GetOuterEdge( fatLine2 );
-- 	local newface2 = outerPrj2:Face3D()
-- 	local extruded2 = newface2:ExtrudedFace(Vector(0, 0, 50));

-- 	local node1 = FXUtility.CreateNodeFrom( extruded1 );
-- 	local node2 = FXUtility.CreateNodeFrom( extruded2 );

-- 	if FXClashDetection.IsCollided( node1 , node2 ) then
-- 		bool = true
-- 	end

-- 	FXClashDetection.DeleteNode( node1 );
-- 	FXClashDetection.DeleteNode( node2 );

-- 	return bool
-- end

-- function proj2LongestLine( projection )
-- 	local outerPrj = FXMeasure.GetOuterEdge( projection );
--     local noOfEdgePnt = outerPrj:GetPointNumber();  
--     local longestLine
--     local longestLine2
    
--     for i = 0, noOfEdgePnt -2, 1  do 
--     	local pnt1  		    = outerPrj:GetPoint( i );
-- 		local pnt2		 	    = outerPrj:GetPoint( i + 1 );
-- 		local thisLine      	= Line3D( pnt1 , pnt2 );
		
-- 		if longestLine == nil or longestLine:Length() < thisLine:Length() then
-- 			longestLine = thisLine
-- 		elseif longestLine:Length() == thisLine:Length() then
-- 			longestLine2 = thisLine
-- 		end

--     end

--     return longestLine , longestLine2
-- end


-- function createFaceFromEdgeToProj( createFace , elev )
-- 	local outerFace = FXMeasure.GetOuterEdge( createFace );
--   	local newFace = outerFace:Face3D()
--   	local extruded = newFace:ExtrudedFace(Vector(0, 0, 21));
--   	local node = FXUtility.CreateNodeFrom( extruded );
-- 	-- local box = FXGeom.GetBoundingBox( node )
-- 	local objproject = FXMeasure.GetObjProjection( node , elev )

-- 	FXClashDetection.DeleteNode( node );

	
-- 	return objproject
-- end
