
local STPGrp = FXGroup:new();
local systemTypes;
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_1_PROVISION_OF_SEWAGE_TREATMENT_PLANT")
     systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
   local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			STPGrp = STPGrp + v;
			STPGrp = STPGrp:Unique();				
		end
	end
end

function checkRule(Building)
	if #STPGrp ~= 0 then
		STPGrp:ForEach(function(STPGrpEle)
			if (FXUtility.HasPatterInString(STPGrpEle:GetAttri("Name"),"Sewage Treatment Plant")) then
				FXUtility.DisplaySolid_Info(STPGrpEle, STPGrpEle:GetAttri("Name") .. " is provided.")
			end
		end)
	else
		FXUtility.DisplaySolid_Error(Building, "Sewage treatment plant is not provided.")
	end
end
