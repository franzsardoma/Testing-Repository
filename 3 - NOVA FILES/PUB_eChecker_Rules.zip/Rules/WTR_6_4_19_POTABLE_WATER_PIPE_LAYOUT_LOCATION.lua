local grpPotablePipe = FXGroup.new()
local grpNonPotablePipe = FXGroup.new()
local grpAllPipes = FXGroup.new()
local systemTypes = {}
local isPotable
local isNonPotable

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType	("System");
	-- CheckEngine.BindCheckFunc   ("getSystem");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_4_19_POTABLE_WATER_PIPE_LAYOUT_LOCATION")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues0 = FXRule.ParseValues(parsedXml, "Condition1")
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition2")
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml,SystemTypes)

	isPotable = ConditionValues0[2]; -- for Condition Values 
	isNonPotable = ConditionValues1[2]; -- for Condition Values 

	for k,v in pairs(GrpObjs) do -- Checking in System
		if (k == 3) then
			grpAllPipes = grpAllPipes + v
			grpAllPipes = grpAllPipes:Unique()
		end	
	end
end


function CheckRule(Building)
	local isErrorFound = false
	local highestElevaion = FXPUB.GetHighestElevation( Building )
	local lowestElevation = GetLowestElevation ( Building )

	local grpSlab = Building:GetDescendants ("Slab")

	local grpUncompliantPotablePipes = FXGroup.new()
	local grpCompliantPotablePipes = FXGroup.new()

	grpAllPipes:ForEach ( function ( pipesObj )
		if FXUtility.HasPatterInString( pipesObj:GetAuxAttri("Mechanical.System Type") ,"Sanitary") and isNonPotable == "true" then
			grpNonPotablePipe : Add ( pipesObj )
		elseif FXUtility.HasPatterInString( pipesObj:GetAuxAttri("Mechanical.System Type") ,"Cold Water") and isPotable == "true" then
			grpPotablePipe : Add ( pipesObj )
		end
	end)

	-- if #grpPotablePipe == 0 or #grpNonPotablePipe == 0 then
	-- 	FXUtility.DisplaySolid_Warning( Building , "No System type Cold Water found.")
	-- end
	grpPotablePipe:ForEach ( function ( potablePipe )
		local grpCollidedSlab = FXGroup.new()
		local grpCollidedNonPotable = FXGroup.new()	
		local lowestCollidedSlabLowPos ;
----------------------------------------------------------------
		local grpCollidedSlabBelow = FXGroup.new()
		local grpCollidedNonPotableBelow = FXGroup.new()
		local HighestCollidedSlabHighPosBelow ; 
---------------------------------------------------------------------
		local pipeProjection = FXMeasure.GetObjProjection( potablePipe , FXGeom.GetBoundingBox ( potablePipe ):HighPos().z )
		local outerEdges = FXMeasure.GetOuterEdge( pipeProjection );
		local noOfPnts = outerEdges:GetPointNumber();
		local PlyLine = PolyLine3D(TRUE);

		for i = 1, noOfPnts -1, 1 do
			local pnt = outerEdges:GetPoint(i);
			PlyLine:AddPoint(pnt);
		end

		local face = PlyLine:Face3D()
		local extrudeFaceUp = face:ExtrudedFace(Vector(0,0, highestElevaion ));
		local pipeNode = FXUtility.CreateNodeFrom(extrudeFaceUp)

		local extrudeFaceDown = face:ExtrudedFace(Vector(0,0, lowestElevation ));
		local pipeNode2 = FXUtility.CreateNodeFrom(extrudeFaceDown)


		grpSlab:ForEach ( function ( slabObj )
			if FXClashDetection.IsCollided( pipeNode , slabObj) then
				grpCollidedSlab:Add( slabObj )
			end
			if FXClashDetection.IsCollided( pipeNode2 , slabObj) then
				grpCollidedSlabBelow:Add( slabObj )
			end
		end)

		grpNonPotablePipe:ForEach ( function ( nonPotablePipe )
			if FXClashDetection.IsCollided( pipeNode , nonPotablePipe ) then
				grpCollidedNonPotable:Add( nonPotablePipe )
			end
			if FXClashDetection.IsCollided( pipeNode2 , nonPotablePipe ) then
				grpCollidedNonPotableBelow:Add( nonPotablePipe )
			end
		end)

		FXClashDetection.DeleteNode(pipeNode)
		FXClashDetection.DeleteNode(pipeNode2)

		if #grpCollidedSlab > 0 then
			grpCollidedSlab:ForEach ( function ( colSlabObj )
				local lowPos = FXGeom.GetBoundingBox ( colSlabObj ) : LowPos().z
				if lowestCollidedSlabLowPos == nil or lowestCollidedSlabLowPos > lowPos then
					lowestCollidedSlabLowPos = lowPos
				end
			end)

		elseif #grpCollidedSlab == 0 and #grpCollidedNonPotable > 0 then
			isErrorFound = true
			grpUncompliantPotablePipes : Add ( potablePipe )
		end

	
		if #grpCollidedNonPotable > 0 then
			grpCollidedNonPotable:ForEach ( function ( colNonPotableObj )
				local pipeHighPos = FXGeom.GetBoundingBox( colNonPotableObj ) :HighPos().z

				if lowestCollidedSlabLowPos > pipeHighPos then
					isErrorFound = true
					grpUncompliantPotablePipes : Add ( potablePipe )
				else
					if #grpCollidedSlabBelow > 0 then
						grpCollidedSlabBelow : ForEach ( function ( slabBelow )
							local slabHighPos = FXGeom.GetBoundingBox ( slabBelow ) : HighPos().z
							if HighestCollidedSlabHighPosBelow == nil or slabHighPos > HighestCollidedSlabHighPosBelow then
								HighestCollidedSlabHighPosBelow = slabHighPos
							end
						end)

						if #grpCollidedNonPotableBelow > 0 then
							grpCollidedNonPotableBelow : ForEach ( function ( collidedObjBelow )
								local pipeBelowHighPos = FXGeom.GetBoundingBox ( collidedObjBelow ) : HighPos().z
								if HighestCollidedSlabHighPosBelow < pipeBelowHighPos then
									grpCompliantPotablePipes : Add ( potablePipe )
								end
							end)
						end
					else
						if #grpCollidedNonPotableBelow > 0 then
							grpCompliantPotablePipes : Add ( potablePipe )
						end
					end
					-- local extrudeFace = face:ExtrudedFace(Vector(0,0, highestElevaion ));
					-- local pipeNode = FXUtility.CreateNodeFrom(extrudeFace)
					-- grpCompliantPotablePipes : Add ( potablePipe)
					
				end
			end)
		elseif #grpCollidedNonPotable == 0 then
			if #grpCollidedSlabBelow > 0 then
				grpCollidedSlabBelow : ForEach ( function ( slabBelow )
					local slabHighPos = FXGeom.GetBoundingBox ( slabBelow ) : HighPos().z
					if HighestCollidedSlabHighPosBelow == nil or slabHighPos > HighestCollidedSlabHighPosBelow then
						HighestCollidedSlabHighPosBelow = slabHighPos
					end
				end)

				if #grpCollidedNonPotableBelow > 0 then
					grpCollidedNonPotableBelow : ForEach ( function ( collidedObjBelow )
						local pipeBelowHighPos = FXGeom.GetBoundingBox ( collidedObjBelow ) : HighPos().z
						if HighestCollidedSlabHighPosBelow < pipeBelowHighPos then
							grpCompliantPotablePipes : Add ( potablePipe )
						end
					end)
				end
			else
				if #grpCollidedNonPotableBelow > 0 then
					grpCompliantPotablePipes : Add ( potablePipe )
				end
			end
		end
	end)
	
	grpUncompliantPotablePipes = grpUncompliantPotablePipes:Unique()
	grpCompliantPotablePipes   = grpCompliantPotablePipes:Unique()

	if isErrorFound then
		grpUncompliantPotablePipes:ForEach(function ( obj )
			print ("1")
			FXUtility.DisplaySolid_Error( obj , "Potable water pipe is laid below the non-potable water pipe.")
		end)
	else
		if #grpCompliantPotablePipes > 0 then
			grpCompliantPotablePipes:ForEach(function ( obj )
				print ("2")
				FXUtility.DisplaySolid_Info( obj , "Potable water pipe is laid above the non-potable water pipe.")
			end)
		else
			FXUtility.DisplaySolid_Warning(Building , "No non-potable water pipe is laid above potable water pipe.")
		end
	end
end

function GetLowestElevation (Building)
	local lowestStoreyElevation
	local highestUpperStorey
	local lowestStorey 
	local storeys = Building:GetChildren("BuildingStorey")

	storeys:ForEach(function (storey)
		local above = #FXUtility.GetAllUpperStorey(storey)
		if highestUpperStorey == nil or above > highestUpperStorey then
			highestUpperStorey = above
			lowestStorey = storey
		end
	end)


	local buildingBOX = FXGeom.GetBoundingBox(lowestStorey)
	-- FXPUB.DisplayTest(storey,"buildingBOX", buildingBOX )
	local lowestStoreyElevation  = buildingBOX:LowPos().z

	return lowestStoreyElevation;
end