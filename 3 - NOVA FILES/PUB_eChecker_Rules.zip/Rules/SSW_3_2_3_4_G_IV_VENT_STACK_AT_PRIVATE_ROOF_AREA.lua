
local grpFlowSegment = FXGroup:new();
local roofSpacesGrp = FXGroup:new()
local ventSystemPipes = FXGroup:new()
local spaceGrp = FXGroup:new()
local ventStackTerminateInRoof = false;
local minHeight;
local collidedSpace;
local spaceName;
local pipeName;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_3_4_G_IV_VENT_STACK_AT_PRIVATE_ROOF_AREA")
	
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
    local bldgGrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 3) then
			grpFlowSegment = grpFlowSegment + v
			grpFlowSegment = grpFlowSegment:Unique()
		end
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				spaceProp = v1["property"];
				spaceValue = v1["value"];
			end
		end
	end

	for k,v in pairs(bldgGrpObjs) do
		if (k == 2) then
			spaceGrp = spaceGrp + v;
			spaceGrp = spaceGrp:Unique();		
		end
	end
	
end



function checkRule(Building)
	local BuildingStorey = Building:GetChildren("BuildingStorey")
	local HighestStorey;
	local ventPipeGrp =FXGroup:new();
	BuildingStorey:ForEach(function(storey)
		HighestStorey = storey;
	end)

	local ElevationStorey = HighestStorey:Elevation();
	local roofSlabs = HighestStorey:GetDescendants("Slab");
	local roofElement = FXGroup.new()
	roofSlabs:ForEach(function ( slab )
		local  slabParent = slab:GetParent()
		if FXUtility.HasPatterInString(slabParent:GetAttri("Name"), "Roof") or FXUtility.HasPatterInString(slab:GetAttri("Name"), "Roof") then
			roofElement:Add(slab)
		end
	end)

	spaceGrp:ForEach(function ( space )
		if FXUtility.HasPatterInString(space:GetAttri(spaceProp), spaceValue) then
			roofSpacesGrp:Add(space)
		end
	end)
	
	grpFlowSegment:ForEach(function ( ventPipe )
		if FXUtility.HasPatterInString(ventPipe:GetAttri("ObjectType"), "Vent") then
			ventPipeGrp:Add(ventPipe)
		end
	end)
	local isCompliant = true;
	local collidedPipe;
	local ArrPipe = {};
	local ArrPipeObj= {};
	local ArrPipeHeight= {};
	local ArrArrowGeom = {};
	local ArrCollidedSpace= {};
	local i = 0;
	local ventStackTerminateInRoof = false;

	if #roofSpacesGrp ~= 0 then
		if #grpFlowSegment ~= 0 then
			if #roofElement ~= 0 then
				grpFlowSegment:ForEach(function ( pipe )
					roofElement:ForEach(function ( roof )
						if FXClashDetection.IsCollided(pipe, roof) then
							ventStackTerminateInRoof = true; 
						end
					end)
				end)
			end
			roofSpacesGrp:ForEach(function ( space )
				grpFlowSegment:ForEach(function ( pipe )	
					pipeObj = pipe:GetAttri("ObjectType")
					if FXClashDetection.IsCollided(pipe, space) then
						isCompliant = false;
						FXUtility.DisplaySolid_Error(space, pipeObj .. " found within Private Roof Balcony.");
						CheckReport.AddRelatedObj( pipe, pipeObj)
					else
						i = i + 1
						ArrPipe[i] = pipe;
						ArrPipeObj[i] = pipeObj
						ArrCollidedSpace[i] = space
					end

					if ventStackTerminateInRoof == false and isCompliant == true then
						FXUtility.DisplaySolid_Warning(pipe, MSG_VENT_STACK_TERMINATE)
					end
				end)	
			end)

			if ventStackTerminateInRoof == true and isCompliant == true  then
				FXUtility.DisplaySolid_Info(ArrCollidedSpace[i], " No Vent Pipes found within Private Roof Balcony.");
			end
		else
			FXUtility.DisplaySolid_Warning(Building, MSG_NO_VENT_STACK)
		end		
	else
		FXUtility.DisplaySolid_Warning(Building, " No Private Roof found.")
	end
end

-- function CheckResult(Building, isCompliant, pipeObj, pipe, collidedSpace, spaceName)

-- 	if isCompliant then
-- 		FXUtility.DisplaySolid_Info(collidedSpace, "No Vent Pipes found within Private Roof Balcony.");
-- 		-- CheckReport.AddRelatedObj( collidedSpace, spaceName )
-- 	else
-- 		FXUtility.DisplaySolid_Error(collidedSpace, pipeObj .. " found within Private Roof Balcony.");
-- 		-- CheckReport.AddRelatedObj( collidedSpace, spaceName )
-- 		CheckReport.AddRelatedObj( pipe, pipeObj)
-- 	end
-- end

