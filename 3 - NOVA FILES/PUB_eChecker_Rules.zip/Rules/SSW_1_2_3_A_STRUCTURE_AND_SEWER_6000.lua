local grpPipeSegment 	= FXGroup:new();
local minimumdist 	--= 6000;
local grpPipes 		= FXGroup:new();


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local Project = Building:GetParent():GetParent()
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_3_A_STRUCTURE_AND_SEWER_6000")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	minimumdist = tonumber(ConditionValues[2])

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpPipeSegment = grpPipeSegment + v;
				grpPipeSegment = grpPipeSegment:Unique();
			end
		end
	end

	if GrpObjs ~= nil then
		grpBldgObj = FXPUB.GetElementtype2InAdvisoryNote( Project, tblValues, GrpObjs )
	end
end

function checkRule(Building)

	if #grpBldgObj == 0 then
		FXUtility.DisplaySolid_Warning(Building, NO_BLDG);
		return;
	end
	-- Bridge Scenario ------------------------------------
	local bridgeSlabs = FXGroup.new();
	local excludedObjGrp = FXGroup.new();
	local slabGrp = Building:GetDescendants("Slab")
	slabGrp:ForEach(function(slab)
		if FXUtility.HasPatterInString(slab:GetAttri("Name"), "Bridge") then
			-- bridgeSlabs:Add(slab);
			excludedObjGrp:Add(slab);
			print("excludedObjGrp " .. #excludedObjGrp)
			local storey = slab:GetParent();
			excludedObjGrp = excludedObjGrp + storey:GetChildren("Railing") + storey:GetChildren("Beam") -- railing and beam for now
		end
	end)
	grpBldgObj = grpBldgObj - excludedObjGrp
	-------------------------------------------------------


	local bldgMaxPnt = FXPUB.GetHighestElevation(Building)

	if #grpPipeSegment == 0 then
		FXUtility.DisplaySolid_Warning(Building,"No DTSS found.");
		return;
	end
	grpPipeSegment:ForEach(function(pipe)
		-- 3) Check the lateral distance
					local invertLevelElevation = FXPUB.GetInvertElevation(pipe)
		-- local invertLevelElevation = tonumber(pipe:GetAuxAttri("Mechanical.Invert Elevation"))
		local prjBldg = FXMeasure.GetProjection(grpBldgObj, invertLevelElevation);
		local pipePrj = FXMeasure.GetProjection(grpPipes,invertLevelElevation) -- gas and water pipes
		if pipePrj ~= nil then
			prjBldg = FXMeasure.MergeTwoProjection(prjBldg, pipePrj, invertLevelElevation);
		end

		local dist, centerLine = FXPUB.GetLateralDistance_master(pipe, prjBldg)
		local distLength = FXUtility.Round(dist:Length())

		local arrowGeom = DoubleArrow(dist:GetStartPoint(),dist:GetEndPoint());
		local pipeDiam = FXPUB.GetDiameter(pipe)
		local msg = string.format(ADV_RESULT_NO_DEPTH, distLength, pipe:GetAttri("ObjectType"), pipeDiam)
			local pipeDiam = FXPUB.GetDiameter(pipe)  
		minimumdist = minimumdist + (pipeDiam/2) 
		if( distLength >= minimumdist ) then
			local faceA = FXPUB.CreateBox(pipe,dist, centerLine, bldgMaxPnt);
					-- local faceA = CreateBox(pipe,dist, centerLine, bldgMaxPnt);

			if faceA ~= nil then
				FXUtility.DisplaySolid_Info(pipe, msg, prjBldg); 
				CheckReport.AddRelatedGeometry_Info(arrowGeom, msg)
				CheckReport.AddRelatedGeometry_Wire(faceA, msg)
			end
		else
			if distLength < 10 then
				FXUtility.DisplaySolid_Error(pipe, msg, prjBldg); 
			elseif distLength < 50 then
				FXUtility.DisplaySolid_Error(pipe, msg, prjBldg); 
				CheckReport.AddRelatedGeometry_Error(arrowGeom, msg)
			else
				local faceA = FXPUB.CreateBox(pipe,dist,centerLine, bldgMaxPnt);
					-- local faceA = CreateBox(pipe,dist, centerLine, bldgMaxPnt);
				
				FXUtility.DisplaySolid_Error(pipe, msg, prjBldg); 
				CheckReport.AddRelatedGeometry_Error(arrowGeom, msg)
				CheckReport.AddRelatedGeometry_Wire(faceA, msg)
			end
		end
	end)
end
