local grpDrainageCurve = FXGroup:new()
local grpDrainageChannel = FXGroup:new()
local width;
local triple;
local isCompliant = true;
local arrObj = {}
local arrObj1 = {}
local arrObj2 = {}
local arrObj3 = {}
local arrObj4 = {}
local arrObj5 = {}


function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("Building");
	-- CheckEngine.BindCheckFunc("CheckRuleforDrainage");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_3_1_MINIMUM_RADIUS_OF_DRAIN_CURVE")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	triple = ConditionValues[2];
	if GrpObjSystem ~= nil then
		for k,v in pairs(GrpObjSystem) do
			if (k == 2) then
				grpDrainageCurve = grpDrainageCurve + v
				grpDrainageCurve = grpDrainageCurve:Unique()
			end
			if (k == 3) then
				grpDrainageChannel = grpDrainageChannel + v
				grpDrainageChannel = grpDrainageChannel:Unique()
			end
		end
	else
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpDrainageCurve = grpDrainageCurve + v
				grpDrainageCurve = grpDrainageCurve:Unique()
			end
			if (k == 3) then
				grpDrainageChannel = grpDrainageChannel + v
				grpDrainageChannel = grpDrainageChannel:Unique()
			end
		end
	end
end

-- function CheckRuleforDrainage(Building)
-- 	local BuildingElement = Building:GetDescendants("FlowSegment");
-- 	local ftngs = Building:GetDescendants("FlowFitting");

-- 	BuildingElement:ForEach(function(ele)
-- 		local name = ele:GetAttri("Name")
-- 		if FXUtility.HasPatterInString(name,"Drain Channel") then
-- 			grpDrainageChannel:Add(ele)
-- 		end
-- 		-- if FXUtility.HasPatterInString(name,"Drain Channel Bend") then
-- 		-- 	grpDrainageCurve:Add(ele)
-- 		-- end
-- 	end)

-- 	ftngs:ForEach(function( ftng )
-- 		local name = ftng:GetAttri("Name")
-- 		if FXUtility.HasPatterInString(name,"Drain Channel Bend") then
-- 			grpDrainageCurve:Add(ftng)
-- 		end
-- 	end)
-- end

function CheckRule(Building)
	if #grpDrainageChannel == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Drainage Channel is not detected.")
	else
		if #grpDrainageCurve ~= 0 then
			local tempObj;
			local pnt1;
			local pnt2;
			local sumpWidth;
			local i = 0;
			grpDrainageChannel:ForEach(function(channel)
				local cntrLine = FXMeasure.GetProjectionCenterLine(channel)
				pnt1 = cntrLine:GetStartPoint();
				pnt2 = cntrLine:GetEndPoint();

				if pnt1.y == pnt2.y then
					tempObj = channel;
				else
					if pnt1.x == pnt2.x then
						tempObj = channel;
					end
				end
				-- FXUtility.DisplaySolid_Info(channel,"Center Line",cntrLine)
			end)
			if tempObj ~= nil then
				local box = FXGeom.GetBoundingBox(tempObj);

				if box:x_range() > box:y_range() then
					local Line = ShrinkFaced(box,tempObj)
					sumpWidth = math.floor(FXUtility.Round(Line:Length()))
					local arrow = DoubleArrow(Line:GetStartPoint(),Line:GetEndPoint())
					-- FXUtility.DisplaySolid_Info(tempObj,tempObj:GetAttri("Name").." Width: "..sumpWidth.."mm",arrow)
				else
					if box:y_range() > box:x_range() then
						local Line = ShrinkFaced(box,tempObj)
						sumpWidth = math.floor(FXUtility.Round(Line:Length()))
						local arrow = DoubleArrow(Line:GetStartPoint(),Line:GetEndPoint())
						-- FXUtility.DisplaySolid_Info(tempObj,tempObj:GetAttri("Name").." Width: "..sumpWidth.."mm",arrow)
					end
				end

				grpDrainageCurve:ForEach(function(bend)
					if FXClashDetection.IsCollided(bend,tempObj) then
						local topFace = FXMeasure.GetTopFace(bend);
						local outer1 = FXMeasure.GetOuterEdge(topFace);
						local points = FXMeasure.GetCenterPointsOfPolygon(topFace,0)
						local Radius = (FXMeasure.GetOuterRadiusOfCircle(topFace,0,0))
						local Line = GetLongestLine(outer1);
						
						local Pnt1 = Point3D(Line:GetStartPoint().x, Line:GetStartPoint().y, Line:GetStartPoint().z+500);
						local Pnt3 = Point3D(points.x, points.y, points.z+500);
						local Pnt2 = Point3D(Line:GetEndPoint().x, Line:GetEndPoint().y, Line:GetEndPoint().z)

						local PlyLine  = PolyLine3D(TRUE);
						PlyLine:AddPoint(Line:GetStartPoint());
						PlyLine:AddPoint(Pnt1);
						PlyLine:AddPoint(Pnt3);
						PlyLine:AddPoint(points);

						local distance = math.floor(Pnt3:Distance_Pnt(Pnt1));
						local dArrow = DoubleArrow(Pnt3,Pnt1)

						width = math.floor(sumpWidth * triple);
						local tolerance = FXPUB.GetTolerance(width,distance)
						if distance < width then
							if tolerance then
								i = i + 1;
								arrObj[i] = bend;
								arrObj1[i] = tempObj;
								arrObj2[i] = width;
								arrObj3[i] = distance;
								arrObj4[i] = dArrow;
								arrObj5[i] = PlyLine;

							else
								isCompliant = false;
								FXUtility.DisplaySolid_Error(bend," Width: "..sumpWidth.." mm".."; Radius: "..distance.." mm",dArrow)
								CheckReport.AddRelatedGeometry_Error(PlyLine);
							end
						else
							if distance >= width then
								i = i + 1;
								arrObj[i] = bend;
								arrObj1[i] = tempObj;
								arrObj2[i] = sumpWidth;
								arrObj3[i] = distance;
								arrObj4[i] = dArrow;
								arrObj5[i] = PlyLine;
							end
						end
					end
				end)
			end
			if isCompliant then
				for k,bend in pairs(arrObj) do
					FXUtility.DisplaySolid_Info(bend," Width: "..arrObj2[k].." mm".."; Radius: "..arrObj3[k].." mm",arrObj4[k]);
					CheckReport.AddRelatedGeometry_Solid(arrObj5[k])
				end
			end
		else
			FXUtility.DisplaySolid_Warning(Building,"Drainage Channel Bend is not provided.")
		end
	end
end

function GetShortestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() >= Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetLongestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function ShrinkFaced(box,tempObj)
	local zPoint = box:HighPos().z;
	local channelProj = FXMeasure.GetObjProjection(tempObj,zPoint);

	local edges = FXMeasure.GetOuterEdge(channelProj);
	local face = edges:Face3D();
	local shrinkFace;

	local adder = 0
	while adder ~= 10000 do
		adder = adder + .2
		shrinkFace = FXMeasure.ShrinkFace( face , adder )
		-- local shrinkedEdges = FXMeasure.GetOuterEdge( shrinkFace )
		-- local shrinkedEdgesToFace = shrinkedEdges:Face3D()
		-- local extruded = shrinkedEdgesToFace:ExtrudedFace(Vector(0, 0, 5));
		local node = FXUtility.CreateNodeFrom( shrinkFace )

		if FXClashDetection.IsCollided( node , tempObj ) == false then
			break;
		end
		FXClashDetection.DeleteNode(node)
	end
	local outer = FXMeasure.GetOuterEdge(shrinkFace)
	local Line = GetShortestLine(outer);

	return Line;
end