
local FSegment = FXGroup:new()
local grpCheckableObjs = FXGroup:new()

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_1_5_PROHIBITED_LOCATIONS_FOR_WATER_SUPPLY_PIPE")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjsBuilding) do
		
		if (k == 3) then
			grpCheckableObjs = grpCheckableObjs + v;
			grpCheckableObjs = grpCheckableObjs:Unique();
		end
	end
	for k,v in pairs(GrpObjsSystem) do
		if (k == 2) then
			FSegment = FSegment + v;
			FSegment = FSegment:Unique();
		end
		
	end
end

function checkRule(Building)
	-- Get All pipes except Sewer
	local grpPipe = FXGroup:new()
	FSegment:ForEach(function(Element)
		local test = Element:GetAttri("Name")
		if FXUtility.HasPatterInString(test,"Sewer") == false then
			grpPipe:Add(Element)
		end
	end)

	local flagCompliant = true
	local grpComplaints = FXGroup:new()

	grpCheckableObjs:ForEach(function ( CheckableObj )
		local flag = true
		local grpNonCompliantObj = FXGroup:new()
		local node = FXClashDetection.CreateNode()
		-- Get all refuse chute and make it node
		if FXUtility.HasPatterInString(CheckableObj:GetAttri("Name"),"Refuse Chute") then
			local RCTopface = FXMeasure.GetTopFace(CheckableObj)
			theBOX = RCTopface:ExtrudedFace(Vector(0,0,-(FXGeom.GetBoundingBox(CheckableObj):HighPos().z - FXGeom.GetBoundingBox(CheckableObj):LowPos().z)));
			node = FXUtility.CreateNodeFrom(theBOX);
			
		end
		
		--check if pipe is collided to node or CheckableObj
		grpPipe:ForEach(function ( Pipe )

			if FXClashDetection.IsCollided(node,Pipe) then
 				flag = false
 				grpNonCompliantObj:Add(Pipe)
 			elseif FXClashDetection.IsCollided(CheckableObj,Pipe) then
 					flag = false
 				grpNonCompliantObj:Add(Pipe)
 	 		end
		end)
		FXClashDetection.DeleteNode(node);


		if(flag == true) then
			grpComplaints:Add(CheckableObj)
		else
			flagCompliant = false
			local ObjName;
			if FXUtility.HasPatterInString(CheckableObj:GetAttri("Description"),"Sewer") then
				ObjName = CheckableObj:GetAttri("Description")
			else
				ObjName = CheckableObj:GetAttri("Name")
			end
			FXUtility.DisplaySolid_Error(CheckableObj,"Water supply pipe is located inside "..ObjName);
			grpNonCompliantObj:ForEach(function ( Element )
				CheckReport.AddRelatedObj(Element, Element:GetAttri("Name"))	
			end)
		end
	end)

	if flagCompliant == true then
		grpComplaints:ForEach(function ( ComEle )
			local ObjName;
			if FXUtility.HasPatterInString(ComEle:GetAttri("Description"),"Sewer") then
				ObjName = ComEle:GetAttri("Description")
			else
				ObjName = ComEle:GetAttri("Name")
			end


			
			FXUtility.DisplaySolid_Compliant(ComEle,"No water supply pipe in "..ObjName);
		end)
	end
	
end