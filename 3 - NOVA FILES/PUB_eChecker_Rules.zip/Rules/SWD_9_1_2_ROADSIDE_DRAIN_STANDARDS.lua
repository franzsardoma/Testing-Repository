local Roadside = FXGroup.new()
local Weephole = FXGroup:new()
local falseBottom = FXGroup:new()
local rsCondi
local equals1
local fbCondi

function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_1_2_ROADSIDE_DRAIN_STANDARD")
    local GrpObjs = FXRule.filterObjects(parsedXml, Building)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")
    local Condition2 = FXRule.ParseValues(parsedXml, "Condition2")


	rsCondi = tostring(Condition1[1])
	fbCondi = tonumber(Condition2[3])
	
	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if ( k == 2 ) then

				Roadside = Roadside + v
				Roadside = Roadside:Unique()
			end
			if ( k == 3 ) then

				Weephole = Weephole + v
				Weephole = Weephole:Unique()
			end	
			if ( k == 4 ) then

				falseBottom =  falseBottom + v
				falseBottom = falseBottom:Unique()
			end
		end
	end
end

function CheckRule(Building)

	local roadsideArr = {}
	local falsebottomArr = {}
	local weepholeArr = {}
	local isCompliant = true
	local notCollided = true
	local roadsideGrp
	local weepholeGrp
	local falsebottomGrp
	local distance
	local doubleArrow

	if CheckWarning(Building) then

	-- Minimum C28/35 concrete is to be used for drain
	-- Provision of 75mm dia. weepholes at 1000mm; center to center; staggered
	-- Provision of false bottom hardcore with 300mm depth
	-- Swan neck outlet is proposed to be connected  to an internal drain/sump before discharging into roadside drain*	
		Roadside:ForEach(function(roadsideEle)
			
			local lowRoad = FXGeom.GetBoundingBox(roadsideEle):LowPos().z
			local Material = FXPUB.CheckObjMaterial(roadsideEle,rsCondi)

			if ( Material ~= nil ) then

				if ( Material == rsCondi ) then

					isCompliant = true
					roadsideGrp = roadsideEle
				else

					isCompliant = false
					FXUtility.DisplaySolid_Warning(roadsideEle,roadsideEle:GetAttri("Name").. ";" ..roadsideEle:GetAuxAttri("Material.layer.O.material"))
				end
			else

				isCompliant = false
				FXUtility.DisplaySolid_Warning(roadsideEle,"Material is not provided")
			end

			if (#Weephole ~= 0) then
				
				local projection = FXMeasure.GetObjProjection(roadsideEle,lowRoad)
				local outerEdge = FXMeasure.GetOuterEdge(projection)
				local LINES = GetLines(outerEdge)

				for k,Line in pairs(LINES) do
						
					local extended = FXMeasure.CreateFaceFromEdge(Line, 100);
					local outerEdge2 = FXMeasure.GetOuterEdge(extended)
					local face = outerEdge2:Face3D();
					local extrudeFace = face:ExtrudedFace(Vector(0,0,FXGeom.GetBoundingBox(roadsideEle):HighPos().z - lowRoad));
					-- FXUtility.DisplaySolid_Info(roadsideEle, "asadas",extrudeFace)	
					local groupA = FXGroup.new()
					local extrueNode = FXUtility.CreateNodeFrom(extrudeFace)
			
					Weephole:ForEach(function(weepholeEle)
							
						if FXClashDetection.IsCollided(weepholeEle,extrueNode) then
									groupA:Add(weepholeEle)
						end
					end)

					FXClashDetection.DeleteNode(extrueNode)	

					print(#groupA)
					groupA:ForEach(function(aEle)

						local aMid = Point3D(FXGeom.GetBoundingBox(aEle):MidPos().x, FXGeom.GetBoundingBox(aEle):MidPos().y, FXGeom.GetBoundingBox(aEle):LowPos().z) 
						local atempMid = aMid

						while true do

							atempMid = atempMid:Add_Vec(Vector(0,0,1))
							local aline1 = Line3D(aMid, atempMid)
							local aline2
							local aNode = FXUtility.CreateNodeFrom(aline1)

								-- if FXClashDetection.IsCollided(aNode,weepholeEle) then

								-- 	aline2 = aline1
								-- 	aMid = Point3D(aMid.x, aMid.y, aMid.z) 
								-- 	break
								-- 	FXClashDetection.DeleteNode(aNode)
								-- end

							FXClashDetection.DeleteNode(aNode)
						end
							
						-- interval = aMid:Distance_Pnt(atempMid)  --when getting the distance point to point 
						-- doubleArrow2 = DoubleArrow(aMid, atempMid)

						-- if (interval == whCondi) then

						-- 	isCompliant = true
						-- 	weepholeGrp = aEle
						-- else

						-- 	isCompliant = false
						-- 	FXUtility.DisplaySolid_Error(roadsideEle,weepholeEle:GetAttri("Name").." interval: "..interval.." mm")
						-- 	CheckReport.AddRelatedGeometry_Error(doubleArrow, "Arrow3D")
						-- end							
					end)
					
	
				end
			end

			if (#falseBottom ~= 0) then

				falseBottom:ForEach(function(falboEle)

					if ( FXClashDetection.IsCollided(roadsideEle, falboEle) ) == true then	

						local fbLow = Point3D(FXGeom.GetBoundingBox(falboEle):MidPos().x, FXGeom.GetBoundingBox(falboEle):MidPos().y, FXGeom.GetBoundingBox(falboEle):LowPos().z + 1) 
						local fblowTemp = fbLow

						while true do

							fblowTemp = fblowTemp:Add_Vec(Vector(0,0,1))
							local line1 = Line3D(fbLow, fblowTemp)
							local line2
							local Node = FXUtility.CreateNodeFrom(line1)

							if FXClashDetection.IsCollided(Node,roadsideEle) then

								line2 = line1
								fbLow = Point3D(fbLow.x, fbLow.y, fbLow.z - 1) 
								break
								FXClashDetection.DeleteNode(Node)
							end

							FXClashDetection.DeleteNode(Node)
						end
										
						distance = fbLow:Distance_Pnt(fblowTemp)
						doubleArrow = DoubleArrow(fbLow, fblowTemp)

						if (distance == fbCondi) then

							isCompliant = true
							falsebottomGrp = falboEle
						else

							isCompliant = false
							FXUtility.DisplaySolid_Error(roadsideEle,falboEle:GetAttri("Name").." depth: "..distance.." mm")
							CheckReport.AddRelatedGeometry_Error(doubleArrow, "Arrow3D")
						end

						notCollided = false
					end

					if notCollided then
						
						isCompliant = false
						FXUtility.DisplaySolid_Error(roadsideEle,"False Bottom is not provided")
					end
				end)
			end
		end)

		if isCompliant then

			table.insert(roadsideArr,roadsideGrp)
			-- table.insert(weepholeArr,falsebottomGrp)
			table.insert(falsebottomArr,falsebottomGrp)
		end	

		if isCompliant then

			for k=1, #roadsideArr do

				FXUtility.DisplaySolid_Info(roadsideArr[k], "Material: "..roadsideArr[k]:GetAuxAttri("Material.Layer.0.material").."; "..falsebottomArr[k]:GetAttri("Name")..": "..distance.."mm")
				-- CheckReport.AddRelatedObj(roadsideArr[k], falsebottomArr[k]:GetAttri("Name"))
				-- CheckReport.AddRelatedObj(falsebottomArr[k], falsebottomArr[k]:GetAttri("Name"))
				-- CheckReport.AddRelatedGeometry_Solid(doubleArrow2, "Arrow3D")
				CheckReport.AddRelatedGeometry_Solid(doubleArrow, "Arrow3D")
			end
		end	
	end
end

function CheckWarning( Building )

	local Warning = true

	if (#Roadside == 0) then
		FXUtility.DisplaySolid_Warning(Building,"FlowSegment is not provided")	
		Warning = false
	end

	return Warning
end

function GetLines( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local lines = {};

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		table.insert(lines, Line)
	end
	return lines;
end

function getFaceFromEdge( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local PlyLine  = PolyLine3D(TRUE);

	PlyLine:AddPoint(outerEdge:GetPoint(0));
	PlyLine:AddPoint(outerEdge:GetPoint(1));
	PlyLine:AddPoint(outerEdge:GetPoint(2));
	PlyLine:AddPoint(outerEdge:GetPoint(3));
	PlyLine:ClosePolyline();

	local face = PlyLine:Face3D();
	return face;
end