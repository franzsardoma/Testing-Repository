--[[-----------------------------------------------------

Author: Mike Agustin 
Co-Author: Derick Pauig

Rule ID: WTR Figure 8,9,10 Space Provision 
Rule Name: Space provision for 15 mm water meter 

All copyrights to novasolutions 
--]]-----------------------------------------------------
local groupStopCock = FXGroup:new()
local groupWaterMeter = FXGroup:new()
local groupSubMeter = FXGroup:new()
local groupServiceDuct = FXGroup:new()
local allowedSpaceProvision = 200
local isErrorFound = false
local comTerminalArr = {}
local comStoreyArr = {}
local comResultArr = {}
local comArrowArr = {}
local comPolyArr = {}
local x = 0

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("MakeGroupUnique")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("CheckRuleScenario1")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("CheckRuleScenario2n3")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("DisplayCom")
	CheckEngine.RunCheckPipeline()
end


function script_path()	
	local var = FX_PATH.ConfigPath()
	return string.gsub(var,"\\Rules","")
	
	-- for debug only
	-- local str = debug.getinfo(2, "S").source:sub(2)
	-- local str2 = string.gsub(str,str:match("^.*/(.*).lua$")..".lua","")
	-- local str3 = string.gsub(str2,"/Rules","")
	-- return string.gsub(str3,"/","\\")	
end 


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
  -- print("LUA " .. path())
  local parsedXml = FXPUB.ParseXml(path(), "WTR_8_9_10_SPACE_PROVISION")

  local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
  -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
  -- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
  -- for k,v in pairs(tbl) do
  --  if k == 5 then
  --    tblSpace = v
  --  end
  -- end
  local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
  local xmlObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
  for k,v in pairs(xmlObjs1) do -- get the model objects
    if k == 3 then
      groupWaterMeter = groupWaterMeter + v
      groupWaterMeter = groupWaterMeter:Unique()      
    end    
    if k == 4 then
      groupSubMeter = groupSubMeter + v
      groupSubMeter = groupSubMeter:Unique()      
    end    
    if k == 5 then
      groupStopCock = groupStopCock + v
      groupStopCock = groupStopCock:Unique()      
    end    
  end
  local xmlObjs = FXRule.filterObjects(parsedXml, Building);
  for k,v in pairs(GrpBuildingObjs) do -- get the model objects
	    if k == 2 then
	      groupServiceDuct = groupServiceDuct + v
	      groupServiceDuct = groupServiceDuct:Unique()      
	    end    
  end
	
end


function GetStopCock(element)
	local name = element:GetAuxAttri("Entity.ObjectType");
	local stopCock = nil	
	if (FXUtility.HasPatterInString(name, "STOPCOCK")) then
		local elementGlobalId = element:GetAttri("GlobalId");	    
		groupStopCock:Filter(function(control)		
			local controlGlobalId = control:GetAttri("GlobalId");
			if (FXUtility.HasPatterInString(controlGlobalId, elementGlobalId)) then
				stopCock = control;			
			end	
		end)
	else
		local elements = element:GetConnectedElement();	    
		elements:ForEach(function(item)		
			local itemName = item:GetAuxAttri("Entity.ObjectType");
			if (FXUtility.HasPatterInString(itemName,"STOPCOCK")) then
				groupStopCock:Filter(function(sc)		
					local itemGlobalId = item:GetAttri("GlobalId");
					local scGlobalId = sc:GetAttri("GlobalId");
					if (FXUtility.HasPatterInString(scGlobalId, itemGlobalId)) then
						stopCock = sc;			
					end	
				end)		
			end	
		end)
    end	

    if (stopCock == nil) then
		print("No Stopcock found.")
		FXUtility.DisplaySolid_Warning(BuildingStorey, "No Stopcock found.")
	end

	return stopCock;
end


function GetSegmentDirectlyConnectedPubMain(element)
	local elementGlobalId = element:GetAttri("GlobalId");	
	local targetSegment = nil;
	local fittings = element:GetConnectedFitting();
	fittings:ForEach(function(fitting)		
		local segments = fitting:GetConnectedSegment();	
		segments:ForEach(function(segment)
			local segmentGlobalId = segment:GetAttri("GlobalId");
			if (FXUtility.HasPatterInString(segmentGlobalId, elementGlobalId) == false) then
				targetSegment = segment;			
			end	
		end)	
	end)	
	return targetSegment;
end


function GetRelatedElements(terminal)
	local element1 = nil
	local element2 = nil	
	local elements = terminal:GetConnectedElement();
	elements:ForEach(function(elem)				    						
		if(element1 == nil) then				    				    					
			element1 = elem; 
		else					
			element2 = elem;
		end
	end)
	return element1, element2;
end


function CheckSpaceProvision(storey, terminal, element1, element2)
	local distance = FXMeasure.Distance(element1, element2);
	local pnt1 = distance:GetStartPoint()
	local pnt2 = distance:GetEndPoint()
	local newpnt1 = Point3D(pnt1.x,pnt1.y,pnt1.z + 100)
	local newpnt2 = Point3D(pnt2.x,pnt2.y,pnt2.z + 100)
	local arrowGeom = DoubleArrow(newpnt1, newpnt2);
	local result = FXUtility.Round(distance:Length());
	local plyline = PolyLine3D(TRUE);
	plyline:AddPoint(distance:GetStartPoint())
	plyline:AddPoint(newpnt1)
	plyline:AddPoint(newpnt2)
	plyline:AddPoint(distance:GetEndPoint())

	local line1 = Line3D(pnt1,distance:GetStartPoint()) local line2 =
	Line3D(pnt2,distance:GetEndPoint())
	
	if result == allowedSpaceProvision then				
		FXUtility.DisplaySolid_Info(storey, result.." mm ; "..terminal:GetAuxAttri("Entity.ObjectType"));
		CheckReport.AddRelatedObj(terminal, terminal:GetAuxAttri("Entity.ObjectType"));	
		CheckReport.AddRelatedGeometry_Solid(arrowGeom, result);
		CheckReport.AddRelatedGeometry_Solid(plyline);			
	else				
		FXUtility.DisplaySolid_Error(storey, result.." mm ; "..terminal:GetAuxAttri("Entity.ObjectType"));
		CheckReport.AddRelatedObj(terminal, terminal:GetAuxAttri("Entity.ObjectType"));	
		CheckReport.AddRelatedGeometry_Error(arrowGeom, result);
		CheckReport.AddRelatedGeometry_Error(plyline);					
	end	
end
function CheckSpaceProvision2n3(storey, terminal, element1, element2, pnt1, pnt2)
	local distance = FXMeasure.Distance(element1, element2);
	local arrowGeom = DoubleArrow(pnt1, pnt2);
	local result = FXUtility.Round(distance:Length());
	local plyline = PolyLine3D(TRUE);
	plyline:AddPoint(distance:GetStartPoint())
	plyline:AddPoint(pnt1)
	plyline:AddPoint(pnt2)
	plyline:AddPoint(distance:GetEndPoint())

	local line1 = Line3D(pnt1,distance:GetStartPoint())
	local line2 = Line3D(pnt2,distance:GetEndPoint())
	
	if result == allowedSpaceProvision then				
		x = x + 1
		comStoreyArr[x] = storey
		comResultArr[x] = result
		comTerminalArr[x] = terminal
		comArrowArr[x] = arrowGeom
		comPolyArr[x] = plyline		
	else				
		FXUtility.DisplaySolid_Error(storey, result.." mm ; "..terminal:GetAuxAttri("Entity.ObjectType"));
		CheckReport.AddRelatedObj(terminal, terminal:GetAuxAttri("Entity.ObjectType"));	
		CheckReport.AddRelatedGeometry_Error(arrowGeom, result);
		CheckReport.AddRelatedGeometry_Error(plyline);					
	end	
end


function CheckRuleScenario2n3(BuildingStorey)	
	if(#groupSubMeter ~= 0) then
		groupSubMeter:ForEach(function(sm)			
			local element1, element2 = GetRelatedElements(sm);
			local controller1 = GetStopCock(element1);			
			local controller2 = GetStopCock(element2);
			local obbC1 = FXGeom. GetBoundingBox(controller1);
			local obbC2 = FXGeom. GetBoundingBox(controller2);
			local distance = FXMeasure.Distance(controller1, controller2);
			local newPnt1
			local newPnt2
			if (controller1 ~= nil and controller2 ~= nil) then						
				if obbC1:y_range() > obbC1:x_range() then
					if distance:GetStartPoint().y > 0 then
						newPnt1 = Point3D(distance:GetStartPoint().x,obbC1:HighPos().y,distance:GetStartPoint().z)
						newPnt2 = Point3D(distance:GetEndPoint().x,obbC2:HighPos().y,distance:GetEndPoint().z)
					else
						newPnt1 = Point3D(distance:GetStartPoint().x,obbC1:LowPos().y,distance:GetStartPoint().z)
						newPnt2 = Point3D(distance:GetEndPoint().x,obbC2:LowPos().y,distance:GetEndPoint().z)
					end
				else
					if distance:GetStartPoint().x > 0 then
						newPnt1 = Point3D(obbC1:HighPos().x,distance:GetStartPoint().y,distance:GetStartPoint().z)
						newPnt2 = Point3D(obbC2:HighPos().x,distance:GetEndPoint().y,distance:GetEndPoint().z)
					else
						newPnt1 = Point3D(obbC1:LowPos().x,distance:GetStartPoint().y,distance:GetStartPoint().z)
						newPnt2 = Point3D(obbC2:LowPos().x,distance:GetEndPoint().y,distance:GetEndPoint().z)
					end
				end
			end
			CheckSpaceProvision2n3(BuildingStorey, sm, controller1, controller2, newPnt1,newPnt2);	
		end)
	else
		if(#groupWaterMeter == 0) then
			print("No Sub Meter found.")
			FXUtility.DisplaySolid_Warning(BuildingStorey, "No Sub Meter found.")
		end
	end
end     


function CheckRuleScenario1(BuildingStorey)	
	if(#groupWaterMeter ~= 0) then
		groupWaterMeter:ForEach(function(wm)			
			local element1, element2 = GetRelatedElements(wm);			
			local segment1 = GetSegmentDirectlyConnectedPubMain(element1);			
			local controller1 = GetStopCock(element2);			
			if (segment1 ~= nil and controller1 ~= nil) then			    
			    local stpckOBB = FXGeom.GetBoundingOBB(controller1)			    
			    local stpckMaxPnt = stpckOBB:MaxPnt();
			    local pipeOBB = FXGeom.GetBoundingOBB(segment1);
			    local pipeCenterPnt = pipeOBB:GetPos();	
			    local pipeMinPnt = pipeOBB:MinPnt();	
 				local pipeCenterLine = Line3D(Point3D(pipeCenterPnt.x, pipeCenterPnt.y, stpckMaxPnt.z + 1000), 
 					                          Point3D(pipeCenterPnt.x, pipeCenterPnt.y, pipeMinPnt.z))
				local pipeCenterLineNode = FXUtility.CreateNodeFrom(pipeCenterLine)	
	   		    				
				CheckSpaceProvision(BuildingStorey, wm, controller1, pipeCenterLineNode);	
				FXClashDetection.DeleteNode(pipeCenterLineNode);
			end
		end)
	else
		if(#groupSubMeter == 0) then
			print("No Water Meter found.")
			FXUtility.DisplaySolid_Warning(BuildingStorey, "No Water Meter found.")
		end		
	end
end  


function MakeGroupUnique(BuildingStorey)    
    groupWaterMeter = groupWaterMeter:Unique();
    if(#groupWaterMeter ~= 0) then 
		print("Water Meter -> "..#groupWaterMeter)	
	end
   
	groupSubMeter = groupSubMeter:Unique();
	if(#groupSubMeter ~= 0) then
		print("Sub Meter -> "..#groupSubMeter)		
	end
	
	groupStopCock = groupStopCock:Unique();
    if(#groupStopCock ~= 0) then    
		print("Stopcock -> "..#groupStopCock)		
	end
	
	groupServiceDuct = groupServiceDuct:Unique();
	if(#groupServiceDuct ~= 0) then    
		print("Service Duct -> "..#groupServiceDuct)	
	end
end


function DisplayCom( Building )
	local y = 1
	-- print (isErrorFound)

	if isErrorFound == false then
		while y ~= x + 1 do
			print ("yo")
			FXUtility.DisplaySolid_Info(comStoreyArr[y], comResultArr[y].." mm ; "..comTerminalArr[y]:GetAuxAttri("Entity.ObjectType"));
			CheckReport.AddRelatedObj(comTerminalArr[y], comTerminalArr[y]:GetAuxAttri("Entity.ObjectType"));	
			CheckReport.AddRelatedGeometry_Solid(comArrowArr[y], comResultArr[y]);
			CheckReport.AddRelatedGeometry_Solid(comPolyArr[y]);	
			y = y + 1
		end		
	end 
end