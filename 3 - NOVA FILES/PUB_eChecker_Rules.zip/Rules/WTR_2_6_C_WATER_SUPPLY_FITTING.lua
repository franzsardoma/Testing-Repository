--modified By: Lawrence 1/3/2019
--modified By: Lawrence 1/15/2019

local PUBMAINS = FXGroup.new();
local grpELements1 = FXGroup.new();
local grpLLTanks = FXGroup.new();
local grpHLLtanks = FXGroup.new();
local LLTankValues
local HLTankValues
local PUBMAINSValue
local isErrorNotFound = true
local ARRCBuilding1 = {}
local ARRCProjection = {}
local ARRCTankBelowMRL = {}
local ARRCTankBelowInletPipe = {}
local ARRCPipeZ = {}
local ARRCTankAboveMRL = {}
local ARRCTerminal = {}
local ARRCHighestPipe = {}
local TEMPmRL = 137000;
local mRL = 0;

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckCompliant");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_2_6_C_WATER_SUPPLY_FITTING")
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpELements1 = grpELements1 + v;
				grpELements1 = grpELements1:Unique();
			end
			if (k == 3) then
				grpLLTanks = grpLLTanks + v;
				grpLLTanks = grpLLTanks:Unique();
			end
			if (k == 4) then
				grpHLLtanks = grpHLLtanks + v;
				grpHLLtanks = grpHLLtanks:Unique();
			end
			if (k == 5) then
				PUBMAINS = PUBMAINS + v;
				PUBMAINS = PUBMAINS:Unique();
			end
		end
	end

	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	local Values2 = {}
	local Values3 = {}
	local Values4 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 2) then
				table.insert(Values2, v1["value"])
			end
			if(k == 3) then
				table.insert(Values3, v1["value"])
			end
			if(k == 4) then
				table.insert(Values4, v1["value"])
			end
		end
	end

	LLTankValues = Values2[1]
	for k,v in pairs(Values2) do
		if k ~= 1 then
			LLTankValues = LLTankValues.." or "..v
		end
	end

	HLTankValues = Values3[1]
	for k,v in pairs(Values3) do
		if k ~= 1 then
			HLTankValues = HLTankValues.." or "..v
		end
	end

	PUBMAINSValue = Values4[1]
	for k,v in pairs(Values4) do
		if k ~= 1 then
			PUBMAINSValue = PUBMAINSValue.." or "..v
		end
	end
end

function getMRL( Building )
	local bldgStorey = Building:GetDescendants("BuildingStorey")
	local LevelElev = 0
	bldgStorey:ForEach(function ( bldgStoreyObj )
		if ( FXUtility.HasPatterInString(bldgStoreyObj:GetAttri("Name"), "level 01") or FXUtility.HasPatterInString(bldgStoreyObj:GetAttri("Name"), "storey 01")) then
			LevelElev = bldgStoreyObj:Elevation()
		end
	end)

	local SiteRefElev = Building:GetParent()
	local mRL = (TEMPmRL - (SiteRefElev:GetAttri("RefElevation") + LevelElev)) + LevelElev
	
	return mRL
end

function CheckWaring( Building, Projection, mRL )
	local isWarningNotFound = true
	local isNotDisplayed = true
	
	if #grpELements1 == 0 then
		FXUtility.DisplaySolid_Warning(Building, FXPUB.SetStandardMrl(mRL).." SHD");
		CheckReport.AddRelatedGeometry_SupportedInfo(Projection)

		isNotDisplayed = false
		isWarningNotFound = false
		CheckReport.Warning( Building, "No fittings found." )
		CheckReport.Warning( Building, "No pipe found." )
	end
	
	if #PUBMAINS == 0 then
		if isNotDisplayed then
			FXUtility.DisplaySolid_Warning(Building, FXPUB.SetStandardMrl(mRL).." SHD");
			CheckReport.AddRelatedGeometry_SupportedInfo(Projection)
		end
		isWarningNotFound = false
		CheckReport.Warning( Building, "No "..PUBMAINSValue.." found." )
	end
	return isWarningNotFound
end

function CheckRule(Building)
	local BuildingStoreyGroup = Building:GetDescendants("BuildingStorey");
	local Slab;
	mRL = getMRL( Building )

	BuildingStoreyGroup:ForEach(function(Storey)
		local SlabGrp = Storey:GetDescendants("Slab");

		if(#SlabGrp ~= 0)then 
			SlabGrp:ForEach(function(Object)
				if(Object ~= nil)then 
					Slab = Object;
					return;
				end				
			end)
		end		
	end)

	local Projection = FXMeasure.GetObjProjection(Slab,mRL);
	
	if CheckWaring(Building, Projection, mRL) == false then
		-- FXUtility.DisplaySolid_Warning(Building, (mRL/1000).." mRL");
		-- CheckReport.AddRelatedGeometry_SupportedInfo(Projection)
		return;
	end
	
	
	local FlowStorageDevice = Building:GetDescendants("FlowStorageDevice");
	-- local FlowTerminal = Building:GetDescendants("FlowTerminal");
	local IsBelowTankConnectedToPUB = false;
	local IsTerminalsConnected = false;	
	local IsTanksConnected = false;
	local TankBelowInletPipe;
	local TankBelowMRL;
	local TankAboveMRL;
	
	-- local Projection;
	
	local TankFlag = false;
	local TankFlag1 = false;
	local TankObj;
	local Flag = false;
	local TwoTankAboveOrBelowMRL = false;
	
	local NoWaterFittings = false;
	local HighestFittingElevation;

	local FlagNoBothTank = false;
	local highestTerminal
	-- local Lavatory = FXGroup.new();
	-- local WaterCloset = FXGroup.new();

	
	FlowStorageDevice:ForEach(function(Element)
		if(Element ~= nil)then 
			local BOX = FXGeom.GetBoundingBox(Element);
			local Z = BOX:HighPos().z;
			-- print(FXUtility.Round(Z,0).." < "..mRL)
			if(Z < mRL) then
				TankBelowMRL = Element;
			else
				TankAboveMRL = Element;
			end
		end		
	end)

	if(TankBelowMRL ~= nil and TankAboveMRL ~= nil)then 
		TankFlag = true;
	else
		-- print("CHECK")
		if(TankBelowMRL ~= nil and TankAboveMRL == nil)then
			-- print("CHECK1")
			TankFlag1 = true;
			TankObj = TankBelowMRL;
			TwoTankAboveOrBelowMRL = true;
		elseif(TankBelowMRL == nil and TankAboveMRL ~= nil)then
			-- print(TankAboveMRL.Type)
			TankObj = TankAboveMRL;
			TwoTankAboveOrBelowMRL = true;
		else 
			FlagNoBothTank = true;
		end
	end


	if(TwoTankAboveOrBelowMRL)then 
		local TempInletPipeZ;
		local TempTank;
		FlowStorageDevice:ForEach(function(Tank)
			local temp;
			local PipeConnGroup = Tank:GetConnectedSegment();
			PipeConnGroup:ForEach(function(Element)
				--------------------------------------------------------
				if(#PipeConnGroup > 1)then 
					if(temp == nil)then 
						temp = Element;
					else
						local OBB1 = FXGeom.GetBoundingOBB(temp);
						local OBB2 = FXGeom.GetBoundingOBB(Element);
						local Mz1 = OBB1:MaxPnt().z;
						local Mz2 = OBB2:MaxPnt().z;

						if(TempTank == nil)then 
							if(Mz1 > Mz2)then 
								TempInletPipeZ = Mz1;
							else
								TempInletPipeZ = Mz2;
							end
							TempTank = Tank;
						else
							if(Mz1 > Mz2)then 
								if(Mz1 < TempInletPipeZ)then 
									TankBelowMRL = Tank;
								else
									TankBelowMRL = TempTank;
								end
							else
								if(Mz2 < TempInletPipeZ)then 
									TankBelowMRL = Tank;
								else
									TankBelowMRL = TempTank;
								end
							end
						end
					end			
				else
					local OBB = FXGeom.GetBoundingOBB(Element);
					local Mz = OBB:MaxPnt().z;
					if(TempTank == nil)then 
						TempInletPipeZ = Mz;
						TempTank = Tank;
					else
						if(Mz < TempInletPipeZ)then 
							TankBelowMRL = Tank;
						else
							TankBelowMRL = TempTank;
						end
					end
				end
				--------------------------------------------------------
				
			end)
		end)
	end
	--------------------------------------------------------
	-- BuildingStoreyGroup:ForEach(function(Storey)
	-- 	local SlabGrp = Storey:GetDescendants("Slab");
	-- 	if(#SlabGrp ~= 0)then 
	-- 		SlabGrp:ForEach(function(Object)
	-- 			if(Object ~= nil)then 
	-- 				Slab = Object;
	-- 				return;
	-- 			end				
	-- 		end)
	-- 	end		
	-- end)
	-- --------------------------------------------------------
	-- Projection = FXMeasure.GetObjProjection(Slab,mRL);
	--------------------------------------------------------		
		-- print("CHECK")
		-- print(TankAboveMRL)
		if(#grpELements1 > 0)then
			if(TankAboveMRL ~= nil)then 
				local TempBoxHighPosZ;
				grpELements1:ForEach(function(Terminal)
					highestTerminal = Terminal
					local BoxTerminal = FXGeom.GetBoundingBox(Terminal);
					local BoxHighPos = BoxTerminal:HighPos().z;
					-- print(BoxHighPos)
					-- print(BoxHighPos.." > "..mRL) 
					-- FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("Name").." | "..BoxHighPos.." > "..mRL,Projection)
					--------------------------------------------------------		
					if(FXPUB.IsObjsConnected(Terminal,TankAboveMRL))then 
						IsTerminalsConnected = true;
					else
						IsTerminalsConnected = false;
					end
					--------------------------------------------------------		
					-- if(TempBoxHighPosZ == nil)then 
					-- 	TempBoxHighPosZ = BoxHighPos;
					-- else
					-- 	if(BoxHighPos > TempBoxHighPosZ)then 
					-- 		HighestFittingElevation = BoxHighPos
					-- 	else
					-- 		HighestFittingElevation = TempBoxHighPosZ;
					-- 	end	
					-- end
					if TempBoxHighPosZ == nil or TempBoxHighPosZ < BoxHighPos then
						TempBoxHighPosZ = BoxHighPos;
					end
					--------------------------------------------------------		
				end)
				HighestFittingElevation = TempBoxHighPosZ
			end
		else
			NoWaterFittings = true;
		end
		
	if(NoWaterFittings == false)then
		-------------------------------------------------------------------------------
		if(FlagNoBothTank)then 
			FXUtility.DisplaySolid_Error(Building,"No Low Level Tank provided");
			FXUtility.DisplaySolid_Error(Building,"No High Level Tank provided");
			isErrorNotFound = false
		end
		-------------------------------------------------------------------------------
		-- FlowTerminal:ForEach(function(Element)
		-- 	if(FXUtility.HasPatterInString(Element:GetAttri("ObjectType"),"Lavatory"))then 
		-- 		Lavatory:Add(Element);
		-- 	else
		-- 		WaterCloset:Add(Element);
		-- 	end
		-- end)
		-------------------------------------------------------------------------------
		local HighestPipe = GetHighestObj(grpELements1);
		local BoxHighestPipe = FXGeom.GetBoundingBox(HighestPipe);
		local HighestPipeHighPos = BoxHighestPipe:HighPos().z;
		-------------------------------------------------------------------------------
		if(TankBelowMRL ~= nil)then 
			local temp;
			local PipeConnGroup = TankBelowMRL:GetConnectedSegment();
			PipeConnGroup:ForEach(function(Element)
				if(temp == nil)then 
					temp = Element;
				else
					local OBB1 = FXGeom.GetBoundingOBB(temp);
					local OBB2 = FXGeom.GetBoundingOBB(Element);
					local Mz1 = OBB1:MaxPnt().z;
					local Mz2 = OBB2:MaxPnt().z;

					if(Mz1 > Mz2)then 
						TankBelowInletPipe = temp;
					else
						TankBelowInletPipe = Element;
					end
				end			
			end)
		end
		-------------------------------------------------------------------------------
		if(TankBelowMRL ~= nil and #PUBMAINS > 0)then 
			PUBMAINS:ForEach(function(PipeObject)
				if(FXPUB.IsObjsConnected(TankBelowMRL,PipeObject))then 
					IsBelowTankConnectedToPUB = true;
				-- else
					-- IsBelowTankConnectedToPUB = false;
				end
			end)
		end
		-------------------------------------------------------------------------------
		if(TankFlag)then
			if(FXPUB.IsObjsConnected(TankAboveMRL,TankBelowMRL))then 
				if(IsTerminalsConnected)then 
				-------------------------------------------------------------------------------
					if(HighestPipeHighPos > mRL)then
						if(HighestFittingElevation ~= nil)then 
							if(HighestFittingElevation > mRL)then
								-------------------------------------------------------------------
								-- local ARRCBuilding1 = {}
								-- local ARRCProjection = {}

								-- local ARRCTankBelowMRL = {}
								-- local ARRCTankBelowInletPipe = {}
								-- local ARRCPipeZ = {}

								-- local ARRCTankAboveMRL = {}

								-- local ARRCTerminal = {}

								-- local ARRCHighestPipe = {}

								if(Projection ~= nil)then 
									table.insert(ARRCBuilding1, Building)
									table.insert(ARRCProjection, Projection)
									-- FXUtility.DisplaySolid_Info(Building,(mRL/1000).."mRL",Projection);
								else
									print("Projection is nil");
								end
								-------------------------------------------------------------------
								if(IsBelowTankConnectedToPUB)then 
									local HighPos = FXGeom.GetBoundingBox(TankBelowInletPipe):HighPos().z;
									local PipeZ = FXUtility.Round(HighPos/1000);
									-------------------------------------------------------------------
									table.insert(ARRCTankBelowMRL, TankBelowMRL)
									table.insert(ARRCTankBelowInletPipe, TankBelowInletPipe)
									table.insert(ARRCPipeZ, PipeZ)
									-- FXUtility.DisplaySolid_Info(Building,"Low Level Tank provided");
									-- CheckReport.AddRelatedObj(TankBelowMRL,TankBelowMRL:GetAttri("ObjectType"));
									-- CheckReport.AddRelatedObj(TankBelowInletPipe,"Inlet: "..PipeZ.."mRL");
									----------------------------------------------------------------------
									table.insert(ARRCTankAboveMRL, TankAboveMRL)
									-- FXUtility.DisplaySolid_Info(Building,"High Level Tank provided");
									-- CheckReport.AddRelatedObj(TankAboveMRL,TankAboveMRL:GetAttri("ObjectType"));
									----------------------------------------------------------------------
									grpELements1:ForEach(function ( Terminal )
										table.insert(ARRCTerminal, Terminal)
										-- FXUtility.DisplaySolid_Info(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");
									end)
									-- Lavatory:ForEach(function(Terminal)
									-- 	FXUtility.DisplaySolid_Info(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");	
									-- end)

									-- WaterCloset:ForEach(function(Terminal)
									-- 	FXUtility.DisplaySolid_Info(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");	
									-- end)
									----------------------------------------------------------------------
									table.insert(ARRCHighestPipe, HighestPipe)
									-- FXUtility.DisplaySolid_Info(HighestPipe,HighestPipe:GetAttri("ObjectType"));
								else
									FXUtility.DisplaySolid_Error(TankBelowMRL,TankBelowMRL:GetAttri("ObjectType")..": Not Connected to PUB Mains");	
									isErrorNotFound = false
								end	
								-------------------------------------------------------------------------------
							else		
								FXUtility.DisplaySolid_Warning(Building,"Highest fitting is below "..FXPUB.SetStandardMrl(mRL).." SHD");
								CheckReport.AddRelatedGeometry_SupportedInfo(Projection)
								CheckReport.AddRelatedObj(highestTerminal, highestTerminal:GetAttri("ObjectType"));
							end
							-----------------------------------------------------------------------------------
						else
							print("HighestFittingElevation is nil");
						end		
					end					
				else
					grpELements1:ForEach(function ( Terminal )
						FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
						isErrorNotFound = false
					end)
					-- Lavatory:ForEach(function(Terminal)
					-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
					-- end) 

					-- WaterCloset:ForEach(function(Terminal)
					-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank 1");
					-- end) 
				end
				-----------------------------------------------------------------------------------------------			
			else 
				FXUtility.DisplaySolid_Error(Building,"High Level Tank is not connected to Low Level Tank");
				CheckReport.AddRelatedObj(TankAboveMRL,TankAboveMRL:GetAttri("ObjectType"));
				CheckReport.AddRelatedObj(TankBelowMRL,TankBelowMRL:GetAttri("ObjectType"));
				---------------------------------------------------------------------------
				FXUtility.DisplaySolid_Error(Building,FXPUB.SetStandardMrl((mRL)).." SHD");
				CheckReport.AddRelatedGeometry_SupportedInfo(Projection)	
				isErrorNotFound = false			
			end
				-----------------------------------------------------------------------------------------------
		else
			isErrorNotFound = false
			print("in")
			FXUtility.DisplaySolid_Error(Building,FXPUB.SetStandardMrl(mRL).." SHD");
			CheckReport.AddRelatedGeometry_SupportedInfo(Projection)
			if(TankFlag1 and TankBelowMRL ~= nil)then
				FXUtility.DisplaySolid_Error(Building,"No High Level Tank Found");
				
				---------------------------------------------------------------------------
				grpELements1:ForEach(function ( Terminal )
					FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
				end)
				-- Lavatory:ForEach(function(Terminal)
				-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
				-- end) 

				-- WaterCloset:ForEach(function(Terminal)
				-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
				-- end) 
				---------------------------------------------------------------------------
			else
				---------------------------------------------------------------------------
				isErrorNotFound = false
				if(#FlowStorageDevice > 1 and TankBelowInletPipe ~= nil)then 
					FXUtility.DisplaySolid_Error(TankBelowMRL,"Low Level Tank Inlet is above "..FXPUB.SetStandardMrl(mRL).." SHD");
					local PipeElevation = FXGeom.GetBoundingBox(TankBelowInletPipe):HighPos().z;
					-- PipeElevation = FXUtility.Round(PipeElevation,0);
					CheckReport.AddRelatedObj(TankBelowInletPipe,TankBelowInletPipe:GetAttri("ObjectType").."; "..FXUtility.Round(FXPUB.SetStandardMrl(PipeElevation)).." SHD");
				else
					FXUtility.DisplaySolid_Error(Building,"No Low Level Tank Found");
					FXUtility.DisplaySolid_Error(Building,"High Level Tank is not connected to Low Level Tank");
					if(IsTerminalsConnected)then
						grpELements1:ForEach(function ( Terminal )
							FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");
						end)
						-- Lavatory:ForEach(function(Terminal)
						-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");
						-- end) 

						-- WaterCloset:ForEach(function(Terminal)
						-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");
						-- end) 
					else
						grpELements1:ForEach(function ( Terminal )
							FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
						end)
						-- Lavatory:ForEach(function(Terminal)
						-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
						-- end) 

						-- WaterCloset:ForEach(function(Terminal)
						-- 	FXUtility.DisplaySolid_Error(Terminal,Terminal:GetAttri("ObjectType")..": Not Connected to High Level Tank");
						-- end) 
					end
				end
			end	
		end		
		-------------------------------------------------------------------------------	
		-------------------------------------------------------------------------------		
	-- else
	-- 	FXUtility.DisplaySolid_Warning(Building,"No water fittings found");
	end
end

function CheckCompliant( Building )

	for k,Building in pairs(ARRCBuilding1) do
		FXUtility.DisplaySolid_Info(Building,FXPUB.SetStandardMrl(mRL).." SHD");
		CheckReport.AddRelatedGeometry_SupportedInfo(ARRCProjection[k])
	end

	for k,TankBelowMRL in pairs(ARRCTankBelowMRL) do
		FXUtility.DisplaySolid_Info(TankBelowMRL, TankBelowMRL:GetAttri("ObjectType").." provided");
		CheckReport.AddRelatedObj(TankBelowMRL,TankBelowMRL:GetAttri("ObjectType"));
		CheckReport.AddRelatedObj(ARRCTankBelowInletPipe[k],"Inlet: "..ARRCPipeZ[k].." SHD");
	end
	
	for k,TankAboveMRL in pairs(ARRCTankAboveMRL) do
		FXUtility.DisplaySolid_Info(TankAboveMRL, TankAboveMRL:GetAttri("ObjectType").." provided");
		CheckReport.AddRelatedObj(TankAboveMRL,TankAboveMRL:GetAttri("ObjectType"));
	end

	for k,Terminal in pairs(ARRCTerminal) do
		FXUtility.DisplaySolid_Info(Terminal,Terminal:GetAttri("ObjectType")..": Connected to High Level Tank");
		CheckReport.AddRelatedObj(Terminal,Terminal:GetAttri("ObjectType"));
	end
			
	for k,HighestPipe in pairs(ARRCHighestPipe) do
		FXUtility.DisplaySolid_Info(HighestPipe,HighestPipe:GetAttri("ObjectType"));
	end															
end

function GetHighestObj(Group)
	local highest;
	Group:ForEach(function (ele)
		if(highest == nil)then
			highest = ele;
		else
			local highBox = FXGeom. GetBoundingBox(highest);
			local eleBox = FXGeom. GetBoundingBox(ele);
			local hpoint = highBox:HighPos();
			local epoint = eleBox:HighPos();
			if(hpoint.z < epoint.z)then
				highest = ele;
			end
		end
	end)
	return highest;
end