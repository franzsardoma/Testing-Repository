-- Author:Mohammad Derick Pauig
local grpDownPipe = FXGroup.new()
local grpDrain = FXGroup.new()



function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_4_10_1_B_II_SURFACE_WATER_CATCHMENT")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	--local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpDownPipe = grpDownPipe + v
			grpDownPipe = grpDownPipe:Unique()			
		end
		if k == 3 then
			grpDrain = grpDrain + v
			grpDrain = grpDrain:Unique()			
		end			
	end
end

function checkRule(Building)
	local grpPipeNotCol = FXGroup.new()
	local grpPipeColAll = FXGroup.new()
	

	 print(#grpDownPipe.."Pipe")
	 print(#grpDrain.."Drain")
	if #grpDownPipe ~= 0 then
		if #grpDrain ~= 0 then
			grpDrain:ForEach(function (drain)
				local flag 
				local grpPipeCol = FXGroup.new()
				grpDownPipe:ForEach(function (pipe)
					if FXPUB.ObjToObjIsConnected(drain,pipe,10) == true then
						if flag ~= false or flag == true then
							flag = true
							grpPipeCol:Add(pipe)
						end
					end
				end)
				if flag == true then
					FXUtility.DisplaySolid_Info(Building,"Rainwater Downpipe is connected to ".. drain:GetAttri("Name"))
					CheckReport.AddRelatedObj( drain, drain:GetAttri("Name"));
					grpPipeCol:ForEach(function (pipe)
						CheckReport.AddRelatedObj( pipe, pipe:GetAttri("Name"));
					end)
				end
				grpPipeColAll = grpPipeColAll + grpPipeCol
			end)
		else
			flag = false
			FXUtility.DisplaySolid_Error(Building,"Rainwater Downpipe is not connected to Surface Gravity Drain")
			grpDownPipe:ForEach(function (pipe)
				CheckReport.AddRelatedObj( pipe, pipe:GetAttri("Name"));
			end)
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Rainwater Downpipe is not provided")
	end

	grpPipeNotCol = grpDownPipe - grpPipeColAll
		
	 if #grpPipeNotCol ~= 0 then
	 	if flag ~= false then
		 	FXUtility.DisplaySolid_Error(Building,"Rainwater Downpipe is not connected to Surface Gravity Drain")
		 	CheckReport.AddRelatedObj( drain, drain:GetAttri("Name"));
		 	grpPipeNotCol:ForEach(function (pipe)
		 		CheckReport.AddRelatedObj( pipe, pipe:GetAttri("Name"));
		 	end)
		 end
	end

end

-- function ObjToObjIsConnected1(Chamber1,Chamber2,Cnt)
-- 	local isConnected = false
-- 	if FXClashDetection.IsCollided(Chamber1,Chamber2) then
-- 		return true
-- 	else
-- 		local cha1Container = Chamber1:GetParent()
-- 		local cha2Container = Chamber2:GetParent()

		
-- 		local grpPipe = cha1Container:GetDescendants("FlowSegment")
-- 		local grpFitting = cha1Container:GetDescendants("FlowFitting")
		
-- 		grpPipe = cha2Container:GetDescendants("FlowSegment")
-- 		grpFitting = cha2Container:GetDescendants("FlowFitting")

-- 		grpPipe = grpPipe:Unique()
-- 		grpFitting = grpFitting:Unique()
		
-- 		local grpCollided1 = FXGroup.new()
-- 		local grpCollided2 = FXGroup.new()

	
-- 		grpPipe:ForEach(function (pipe)
-- 			if FXClashDetection.IsCollided(Chamber1,pipe) then
-- 				grpCollided1:Add(pipe)
-- 			end
-- 			if FXClashDetection.IsCollided(Chamber2,pipe) then
-- 				grpCollided2:Add(pipe)
-- 			end
-- 		end)

-- 		grpFitting:ForEach(function (fitting)
-- 			if FXClashDetection.IsCollided(Chamber1,fitting) then
-- 				grpCollided1:Add(fitting)
-- 			end
-- 			if FXClashDetection.IsCollided(Chamber2,fitting) then
-- 				grpCollided2:Add(fitting)
-- 			end
-- 		end)

-- 		grpCollided1:ForEach(function (col1)
-- 			grpCollided2:ForEach(function (col2)
-- 				if FXPUB.IsTwoObjsConnected(col1,col2,Cnt) == true then
-- 					isConnected = true
-- 				end
-- 			end)
-- 		end)
-- 	end
-- 	return isConnected
-- end