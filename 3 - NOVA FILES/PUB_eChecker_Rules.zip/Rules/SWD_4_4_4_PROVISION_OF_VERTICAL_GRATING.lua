-- Author:Mohammad Derick Pauig


local grpIntDrain = FXGroup.new()
local grpPubDrain = FXGroup.new()
local grpGrating = FXGroup.new()


function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_4_4_4_PROVISION_OF_VERTICAL_GRATING")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	-- local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpGrating = grpGrating + v
			grpGrating = grpGrating:Unique()			
		end
		if k == 3 then
			grpPubDrain = grpPubDrain + v
			grpPubDrain = grpPubDrain:Unique()			
		end	
		if k == 4 then
			grpIntDrain = grpIntDrain + v
			grpIntDrain = grpIntDrain:Unique()			
		end			
	end
end

function checkRule(Building)
	-- local grpEle = Building:GetDescendants("DistributionChamberElement")
	local site = Building:GetParent("Site")
	
	-- print(#grpEle)s
	-- grpEle:ForEach(function (Ele)
	-- 	local name = Ele:GetAttri("Name")
	-- 	if FXUtility.HasPatterInString(name,"Internal Drain") then
	-- 		grpIntDrain:Add(Ele)
	-- 	end
	-- 	if FXUtility.HasPatterInString(name,"Public Drain") then
	-- 		grpPubDrain:Add(Ele)
	-- 	end
	-- end)
	-- -- print(#grpIntDrain)
	-- grpGrating = Building:GetDescendants("FlowTreatmentDevice")
	print(#grpGrating.."grating")
	print(#grpIntDrain.."Int")
	print(#grpPubDrain.."pub")
	local name2 = site:GetAuxAttri("Entity.Description");
	-- print(name2)
	local grpsub = FXGroup.new()
	if FXUtility.HasPatterInString(name2,"Development Site") then

		if #grpIntDrain ~= 0 then
			if #grpPubDrain ~=0 then
				grpIntDrain:ForEach(function (int)
					grpPubDrain:ForEach(function (pub)
						local dist = FXMeasure.Distance(int, pub):Length()
						print(dist)
						if FXClashDetection.IsCollided(int,pub,20) then
							if #grpGrating ~= 0 then
								grpGrating:ForEach(function (grating)
									if FXClashDetection.IsCollided(grating,site) then
										if FXClashDetection.IsCollided(grating,int) then
											FXUtility.DisplaySolid_Info(grating,int:GetAttri("Name").." is connected to Public Drain; "..grating:GetAttri("Name").." is provided",intObb);
										end
									else
										FXUtility.DisplaySolid_Error(grating,int:GetAttri("Name").." is connected to Public Drain; No "..grating:GetAttri("Name").." is found within perimeter");
									end
									-- grpsub:Add(grating)
								end)
							else
								FXUtility.DisplaySolid_Error(int,int:GetAttri("Name").." is connected to Public Drain; No Vertical Grating found");
							end
						else
							FXUtility.DisplaySolid_Warning(int,"No "..int:GetAttri("Name").." found connected with "..pub:GetAttri("Name"));
						end
					end)
					grpGrating = grpGrating - grpsub
				end)
			else
				FXUtility.DisplaySolid_Warning(Building,"Public Drain is not provided")
			end
		else
			FXUtility.DisplaySolid_Warning(Building,"Internal Drain is not provided")
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Development Site is not provided")
	end
end

