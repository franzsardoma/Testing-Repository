local pumpingMainGrp = FXGroup.new();

function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SSW_2_2_1_MINIMUM_SIZE_OF_PUMPING_MAIN");
  -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
  minDiameter = ConditionValues[3]
  SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2) then
      pumpingMainGrp = pumpingMainGrp + v;
      pumpingMainGrp = pumpingMainGrp:Unique();
    end
  end
end

function checkRule(Building)
	local check = false;
	if #pumpingMainGrp ~= 0 then
		check = true;
	end

	if check then
		local pipeDiameter;
		local circleFace;
		local compliantGrp=FXGroup.new()
		local noncompliantGrp=FXGroup.new()
		local arrow;
		local rounded;
		pumpingMainGrp:ForEach(function(pumpingEle)
			for i=0, 5, 1 do 
				if FXMeasure.GetCircularFacesInDirection(pumpingEle,i) ~= nil then
					circleFace = FXMeasure.GetCircularFacesInDirection(pumpingEle,i)
					break
				end
			end

			local outerEdge = FXMeasure.GetOuterEdge(circleFace);
			local longestLine = GetLongestLine(outerEdge)
			local edgeLineLength = longestLine:Length();
			rounded = FXUtility.Round(edgeLineLength,2)
			local StartPnt = longestLine:GetStartPoint();
			local EndPnt = longestLine:GetEndPoint();
			arrow = DoubleArrow(EndPnt,StartPnt)

			if rounded >= tonumber(minDiameter) then
				compliantGrp:Add(pumpingEle)
			else
				noncompliantGrp:Add(pumpingEle)
			end
		end)
		if #noncompliantGrp ~= 0 then
			noncompliantGrp:ForEach(function(pumpingEle)
				FXUtility.DisplaySolid_Error(pumpingEle:GetParent(),"Pumping Main Diameter = " .. rounded .. " mm",arrow);
				CheckReport.AddRelatedObj(pumpingEle,pumpingEle:GetAttri("Name"))
			end)
		else
			compliantGrp:ForEach(function(pumpingEle)
				FXUtility.DisplaySolid_Info(pumpingEle:GetParent(),"Pumping Main Diameter = " .. rounded .. " mm",arrow);
				CheckReport.AddRelatedObj(pumpingEle,pumpingEle:GetAttri("Name"))
			end)
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Pumping Main is not provided.")
	end
end	

function GetLongestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end	






 