local DrainChannelBend = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser( Building )
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_3_2_CENTRE_OF_DRAIN_CHANNEL_BEND")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			DrainChannelBend = DrainChannelBend + v;
			DrainChannelBend = DrainChannelBend:Unique();
		end
	end
end

function CheckRule( Building )
	local flag = true;
	local Compliant = {};
	local Width = {};
	local WidthArrow = {};
	local Plyline = {};
	local FullWidth = {};
	local WidthArrow2 = {};

	if (#DrainChannelBend ~= 0) then
		DrainChannelBend : ForEach(function ( drain )
			-- Full Inner Width --
			local Box = FXGeom.GetBoundingBox(drain);
			local highZ = Box:HighPos().z
			local projection = FXMeasure.GetObjProjection(drain,highZ);
			local outerEdge = FXMeasure.GetOuterEdge(projection);
			local edges = LongestLine(outerEdge);
			local lengthLine;
			local count = 1;
			local i = 1;

			while (i > 0) do
				local shrinkLine = FXGFA.ShrinkageLine(edges,count);
				local node = FXUtility.CreateNodeFrom(shrinkLine);

				if (FXClashDetection.IsCollided(drain, node) == false) then
					i = i - 1;
					lengthLine = shrinkLine;
					FXClashDetection.DeleteNode(node);
				end
				FXClashDetection.DeleteNode(node);
				count = count + 0.1;
			end

			local Point1 = lengthLine:GetStartPoint();
			local Point2 = lengthLine:GetEndPoint();
			local fullWidth = FXUtility.Round(Point1:Distance_Pnt(Point2));
			local fullArrow = DoubleArrow(Point1, Point2);
			local Result = (fullWidth / 4); -- 1/4 of Full inner drain width --
			-- print(Divide);
			-- 1/4 Width --
			local topFace = FXMeasure.GetAllTopFace(drain);
			local lowestFace, lowestElevation;

			for i = 1, #topFace, 1 do
				local edges = FXMeasure.GetOuterEdge(topFace[i]);
				local pointElevation = edges:GetPoint(1).z

				if (lowestElevation == nil or lowestElevation > pointElevation) then
					lowestFace = topFace[i];
					lowestElevation = pointElevation;
				end
			end

			local lowestFaceElevation = FXMeasure.GetOuterEdge(lowestFace)
			local newPointLine = Line3D(Point1 , Point2);
			
			local ShortestLine = shortestLine( lowestFaceElevation , newPointLine ) -- Get the shortest line of lowest face, and make it parrallel to the full line of drain --
			local centerPoint = FXUtility.CenterPoint(ShortestLine:GetStartPoint(), ShortestLine:GetEndPoint()); -- Center point of shortest line --

			local centerPointZ = Box:MidPos().z;
			local closestPoint = closestPointToPointOfLine( centerPoint , newPointLine ); -- compare the nearest point of full inner width from center point to the lowest elevation of face

			local P1 = Point3D(centerPoint.x, centerPoint.y, centerPointZ ); -- hight of point 1 from mid of drain
			local P2 = Point3D(closestPoint.x, closestPoint.y, centerPointZ); -- closest point from center point --
			local P3 = Point3D(centerPoint.x, centerPoint.y, highZ); -- line --

			local width = FXUtility.Round(P1:Distance_Pnt(P2));
			local Arrow = DoubleArrow( P1 , P2 );
			local line = Line3D ( centerPoint , P3 );


			if (width == Result) then -- if the measure width from bend drain is equal to the 1/4 of full measure of drain --
				table.insert(Compliant, drain);
				table.insert(Width, width);
				table.insert(WidthArrow, Arrow);
				table.insert(FullWidth, fullWidth);
				table.insert(WidthArrow2, fullArrow);
				table.insert(Plyline, line);
			else
				flag = false;
				FXUtility.DisplaySolid_Error(drain, "Center: ".. width .. "mm; Width: " .. fullWidth, Arrow);
				CheckReport.AddRelatedGeometry_Error(fullArrow);
				CheckReport.AddRelatedGeometry_Error(line);
			end
		end)

		if (flag) then
			for i = 1, #Compliant do
				FXUtility.DisplaySolid_Info(Compliant[i],Compliant[i]:GetAttri("ObjectType") .. "Center: ".. Width[i] .. "mm; Width: ".. FullWidth[i] .. "mm", WidthArrow[i]);
				CheckReport.AddRelatedGeometry_Info(WidthArrow2[i]);
				CheckReport.AddRelatedGeometry_Info(Plyline[i]);
			end
		end
	else
		FXUtility.DisplaySolid_Info(Building, "Drain Channel Bend is not provided.");
	end
end

function LongestLine( Edge )
	local LinePointNumber = Edge:GetPointNumber();
	local dist;

	for i=0,(LinePointNumber-2) do
		local Point1 = Edge:GetPoint(i)
		local Point2 = Edge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function shortestLine( edge , line )
	local LinePointNumber = edge:GetPointNumber();
	local dist;

	for i=0,(LinePointNumber-2) do
		local Point1 = edge:GetPoint(i)
		local Point2 = edge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			if FXUtility.IsParallel( Line, line )then
				dist = Line;
			end
		end
	end
	return dist;
end

function closestPointToPointOfLine( pnt , line )
	local startPnt = line:GetStartPoint();
	local endPnt = line:GetEndPoint();
	if pnt:Distance_Pnt(startPnt) > pnt:Distance_Pnt(endPnt) then
		return endPnt
	else
		return startPnt
	end
	
end