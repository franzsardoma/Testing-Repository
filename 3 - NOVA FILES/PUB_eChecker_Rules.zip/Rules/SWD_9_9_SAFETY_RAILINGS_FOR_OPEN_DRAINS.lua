local checkedRailings = FXGroup.new()
local grpRailings = FXGroup:new();
local grpDrain = FXGroup:new();
local compliantDrainHeight = {}
local compliantDoubleArrow = {}
local compliantRailings = {}
local compliantDrain = {}
local minHeight;
local isAllCompliant = true;
local RailVal1, RailVal2;
local compliantMsg = {}
local StandardTypeB = 0;
local Drawing06 = 0;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_9_SAFETY_RAILINGS_FOR_OPEN_DRAINS")
	
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	local tblValues = FXRule.filterTableValues(parsedXml, proj);

	local Values1 = {}

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
		end
	end

	RailVal1 = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			RailVal1 = RailVal1
			RailVal2 = v
		end
	end

	minHeight = ConditionValues[3]

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpRailings = grpRailings + v;
			grpRailings = grpRailings:Unique();
		end

		if (k == 3) then
			grpDrain = grpDrain + v;
			grpDrain = grpDrain:Unique();
		end
	end
end


function checkRule( Building )
	if (#grpDrain == 0) then
		CheckReport.Warning(Building,"Drain is not provided.")
		return;
	end

	grpDrain:ForEach(function ( drain )
		local drainTopFace = FXMeasure.GetTopFace(drain)
		local doubleArrow;
		local ctrDepth = 0.1;
		local drainName = drain:GetAttri("ObjectType")
		local depthPnt;
		local depthLine;
		local drainOBB = FXGeom.GetBoundingOBB(drain);
		local cntrOBB = drainOBB:GetPos();
		local maxPntZ = drainOBB:MaxPnt().z
		local isCompliant = false;
		local connectedRailings = FXGroup.new();
		local hasRailing;
		local msg
	

		while (true) do
			ctrDepth = ctrDepth + 0.1;
			depthPnt = Point3D(cntrOBB.x , cntrOBB.y, cntrOBB.z - ctrDepth);
			depthLine = Line3D(cntrOBB , depthPnt);
			local depthNode = FXUtility.CreateNodeFrom(depthLine);

			if (FXClashDetection.IsCollided(depthNode, drain)) then
				FXClashDetection.DeleteNode(depthNode);
				break;
			end

			FXClashDetection.DeleteNode(depthNode);
		end

		local drainHeight =  FXUtility.Round(maxPntZ - depthPnt.z) ;
		doubleArrow = DoubleArrow(depthPnt, Point3D(depthPnt.x , depthPnt.y, maxPntZ));

		if (drainHeight > tonumber(minHeight)) then
			if (#grpRailings > 0) then
				
				isCompliant, connectedRailings, msg = checkRailing(grpRailings, drain, msg)
				checkedRailings = checkedRailings + connectedRailings;
				checkResult(Building, isCompliant, drain, drainName, connectedRailings, drainHeight, doubleArrow, msg )
			else
				checkResult(Building, isCompliant, drain, drainName, connectedRailings, drainHeight, doubleArrow, msg)
			end
		else
			CheckReport.Warning(Building,"Depth of "..drainName.." is less than 1000 mm")
		end
	end)

	finalResult()
end

function checkRailing(grpRailings, drain, msg)
	local hasRailing = false;
	local isCompliant = false;
	local connectedRailings = FXGroup.new()

	grpRailings:ForEach(function ( railing )
		if (FXClashDetection.IsCollided(railing, drain)) then
			hasRailing = true;
			connectedRailings:Add(railing)

			if (FXUtility.HasPatterInString(railing:GetAttri("ObjectType"), RailVal1)) then
				StandardTypeB = StandardTypeB + 1
				msg = "Standard Safety " .. RailVal1 .. " Railing is provided on top of the " .. drain:GetAttri("ObjectType") .. ". (As per Land Transport Authority's latest Standard Details of Road Elements)"
			end

			if (FXUtility.HasPatterInString(railing:GetAttri("ObjectType"), RailVal2)) then
				Drawing06 = Drawing06 + 1
				msg = "Standard Safety " .. RailVal2 .. " Railing is provided on top of the " .. drain:GetAttri("ObjectType") .. ". (" .. RailVal2 ..", As per Request of Board)"
			end
		end
	end)

	if (hasRailing and #connectedRailings > 1) then
		isCompliant = true
	end

	return isCompliant, connectedRailings, msg;
end

function checkResult( Building, isCompliant, drain, drainName, connectedRailings, drainHeight, doubleArrow, msg )
	if (isCompliant) then
		table.insert(compliantDrain, drain);
		table.insert(compliantDrainHeight, drainHeight);
		table.insert(compliantRailings, connectedRailings);
		table.insert(compliantDoubleArrow, doubleArrow);
		table.insert(compliantMsg, msg);
	else

		if StandardTypeB == 0 then

			isAllCompliant = false;
			FXUtility.DisplaySolid_Error(drain, "Standard Safety ".. RailVal1.." Railing is not provided on top of the "..drainName..". (As per Land Transport Authority's latest Standard Details of Road Elements)");
			FXUtility.DisplaySolid_Error(drain, "Depth: "..drainHeight .. " mm", doubleArrow);
			-- CheckReport.AddRelatedObj(drain, drainName);
		end

		if Drawing06 == 0 then

			isAllCompliant = false;
			FXUtility.DisplaySolid_Error(drain, "Standard Safety ".. RailVal2.." Railing is not provided on top of the ".. drainName .. ". (" .. RailVal2 .. ", As per Request of Board)");
			FXUtility.DisplaySolid_Error(drain, "Depth: "..drainHeight .. " mm", doubleArrow);
			-- CheckReport.AddRelatedObj(drain, drainName);
		end
	end
end

function finalResult()

	if (isAllCompliant) then
		for i=1, #compliantDrain do
			compliantRailings[i]:ForEach(function ( railing )
				FXUtility.DisplaySolid_Info(railing, compliantMsg[i]);
				FXUtility.DisplaySolid_Info(railing, "Depth: "..compliantDrainHeight[i] .. " mm", compliantDoubleArrow[i]);
				CheckReport.AddRelatedObj(compliantDrain[i], compliantDrain[i]:GetAttri("ObjectType"));
			end)
		end
		-- for i=1, #compliantDrain do
		-- 	FXUtility.DisplaySolid_Info(compliantDrain[i], compliantMsg[i]);
		-- 	FXUtility.DisplaySolid_Info(compliantDrain[i], "Depth: "..compliantDrainHeight[i] .. " mm", compliantDoubleArrow[i]);
		-- 	-- CheckReport.AddRelatedGeometry_Info(compliantDoubleArrow[i], compliantDrainHeight[i].." mm height of "..compliantDrain[i]:GetAttri("ObjectType"));
		-- 	CheckReport.AddRelatedObj(compliantDrain[i], compliantDrain[i]:GetAttri("ObjectType"));
		-- 	compliantRailings[i]:ForEach(function ( railing )
		-- 	CheckReport.AddRelatedObj(railing, railing:GetAttri("ObjectType"));
		-- 	end)
		-- end
	end
	
end
