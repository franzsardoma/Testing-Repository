-- Author:Mohammad Derick Pauig


local grpOutlet = FXGroup.new()
local grpStorage = FXGroup.new()
local grpWash = FXGroup.new()
local grpVent = FXGroup.new()
local grpStrainer = FXGroup.new()
local grpTankVent = FXGroup.new()


function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_3_2_STORAGE_TANK_OUTLET_AND_WASH_OUT_PIPE")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	--local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpStorage = grpStorage + v
			grpStorage = grpStorage:Unique()			
		end	
		if k == 3 then
			grpOutlet = grpOutlet + v
			grpOutlet = grpOutlet:Unique()			
		end	
		if k == 4 then
			grpWash = grpWash + v
			grpWash = grpWash:Unique()			
		end
		if k == 5 then
			grpVent = grpVent + v
			grpVent = grpVent:Unique()			
		end
		if k == 6 then
			grpStrainer = grpStrainer + v
			grpStrainer = grpStrainer:Unique()			
		end
		if k == 7 then
			grpTankVent = grpTankVent + v
			grpTankVent = grpTankVent:Unique()			
		end	
	end
end

function checkRule(Building)

	print(#grpStorage.."Sto")
	print(#grpOutlet.."Out")
	print(#grpWash.."wash")
	print(#grpVent.."Vent")
	print(#grpStrainer.."stra")
	print(#grpTankVent.."tVent")
	local isNonCom =false
	local isCom = true 
	local Sto, Out, Wash,Stra, Tvent, dist, Point, Line1, Line2, dbArrow
	local grp = FXGroup.new()
	if #grpStorage ~= 0 then
		grpStorage:ForEach(function ( sto )
			if #grpOutlet ~= 0 then
				grpOutlet:ForEach(function ( out )	
					if FXPUB.IsObjsConnected(sto,out,5) then
						Out = out
						if #grpVent ~= 0 then
							grpVent:ForEach(function ( vent )
								if FXPUB.IsObjsConnected(sto,vent,5) then
									Vent = vent
									local stoOBB = FXGeom.GetBoundingOBB(sto);
									local cntrOBB = stoOBB:GetPos();
									local zp = cntrOBB.z
									local i = 1
									while (i > 0)do
										zp = zp - 1
										local point = Point3D(cntrOBB.x,cntrOBB.y,zp)
										local line = Line3D(cntrOBB,point)
										extndNode = FXUtility.CreateNodeFrom(line);
										if(FXClashDetection.IsCollided(extndNode , sto))then
											i = i - 1;
											zp = zp + 1
											FXClashDetection.DeleteNode(extndNode);
										end
										FXClashDetection.DeleteNode (extndNode);
									end
									
									local Point = Point3D(cntrOBB.x,cntrOBB.y,zp)
									local invert = out:GetAuxAttri("Mechanical.Invert Elevation")
									dist = invert - zp
									local outbox = FXGeom.GetBoundingBox(out)
									local low = outbox:LowPos()
									
									if outbox:x_range() > outbox:y_range() then
										Line1 = Line3D(Point3D(low.x,low.y,invert),Point3D(low.x + 100,low.y,invert))
										Line2 = Line3D(Point3D(Point.x,low.y,Point.z),Point3D(low.x + 100,low.y,zp))
										dist = Line3D(Point3D(low.x + 100,low.y,zp),Point3D(low.x + 100,low.y,invert)):Length()
										dbArrow = DoubleArrow(Point3D(low.x + 100,low.y,zp),Point3D(low.x + 100,low.y,invert));
									else
										Line1 = Line3D(Point3D(low.x,low.y,invert),Point3D(low.x,low.y + 100,invert))
										Line2 = Line3D(Point3D(low.x,Point.y,Point.z),Point3D(low.x,low.y + 100,zp))
										dist = Line3D(Point3D(low.x,low.y + 100,zp),Point3D(low.x,low.y + 100,invert)):Length()
										dbArrow = DoubleArrow(Point3D(low.x,low.y + 100,zp),Point3D(low.x,low.y + 100,invert));
									end
									print(dist)
									if dist <= 75 or dist >= 100 then
										isCom= false
										FXUtility.DisplaySolid_Error(sto ,out:GetAuxAttri("Entity.Description").." to bottom of "..sto:GetAttri("Name").." = "..FXUtility.Round(FXUtility.Round(dist,2)).." mm");
										CheckReport.AddRelatedGeometry_Error(Line1);
										CheckReport.AddRelatedGeometry_Error(Line2);
										CheckReport.AddRelatedGeometry_Error(dbArrow);
									end
									
									if #grpStrainer ~= 0 then
										grpStrainer:ForEach(function ( stra )
											
											if FXPUB.IsObjsConnected(stra,out,5) then
												Stra = stra
												if FXClashDetection.IsCollided(sto,stra) == false then
													isCom = false
													isNonCom = true
												else
													Stra = stra
												end
											else
												isCom = false
												isNonCom = true
											end
										end)
										if isNonCom == true then
											FXUtility.DisplaySolid_Error(sto ,"Strainer for "..out:GetAuxAttri("Entity.Description").." is not provided.");
											isNonCom = false
										end
									else
										isCom = false
										FXUtility.DisplaySolid_Error(sto ,"Strainer for "..out:GetAuxAttri("Entity.Description").." is not provided.");
									end
									

									if #grpWash ~= 0 then
										grpWash:ForEach(function ( wash )
											
											if FXPUB.IsObjsConnected(wash,sto,5) == false then
												isCom = false
												isNonCom = true
											else
												Wash = wash
											end
										end)
										if isNonCom == true then
											FXUtility.DisplaySolid_Error(sto ,"Wash-Out Pipe is not provided");
											isNonCom = false
										end
									else
										isCom = false
										FXUtility.DisplaySolid_Error(sto ,"Wash-Out Pipe is not provided");
									end

									if #grpTankVent ~= 0 then
										grpTankVent:ForEach(function ( tvent )
											
											if FXPUB.IsObjsConnected(tvent,vent,5) == false then
												isCom = false
												isNonCom = true
											else
												Tvent = tvent
											end
										end)
										if isNonCom == true then
											FXUtility.DisplaySolid_Error(sto ,"Tank Vent is not provided");
											isNonCom = false
										end
									else
										isCom = false
										FXUtility.DisplaySolid_Error(sto ,"Tank Vent is not provided");
									end
								

								else
									isCom = false
									isNonCom = true
								end
								if isNonCom == true then
									FXUtility.DisplaySolid_Warning(sto ,"Vent Pipe in "..sto:GetAttri("Name").." is not provided.");
									isNonCom = false
								end
							end)
						else
							isCom = false
							FXUtility.DisplaySolid_Warning(sto ,"Vent Pipe in "..sto:GetAttri("Name").." is not provided.");
						end
					else
						isCom = false
						isNonCom = true
					end
					if isNonCom == true then
						FXUtility.DisplaySolid_Warning(sto ,"Outlet Pipe in "..sto:GetAttri("Name").." is not provided.");
						isNonCom = false
					end
				end)
			else
				isCom = false
				FXUtility.DisplaySolid_Warning(sto ,"Outlet Pipe in "..sto:GetAttri("Name").." is not provided.");
			end
			Sto = sto
			if isCom == true then
				FXUtility.DisplaySolid_Info(Sto ,Out:GetAuxAttri("Entity.Description").." to bottom of "..Sto:GetAttri("Name").." = "..FXUtility.Round(FXUtility.Round(dist,2)).." mm");
				CheckReport.AddRelatedGeometry_Info(Line1);
				CheckReport.AddRelatedGeometry_Info(Line2);
				CheckReport.AddRelatedGeometry_Info(dbArrow);

				FXUtility.DisplaySolid_Info(Wash ,Wash:GetAuxAttri("Entity.Description").." is not provided.");
				FXUtility.DisplaySolid_Info(Stra ,Stra:GetAttri("Name").." for ".. Out:GetAuxAttri("Entity.Description").." is not provided.");
				FXUtility.DisplaySolid_Info(Tvent ,Tvent:GetAttri("Name").." is not provided.");
			end
			grp:Add(Out)
			grp:Add(Stra)
			grp:Add(Wash)
			grp:Add(Vent)
			grp:Add(Tvent)
			grpWash = grpWash - grp
			grpStrainer = grpStrainer - grp
			grpVent = grpVent - grp
			grpTankVent = grpTankVent - grp
			grpOutlet = grpOutlet - grp
		end)
	else
		isCom = false
		FXUtility.DisplaySolid_Warning(Building ,"Water Storage Tank is not provided.");
	end

	

end