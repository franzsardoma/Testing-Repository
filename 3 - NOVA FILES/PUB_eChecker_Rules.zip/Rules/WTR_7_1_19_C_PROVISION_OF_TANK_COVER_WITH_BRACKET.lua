--[[ 
	Implemented By: Jayson Barateta 01-08-19

]]

local Condition1;
local Condition2;
local TankGrp = FXGroup.new();
local TankCoverGrp = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("Parser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("CheckRule")
	CheckEngine.RunCheckPipeline()
end

function Parser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_19_C_PROVISION_OF_TANK_COVER_WITH_BRACKET");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsWithSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	Condition1Value = ConditionValues1[2];
	Condition2Value = ConditionValues2[2];
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	---------------WITHOUT SYSTEM---------------
	for k,v in pairs(GrpObjs) do
		if (k == 3) then	
			TankGrp = TankGrp + v;
			TankGrp = TankGrp:Unique();
		end
		if (k == 4) then	
			TankCoverGrp = TankCoverGrp + v;
			TankCoverGrp = TankCoverGrp:Unique();
		end
	end
	----------------WITH SYSTEM----------------		
	for k,v in pairs(GrpObjsWithSystem) do
		if (k == 2) then
			TankGrp = TankGrp + v;
			TankGrp = TankGrp:Unique();
		end
	end
end

function CheckRule(Building)
	local CompliantTankCover = {};
	local CompliantTank = {};
	local IsCompliant = true;
	
	if(#TankGrp ~= 0)then 
		if(#TankCoverGrp ~= 0)then
			TankGrp:ForEach(function(Element)
				local BuildingStorey = FXUtility.GetStorey(Element);
				local TankCover = GetTankCover(TankCoverGrp, BuildingStorey);
				if(Element.Type ~= "Space")then
					TankCover:ForEach(function(Element1)
						if(FXClashDetection.IsCollided(Element1,Element))then 
							local Condition1, Condition2 = CheckObjectProperty(Element1);
							if(Condition1 == Condition1Value and Condition2 == Condition2Value)then
								table.insert(CompliantTankCover,Element1);
							elseif (Condition1 ~= Condition1Value and Condition2 == Condition2Value or Condition1 == Condition1Value and Condition2 ~= Condition2Value)then
		
								IsCompliant = false;
								FXUtility.DisplaySolid_Error(Element1,"Incomplete fastening requirements.");
							else
								IsCompliant = false;
								FXUtility.DisplaySolid_Error(Element1,"Stainless steel brackets and tapered round nuts are not provided.");
							end
						end
					end)
				else
					local Doors = Element:GetConnectedDoor();
					if(#Doors == 0)then
						TankCover:ForEach(function(Element1)
							if(GetCollidedElementInSpace(Element,Element1))then 
								local Condition1, Condition2 = CheckObjectProperty(Element1);
								if(Condition1 == Condition1Value and Condition2 == Condition2Value)then
									table.insert(CompliantTankCover,Element1);
								elseif (Condition1 ~= Condition1Value and Condition2 == Condition2Value or Condition1 == Condition1Value and Condition2 ~= Condition2Value)then
									IsCompliant = false;
									FXUtility.DisplaySolid_Error(Element1,"Incomplete fastening requirements.");
								else
									IsCompliant = false;
									FXUtility.DisplaySolid_Error(Element1,"Stainless steel brackets and tapered round nuts are not provided.");
								end
							end
						end)
					end
				end
			end)

			if(IsCompliant)then
			 	for k,v in pairs(CompliantTankCover) do
			 		FXUtility.DisplaySolid_Info(v,"Stainless steel brackets, tapered round nuts are provided.");
			 	end
			end
		else
			FXUtility.DisplaySolid_Warning(Building, "Tank Cover is not provided.");
		end	
	else
		FXUtility.DisplaySolid_Warning(Building, "Tank is not provided.");
	end
end

function GetTankCover(Group, BuildingStorey)
	local TankCoverWithSameLevel = FXGroup.new();
	Group:ForEach(function(Element)
		local Storey = FXUtility.GetStorey(Element);
		if(Storey.Id == BuildingStorey.Id)then 
			TankCoverWithSameLevel:Add(Element);
		end
	end)
	return TankCoverWithSameLevel;
end

function GetCollidedElementInSpace(Object, tankCover)
	local Result = false;
	local GrpObjects = Object:GetConnectedWall();
	GrpObjects:ForEach(function(Element)
		if(FXClashDetection.IsCollided(Element,tankCover))then 
			Result = true;
		end
	end)

	return Result;
end

function CheckObjectProperty(Object)
	local Property1 = Object:GetAuxAttri("Mechanical.Stainless Steel Bolts and Nuts");
	local Property2 = Object:GetAuxAttri("Mechanical.Stainless Steel Bracket(s)");

	return Property1, Property2;
end