local TrenchGrp=FXGroup.new();
local compliantGrp = FXGroup.new()
local noncompliantGrp = FXGroup.new()
function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end



function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_7_REQUIRED_TRENCH_MATERIAL");
  local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
  materials = (ConditionValues[3]);
  -- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  -- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2 ) then
      TrenchGrp = TrenchGrp + v;
      TrenchGrp = TrenchGrp:Unique();
    end
  end
end

function checkRule(Building)
  local isCompliant = true;
  if #TrenchGrp ~= 0 then
    TrenchGrp:ForEach(function(trenchEle)
      local sturdy,mats = FXPUB.CheckObjMaterial(trenchEle, materials)
      if sturdy then
        compliantGrp:Add(trenchEle)
      else
        noncompliantGrp:Add(trenchEle)
      end
    end)

    if #noncompliantGrp == 0 then 
      compliantGrp:ForEach(function(compliantEle)
        local sturdy,mats = FXPUB.CheckObjMaterial(compliantEle, materials)
        FXUtility.DisplaySolid_Info(compliantEle,mats);
      end)
    else
      noncompliantGrp:ForEach(function(noncompliantEle)
        local sturdy,mats = FXPUB.CheckObjMaterial(noncompliantEle, materials)
        FXUtility.DisplaySolid_Error(noncompliantEle,mats);
      end)
    end
  else
    FXUtility.DisplaySolid_Warning(Building,"Trench is not detected.")
  end   
end		