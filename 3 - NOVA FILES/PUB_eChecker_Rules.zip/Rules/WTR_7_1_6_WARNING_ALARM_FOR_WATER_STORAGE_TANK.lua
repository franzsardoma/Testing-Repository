local grpWarning = FXGroup.new()
local grpFlowStorageDevice = FXGroup.new()
local grpOverFlow = FXGroup.new()

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_6_ALARM_LEVEL_FOR_WATER_STORAGE_TANK")
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	local GrpObjs1 = FXRule.filterObjects(parsedXml, Building);

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpWarning = grpWarning + v
				grpWarning = grpWarning:Unique()
			end	    
			if (k == 3) then
				grpFlowStorageDevice = grpFlowStorageDevice + v
				grpFlowStorageDevice = grpFlowStorageDevice:Unique()
			end	
			if (k == 4) then
				grpOverFlow = grpOverFlow + v
				grpOverFlow = grpOverFlow:Unique()
			end	   	 
		end
	end
	for k,v in pairs(GrpObjs1) do
		if (k == 2) then
			grpWarning = grpWarning + v
			grpWarning = grpWarning:Unique()
		end
	end
end

function CheckRule(Building)
	print (#grpFlowStorageDevice .. " - " .. #grpOverFlow .. " - " .. #grpWarning)

	if #grpFlowStorageDevice == 0 then 
		return
	elseif #grpOverFlow == 0 then 
		return
	end

	local nonCompPipe = {}
	local flag = true
	local flag2 = true
	local desiredLvl = tonumber(ConditionValues1[1])
	local nonCompBldgStorey = {}
	local nonCompBldgStorey2 = {}
	local compBldgStorey = {}
	local compArrow = {}
	local nonCompArrow = {}
	local compLine = {}
	local nonCompLine = {}
	local compLength = {}
	local nonCompLength = {}
	local tankArray = {}
	local overFlowArray = {}
	local warningArray = {}
	local isErrorFound = false
	local i = 0

	grpFlowStorageDevice : ForEach ( function ( flowStorageObj )
		local topFace = FXMeasure.GetTopFace( flowStorageObj )	
		local storageHeight = FXGeom.GetBoundingBox(flowStorageObj):HighPos().z - FXGeom.GetBoundingBox(flowStorageObj):LowPos().z
		local extrudeFace = topFace:ExtrudedFace(Vector(0,0, - storageHeight ));
		
		local isDistributionControlElementFound = false
		local foundDistributonControlElement
		local node = FXUtility.CreateNodeFrom( extrudeFace );

		local collidedLevel 
		local overFlow

		grpOverFlow : ForEach ( function ( overObj )
			if FXPUB.IsObjsConnected( flowStorageObj , overObj , 2 ) then
				overFlow = overObj			
			end
		end)

		if #grpWarning == 0 then
			table.insert(nonCompBldgStorey2, flowStorageObj:GetParent())
			table.insert(nonCompPipe, overFlow)
			flag = false
		else
			grpWarning : ForEach ( function ( warningLevel )
				if FXClashDetection.IsCollided( node , warningLevel )then
					collidedLevel = warningLevel
				end
			end)
		end
		
		FXClashDetection.DeleteNode( node );

		if flag == true then

			local warningElev = FXGeom.GetBoundingBox( collidedLevel ):HighPos()
			local warningOBB = FXGeom.GetBoundingOBB( collidedLevel )
			local pipeOBB = FXGeom.GetBoundingOBB( overFlow )
			local pipeLowPos2 = FXGeom.GetBoundingBox( overFlow ):LowPos()
			local cntrOBB = pipeOBB:GetPos();
			local cntrOBB2 = warningOBB:GetPos();
			local line1 = Line3D(Point3D(cntrOBB.x,cntrOBB.y,warningElev.z),cntrOBB2)
			local Node = FXUtility.CreateNodeFrom( line1 );
			local distance = FXMeasure.Distance(Node, overFlow);
			local warningLevelDist = distance:Length(); 
			local arrowGeom = DoubleArrow(distance:GetStartPoint(),distance:GetEndPoint());
			FXClashDetection.DeleteNode( Node );

			if warningLevelDist >=  desiredLvl then
				table.insert(compBldgStorey, flowStorageObj:GetParent())
				table.insert(compArrow, arrowGeom)
				table.insert(compLine, line1)
				table.insert(compLength, warningLevelDist)
			else
				flag2 = false
				table.insert(nonCompBldgStorey, flowStorageObj:GetParent())
				table.insert(nonCompArrow, arrowGeom)
				table.insert(nonCompLine, line1)
				table.insert(nonCompLength, warningLevelDist)
			end
		end		
	end)

	if flag == false then
		for i=1,#nonCompPipe do
			FXUtility.DisplaySolid_Error ( nonCompPipe[i] , "Warning Alarm Level is not provided.")
		end
	elseif flag2 == true then
		for i=1,#compArrow do
			FXUtility.DisplaySolid_Info ( compBldgStorey[i] , "Space between Warning Alarm Level and Overflow Pipe invert level is " .. compLength[i] .."mm." )
			CheckReport.AddRelatedGeometry_Info( compArrow[i] )
			CheckReport.AddRelatedGeometry_Info( compLine[i] )
		end
	else
		for i=1,#nonCompArrow do
			FXUtility.DisplaySolid_Error ( nonCompBldgStorey[i] , "Space between Warning Alarm Level and Overflow Pipe invert level is " .. nonCompLength[i] .."mm." )
			CheckReport.AddRelatedGeometry_Error( nonCompArrow[i] )
			CheckReport.AddRelatedGeometry_Error( nonCompLine[i] )
		end
	end
end