local Sewage = FXGroup:new()
local sewCondi

function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_8_G_IX_SEWAGE_TREATMENT_PLANT_MATERIAL")
    local systemTypes = FXRule.ParseValues(parsedXml, "SystemType")
   	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

    sewCondi = tostring(Condition1[1])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if ( k == 2 ) then
				Sewage = Sewage + v
				Sewage = Sewage:Unique()
			end
		end
	end
end	

function CheckRule(Building)

	local arraySewage = {}
	local sewageTable
	local isCompliant = true

	if CheckWarning(Building) then
		
		Sewage:ForEach(function(sewageEle)
			
			local Material = FXPUB.CheckObjMaterial(sewageEle,sewCondi)

			if ( Material ~= nil ) then

				if Material then

					isCompliant = true
					sewageTable = sewageEle
				else

					isCompliant = false
					FXUtility.DisplaySolid_Error(sewageEle, " The Sewage Treatment Plant is not made of corrosion resistant material.")					
					CheckReport.AddRelatedObj(sewageEle, sewageEle:GetAttri("Name").. ";" ..sewageEle:GetAuxAttri("Materials and Finishes.Material"))
				end
			else

				isCompliant = false
				FXUtility.DisplaySolid_Warning(sewageEle, "Material is not Provided")
			end

			if isCompliant then

				table.insert(arraySewage,sewageTable)
			end
		end)

		if isCompliant then

			for k=1, #arraySewage do

				FXUtility.DisplaySolid_Info(arraySewage[k], " The Sewage Treatment Plant is made of corrosion resistant material.")
				CheckReport.AddRelatedObj(arraySewage[k], arraySewage[k]:GetAttri("Name").. ";" ..arraySewage[k]:GetAuxAttri("Materials and Finishes.Material"))
			end
		end
	end
end

function CheckWarning(Building)
	
	local Warning = true

	if (#Sewage == 0) then

		FXUtility.DisplaySolid_Warning(Building, "Sewage Treatment Plant is not provided.")
		Warning = false
	end

	return Warning
end
