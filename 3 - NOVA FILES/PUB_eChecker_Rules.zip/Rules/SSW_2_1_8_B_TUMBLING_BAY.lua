local grpManhole = FXGroup.new()
local grpIncomingSewer = FXGroup.new()
local grpPublicSewer = FXGroup.new()
local grpTumblingBay = FXGroup.new()
local ARRManhole={}
local ARRIncoming={}
local ARRPublic={}
local ARRTumbling={}
local ARRVerticalDistance={}
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_8_B_TUMBLING_BAY");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	operator = (ConditionValues[4])
  	max = tonumber(ConditionValues[5])
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpManhole = grpManhole + v;
			grpManhole = grpManhole:Unique();
		end
		if (k == 3) then
			grpIncomingSewer = grpIncomingSewer + v;
			grpIncomingSewer = grpIncomingSewer:Unique();
		end
		if (k == 4) then
			grpPublicSewer = grpPublicSewer + v;
			grpPublicSewer = grpPublicSewer:Unique();
		end
		if (k == 5) then
			grpTumblingBay = grpTumblingBay + v;
			grpTumblingBay = grpTumblingBay:Unique();
		end
	end
end

function checkRule(Building)
	local check = true;
	local isCompliant = true;
	if #grpManhole == 0 then
		check = false
		FXUtility.DisplaySolid_Warning(Building, MSG_NO_MANHOLE)
	end
	if #grpIncomingSewer == 0 then
		check = false
		FXUtility.DisplaySolid_Warning(Building, MSG_NO_SEWER_CONNECTION)
	end
	if #grpPublicSewer == 0 then
		check = false
		FXUtility.DisplaySolid_Warning(Building, MSG_NO_PUBLIC_SEWER)
	end
	if check then
		local i = 0;
		grpManhole:ForEach(function ( Manhole )
			local ReducerGrp = FXGroup.new()
			local FlowFittingGrp = Building:GetDescendants("FlowFitting");
			local FlowSegmentGrp = Building:GetDescendants("FlowSegment");
			local incomingSewer;
			local publicSewer;
			local manholeName = Manhole:GetAttri("Name")
			local publicLowpos=0;
			local incomingLowpos=-0;
			local flag = false
			
			FlowFittingGrp:ForEach(function(flowfittingEle)
				local name = string.lower(flowfittingEle:GetAttri("Name"))
				 if FXUtility.HasPatterInString(name,"reducer") == true then
				 	ReducerGrp:Add(flowfittingEle);
				 end
			end)

			grpIncomingSewer:ForEach(function ( sewer )
				local checkConnectedChamber = FXPUB.CheckConnectedChamberElement(Building,Manhole,sewer)
				if checkConnectedChamber == true then
					incomingSewer = sewer;
					incomingOBBLowPos = FXGeom.GetBoundingBox(sewer):LowPos().z
					incomingLowpos = incomingOBBLowPos;
					flag = true;
				end	
			end)

			if flag == false then
				FXUtility.DisplaySolid_Warning(Building,"Manhole not connected to sewer.")
				return;
			end	

			grpPublicSewer:ForEach(function ( sewer )
				if FXClashDetection.IsCollided(Manhole, sewer) then
					publicSewer = sewer
					publicOBBLowPos = FXGeom.GetBoundingBox(sewer):LowPos().z
					publicLowpos = publicOBBLowPos;	
				end
			end)
			local verticalDistance = FXUtility.Round(incomingLowpos - publicLowpos,2)
			local verticalDistanceRounded = FXUtility.Round(verticalDistance/1000,2)
			if verticalDistance <= max and verticalDistance >=500 then
				if #grpTumblingBay ~= 0  then
					grpTumblingBay:ForEach(function ( tumblingBay )
						if FXPUB.CheckConnectedChamberElement(Building,Manhole,tumblingBay) then
							i = i + 1;
							ARRManhole[i] = Manhole;
							ARRPublic[i] = grpPublicSewer;
							ARRIncoming[i] = grpIncomingSewer;
							ARRTumbling[i] = grpTumblingBay;
							ARRVerticalDistance[i] = verticalDistanceRounded
						end
					end)
				else
					isCompliant = false;
					FXUtility.DisplaySolid_Error(Manhole, Manhole:GetAttri("Name").." : Tumbling Bay is not provided.");
					CheckReport.AddRelatedObj( Manhole, "Vertical Distance: "..verticalDistanceRounded.." m")

					grpIncomingSewer:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
					end)

					grpPublicSewer:ForEach(function ( sewer )
						CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
					end)

					grpTumblingBay:ForEach(function ( tbayEle )
						CheckReport.AddRelatedObj( tbayEle, tbayEle:GetAttri("Name"))
					end)
				end
			elseif verticalDistance > max then
				isCompliant = false;
				FXUtility.DisplaySolid_Warning(Manhole, "Vertical Distance is greater than 1.5m")
				CheckReport.AddRelatedObj( Manhole, "Vertical Distance: "..verticalDistanceRounded.." m")

				grpIncomingSewer:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
				end)

				grpPublicSewer:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
				end)
				return
			else 	
				isCompliant = false;
				FXUtility.DisplaySolid_Warning(Manhole, "Vertical Distance  is less than 0.5m")
				CheckReport.AddRelatedObj( Manhole, "Vertical Distance: "..verticalDistanceRounded.." m")

				grpIncomingSewer:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
				end)

				grpPublicSewer:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
				end)
				return
			end
		end)

		if isCompliant then
			for i,manhole in pairs(ARRManhole) do
				FXUtility.DisplaySolid_Info(manhole, manhole:GetAttri("Name").." : Tumbling Bay is provided.");
				CheckReport.AddRelatedObj( manhole, "Vertical Distance: "..ARRVerticalDistance[i].." m")

				ARRPublic[i]:ForEach(function ( sewer )
				CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
				end)

				ARRIncoming[i]:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
				end)

				ARRTumbling[i]:ForEach(function ( tbayEle )
					CheckReport.AddRelatedObj( tbayEle, tbayEle:GetAttri("Name"))
				end)
			end
		end
	end
end