--[[
	Implemented by: Lawrence Roy Quiling
	Modefied by: Aldrin Lacorte 01/03/2019
	Modefied by: Lawrence Roy Quiling 01/22/2019
]]

local grpPublicSewers = FXGroup:new();
local grpManholes = FXGroup:new();
local grpSewerConnections = FXGroup:new();
local grpConnToPublic = FXGroup:new();
local BuildingValues = {}
local Element4Types = {}
local ProjectValue
local ManholeValues = {}
local SewerValues
local PublicSewerValues

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_3_A_IV_MANHOLE_IN_DRAIN_TO_PUBLIC_SEWER") 
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	-- print(#GrpObjsSystem)
	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpSewerConnections = grpSewerConnections + v;
				grpSewerConnections = grpSewerConnections:Unique();
			end
			if (k == 3) then
				grpPublicSewers = grpPublicSewers + v;
				grpPublicSewers = grpPublicSewers:Unique();
			end
			if (k == 4) then
				grpManholes = grpManholes + v;
				grpManholes = grpManholes:Unique();
			end
		end
	end
	
	local Values1 = {}
	local Values2 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
			if(k == 2) then
				table.insert(Values2, v1["value"])
			end
			if(k == 3) then
				table.insert(ManholeValues, v1["value"])
			end
			if(k == 4) then
				table.insert(BuildingValues, v1["value"])
				table.insert(Element4Types, v1["type"])
				ProjectValue = v1["property"]
			end
		end
	end

	SewerValues = getValue(Values1)
	PublicSewerValues = getValue(Values2)
end

function getValue( tab )
	local value = tab[1]
	local length = #tab

	for k,v in pairs(tab) do
		if k ~= 1 then
			if k ~= length then
				value = value..", "..v
			
			elseif k == length then 
				value = value.." or "..v
			end
		end
	end

	return value
end

function getProjDevType( Building )
	for k,v in pairs(Element4Types) do
		if v == "Building" then
			return FXPUB.GetProjDevelopmentType(Building)
		elseif v == "Site" then
			return FXPUB.GetProjDevelopmentType(Building:GetParent())
		end
	end
	return nil
end

function checkRule( Building )
	
	local BuildingType  = getProjDevType(Building)
	grpConnToPublic = grpManholes + getJunctions(Building:GetDescendants("FlowSegment"))
	local flag = true

	if(#grpSewerConnections == 0) then
		flag = false
		CheckReport.Warning( Building, SewerValues.." is not provided." )
	end
	if(#grpPublicSewers == 0) then
		flag = false
		CheckReport.Warning( Building, PublicSewerValues.." is not provided." )
	end
	if BuildingType == nil or HasValue( BuildingType, BuildingValues ) == false then
		flag = false
		CheckReport.Warning( Building, ProjectValue.." is not provided." )
	end

	if(flag == true) then
		local isErrorNotFound = true
		local isNil = true
		local ARRConn = {}
		grpConnToPublic = getConnToPublicSewer( grpConnToPublic )

		grpSewerConnections:ForEach(function ( SewerConnEle )
			local isDirectConn = false
			local ConnToPublic;

			grpConnToPublic:ForEach(function ( ConnEle )

				if(FXClashDetection.IsCollided(SewerConnEle,ConnEle))then
					if(FXClashDetection.IsCollided(SewerConnEle,ConnEle))then
						isDirectConn = true
						ConnToPublic = ConnEle
					end
				end
			end)

			if(isDirectConn == false) then
				local grpFlowFittings = getConnFlowFittings(SewerConnEle) 
				ConnToPublic = getConnToPublic( grpFlowFittings ) 
			end
			
			if (ConnToPublic ~= nil) then
				isNil = false
				if HasValue( ConnToPublic:GetAttri("ObjectType"), ManholeValues ) then
					table.insert(ARRConn, ConnToPublic) 
				else
					FXUtility.DisplaySolid_Error(ConnToPublic, "Project Development Type: "..BuildingType.."; "..ManholeValues[1].." is not provided");
					CheckReport.AddRelatedObj(ConnToPublic, ConnToPublic:GetAttri("ObjectType") )
					isErrorNotFound = false
				end
			end
		end)
		if isNil then
			CheckReport.Warning( Building, "There is no connection to "..PublicSewerValues )
		end
		if isErrorNotFound then
			for k,ConnToPublic in pairs(ARRConn) do
				FXUtility.DisplaySolid_Info(ConnToPublic, "Project Development Type: "..BuildingType.."; "..ConnToPublic:GetAttri("ObjectType").." is provided");
				CheckReport.AddRelatedObj(ConnToPublic, ConnToPublic:GetAttri("ObjectType") )
			end
		end
	end
end

function getConnFlowFittings( Obj )
	local grpFittings = FXGroup:new()
	local connectedObj = Obj:GetConnectedElement();

	connectedObj:ForEach(function ( Ele )
		if (FXUtility.HasPatterInString(Ele.Type,"FlowFitting")) then
			grpFittings:Add(Ele)
		end
	end)
	return grpFittings;
end

function getConnToPublic( grpFlowFittings )
	local flag = false
	local obj;

	grpFlowFittings:ForEach(function ( FlowFittingEle )
		if flag == false then
			grpConnToPublic:ForEach(function ( ConnEle )
				if(flag == false and FXClashDetection.IsCollided(FlowFittingEle,ConnEle))then
					flag = true
					obj = ConnEle
				end
			end)
		end
	end)
	return obj;
end

function getJunctions( grpSegments )
	local grpJunctions = FXGroup:new();

	grpPublicSewers:ForEach(function ( PublicSewer )
		grpJunctions = grpJunctions + PublicSewer:GetConnectedElement();
		grpJunctions:Unique()
	end)
	grpJunctions = grpJunctions - grpSegments
	return grpJunctions;
end

function getConnToPublicSewer( grpConnToPublic1 )
	local grp = FXGroup:new();

	grpConnToPublic1:ForEach(function ( ConnEle )

		grpPublicSewers:ForEach(function ( PublicSewerEle )

			if(FXClashDetection.IsCollided(PublicSewerEle,ConnEle) or FXRelation.Distance(PublicSewerEle, ConnEle):Length() <= 1)then
				grp:Add(ConnEle)
			end
		end)
	end)
	return grp;
end

function HasValue( val, tab )
    for index, value in pairs(tab) do
        if (FXUtility.HasPatterInString(value,val)) then
            return true
        end
    end
    return false
end