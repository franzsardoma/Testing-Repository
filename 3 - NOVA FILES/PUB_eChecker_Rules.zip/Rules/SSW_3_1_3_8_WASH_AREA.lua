--Rafael 
--Update SSW 3.1.3.8 Wash Area

local SystemTypes;
local grpSpaces = FXGroup:new();
local grpKerb = FXGroup:new();
local grpFlrWaste = FXGroup:new();
local grpCover = FXGroup:new();
local grpFlrTrap = FXGroup:new();
local grpInsChamber = FXGroup:new();
local systemGrp = FXGroup:new();
local grpFlowSegment = FXGroup:new()
local flowGrp = grpFlowSegment + grpFlrTrap + grpFlrWaste;
local coverRoof1;
local coverRoof2;
local minWidthKerb;
local minHeightKerb;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRuleParams");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

-- function script_path()
-- 	local str = debug.getinfo(2, "S").source:sub(2)
-- 	local str2 = string.gsub(str,str:match("^.*/(.*).lua$")..".lua","")
-- 	local str3 = string.gsub(str2,"/Rules","")
-- 	return string.gsub(str3,"/","\\")

--     --local var = FX_PATH.ConfigPath()
-- 	--return string.gsub(var,"\\Rules","")
-- end 


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_8_WASH_AREA")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	minWidthKerb = tonumber(ConditionValues[2]);
	minHeightKerb = tonumber(ConditionValues[5]);


	-- if GrpObjSystem ~= nil then
	-- 	for k,v in pairs(GrpObjSystem) do
	-- 		if (k == 2) then
	-- 			grpSpaces = grpSpaces + v
	-- 			grpSpaces = grpSpaces:Unique()
	-- 		end
	-- 		if (k == 3) then
	-- 			grpKerb = grpKerb + v
	-- 			grpKerb = grpKerb:Unique()
	-- 		end
	-- 		if (k == 4) then
	-- 			grpFlrWaste = grpFlrWaste + v
	-- 			grpFlrWaste = grpFlrWaste:Unique()
	-- 		end
	-- 		if (k == 5) then
	-- 			grpCover = grpCover + v
	-- 			grpCover = grpCover:Unique()
	-- 		end
	-- 		if (k == 6) then
	-- 			grpFlrTrap = grpFlrTrap + v
	-- 			grpFlrTrap = grpFlrTrap:Unique()
	-- 		end
	-- 		if (k == 7) then
	-- 			grpInsChamber = grpInsChamber + v
	-- 			grpInsChamber = grpInsChamber:Unique()
	-- 		end
	-- 	end
	-- else
	if GrpObjSystem ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpSpaces = grpSpaces + v
				grpSpaces = grpSpaces:Unique()
			end
			if (k == 3) then
				grpKerb = grpKerb + v
				grpKerb = grpKerb:Unique()
			end
			if (k == 4) then
				grpFlrWaste = grpFlrWaste + v
				grpFlrWaste = grpFlrWaste:Unique()
			end
			if (k == 5) then
				grpCover = grpCover + v
				grpCover = grpCover:Unique()
			end
			if (k == 6) then
				grpFlrTrap = grpFlrTrap + v
				grpFlrTrap = grpFlrTrap:Unique()
			end
			if (k == 7) then
				grpInsChamber = grpInsChamber + v
				grpInsChamber = grpInsChamber:Unique()
			end
		end
	end
end
function checkRuleParams(Building)
	
	grpFlowSegment = Building:GetDescendants("FlowSegment");
	
end
	
	-- grpCover = Building:GetDescendants("Roof") + Building:GetDescendants("Slab");
	
	-- grpKerb = Building:GetDescendants("BuildingElementProxy");
	-- tempName = {"Kerb"}
	-- grpKerb = grpKerb:Filter(function(ele)
	-- 	return FXUtility.IsBelongToTableElement(ele,tempName);
	-- end);
	
	-- grpFlrWaste = Building:GetDescendants("FlowTerminal");
	-- tempName = {"Floor Waste"}
	-- grpFlrWaste = grpFlrWaste:Filter(function(ele)
	-- 	return FXUtility.IsBelongToTableElement(ele,tempName);
	-- end);
	-- grpFlrTrap = Building:GetDescendants("FlowFitting");
	-- tempName = {"Floor Trap"}
	-- grpFlrTrap = grpFlrTrap:Filter(function(ele)
	-- 	return FXUtility.IsBelongToTableElement(ele,tempName);
	-- end);

	-- grpFlowSegment = Building:GetDescendants("FlowSegment");
	
	-- grpInsChamber = Building:GetDescendants("DistributionChamberElement") + Building:GetDescendants("FlowTerminal");
	-- tempName = {"Inspection Chamber"}
	-- grpInsChamber = grpInsChamber:Filter(function(ele)
	-- 	return FXUtility.IsBelongToTableElement(ele,tempName);
	-- end);
	
	-- systemGrp = Building:GetParent():GetParent():GetDescendants("System");
	
--[[print("***************************************** grpSpaces: "..#grpSpaces);
	print("***************************************** grpKerb: "..#grpKerb);
	print("***************************************** grpFlrWaste: "..#grpFlrWaste);
	print("***************************************** grpCover: "..#grpCover);
	print("***************************************** grpFlrTrap: "..#grpFlrTrap);
	print("***************************************** grpInsChamber: "..#grpInsChamber);]]


function checkRule(Building)
	flowGrp = grpFlrTrap + grpFlrWaste + grpFlowSegment;
	if(#grpSpaces == 0) then
		FXUtility.DisplaySolid_Warning(Building,"No Wash Area found.");
		return;
	end
	local flag = 0;
	local spacePrj;
	grpSpaces:ForEach(function(space)
		local obbSpace 			= FXGeom. GetBoundingOBB(space);
		local zSpace 			= obbSpace:MaxPnt().z;
		local zSpaceMin 			= obbSpace:MinPnt().z;
		local InSpaceEles = space:GetInSpaceElement();
		local resFinal = false;
		local resCover = false;
		local resWaste = false;
		local prjCoverdGrp;
		local tempObject;
		local kerbObj;
		local flrTrapObj;
		local inspctObj;
		local isHtEnough;
		spacePrj = FXMeasure.GetObjProjection(space,zSpaceMin)
		local outer = FXMeasure.GetOuterEdge(spacePrj)
		local face = outer:Face3D();
		local extruded = face:ExtrudedFace(Vector(0,0,-2500))
		local faceNode = FXUtility.CreateNodeFrom(extruded)
		local longestPipe = FXGroup:new()
		
		if #grpFlowSegment ~= 0 then
			local longest;
			if flag ~= 2 then
				flag = 1;
			end
			flowGrp:ForEach(function(obj)
				if FXClashDetection.IsCollided(faceNode,obj)then
					local name = obj:GetAttri("Name")
					if FXUtility.HasPatterInString(name,"Floor Trap") == true then
						local flowsegGrp = FXPUB.GetConnectedObjGrp(obj,"FlowSegment","Any")
						flowsegGrp = flowsegGrp:Unique()
						local lastpipe;
						flowsegGrp:ForEach(function(pipe)
							lastpipe = pipe
						end)
						if lastpipe ~= nil then
							if #grpInsChamber ~= 0 then
								grpInsChamber:ForEach(function(obj1)
									if FXClashDetection.IsCollided(lastpipe,obj1)then
										inspctObj = obj1
									end
								end)
							end
						end
---------------------------------------------------------- Inspector Chamber --------------------------------------
						if( #grpInsChamber == 0 ) then
							FXUtility.DisplaySolid_Error(space, "No Inspection chamber found");
							flag = 2
						elseif( inspctObj == nil ) then
							local dist;
							local objTemp;
							grpInsChamber:ForEach(function(obj5)
								local linedist = FXMeasure.Distance(space, obj5);
								if( dist == nil ) then
									dist = linedist:Length();
									objTemp = obj5;
								else
									if( dist > linedist:Length() ) then
										dist = linedist:Length();
										objTemp = obj5;
									end
								end
							end)

							if( obj ~= nil and objTemp ~= nil ) then
								FXUtility.DisplaySolid_Error(space, "No Connection; "..obj:GetAttri("Name").."; "..objTemp:GetAttri("Name"));
								flag = 2
							end
						end
					end
				end
			end)
		end
		InSpaceEles:ForEach(function(obj)
			if FXUtility.HasPatterInString(obj:GetAttri("Name"), "kerb" ) then
				kerbObj = obj;
			end
		end)
		if( kerbObj ~= nil ) then
			local obb 				= FXGeom. GetBoundingOBB(kerbObj);
			local zValue 			= obb:MaxPnt().z;
			local kerbProj 			= FXMeasure.GetObjProjection(kerbObj, zValue);	
			
			---------------------------------------------------------- Kerb Covered --------------------------------------
			
			grpCover:ForEach(function(cover)
				local obbCover 			= FXGeom. GetBoundingOBB(cover);
				local zCover 			= obbCover:MaxPnt().z;
				
				if( zCover > zSpace ) then
					local coverProj =  FXMeasure.GetObjProjection(cover, zValue);
					local tempprjCoverdGrp = FXMeasure.IntersectTwoProjection(coverProj,kerbProj, 0);
					local coveredspacePrj = FXMeasure.IntersectTwoProjection(coverProj,spacePrj, 0);				
					local area1 = FXUtility.Round(FXMeasure.GetProjectionArea(kerbProj)/1000000, 2);
					local area2 = FXUtility.Round(FXMeasure.GetProjectionArea(tempprjCoverdGrp)/1000000, 2);

					if( area2 ~= 0 and area1 == area2 ) then
						resCover = true
						coverRoof1 = cover
					end
					
					if( area1 ~= area2 and resFinal == false ) then
						if( area2 ~= 0 ) then
							prjCoverdGrp = coveredspacePrj;
							coverRoof2 = cover;
						end
					end
				end
			end)
			
			if( resCover == false and prjCoverdGrp == nil) then
				FXUtility.DisplaySolid_Error(space, "No cover; "..space:GetAttri("LongName"),spacePrj);
				flag = 2

			elseif( resCover == false and prjCoverdGrp ~= nil) then
				FXUtility.DisplaySolid_Error(space, "Partially covered; "..space:GetAttri("LongName"), prjCoverdGrp);
				CheckReport.AddRelatedObj(coverRoof2, coverRoof2:GetAttri("Name"))
				flag = 2
			end
		else
			FXUtility.DisplaySolid_Error(space, "No Kerb found");
			flag = 2
		end
		
		---------------------------------------------------------- Floor Waste --------------------------------------
			
		grpFlrWaste:ForEach(function(obj1)
			local distanceObjs = FXMeasure.Distance(space, obj1)
			if(distanceObjs:Length() < 100) then
				resWaste = true;
			end
			
			isHtEnough = CheckKerp(space, obj1);
		end)
		
		if not( resWaste ) then
			FXUtility.DisplaySolid_Error(space, "No Floor Waste found");
			flag = 2
		end
		
		---------------------------------------------------------- Floor Trap --------------------------------------
		
		grpFlrTrap:ForEach(function(obj1)
			local distanceObjs = FXMeasure.Distance(space, obj1)
			if(distanceObjs:Length() < 300) then
				flrTrapObj = obj1;
			end
		end)
		
		if ( flrTrapObj == nil ) then
			FXUtility.DisplaySolid_Error(space, "No Floor Trap found");
			flag = 2
		end
		
		
	end)
	---------------------------------------------------------- Compliant Result --------------------------------------
	if flag == 1 then
		grpSpaces:ForEach(function(space)
			FXUtility.DisplaySolid_Info(space, "The Wash Area is fully covered and appropriately kerbed. It is connected to a floor waste, floor trap and inspection chamber.", spacePrj);
			CheckReport.AddRelatedObj(coverRoof1, coverRoof1:GetAttri("Name"))
		end)
		grpKerb:ForEach(function(kerb)
			CheckReport.AddRelatedObj(kerb, kerb:GetAttri("Name"))
		end)
		grpFlrWaste:ForEach(function(waste)
			CheckReport.AddRelatedObj(waste, waste:GetAttri("Name"))
		end)
		grpFlrTrap:ForEach(function(flrTrap)
			CheckReport.AddRelatedObj(flrTrap, flrTrap:GetAttri("Name"))
		end)
		grpInsChamber:ForEach(function(chamber)
			CheckReport.AddRelatedObj(chamber, chamber:GetAttri("Name"))
		end)

	end
end

function CheckKerp(space, flrWaste)

	local InSpaceEles = space:GetInSpaceElement();
	local belowSlab = space:GetSlabsBelow();
	
	local height;
	local width;
	local isPassed = true;
	
	InSpaceEles:ForEach(function(obj)
		if FXUtility.HasPatterInString(obj:GetAttri("Name"), "kerb" ) then
			local obbKerb 			= FXGeom. GetBoundingOBB(obj);
			local zKerb 			= obbKerb:MaxPnt();
			local Zslab;
			local slab;
			
			belowSlab:ForEach(function(obj1)
				local obbSlab 			= FXGeom. GetBoundingOBB(obj1);
				local zSlabtemp 			= obbSlab:MinPnt();
				
				if( zSlabtemp.z < zKerb.z and FXClashDetection.IsCollided(obj1,flrWaste)) then
					Zslab = zSlabtemp;
					slab = obj1;
				end
			end)
			
			if(slab) then
				----------------------------------------------- Start Get Height
				
				local elev = slab:GetTopElevation();
				local pnt1 = Point3D(Zslab.x, Zslab.y, elev)
				local pnt2 = Point3D(Zslab.x, Zslab.y, zKerb.z);
				height = Line3D(pnt1, pnt2);
				
				local slabProj =  FXMeasure.GetObjProjection(slab, zKerb.z);
				local kerbProj =  FXMeasure.GetObjProjection(obj, zKerb.z);
				local PrjFinal = FXMeasure.SubtractProjection(slabProj, kerbProj, zKerb.z);
				local pNode1 = FXUtility.CreateNodeFrom(PrjFinal);
				
				----------------------------------------------- Start Get Width
				
				local outer 					= FXMeasure.GetOuterEdge(slabProj);
				local noOfPnt 					= outer:GetPointNumber(); 
				local line;
				for i = 1, noOfPnt -1, 1  do
					local pnt1 = outer:GetPoint(i-1);
					local pnt2 = outer:GetPoint(i);
					line = Line3D(pnt1,pnt2);
				end
				
				local PlyLine =  PolyLine3D(TRUE)
				PlyLine:AddPoint(line:GetStartPoint())
				PlyLine:AddPoint(line:GetEndPoint())
				PlyLine:AddPoint(Point3D(line:GetEndPoint().x,line:GetEndPoint().y,line:GetEndPoint().z + 100))
				PlyLine:AddPoint(Point3D(line:GetStartPoint().x,line:GetStartPoint().y,line:GetStartPoint().z + 100))
				PlyLine:ClosePolyline()
				local PolyLineFace3D = PlyLine:Face3D()
				local pNode2 = FXUtility.CreateNodeFrom(PolyLineFace3D);
				
				----------------------------------------------- End Get Width
					
				local width = FXMeasure.Distance(pNode1, pNode2);
				local arrow1 = DoubleArrow(height:GetStartPoint(), height:GetEndPoint());	
				local arrow2 = DoubleArrow(width:GetStartPoint(), width:GetEndPoint());	
				
				local tempHeight =  FXUtility.Round(height:Length(),2);
				local tempWidth = FXUtility.Round(width:Length(),2);
				
				if( tempHeight < minHeightKerb ) then
					isPassed = false;
					FXUtility.DisplaySolid_Error(space, "Kerb height is less than "..minHeightKerb.."mm; Kerb height "..tempHeight.."mm; "..obj:GetAttri("Name"), arrow1);
					flag = 2
				end
				
				if( tempWidth < minWidthKerb ) then
					isPassed = false;
					FXUtility.DisplaySolid_Error(space, "Kerb width is less than "..minWidthKerb.."mm; Kerb width "..tempWidth.."mm; "..obj:GetAttri("Name"), arrow2);
					flag = 2
				end

				FXClashDetection.DeleteNode(pNode1);
				FXClashDetection.DeleteNode(pNode2);
			end
		end
	end)
	
	return isPassed, height, width;
end