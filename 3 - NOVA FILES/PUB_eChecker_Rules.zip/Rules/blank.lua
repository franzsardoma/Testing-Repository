local dischargeGrp = FXGroup:new();
local roadGrp = FXGroup:new();
local slabGrp = FXGroup:new();

function main()
	-- CheckEngine.SetCheckType("Building")
	-- CheckEngine.BindCheckFunc("XMLParser")
	-- CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("Building");
	-- CheckEngine.BindCheckFunc("checkRule");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("TEST");
	CheckEngine.RunCheckPipeline();
end

function TEST(Building)
	local tanks = Building:GetDescendants("FlowStorageDevice")
	tanks:ForEach(function (tank)
		FXUtility.DisplaySolid_Info(tank, "Compliant")
		-- FXUtility.DisplaySolid_Info(tank, "Compliant")
		-- FXUtility.DisplaySolid_Error(tank, "NCompliant")
		FXUtility.DisplaySolid_Error(tank, "NCompliant")

	end)
	local pipes = Building:GetDescendants("FlowSegment")
	pipes:ForEach(function(pipe)
		if pipe:GetAttri("Name") == "Pipe Types:PVC:651581" then
			FXUtility.DisplaySolid_Info(pipe, "Compliant")
			FXUtility.DisplaySolid_Error(pipe, "NCompliant")
		elseif pipe:GetAttri("Name") == "Pipe Types:PVC:654275" then
			FXUtility.DisplaySolid_Info(pipe, "Compliant")
			FXUtility.DisplaySolid_Error(pipe, "NCompliant")
		end
	end)
	-- Pipe Types:PVC:651581 Pipe Types:PVC:654275
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_2_1_1_B_I_AND_II_COMMERCIAL_MULTI_UNIT_RESIDENTIAL")
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building)
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1")
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2")
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3")
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	minSouth = ConditionValues[3]
	minNorth = ConditionValues2[3]
	minRoad = ConditionValues3[3]

	for k,v in pairs(GrpObjs) do 
		if (k == 2) then
			slabGrp = dischargeGrp + v
			slabGrp = dischargeGrp:Unique()
		end

		if (k == 4) then
			dischargeGrp = dischargeGrp + v
			dischargeGrp = dischargeGrp:Unique()
		end

		if (k == 5) then
			roadGrp = roadGrp + v
			roadGrp = roadGrp:Unique()
		end
	end

	print("slabGrp " .. #slabGrp .. " dischargeGrp " .. #dischargeGrp .. " roadGrp " .. #roadGrp)
end

function checkRule(Building)
	local site = Building:GetParent();
	local prj = FXMeasure.GetObjProjection(site,0)
	FXPUB.DisplayTest(Building, "site" , prj)

	-- FXUtility.DisplaySolid_Warning(Building,"This rule has not yet implemented. Please check the rule you have run.")

	-- local site = Building:GetParent();
	-- local maxpnt = (FXGeom.GetBoundingOBB(site):MaxPnt().z)/1
	-- if tostring(maxpnt) == "-nan(ind)" then print("noo") end
	-- print(type(maxpnt) .. " " .. tostring(maxpnt))
end