
local PumpingMain = FXGroup:new()

local FlexibleAdaptor = FXGroup:new()
local bldgPumpMain = FXGroup:new()
local bldgAdaptor = FXGroup:new()


local Objs = {}

function main()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("building")
	CheckEngine.BindCheckFunc("Building")
	CheckEngine.RunCheckPipeline()

end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_2_3_III_PUMP_MAIN_CONNECTION")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)

	local tblValues = FXRule.filterTableValues(parsedXml,Building)

	for k,v in pairs(tblValues) do    
		for k1,v1 in pairs(v) do
			table.insert( Objs , v1["value"] )
		end
	end

	for k,v in pairs(xmlObjs) do
		if (k == 2) then
			PumpingMain = PumpingMain + v;
			PumpingMain = PumpingMain:Unique();			    
		end

		if (k == 3) then
			FlexibleAdaptor = FlexibleAdaptor + v;
			FlexibleAdaptor = FlexibleAdaptor:Unique();			    
		end
	end
end

function Building(building)

	if #PumpingMain == 0 then
		CheckReport.Warning(building,"Pumping Main is not provided.")
		return;
	end

	local Flag = false
	local IsAllPumpingMain = false

	local BuildingStorey = building:GetDescendants('BuildingStorey')
	local lowestStoreyGrp = FXGroup:new()
	local Pipes = FXGroup:new()
	local Fittings = FXGroup:new()

	BuildingStorey:ForEach(function(storey)
		local lowestStorey = storey:GetBelowStorey()

		if (lowestStorey <= 0 ) then
			local upperStorey = FXUtility.GetNextStoreyUpper(storey);
			lowestStoreyGrp:Add(storey)
			lowestStoreyGrp:Add(upperStorey)
		end
	end)

	lowestStoreyGrp:ForEach(function(storey)
		local FlowSegments = storey:GetDescendants('FlowSegment')
		local FlowFittings = storey:GetDescendants('FlowFitting')

		Pipes = Pipes + FlowSegments
		Fittings = Fittings + FlowFittings
	end)

	-- if #Pipes == 0 or #Fittings == 0 then
	-- 	CheckReport.Warning(building,"Not enough elements to check within the selected first two lowest storey.")
	-- 	return;
	-- end
	
	Pipes:ForEach(function(pipes)
		if (FXUtility.HasPatterInString(pipes:GetAttri("ObjectType"),Objs[1])) then
			bldgPumpMain:Add(pipes)
		end
	end)

	Fittings:ForEach(function(fit)
		if (FXUtility.HasPatterInString(fit:GetAttri("ObjectType"),Objs[2])) or
			(FXUtility.HasPatterInString(fit:GetAttri("ObjectType"),Objs[3])) then
			bldgAdaptor:Add(fit)
		end	
	end)

	if #bldgPumpMain == 0 then
		CheckReport.Warning(building,"Pumping Main is not provided.")
		return;
	end

	if #FlexibleAdaptor ~= 0 and #bldgAdaptor ~= 0 then
		Flag = true

		-- if #bldgAdaptor == 0 then
		-- 	CheckReport.Warning(building,"Flexible Coupling/Flange Adaptor is not provided within the selected first two lowest storey.")
		-- 	return;
		-- end

		bldgAdaptor:ForEach(function(fit)

			local PumpMain, ConnectedPipes, IsMorethanOne = CheckConnection(fit, bldgPumpMain)

			if #PumpMain == #ConnectedPipes and IsMorethanOne == true then
				IsAllPumpingMain = true

				FXUtility.DisplaySolid_Info(fit, fit:GetAttri('ObjectType') .. " is provided. ");
				-- CheckReport.AddRelatedObj(fit, " " .. fit:GetAttri("Name"));
				PumpMain:ForEach(function(pipes)
					CheckReport.AddRelatedObj(pipes, " " .. pipes:GetAttri("Name"));
				end)
			end

			-- Start of NonCompliant

			if IsAllPumpingMain == false then

				ConnectedPipes = ConnectedPipes - PumpMain
				FXUtility.DisplaySolid_Error(fit, "Not a Flexible Coupling/Flange Adaptor.");
				ConnectedPipes:ForEach(function(pipes)
					CheckReport.AddRelatedObj(pipes, " " .. pipes:GetAttri("Name"));
				end)
			end
		end)
	end

	if Flag == false then
		local Flowfit = FXGroup:new()
		bldgPumpMain:ForEach(function(pipes)
			local ConnectedFitting = pipes:GetConnectedFitting()
			ConnectedFitting:ForEach(function(fit)
				Flowfit:Add(fit)
			end)
		end)

		if #Flowfit ~= 0 then

			Flowfit:ForEach(function(fit)

				local PumpMain, ConnectedPipes = CheckConnection(fit, bldgPumpMain)
				FXUtility.DisplaySolid_Error(fit, "Flexible Coupling/Flange Adaptor is not provided.");
				-- CheckReport.AddRelatedObj(fit, " " .. fit:GetAttri("Name"));
				PumpMain:ForEach(function(pipes)
					CheckReport.AddRelatedObj(pipes, " " .. pipes:GetAttri("Name"));
				end)
			end)
		end
	end

end

function CheckConnection(fit, bldgPumpMain)
local PumpingMainGrp = FXGroup:new()
local ConnectedSegment = fit:GetConnectedSegment()
local IsMorethanOne = false

if #ConnectedSegment > 1 then
	IsMorethanOne = true
	ConnectedSegment:ForEach(function(pipes)

		bldgPumpMain:ForEach(function(main)

			if (FXUtility.HasPatterInString(main.Id, pipes.Id)) then	
				PumpingMainGrp:Add(pipes)
			end
		end)
	end)
end

return PumpingMainGrp, ConnectedSegment, IsMorethanOne

end