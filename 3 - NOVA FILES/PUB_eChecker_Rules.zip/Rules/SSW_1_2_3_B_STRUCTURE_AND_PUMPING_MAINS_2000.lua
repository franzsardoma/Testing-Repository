-- Modified by: Lawrence Roy Quiling 1/8/2019

local grpPipeSegment 	= FXGroup:new();
local minDiameter 	--= 100;
local maxDiameter 	--= 600;
local mindepth		-- = 0;
-- local maxdepth		--= 3000;
local minimumdist 	--= 1000;
local grpPipes 		= FXGroup:new();
local grpBldgObj 	= FXGroup:new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local Project = Building:GetParent():GetParent()
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_3_B_STRUCTURE_AND_PUMPING_MAINS_2000")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	minDiameter = tonumber(ConditionValues[2])
	maxDiameter = tonumber(ConditionValues[4])
	mindepth = tonumber(ConditionValues[9])
	-- maxdepth = tonumber(ConditionValues[10])
	minimumdist = tonumber(ConditionValues[12])

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpPipeSegment = grpPipeSegment + v;
				grpPipeSegment = grpPipeSegment:Unique();
			end
		end
	end

	if GrpObjs ~= nil then
		grpBldgObj = FXPUB.GetElementtype2InAdvisoryNote( Project, tblValues, GrpObjs )
	end
end
function checkRule(Building)
	FXPUB.AdvNoteTblB_1kTO2k_CheckRule(Building, grpBldgObj, grpPipeSegment, minDiameter, maxDiameter, mindepth, maxdepth, minimumdist)
end

-- function checkRule1(Building)
-- 	local bldgMaxPnt = FXPUB.GetHighestElevation(Building)
-- 		local roadMaxPnt = FXPUB.GetRoadMaxPnt_master( Building ) 
-- 		-- local roadMaxPnt = GetRoadMaxPnt( Building ) 

-- 		if roadMaxPnt == nil then
-- 			FXUtility.DisplaySolid_Warning(Building, NO_ROAD);
-- 		end
-- 		if #grpBldgObj == 0 then
-- 			FXUtility.DisplaySolid_Warning(Building, NO_BLDG);
-- 			if #grpPipeSegment == 0 then
-- 				FXUtility.DisplaySolid_Warning(Building,MSG_NO_PUMP_MAINS);
-- 				return;
-- 			end
-- 			return;
-- 		else
-- 			if #grpPipeSegment == 0 then
-- 				FXUtility.DisplaySolid_Warning(Building,MSG_NO_PUMP_MAINS);
-- 				return;
-- 			end
-- 		end

-- 		grpPipeSegment:ForEach(function(pipe)
-- 			-- 1)Check the pipe diameter
-- 			local pipeDiameter, isPass1 = FXPUB.CheckPipeDiameter(pipe, minDiameter, maxDiameter)

-- 			if isPass1 then
-- 				-- 2) Check the pipe depth
-- 				if roadMaxPnt ~= nil then
-- 					local pipeDepth, isPass2 = FXPUB.CheckPipeDepth_master(pipe, roadMaxPnt, mindepth, maxdepth)
-- 					-- local pipeDepth, isPass2 = CheckPipeDepth(pipe, roadMaxPnt, mindepth, maxdepth)
-- 					-- print(isPass2)
-- 					if isPass2 then
-- 						-- 3) Check the lateral distance
-- 						local invertLevelElevation = FXPUB.GetInvertElevation(pipe)
-- 						if invertLevelElevation ~= nil then
-- 							local prjBldg = FXMeasure.GetProjection(grpBldgObj, invertLevelElevation);
-- 							local dist, centerLine = FXPUB.GetLateralDistance_master(pipe, prjBldg)
-- 							-- local dist, centerLine = GetLateralDistance(pipe, prjBldg)

-- 							local distLength = FXUtility.Round(dist:Length())
-- 							-- print(distLength)
-- 							local arrowGeom = DoubleArrow(dist:GetStartPoint(),dist:GetEndPoint());
-- 							local msg = string.format(ADV_RESULT_MSG, distLength, pipe:GetAttri("ObjectType"), pipeDiameter, pipeDepth) 
-- 							if( distLength >= minimumdist ) then
-- 								local faceA = FXPUB.CreateBox(pipe,dist, centerLine, bldgMaxPnt);
-- 								-- local faceA = CreateBox(pipe,dist, centerLine, bldgMaxPnt);
-- 								FXUtility.DisplaySolid_Info(pipe, msg, prjBldg); 
-- 								CheckReport.AddRelatedGeometry_Info(arrowGeom, msg)
-- 								if faceA ~= nil then	
-- 									CheckReport.AddRelatedGeometry_Wire(faceA, msg)
-- 								end
-- 							else
-- 								if distLength < 10 then
-- 									FXUtility.DisplaySolid_Error(pipe, msg, prjBldg); 
-- 								elseif distLength < 50 then
-- 									FXUtility.DisplaySolid_Error(pipe, msg, prjBldg); 
-- 									CheckReport.AddRelatedGeometry_Error(arrowGeom, msg)
-- 								else
-- 									local faceA = FXPUB.CreateBox(pipe,dist,centerLine, bldgMaxPnt);
-- 									-- local faceA = CreateBox(pipe,dist, centerLine, bldgMaxPnt);
-- 									FXUtility.DisplaySolid_Error(pipe, msg, prjBldg); 
-- 									CheckReport.AddRelatedGeometry_Error(arrowGeom, msg)
-- 									if faceA ~= nil then
-- 										CheckReport.AddRelatedGeometry_Wire(faceA, msg)
-- 									end
-- 								end
-- 							end
-- 						else
-- 							print("no invertLevelElevation")
-- 						end
-- 					else
-- 						FXUtility.DisplaySolid_Warning(pipe, DEPTH_FAIL);
-- 					end
-- 				end
-- 			else
-- 				FXUtility.DisplaySolid_Warning(pipe, DIAM_FAIL);
-- 			end
-- 		end)
-- end
