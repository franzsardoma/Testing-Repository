--Implemented by: Jerrick Gillera
--Date: 1/24/2019

local ICGrp = FXGroup.new()

function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_4_2_1_E_II_INSPECTION_CHAMBER_MINIMUM_DEPTH")
	ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	print(#GrpObjs1)
	if GrpObjs1 ~= nil then
		for k,v in pairs(GrpObjs1) do
			if (k == 2) then
				ICGrp = ICGrp + v;
				ICGrp = ICGrp:Unique()
			end	
		end
	end
end

function checkRule(Building)

	if #ICGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building, "Inspection Chamber is not provided.")		
		return
	end

	local InsChamber
	local depth = tonumber(ConditionValues1[1])
	local compIC = {}
	local compHeight = {}
	local compArrow = {}
	local nonCompIC = {}
	local nonCompHeight = {} 
	local nonCompArrow = {}

	local flag = true

	ICGrp:ForEach(function ( rdrain )

		local rDrainOBB = FXGeom.GetBoundingOBB(rdrain);
		local cntrOBB = rDrainOBB:GetPos();
		local dPnt1 = Point3D(cntrOBB.x , cntrOBB.y, cntrOBB.z);
		local dPnt2; -- For moving up line
		local dPnt3; -- For moving down line
		local depthLine;
		local depthNode;
		local ctrDepth = 0;
		local ctrDepth2 = 0;
		local depthNode;
		local i = 1
		local depthLine2;
 
 		while (i > 0)do
			ctrDepth = ctrDepth + 0.1;
			dPnt2 = Point3D(cntrOBB.x, cntrOBB.y + ctrDepth, cntrOBB.z );
			depthLine = Line3D(dPnt1 , dPnt2);
			depthNode = FXUtility.CreateNodeFrom(depthLine);

			if(FXClashDetection.IsCollided(depthNode, rdrain))then
				FXClashDetection.DeleteNode(depthNode);
				break;
			end
			FXClashDetection.DeleteNode(depthNode);
		end
		--#################### Moving down line from previous point #################### --	
		while (i > 0)do
			ctrDepth2 = ctrDepth2 + 0.1;
			dPnt3 = Point3D(cntrOBB.x, cntrOBB.y - ctrDepth2 , cntrOBB.z);
			depthLine2 = Line3D(dPnt1 , dPnt3);
			depthNode = FXUtility.CreateNodeFrom(depthLine2);

			if(FXClashDetection.IsCollided(depthNode, rdrain))then
				FXClashDetection.DeleteNode(depthNode);
				break;
			end
			FXClashDetection.DeleteNode(depthNode);
		end

		local depthLine3 = Line3D(dPnt2 , dPnt3);

		local centerPnt = FXUtility.CenterPoint(depthLine3:GetStartPoint(), depthLine3:GetEndPoint());
		------------------------------------		

		local dPnt4, depthNode1, depthLine3
		local ctrDepth3 = 0

		while (i > 0)do
			ctrDepth3 = ctrDepth3 + 0.1;
			dPnt4 = Point3D(centerPnt.x, centerPnt.y, centerPnt.z - ctrDepth3 );
			depthLine3 = Line3D(centerPnt , dPnt4);
			depthNode1 = FXUtility.CreateNodeFrom(depthLine3);

			if(FXClashDetection.IsCollided(depthNode1, rdrain))then
				FXClashDetection.DeleteNode(depthNode1);
				break;
			end
			FXClashDetection.DeleteNode(depthNode1);
		end

		local site = Building:GetParent();
		local OBB = FXGeom.GetBoundingBox(site);
		local HiPos = Point3D(centerPnt.x, centerPnt.y, OBB:LowPos().z);
		local depthLine = Line3D(HiPos, dPnt4);
		local depthArrowGeom = DoubleArrow(depthLine:GetStartPoint(),depthLine:GetEndPoint());
		local length = FXUtility.Round(depthLine:Length(), 1)
		length = FXUtility.Round(length, 0)

		if length >= depth then
			table.insert(compIC, rdrain)
			table.insert(compHeight, length)
			table.insert(compArrow, depthArrowGeom)
		else
			flag = false
			table.insert(nonCompIC, rdrain)
			table.insert(nonCompHeight, length)
			table.insert(nonCompArrow, depthArrowGeom)
		end


	end)

	if flag == true then
		for i=1,#compIC do
			FXUtility.DisplaySolid_Info(compIC[i],compIC[i]:GetAttri("ObjectType").. " depth: ".. FXUtility.Round(compHeight[i], 2) .. " mm",compArrow[i], site)
		end
	else
		for i=1,#nonCompIC do
			FXUtility.DisplaySolid_Error(nonCompIC[i],nonCompIC[i]:GetAttri("ObjectType").. " depth: ".. FXUtility.Round(nonCompHeight[i], 2) .. " mm; Exceeded minimum depth.", nonCompArrow[i], site)
		end
	end
end
function SmallestLine( line )
	local LinePointNumber = line:GetPointNumber();
	local dist;

	for i=0,(LinePointNumber-2) do
		local Point1 = line:GetPoint(i)
		local Point2 = line:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end