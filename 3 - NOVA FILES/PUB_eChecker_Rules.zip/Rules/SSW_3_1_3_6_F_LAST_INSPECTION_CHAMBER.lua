local SystemTypes;
local grpFlowSegment = FXGroup:new();
local InspectionChamberGrp = FXGroup:new()
local BoundaryWallGrp = FXGroup:new()

local WallVal, WallProp

local SewerConnectionGrp = FXGroup:new()

local maxDistance;
local isConnectedToChamber = false;
local hasBoundaryWalls = false;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_6_F_LAST_INSPECTION_CHAMBER")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local sysObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	maxDistance = ConditionValues[3];

	local Values1 = {}

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 2) then
				table.insert(Values1, v1["value"])
				WallProp = (v1["property"])
			end
		end
	end

	WallVal = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			WallVal = WallVal.." or "..v
		end
	end

	for k,v in pairs(sysObjs) do

		if (k == 2) then
			InspectionChamberGrp = InspectionChamberGrp + v
			InspectionChamberGrp = InspectionChamberGrp:Unique();
		end

	end

	for k,v in pairs(GrpObjs) do
		if (k == 3) then
			BoundaryWallGrp = BoundaryWallGrp + v
			BoundaryWallGrp = BoundaryWallGrp:Unique();
		end

		if (k == 4) then
			SewerConnectionGrp = SewerConnectionGrp + v
			SewerConnectionGrp = SewerConnectionGrp:Unique();
		end
	end
end

function CheckConnectedChamberElement(Building, chamber, pipe)

	local isConnectedToChamber = false;
	local chamberConnectedObjs = FXGroup.new()
	local flowFittingGrp = Building:GetDescendants("FlowFitting")
	local flowSegmentGrp = Building:GetDescendants("FlowSegment")
	if (FXClashDetection.IsCollided(pipe,chamber)) then
		isConnectedToChamber = true;

	else
		if #flowFittingGrp ~= 0 then
			flowFittingGrp:ForEach(function ( fitting )
				if (FXClashDetection.IsCollided(fitting, chamber)) then
					-- chamberConnectedObjs:Add(fitting)
					if (FXClashDetection.IsCollided(fitting, pipe)) then
						isConnectedToChamber = true;
					elseif (FXPUB.IsObjsConnected(fitting, pipe, 2)) then
						isConnectedToChamber = true;
					end
				end
			end)
		end
	end

	if isConnectedToChamber == false then
		flowSegmentGrp:ForEach(function ( segment )
			if (FXClashDetection.IsCollided(segment, chamber)) then
				chamberConnectedObjs:Add(segment)
			end
		end)

		chamberConnectedObjs:ForEach(function ( connectedObj )
			if (FXPUB.IsObjsConnected(connectedObj, pipe)) then
				isConnectedToChamber = true;
				return false;
			end
		end)
	end

	return isConnectedToChamber;
end

function checkRule(Building)

-- local lastInspectionChamber;
local BuildingStorey = Building:GetChildren("BuildingStorey")

if #InspectionChamberGrp == 0 then
	FXUtility.DisplaySolid_Warning(Building, "No corresponding inspection chamber to check.")
	return;
end
	BuildingStorey:ForEach(function ( storey )
		local lastInspectionChamber;

		if (FXUtility.IsFirstStorey(storey)) then

			print(#SewerConnectionGrp)

			if #SewerConnectionGrp ~= 0 then
				
				InspectionChamberGrp:ForEach(function ( chamber )
					SewerConnectionGrp:ForEach(function ( pipe )
						local distance = FXMeasure.Distance(pipe, chamber)

						local IsConnected = CheckConnectedChamberElement(Building, chamber, pipe)

						if IsConnected == true then
							isConnectedToChamber = true;
							lastInspectionChamber = chamber;
						end
					end)
				end)

				if lastInspectionChamber ~= nil then

					local storeyLastChamber = FXUtility.GetStorey(lastInspectionChamber);

					if (storey.Id == storeyLastChamber.Id) then

						local ElevationStorey = storey:Elevation()

						local isCompliant = false;
						local BoundaryWalls = FXGroup.new()
						local chamberName = lastInspectionChamber:GetAttri("ObjectType")
						local box = FXGeom. GetBoundingOBB(lastInspectionChamber)
						local centerPnt = box:GetPos();
						local minPnt = box:MinPnt();
						local maxPnt = box:MaxPnt();
						local chamberCenterLine = Line3D( Point3D(centerPnt.x,centerPnt.y,minPnt.z), Point3D(centerPnt.x,centerPnt.y,ElevationStorey))
						local wallsGrp = storey:GetDescendants("Wall")
						local boundaryWallsPrj;
						if #wallsGrp ~= 0 then
							wallsGrp:ForEach(function ( wall )
								if(FXUtility.HasPatterInString(wall:GetAttri("ObjectType"), WallVal)) then
									BoundaryWalls:Add(wall)
								end
							end)
						end
						
						if #BoundaryWalls ~= 0 then
							boundaryWallsPrj = FXMeasure.GetProjection(BoundaryWalls, ElevationStorey)

							local wallNode = FXUtility.CreateNodeFrom(boundaryWallsPrj)
							local chamberNode = FXUtility.CreateNodeFrom(chamberCenterLine)
							local distLine = FXMeasure.Distance(wallNode, chamberNode)
							local distance = FXUtility.Round(tonumber(distLine:Length()), 2)
							local arrowGeom = DoubleArrow(distLine:GetStartPoint(), distLine:GetEndPoint());

							if (distance <= tonumber(maxDistance)) then
								isCompliant = true;
							end

							CheckResult(Building, isCompliant, chamberName, lastInspectionChamber, distance, arrowGeom, storey);

							FXClashDetection.DeleteNode(wallNode)
							FXClashDetection.DeleteNode(chamberNode)
						else
							FXUtility.DisplaySolid_Warning(storey, "Boundary wall or boundary line not provided.")
						end	
					end
				end
			end
		end
	end)

	if isConnectedToChamber == false then
		FXUtility.DisplaySolid_Warning(Building, "Inspection Chamber not connected to sewer lines.")
	end
end

function CheckResult(Building, isCompliant, chamberName, chamber, distance, arrowGeom, storey)
	
	if isCompliant then
		FXUtility.DisplaySolid_Info(storey, chamberName..": Distance = "..distance.."mm to Lot Boundary Line.");
		CheckReport.AddRelatedObj( chamber, chamberName )
		CheckReport.AddRelatedGeometry_Solid(arrowGeom, "Arrow3D")

	else
		FXUtility.DisplaySolid_Error(storey, chamberName..": Distance = "..distance.."mm to Lot Boundary Line.");
		CheckReport.AddRelatedObj( chamber, chamberName )
		CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
	end
end

