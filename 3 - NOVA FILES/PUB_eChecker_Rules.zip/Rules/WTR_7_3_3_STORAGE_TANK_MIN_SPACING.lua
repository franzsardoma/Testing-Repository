function main()
	-- CheckEngine.SetCheckType("System")
	-- CheckEngine.BindCheckFunc("XMLParser")
	-- CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function checkRule(Building)
	FXUtility.DisplaySolid_Warning(Building,"This rule has not yet implemented. Please check the rule you have run.")
end