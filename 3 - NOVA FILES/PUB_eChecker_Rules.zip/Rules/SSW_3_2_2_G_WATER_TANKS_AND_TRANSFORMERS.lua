local grpFlowSegment = FXGroup:new();
local grpObj = FXGroup:new();
local grpSpaces = FXGroup:new();
local ObjValues

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_G_WATER_TANKS_AND_TRANSFORMERS")
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpFlowSegment = grpFlowSegment + v;
				grpFlowSegment = grpFlowSegment:Unique();
			end
		end
	end
	
	for k,v in pairs(GrpObjsBuilding) do
		if (k == 3) then
			grpObj = grpObj + v;
			grpObj = grpObj:Unique();
		end
		if (k == 4) then
			grpSpaces = grpSpaces + v;
			grpSpaces = grpSpaces:Unique();
		end
	end

	local Values1 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 2) then
				table.insert(Values1, v1["value"])
			end
		end
	end

	ObjValues = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			ObjValues = ObjValues.." or "..v
		end
	end
	
end

function CheckWaring( Building )

	local flag = true

	if #grpFlowSegment == 0 then
		CheckReport.Warning( Building, "Sanitary Pipe is not provided")
		flag = false
	end
	if #grpObj == 0 then
		CheckReport.Warning( Building, ObjValues.." is not provided")
		flag = false
	end
	return flag;
end

function checkRule( Building )

	if CheckWaring(Building) then
		local grpSlabs = Building:GetDescendants("Slab")
		local isErrorNotFound = true
		local ARRCPbj = {}

		grpObj:ForEach(function ( Obj )
			local flag = true
			local CollSpace = getCollSpace( grpSpaces, Obj );
			local grpEXObjs = FXGroup:new()

			if CollSpace ~= nil then
				grpFlowSegment:ForEach(function ( FlowSegment )
					if FXClashDetection.IsCollided(FlowSegment,CollSpace) then
						grpEXObjs:Add(FlowSegment)
						flag = false
						FXUtility.DisplaySolid_Error(Obj, Obj:GetAttri("ObjectType").."; "..FlowSegment:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(Obj, Obj:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(CollSpace, "Space "..CollSpace:GetAttri("LongName"))
						isErrorNotFound = false
					end
				end)

				local grpAboveSegments = getAboveSegment( Obj, grpSlabs, Building, grpFlowSegment - grpEXObjs ) -- get the segment above slab
				
				if (#grpAboveSegments ~= 0) then
					grpAboveSegments:ForEach(function ( FlowSegment )
						FXUtility.DisplaySolid_Error(Obj, Obj:GetAttri("ObjectType").."; "..FlowSegment:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(Obj, Obj:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("ObjectType"))
						flag = false
						isErrorNotFound = false
					end)
				end

				if flag then
					table.insert(ARRCPbj, Obj)
				end
			else
				CheckReport.Warning( Obj, Obj:GetAttri("ObjectType").." is not within the Space")
				CheckReport.AddRelatedObj(Obj, Obj:GetAttri("ObjectType"))
			end
			
		end)

		if isErrorNotFound then
			for k,Obj in pairs(ARRCPbj) do
				FXUtility.DisplaySolid_Info(Obj, "No Sanitary Pipe above "..Obj:GetAttri("ObjectType"))
				CheckReport.AddRelatedObj(Obj, Obj:GetAttri("ObjectType"))
			end
		end
	end
end

function getAboveSegment( Obj, grpSlabs, Building, grpPipes )
	local grpObjs = FXGroup:new()	
	local ObjNode	= FXUtility.CreateNodeFrom(FXGeom.GetBoundingBox(Obj));
	local objprj = FXMeasure.GetObjProjection(ObjNode, FXGeom.GetBoundingBox(Obj):HighPos().z);
	FXClashDetection.DeleteNode(ObjNode);
	local outer1 = FXMeasure.GetOuterEdge(objprj);
	local faceA = outer1:Face3D();
	local ExtrudedFace1 = faceA:ExtrudedFace(Vector(0, 0, getHighestZpnt(Building)))
	local FaceNode	= FXUtility.CreateNodeFrom(ExtrudedFace1);
	local slab = getLowestSlab( grpSlabs, FaceNode )
	-- print(slab)
	grpPipes:ForEach(function ( Segment )
		if FXClashDetection.IsCollided(Segment,FaceNode) then
			-- print("dasdsa")
			if(FXRule.IsOverlap(slab, Segment) == 1 ) then
				grpObjs:Add(Segment);
			end
		end
	end)
	FXClashDetection.DeleteNode(FaceNode);
	return grpObjs;
end

function getHighestZpnt(Building)
	local zPnt;

	storeys = Building:GetDescendants("BuildingStorey")
	if #storeys ~= 0 then

		storeys:ForEach(function(Storey)
			if #FXUtility.GetAllUpperStorey(Storey) == 0  then
				zPnt = FXGeom.GetBoundingBox(Storey):HighPos().z
			end
		end)
	end
	return zPnt;
end

function getCollSpace( grpSpaces, obj )
	local Space;
	local flag = false

	grpSpaces:ForEach(function ( SpaceEle )
		if flag == true then
			return;
		end
		if FXClashDetection.IsCollided(obj,SpaceEle) then
			Space = SpaceEle;
			flag = true
		end
	end)
	return Space;
end

function getLowestSlab( grpSlabs, node1 )
	local slab;
	local slabElevation = 0;

	grpSlabs:ForEach(function ( SlabEle )
		if FXClashDetection.IsCollided(node1,SlabEle) then
			-- print("dsadsa")
			local lowestSlab = FXGeom.GetBoundingBox(SlabEle):LowPos().z
			if(slabElevation == 0) then
				slabElevation = lowestSlab
				slab = SlabEle
			elseif(slabElevation > lowestSlab) then
				slabElevation = lowestSlab
				slab = SlabEle
			end
 		end
	end)
	return slab;
end