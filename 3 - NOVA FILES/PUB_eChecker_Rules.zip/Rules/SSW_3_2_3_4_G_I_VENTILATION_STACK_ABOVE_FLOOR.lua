local SystemTypes;
local grpFlowSegment = FXGroup:new();
local roofSpacesGrp = FXGroup:new()
local ventSystemPipes = FXGroup:new()
local minHeight;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_3_4_G_I_VENTILATION_STACK_ABOVE_FLOOR")

	
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	
	minHeight = tonumber(ConditionValues[3]);
	operator = ConditionValues[2];
	if(GrpObjs ~= nil) then
		for k,v in pairs(GrpObjs) do
			-- if (k == 5) then
			-- 	roofSpacesGrp = roofSpacesGrp + v
			-- end
			if (k == 2) then
				grpFlowSegment = grpFlowSegment + v
				grpFlowSegment = grpFlowSegment:Unique()
			end
		end
	end
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 3) then
				terraceValue = v1["value"];
			end
			if (k == 4) then
				gardenValue = v1["value"];
			end
		end
	end
end


function checkRule(Building)

	print(terraceValue)
		print(gardenValue)
	local BuildingStorey = Building:GetChildren("BuildingStorey")
	local HighestStorey;
	local spaceNames = {terraceValue, gardenValue}

	-- BuildingStorey:ForEach(function(storey)
	-- 	HighestStorey = storey;
	-- end)
	-- local ElevationStorey = HighestStorey:Elevation();
	-- local roofSlabs = HighestStorey:GetDescendants("Slab");
	-- local roofElement = FXGroup.new()
	-- roofSlabs:ForEach(function ( slab )
	-- 	local  slabParent = slab:GetParent()
	-- 	if FXUtility.HasPatterInString(slabParent:GetAttri("Name"), "Roof") or FXUtility.HasPatterInString(slab:GetAttri("Name"), "Roof") then
	-- 		roofElement:Add(slab)
	-- 	end
	-- end)

	local spaceGrp = Building:GetDescendants("Space")
	spaceGrp:ForEach(function ( space )
		if(FXUtility.IsBelongToTableSpace(space, spaceNames)) then
			roofSpacesGrp:Add(space)
			-- FXUtility.DisplaySolid_Info(space, space:GetAttri("LongName"));
		end
	end)
	if #grpFlowSegment ~= 0 then
		if #roofSpacesGrp ~= 0 then
			grpFlowSegment:ForEach(function ( pipe )
				local ventStackTerminateInSpace = false;

				local isCompliant = false;
				local pipeObj = pipe:GetAttri("ObjectType")

						roofSpacesGrp:ForEach(function ( space )
							if FXClashDetection.IsCollided(pipe, space) then

								ventStackTerminateInSpace = true;
								local box = FXGeom. GetBoundingOBB(pipe)
								local centerPnt = box:GetPos()
								local maxPnt = box:MaxPnt()
								local topLine = Line3D(maxPnt, Point3D(centerPnt.x,centerPnt.y,maxPnt.z))
								local spaceOBB = FXGeom. GetBoundingOBB(space)
								local spaceMinPnt = spaceOBB:MinPnt().z
								local spacePrj = FXMeasure.GetObjProjection(space, spaceMinPnt);
								
								local topLineNode = FXUtility.CreateNodeFrom(topLine)
								local spaceNode = FXUtility.CreateNodeFrom(spacePrj)
								local distLine = FXMeasure.Distance(topLineNode, spaceNode)
								local distance = FXUtility.Round(distLine:Length(),2)
								
								if (distance >= tonumber(minHeight)) then
								isCompliant = true;
								end			

								local arrowGeom = DoubleArrow(distLine:GetStartPoint(), distLine:GetEndPoint());	
								FXClashDetection.DeleteNode(topLineNode)
								FXClashDetection.DeleteNode(spaceNode)
								CheckResult(space, isCompliant, pipeObj, pipeObj, pipe, distance, arrowGeom);
							end
						end)

				if ventStackTerminateInHighestRoof == false then
					FXUtility.DisplaySolid_Warning(Building, MSG_VENT_STACK_TERMINATE)
					CheckReport.AddRelatedObj( pipe, pipeObj )
				elseif ventStackTerminateInSpace == false then
					FXUtility.DisplaySolid_Warning(Building, pipeObj.." does not terminate into a Roof Terrace or Roof Garden.")
					CheckReport.AddRelatedObj( pipe, pipeObj )
				end

			end)	

		else
			FXUtility.DisplaySolid_Warning(Building, "Roof Terrace/Roof Garden not found.")
		end	
	else
		FXUtility.DisplaySolid_Warning(Building, "Vent Stack not found")
	end
end

function CheckResult(Building, isCompliant, pipeName, pipeDesc, pipe, distance, arrowGeom)
	
	if isCompliant then
		FXUtility.DisplaySolid_Info(Building, pipeDesc.." = "..distance.." mm");
		CheckReport.AddRelatedObj( pipe, pipeName )
		CheckReport.AddRelatedGeometry_Solid(arrowGeom, "Arrow3D")
	else
		FXUtility.DisplaySolid_Error(Building, pipeDesc.." = "..distance.." mm");
		CheckReport.AddRelatedObj( pipe, pipeName )
		CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
	end
end

