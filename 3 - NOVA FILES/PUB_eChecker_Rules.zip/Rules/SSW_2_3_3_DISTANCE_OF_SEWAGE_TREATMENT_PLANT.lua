local PlantGrp = FXGroup:new();
local ObjsGrp = FXGroup:new();
local nearest = FXGroup:new();
local NewGrp = FXGroup:new();
--Should use Condition Type
local ten = 10;
local fourty = 40;
local fifty = 50;
local oneHundred = 100;
local twoHundred = 200;
local threeHundred = 300;
local fourHundred = 400;
local fiveHundred = 500;
local sixHundred = 600;
local twoK = 2000;
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("BuildingStorey");
	-- CheckEngine.BindCheckFunc("CheckRuleGrp");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end

function XMLParser(Storey)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_3_DISTANCE_OF_SEWAGE_TREATMENT_PLANT")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	-- minHeight = ConditionValues[2];

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			PlantGrp = PlantGrp + v
			PlantGrp = PlantGrp:Unique()
		end
		if (k == 3) then
			ObjsGrp = ObjsGrp + v
			ObjsGrp = ObjsGrp:Unique()
		end
	end
end

-- function CheckRuleGrp(BuildingStorey)
-- 	local flowStorageDevices = BuildingStorey:GetDescendants("FlowStorageDevice");
-- 	local roof = BuildingStorey:GetDescendants("")
-- 	if #flowStorageDevices ~= 0 or flowStorageDevices ~= nil then
-- 		PlantGrp = PlantGrp + flowStorageDevices;
-- 	end
-- end

function CheckRule(Building)
	local roof = Building:GetDescendants("Roof");
	if roof ~= nil then
		ObjsGrp = ObjsGrp + roof;
	end
	-------------------------------------------------------------------
	if #PlantGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building,"No Sewage Treatment Plant found.")
	else
		PlantGrp:ForEach(function(sewage)
			local capacity = tonumber(sewage:GetAuxAttri("Constraints(Type).Capacity"));

			if capacity == nil then
				FXUtility.DisplaySolid_Warning(Building,"Sewage Treatment Plant Capacity not specified.")

			else
				
				local sewageBox = FXGeom.GetBoundingBox(sewage);
				local zValueSewage = sewageBox:HighPos().z;
				
				local RoadObjs = FXGroup:new();
				ObjsGrp:ForEach(function(obj)
					local name = obj:GetAttri("Name");
					local Objs = isRoad(name);
					if Objs == true then
						RoadObjs:Add(obj)
					end
				end)
				NewGrp = ObjsGrp - RoadObjs;
				
				local Projection = FXMeasure.GetProjection(NewGrp,zValueSewage);
				-- FXUtility.DisplaySolid_Info(sewage,"",Projection)
				local pNodeProjection = FXUtility.CreateNodeFrom(Projection);
				if pNodeProjection ~= nil then
					local line = FXMeasure.Distance(sewage,pNodeProjection);
					local pnt1 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y,zValueSewage);
					local pnt2 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y,zValueSewage);
					local DistanceTwoPnt = FXUtility.Round(pnt1:Distance_Pnt(pnt2),0);
					local arrow = DoubleArrow(pnt1,pnt2);
					local plyline = PolyLine3D(TRUE);
					plyline:AddPoint(line:GetEndPoint());
					plyline:AddPoint(pnt1);
					plyline:AddPoint(pnt2);
					plyline:AddPoint(line:GetStartPoint());
					if capacity >= ten and capacity <= fourty then
						if DistanceTwoPnt > 0 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity >= fifty and capacity <= oneHundred then
						if DistanceTwoPnt >= 10000 and DistanceTwoPnt <= 15000 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity == twoHundred then
						if DistanceTwoPnt >= 20000 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity == threeHundred then
						if DistanceTwoPnt >= 25000 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity == fourHundred then
						if DistanceTwoPnt >= 30000 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity == fiveHundred then
						if DistanceTwoPnt >= 35000 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity >= sixHundred and capacity <= twoK then
						if DistanceTwoPnt >= 35000 and DistanceTwoPnt <= 40000 then
							isCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						else
							isNonCompliant(sewage,capacity,DistanceTwoPnt,arrow,Projection,plyline);
						end
					elseif capacity > twoK then
						if DistanceTwoPnt > 0 then
							FXUtility.DisplaySolid_Warning(sewage,"Capacity = "..capacity.." persons; ");
							CheckReport.AddRelatedObj(sewage,"Specify Distance.");
						end
					end
				end
			end
		end)
	end
end

function NearestObj(sewage,obj,temp,near)
	local dist = FXMeasure.Distance(sewage,obj);
	local distance = dist:Length();
	local name = obj:GetAttri("Name");
	local Objs = isNotRoad(name);
	if Objs == true then
		if temp == nil then
			temp = distance;
		else
			if distance < temp then
				near = obj;
				temp = distance;
			end
		end
	end
	return near, temp;
end

function isRoad(objName)
	local isRoad = false;
	if FXUtility.HasPatterInString(objName,"Road") == true then
		isRoad = true;
	end
	return isRoad;
end

function isCompliant(sewage,capacity,distance,arrow,Projection,plyline)
	FXUtility.DisplaySolid_Info(sewage,"Capacity = "..capacity.." persons; "..sewage:GetAttri("Name").." Distance = "..distance.."mm",arrow)
	CheckReport.AddRelatedGeometry_Solid(Projection);
	-- CheckReport.AddRelatedGeometry_Solid(plyline);
end

function isNonCompliant(sewage,capacity,distance,arrow,Projection,plyline)
	FXUtility.DisplaySolid_Error(sewage,"Capacity = "..capacity.." persons; "..sewage:GetAttri("Name").." Distance = "..distance.."mm",arrow)
	CheckReport.AddRelatedGeometry_Solid(Projection);
	-- CheckReport.AddRelatedGeometry_Error(plyline);
end