
local SpaceName = {};
local minDist = 300;
local isPassedPool = true;
local isPassedStorage = true;
local arrProj = {};
local pipeGrp = FXGroup:new()
local isCompliant = true;
local i = 0;
local arrObj = {}
function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parse");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("System")
	CheckEngine.BindCheckFunc("getSystems")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckResult");
	CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_G_DRY_AREAS")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");-- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end	
	
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	-- local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	if xmlObjs ~= nil then
		for k,v in pairs(xmlObjs) do -- get the model objects
			if k == 2 then
				pipeGrp = pipeGrp + v
	 			pipeGrp = pipeGrp:Unique()			
			end	 		
		end

		for k,v in pairs(tblValues) do		
			for k1,v1 in pairs(v) do
				if (k == 2) then				
					ObjValue = v1["value"]
					table.insert(SpaceName, ObjValue)				
				end	
			end
		end
	else
		isCheckable = false
	end

end

function getStoreyProjections(Building)
	arrProj = {};
	local grpStorey = Building:GetChildren("BuildingStorey");
	local countStorey = 0;
	grpStorey:ForEach(function (Storey)
	
		if( FXUtility.IsFirstStorey(Storey) or countStorey >= 1 ) then
			countStorey = countStorey + 1;
		end
	
		local grpSlabs = Storey:GetDescendants("Slab");
		local elev = Storey:Elevation();
		if( #grpSlabs ~= 0 ) then
			local SlabsProj =  FXMeasure.GetProjection(grpSlabs, elev);
			--FXUtility.DisplaySolid_Warning(Storey, Storey:GetAttri("Name"), SlabsProj);
			arrProj[elev] = SlabsProj; 
		end
	end)
	
	if( countStorey > 1 ) then
		return true;
	else
		return false;
	end
	--return arrProj;
end


function CheckLevel( objEle1, objEle2 ) 
	local objEle1Lvl = string.lower(objEle1:GetParent():GetAttri("Name"));
	local objEle2Lvl = string.lower(objEle2:GetParent():GetAttri("Name"));
	local isSameLvl = FXRule.EvaluateString("Contains", objEle2Lvl, objEle1Lvl);
	
	return isSameLvl;
end

function CheckObj( objEle1, objEle2 )

	local isSameLvl = CheckLevel( objEle1, objEle2 );
	
	if( isSameLvl ) then
		return true;
	end
	
	local res = false;
	local cnt = 0;
	local obj =  FXGeom.GetBoundingOBB(objEle1);
	local objElev = obj:MinPnt().z;
			
	for k,v in pairs(arrProj) do
		if( objElev < k ) then
			local obb =  FXGeom.GetBoundingOBB(objEle2);
			local zValue = obb:MinPnt().z;
			if( zValue < k ) then
				return true;
			else
				local pipeProj = FXMeasure.GetObjProjection(objEle2, 0.0);
				PrjFinal = FXMeasure.SubtractProjection(pipeProj, v);
				if( PrjFinal ~= nil ) then
					return true;
				else
					return false;
				end
			end
		end
	end
	
	return res;
end

function checkRule(Building)
	local isMultiStorey = getStoreyProjections(Building);
	
	if not isMultiStorey then
		FXUtility.DisplaySolid_Warning(Building, "Not a Multi-Storey building.");
		return;
	end
	
	if #pipeGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building, "No PipeSegment found under Sanitary System.");
		return;
	end

	local grpSpaces = Building:GetDescendants("Space");
	local strName = "LongName";
	grpSpaces:ForEach(function (Space)
		isPassedPool = true;
		local tempName = Space:GetAttri(strName);
		bRet = FXUtility.IsBelongToTableSpace(Space,SpaceName); --bRet = FXRule.EvaluateString("Contains", string.lower(tempName), SpaceName);
		if not bRet then
			return;
		end
		pipeGrp:ForEach(function (FlowSegment)
			local isCheckObj = CheckObj( Space, FlowSegment );
			if isCheckObj and Space ~= nil and FlowSegment ~= nil then
				if( isPassedPool  ) then
					isPassedPool = compareObjs(Space, FlowSegment, strName);
				else
					compareObjs(Space, FlowSegment, strName);
				end
			end
		end)
		
		if isPassedPool then
			-- FXUtility.DisplaySolid_Info(Space, "No Sanitary Pipe above "..Space:GetAttri("LongName"));
			i = i + 1;
			arrObj[i] = Space;
		end
		
	end)
	
end

function CheckResult(Building)
	
	--if isPassedPool then
	--	FXUtility.DisplaySolid_Info(Building, "No Sanitary Pipe above Swimming Pool");
	--end
	if isCompliant then
		for k,Space in pairs(arrObj) do
			FXUtility.DisplaySolid_Info(Space, "No Sanitary Pipe above "..Space:GetAttri("LongName"));
		end
	end
	
end

function compareObjs(Space, FlowSegment, strName)

	local isPassed = true;
	local obb1 =  FXGeom.GetBoundingOBB(Space);
	local zValue1 = obb1:MinPnt().z;
	local obb2 =  FXGeom.GetBoundingOBB(FlowSegment);
	local zValue2 = obb2:MinPnt().z;
			
	if zValue1 > zValue2 then
		return true;
	end

	local isOverlap = FXRelation.IsOverlap(Space, FlowSegment);
	if isOverlap == -1 then
		isPassed = false;
		FXUtility.DisplaySolid_Error(Space, FlowSegment:GetAttri("Name")..Space:GetAttri(strName));
		CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("Name"));
		isCompliant = false;
	else
		local nodeContainer	= FXUtility.CreateNodeFrom(obb1);
		local SpaceProj =  FXMeasure.GetObjProjection(nodeContainer, 0.0);
		local FlowSegmentProj =  FXMeasure.GetObjProjection(FlowSegment, 0.0);
		
		if( SpaceProj ~= nil and FlowSegmentProj ~=  nil ) then
			SpaceProj = FXMeasure.MoveProjection(SpaceProj,0);
			FlowSegmentProj = FXMeasure.MoveProjection(FlowSegmentProj,0)
			local node1		= FXUtility.CreateNodeFrom(SpaceProj);
			local node2		= FXUtility.CreateNodeFrom(FlowSegmentProj);

			local distance =  FXRelation.Distance(node1, node2);				
			if distance:Length() < minDist then
				isPassed = false;
				FXUtility.DisplaySolid_Error(Space, FlowSegment:GetAttri("Name")..Space:GetAttri(strName));
				CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("Name"));
				isCompliant = false;
			end			
			FXClashDetection.DeleteNode(node1);
			FXClashDetection.DeleteNode(node2);
		end
		
		FXClashDetection.DeleteNode(nodeContainer);
	end
	
	return isPassed;
end