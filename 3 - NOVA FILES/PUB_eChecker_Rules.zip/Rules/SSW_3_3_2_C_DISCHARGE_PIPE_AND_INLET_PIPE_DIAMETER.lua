--[[ 
	Implemented by : Aires Marco S. Ladaga 22/01/2019
]]
local grpDischarge = FXGroup.new();
local grpInlet = FXGroup.new();
local grpPump = FXGroup.new();
local grpTank = FXGroup.new();
local dischargeOperator;
local dischargeVal;
local inletOperator;
local inletVal;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_2_C_DISCHARGE_PIPE_AND_INLET_PIPE_DIAMETER")

	
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	dischargeOperator = ConditionValues1[2];
	dischargeVal = ConditionValues1[3];
	inletOperator = ConditionValues2[2];
	inletVal = ConditionValues2[3];

	for k,v in pairs(GrpObjs) do 
		if (k == 2) then
			grpDischarge = grpDischarge + v
			grpDischarge = grpDischarge:Unique()
		end	
	end

	for k,v in pairs(GrpObjs) do 
		if (k == 3) then
			grpInlet = grpInlet + v
			grpInlet = grpInlet:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do 
		if (k == 4) then
			grpPump = grpPump + v
			grpPump = grpPump:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do 
		if (k == 5) then
			grpTank = grpTank + v
			grpTank = grpTank:Unique()
		end
	end
end

function CheckRule(Building)
	print (#grpDischarge.." - "..#grpInlet.." - "..#grpPump.." - "..#grpTank)
	print (dischargeOperator);
	print (dischargeVal);
	print (inletOperator);
	print (inletVal);
	local flag = true;
	local isErrorFound = false;

	if #grpDischarge == 0 then
		FXUtility.DisplaySolid_Warning ( Building,"Discharge pipe is not provided." );
		flag = false;
	end
	if #grpInlet == 0 then
		FXUtility.DisplaySolid_Warning ( Building,"Inlet pipe is not provided." );
		flag = false;
	end
	if #grpPump == 0 then
		FXUtility.DisplaySolid_Warning ( Building,"Pump is not provided." );
		flag = false;
	end
	if #grpTank == 0 then
		FXUtility.DisplaySolid_Warning ( Building,"Sewage Tank is not provided." );
		flag = false;
	end

	if flag then
		local x = 0;
		local x2 = 0;
		local inletArr = {};
		local inletDiamArr = {};
		local dischargeArr = {};
		local dischargeDiamArr = {};
		local arrowInlet = {};
		local arrowDischarge = {};

		grpTank:ForEach(function ( tankObj )
			local grpContainPump = FXGroup.new();

			local tankBox = FXGeom.GetBoundingBox(tankObj);
			local tankHeight = tankBox:HighPos().z - tankBox:LowPos().z;

			local nodeBox	= FXUtility.CreateNodeFrom(tankBox);
			local tankPrj = FXMeasure.GetObjProjection(nodeBox, tankBox:LowPos().z); -- use box projection to extrude because getBottomFace is getting the wrong face.
			FXClashDetection.DeleteNode(nodeBox);

			local tankBoxFace  = FXMeasure.GetOuterEdge(tankPrj):Face3D(); -- turn projection to face for extrude
			local extruded = tankBoxFace:ExtrudedFace(Vector(0,0,tankHeight)); -- extrude till tank height only.

			local node1	= FXUtility.CreateNodeFrom(extruded);
			grpPump:ForEach(function ( pumpObj )
				local pumpBox = FXGeom.GetBoundingBox( pumpObj );
				if(FXClashDetection.IsCollided(node1,pumpObj) and tankBox:HighPos().z > pumpBox:HighPos().z and tankBox:LowPos().z < pumpBox:LowPos().z ) then -- check range z 
					grpContainPump:Add(pumpObj);
				end
			end)				
			FXClashDetection.DeleteNode(node1);

			if #grpContainPump > 0 then
				grpContainPump:ForEach(function ( pumpObj )
					local grpContainDischarge = FXGroup.new();

					grpDischarge:ForEach(function ( dischargeObj )
						if FXPUB.IsObjsConnected( dischargeObj, pumpObj , 20)then
							grpContainDischarge:Add(dischargeObj);
						end
					end)

					if #grpContainDischarge > 0 then
						grpContainDischarge:ForEach(function ( dischargeObj )
							local faces = FXMeasure.GetALLCircularFaces(dischargeObj);
							local diameter = FXUtility.Round(FXMeasure.GetOuterDiameterLines(faces[1], 0):Length(),0)
							-- local line = FXMeasure.GetOuterDiameterLines(faces[1], 0);
							
							if FXRule.EvaluateNumber( dischargeOperator , diameter , dischargeVal  ) then
								x = x + 1;
								dischargeArr[x] = dischargeObj;
								dischargeDiamArr[x] = diameter;
								-- arrowDischarge[x] = DoubleArrow(line:GetStartPoint() , line:GetEndPoint() )
		
							else
								FXUtility.DisplaySolid_Error ( dischargeObj , dischargeObj:GetAuxAttri("Entity.ObjectType").."; Internal Diameter: "..diameter.." mm.");
								isErrorFound = true;
							end
						end)		
					else
						FXUtility.DisplaySolid_Warning ( pumpObj,"No discharge pipe connected to "..pumpObj:GetAuxAttri("Entity.ObjectType") );
						print ("no discharge connected to pump;")
					end
				end)
			else
				FXUtility.DisplaySolid_Warning ( tankObj,"No Pump inside "..tankObj:GetAuxAttri("Entity.ObjectType") );
			end

			local grpContainInlet = FXGroup.new();
			grpInlet:ForEach(function ( inletObj )
				if FXPUB.IsObjsConnected( inletObj, tankObj, 20)then
					grpContainInlet:Add(inletObj);
				end
			end)

			if #grpContainInlet>0 then
				grpContainInlet:ForEach(function ( inletObj )
					local faces = FXMeasure.GetALLCircularFaces(inletObj);
					local diameter = FXUtility.Round(FXMeasure.GetOuterDiameterLines(faces[1], 0):Length(),0)
					-- local line = FXMeasure.GetOuterDiameterLines(faces[1], 0);

					if FXRule.EvaluateNumber( inletOperator , diameter , inletVal  ) then
						x2 = x2 + 1;
						inletArr[x2] = inletObj;
						inletDiamArr[x2] = diameter;
						-- arrowInlet[x2] = DoubleArrow(line:GetStartPoint() , line:GetEndPoint() )
					else
						FXUtility.DisplaySolid_Error ( inletObj , inletObj:GetAuxAttri("Entity.ObjectType").."; Internal Diameter: "..diameter.." mm.");
						isErrorFound = true;
					end
				end)
			else
				FXUtility.DisplaySolid_Warning ( tankObj,"No inlet pipe connected to "..tankObj:GetAuxAttri("Entity.ObjectType") );
			end
		end)

		if isErrorFound == false then
			local y = 1;
			local y2 = 1;

			while y ~= x + 1 do
				FXUtility.DisplaySolid_Info ( dischargeArr[y] , dischargeArr[y]:GetAuxAttri("Entity.ObjectType").."; Internal Diameter: "..dischargeDiamArr[y].." mm." );
				y = y + 1;
			end

			while y2 ~= x2 + 1 do
				FXUtility.DisplaySolid_Info ( inletArr[y2] , inletArr[y2]:GetAuxAttri("Entity.ObjectType").."; Internal Diameter: "..inletDiamArr[y2].." mm." );
				y2 = y2 + 1;
			end
		end
	end

end