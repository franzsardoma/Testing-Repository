local hasLevelToCheck = false;
local crossVentPipeGrp = FXGroup.new()
local crossVentTeeGrp = FXGroup.new()

function main()
	-- CheckEngine.SetCheckType("Building")
	-- CheckEngine.BindCheckFunc("XMLParser")
	-- CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

-- function XMLParser(Building)
-- 	local ok, path = pcall(FXPUB.GetFilePath())
--     local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_3_3_D_CROSS_VENTING")

	
-- 	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
-- 	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
-- 	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
-- 	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

-- 	minDiameter = ConditionValues[2];

-- 	for k,v in pairs(GrpObjs) do
-- 		-- if (k == 3) then
-- 		-- 	BldgStoreyGrp = BldgStoreyGrp + v;
-- 		-- 	BldgStoreyGrp = BldgStoreyGrp:Unique();
-- 		-- end
-- 		if (k == 4) then
-- 			crossVentPipeGrp = crossVentPipeGrp + v;
-- 			crossVentPipeGrp = crossVentPipeGrp:Unique();
-- 		end
-- 		if (k == 5) then
-- 			crossVentTeeGrp = crossVentTeeGrp + v;
-- 			crossVentTeeGrp = crossVentTeeGrp:Unique();
-- 		end
-- 	end
-- end

function checkRule( Building )
	local BuildingStoreyGrp = Building:GetChildren("BuildingStorey")
	BuildingStoreyGrp:ForEach(function ( BuildingStorey )
		
		local levelsToCheck = {"Level 03", "Level 06", "Level 09", "Level 12", "Level 15", "Level 18", "Level 21", "Level 24", "Level 27"}
		local checkStorey = false;
		local msg = "";
		-- local pipeName;

		if FXUtility.IsBelongToTableElement(BuildingStorey, levelsToCheck) then
			checkStorey = true;
			hasLevelToCheck = true;
		end

		local flowSegmentGrp = BuildingStorey:GetDescendants("FlowSegment")
		local flowFittingGrp = BuildingStorey:GetDescendants("flowFitting")
		local crossVentPipeGrp = FXGroup.new()
		local crossVentTeeGrp = FXGroup.new()
		
		local crossVentPipe;
		local isCompliant = false;

		if (flowSegmentGrp ~= nil) then
			flowSegmentGrp:ForEach(function ( pipe )
				if FXUtility.HasPatterInString(pipe:GetAttri("Description"),"Cross Vent Pipe") then
					crossVentPipeGrp:Add(pipe)
				end
			end)
		end

		if (flowFittingGrp ~= nil) then
			flowFittingGrp:ForEach(function ( fitting )
				if FXUtility.HasPatterInString(fitting:GetAttri("Description"),"Cross Vent Tee") then
					crossVentTeeGrp:Add(fitting)
				end
			end)
		end

		if (#crossVentPipeGrp > 0) then
			crossVentPipeGrp:ForEach(function ( pipe )
				local connectedVentTee = FXGroup.new()
				-- pipeName =  pipe:GetAttri("Name")
				crossVentTeeGrp:ForEach(function ( tee )
					if (FXClashDetection.IsCollided(pipe,tee)) then
						connectedVentTee:Add(tee)
						crossVentPipe = pipe
						isCompliant = true;
					end
				end)

				if #connectedVentTee == 2 then

					isCompliant = true;
					CheckResult(BuildingStorey, isCompliant, checkStorey, crossVentPipe, connectedVentTee)

				elseif #connectedVentTee == 1 then

					FXUtility.DisplaySolid_Warning(BuildingStorey, "Only one connected cross vent tee to cross vent pipe found")
					AddRelatedObj( pipe, connectedVentTee )

				else

					FXUtility.DisplaySolid_Warning(BuildingStorey, "No connected cross vent tee to cross vent pipe found")
					CheckReport.AddRelatedObj( pipe, pipe:GetAttri("Name") )

				end

			end)

		else
			CheckResult(BuildingStorey, isCompliant, checkStorey)
		end
	end)

	if hasLevelToCheck == false then
		FXUtility.DisplaySolid_Warning(Building, "No levels to check.")
	end
end

function CheckResult(BuildingStorey, isCompliant, checkStorey, crossVentPipe, connectedVentTee)
	if isCompliant then
		if checkStorey then
			FXUtility.DisplaySolid_Info(BuildingStorey, "Cross vent pipe provided.");
			FXUtility.DisplaySolid_Info(BuildingStorey, "Cross vent pipe at correct level.");
			AddRelatedObj( crossVentPipe, connectedVentTee )
		else
			FXUtility.DisplaySolid_Error(BuildingStorey, "Cross vent pipe at wrong level.");
			AddRelatedObj( crossVentPipe, connectedVentTee )
		end
		
	else
		if checkStorey then
			FXUtility.DisplaySolid_Error(BuildingStorey, "Cross vent pipe is not provided.");
		end
	end
end

function AddRelatedObj( crossVentPipe, connectedVentTee )
	CheckReport.AddRelatedObj( crossVentPipe, crossVentPipe:GetAttri("Name") )

	connectedVentTee:ForEach(function ( tee )
		CheckReport.AddRelatedObj( tee, tee:GetAttri("Name"))
	end)
end