local DistChamberEleGrp = FXGroup.new()
local FlowFittingGrp = FXGroup.new()
local ManholeGrp= FXGroup.new();
local InsChamGrp= FXGroup.new();
local pubSewerGrp = FXGroup.new();
local incomingSewerGrp = FXGroup.new();
local YjunctionGrp = FXGroup.new();
local RaisedjunctionGrp = FXGroup.new();
local lastDistChamber;
local incomingsewer;
local Manhole;

function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_1_D_I_LAST_MANHOLE_DISTANCE");
  
  -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
  SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 5) then
      DistChamberEleGrp = DistChamberEleGrp + v;
      DistChamberEleGrp = DistChamberEleGrp:Unique();
    end
    if (k == 6) then
      FlowFittingGrp = FlowFittingGrp + v;
      FlowFittingGrp = FlowFittingGrp:Unique();
    end
  end
end

function checkRule(Building)
  local check = true;
  if #DistChamberEleGrp == 0 then
    FXUtility.DisplaySolid_Warning ( Building ,"No Manhole/Inspection Chamber found.")
    check = false;
  end
  if #FlowFittingGrp == 0 then
    FXUtility.DisplaySolid_Warning ( Building ,"No Y/Raised junction found.")
    check = false;
  end
  if check == true then
    local FlowSegmentGrp= Building:GetDescendants("FlowSegment");
    FlowSegmentGrp:ForEach(function(flowsegEle)
      if FXUtility.HasPatterInString(flowsegEle:GetAuxAttri("Entity.Description"),"public sewer line") == true then
        pubSewerGrp:Add(flowsegEle);
      end

      if FXUtility.HasPatterInString(flowsegEle:GetAuxAttri("Entity.Description"),"sewer connection") == true then
       incomingSewerGrp:Add(flowsegEle);
      end
    end)

    FlowFittingGrp:ForEach(function(flowfittingEle)
      if FXUtility.HasPatterInString(flowfittingEle:GetAuxAttri("Entity.Description"),"y junction") == true then
       YjunctionGrp:Add(flowfittingEle);
      end

      if FXUtility.HasPatterInString(flowfittingEle:GetAuxAttri("Entity.Description"),"raised junction") == true then
       RaisedjunctionGrp:Add(flowfittingEle);
      end
    end)
    DistChamberEleGrp:ForEach(function(distchambEle)
      if FXUtility.HasPatterInString(distchambEle:GetAttri("Name"),"manhole") == true then
        ManholeGrp:Add(distchambEle);
      end
    
      if FXUtility.HasPatterInString(distchambEle:GetAttri("Name"),"inspection chamber") == true then
        InsChamGrp:Add(distchambEle);
      end
    end)

    if #ManholeGrp ~= 0 then
      ManholeGrp:ForEach(function(manholeEle)
        incomingSewerGrp:ForEach(function(sewer)
          if FXClashDetection.IsCollided(manholeEle, sewer) then
            incomingsewer = sewer;
            lastDistChamber = manholeEle;
          end
        end) 
      end)
    else 
      InsChamGrp:ForEach(function(inschamEle)
        incomingSewerGrp:ForEach(function(sewer)
          if FXClashDetection.IsCollided(inschamEle, sewer) then
            incomingsewer = sewer;
            lastDistChamber = inschamEle;
          end
        end) 
      end)
    end

    local lastDistChamberOBB = FXGeom.GetBoundingOBB(lastDistChamber)
    local lastDistChamberOBB2 = FXGeom.GetBoundingBox(lastDistChamber)
    local lastDistChamberCenterPoint = lastDistChamberOBB:GetPos();
    local lastDistChamberMax = lastDistChamberOBB2:HighPos().z
    local StartPnt1;
    local StartPnt2;
    local EndPnt1; 
    local EndPnt2;
    local z = lastDistChamberCenterPoint.z;

    if #InsChamGrp ~= 0 then
      StartPnt1, StartPnt2, EndPnt1, EndPnt2 = Check(YjunctionGrp,RaisedjunctionGrp,pubSewerGrp,z)
    else
      if #ManholeGrp ~= 0 then
        StartPnt1, StartPnt2, EndPnt1, EndPnt2 = Check(YjunctionGrp,RaisedjunctionGrp,pubSewerGrp,z)
      end
    end

    local edgeLine1= Line3D(StartPnt1,StartPnt2);
    local edgeLine2= Line3D(StartPnt1,EndPnt2);
    local edgeLine3= Line3D(EndPnt1,EndPnt2);
    local edgeLine4= Line3D(EndPnt1,StartPnt2);
    local edgeLine5;
    
    if edgeLine1:Length() < edgeLine2:Length() then
      edgeLine5 = edgeLine1;
    else
      edgeLine5 = edgeLine2;
    end
   
    if edgeLine3:Length() < edgeLine5:Length() then
      edgeLine5 = edgeLine3;
    else
      edgeLine5 = edgeLine5;
    end
   
    if edgeLine4:Length() < edgeLine5:Length() then
      edgeLine5 = edgeLine4;
    else
      edgeLine5 = edgeLine5;
    end 

    local StartPnt = edgeLine5:GetStartPoint();
    local EndPnt = edgeLine5:GetEndPoint();
    local pnt2 = FXUtility.CenterPoint(StartPnt,EndPnt)
    local Distance = lastDistChamberCenterPoint:Distance_Pnt(pnt2);
    local pipemidpoint = Point3D(pnt2.x,lastDistChamberCenterPoint.y,pnt2.z)
    local pnt3 = Point3D(lastDistChamberCenterPoint.x,lastDistChamberCenterPoint.y,lastDistChamberMax+200);
    local pnt4 = Point3D(pnt2.x,lastDistChamberCenterPoint.y,lastDistChamberMax+200);
    local rounded = FXUtility.Round(Distance,2)
    local arrow = DoubleArrow(pnt4,pnt3);
    local line = Line3D(pnt4,pnt3)
    local length1 = line:Length()
    local plyline1  = PolyLine3D(TRUE);
    plyline1:AddPoint(lastDistChamberCenterPoint);
    plyline1:AddPoint(pnt3);
    plyline1:AddPoint(pnt4);
    plyline1:AddPoint(pipemidpoint);
    if Distance <= 50000 then
      isCompliant = true;
    else
      isCompliant = false;  
    end
    Compliant(isCompliant,arrow,lastDistChamber,rounded,YjunctionGrp,length1,plyline1);
  end
end

function Compliant(isCompliant,arrow,lastDistChamber,rounded,YjunctionGrp,length1,plyline1)
  if isCompliant then
    if #YjunctionGrp ~= 0 then
      FXUtility.DisplaySolid_Info(lastDistChamber:GetParent(),"Inspection chamber to Y junction distance",arrow);
      CheckReport.AddRelatedObj(lastDistChamber, FXUtility.Round(length1,0)+1 .. " mm")
      CheckReport.AddRelatedGeometry_Info(plyline1)
    else
      FXUtility.DisplaySolid_Info(lastDistChamber:GetParent(),"Inspection chamber to raised junction distance",arrow);
      CheckReport.AddRelatedObj(lastDistChamber, FXUtility.Round(length1,0)+1 .. " mm")
      CheckReport.AddRelatedGeometry_Info(plyline1)
    end 
  else
    if #YjunctionGrp ~= 0 then
      FXUtility.DisplaySolid_Error(lastDistChamber:GetParent(),"Inspection chamber to Y junction distance",arrow);
      CheckReport.AddRelatedObj(lastDistChamber, FXUtility.Round(length1,0)+1  .. " mm")
      CheckReport.AddRelatedGeometry_Error(plyline1)
    else
      FXUtility.DisplaySolid_Error(lastDistChamber:GetParent(),"Inspection chamber to raised junction distance",arrow);
      CheckReport.AddRelatedObj(lastDistChamber, FXUtility.Round(length1,0)+1 .. " mm")
      CheckReport.AddRelatedGeometry_Error(plyline1)
    end
  end    
end

function GetStartEnd(Group,z) 
  local StartPnt1;
  local StartPnt2;
  local EndPnt1; 
  local EndPnt2;
  Group:ForEach(function(sewer)
    local centerlineTerminal = FXMeasure.GetProjectionCenterLine(sewer)
    if StartPnt1 == nil then   
      local StartPnt = centerlineTerminal:GetStartPoint();
      StartPnt1 = StartPnt;
    else
      local StartPnt = centerlineTerminal:GetStartPoint();
      StartPnt2 = StartPnt;
    end  
    if EndPnt1 == nil then         
      local EndPnt = centerlineTerminal:GetEndPoint();
      EndPnt1 = EndPnt;
    else   
      local EndPnt = centerlineTerminal:GetEndPoint();
      EndPnt2 = EndPnt;
    end  
  end)
  return StartPnt1, StartPnt2, EndPnt1, EndPnt2;
end

function Check( YjunctionGrp,RaisedjunctionGrp,pubSewerGrp,z)
  if #YjunctionGrp ~= 0 then 
    StartPnt1, StartPnt2, EndPnt1, EndPnt2 = GetStartEnd(pubSewerGrp,z);
  elseif #RaisedjunctionGrp ~= 0 then 
    StartPnt1, StartPnt2, EndPnt1, EndPnt2 = GetStartEnd(pubSewerGrp,z);
  else   
    FXUtility.DisplaySolid_Warning(Building,"No Y junction/raised junction found.")
  end
  return StartPnt1, StartPnt2, EndPnt1, EndPnt2;
end