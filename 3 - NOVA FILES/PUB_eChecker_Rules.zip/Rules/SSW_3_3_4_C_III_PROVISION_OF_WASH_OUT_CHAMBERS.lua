--[[
	Implement by: Rafael L. Balanag
]]
local pumpingMains = FXGroup:new();
local pumpingMains2 = FXGroup:new();
local WashoutChambers = FXGroup:new();
local isCompliant = true;
local arr = {}
local arr1 = {}
local Fittings = FXGroup:new();
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end
function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_4_C_III_PROVISION_OF_WASH_OUT_CHAMBERS")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystems = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- minHeight = ConditionValues[2];
	if GrpObjSystems ~= nil then
		for k,v in pairs(GrpObjSystems) do
			if (k == 2) then
				WashoutChambers = WashoutChambers + v
				WashoutChambers = WashoutChambers:Unique()
			end
			if (k == 3) then
				pumpingMains = pumpingMains + v
				pumpingMains = pumpingMains:Unique()
			end
		end
	else
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				WashoutChambers = WashoutChambers + v
				WashoutChambers = WashoutChambers:Unique()
			end
			if (k == 3) then
				pumpingMains = pumpingMains + v
				pumpingMains = pumpingMains:Unique()
			end
		end
	end
end

function CheckRule(Building)
	local ArrFtng = FXGroup:new();
	local name; --Getting the name of the pipe for this clause because it included in the RI...(any pipe just to include the name in the message)
	if #WashoutChambers == 0 then
		if #pumpingMains ~= 0 then
			pumpingMains:ForEach(function(mains)
				-- FXUtility.DisplaySolid_Error(mains,"Wash-out Chamber is not provided.")
				local conFittings = mains:GetConnectedFitting();
				conFittings:ForEach(function(obj)
					Fittings:Add(obj)
				end)
			end)
			Fittings:Unique();
			Fittings:ForEach(function(fitting)
				local Box = FXGeom.GetBoundingBox(fitting);
				local midPos = Box:MidPos();
				local conPipe = fitting:GetConnectedSegment();
				local nearest;
				local lowest;
				local lowestFtng;
				local nearestPipe;
				if #conPipe == 2 then
					conPipe:ForEach(function(pipe)
						name = pipe:GetAttri("ObjectType");
						local slope, centerline = FXMeasure.GetPipeProperty(pipe);
						if tonumber(slope) ~= 0 and tonumber(pipe:GetAuxAttri("Constraints.Slope")) ~= 0 then
							local conFitts = pipe:GetConnectedFitting();
							if #conFitts == 2 then
								conFitts:ForEach(function(ftng)
									local Box = FXGeom.GetBoundingBox(ftng)
									local zVal = Box:MidPos().z
									if lowest == nil then
										lowest = zVal;
										lowestFtng = ftng
									else
										if lowest > zVal then
											lowest = zVal;
											lowestFtng = ftng
										end
									end
								end)
							end
						end
					end)
				end
				if lowestFtng ~= nil then
					ArrFtng:Add(lowestFtng);
				end
			end)
			ArrFtng:Unique();
			if #ArrFtng ~= 0 then
				ArrFtng:ForEach(function(obj)
					FXUtility.DisplaySolid_Error(obj,name..":".."Wash-out Chamber is not provided.")
				end)
			end
		else
			FXUtility.DisplaySolid_Warning(Building,"Wash-out Chamber and Pumping Main is not provided.")
		end
	else
		WashoutChambers:ForEach(function(washout)
			local Box = FXGeom.GetBoundingBox(washout);
			local midPos = Box:MidPos();
			local conObject = FXGroup:new();
			local nearest;
			local nearestPipe;
			pumpingMains:ForEach(function(mains)
				local slope, centerline = FXMeasure.GetPipeProperty(mains);
				if tonumber(slope) ~= 0 or tonumber(mains:GetAuxAttri("Constraints.Slope")) ~= 0 then
					if FXPUB.IsObjsConnected2(mains, washout, "FlowSegment") then
						conObject:Add(mains)
					end
				end
			end)
			if conObject ~= nil or #conObject ~= 0 then
				conObject:ForEach(function(obj)
					local slope, centerline = FXMeasure.GetPipeProperty(obj);
					local startPnt = Point3D(centerline:GetStartPoint().x, centerline:GetStartPoint().y, centerline:GetStartPoint().z);
					local endPnt = Point3D(centerline:GetEndPoint().x, centerline:GetEndPoint().y, centerline:GetEndPoint().z);
					local centerPoint = FXUtility.CenterPoint(startPnt, endPnt);

					local dist1 =  math.floor(centerPoint:Distance_Pnt(midPos));
					
					if nearest == nil then
						nearest = dist1;
						nearestPipe = obj
					else
						if nearest > dist1 then
							nearest = dist1;
							nearestPipe = obj
						end
					end
				end)
				if nearestPipe ~= nil then
					local slope, centerline = FXMeasure.GetPipeProperty(nearestPipe);

					local startPnt = Point3D(centerline:GetStartPoint().x, centerline:GetStartPoint().y, centerline:GetStartPoint().z);
					local endPnt = Point3D(centerline:GetEndPoint().x, centerline:GetEndPoint().y, centerline:GetEndPoint().z);
					local centerPoint = FXUtility.CenterPoint(startPnt, endPnt);

					local dist1, Pnt1 =  math.floor(startPnt:Distance_Pnt(midPos)), startPnt.z;
					local dist2, Pnt2 =  math.floor(endPnt:Distance_Pnt(midPos)), endPnt.z;

					if dist1 < dist2 then
						if Pnt1 > Pnt2 then
							isCompliant = false;
							FXUtility.DisplaySolid_Error(washout,nearestPipe:GetAttri("ObjectType")..": "..washout:GetAttri("ObjectType").." is located at high point.")
							-- CheckReport.AddRelatedObj(nearestPipe)
						else
							table.insert(arr, washout)
							table.insert(arr1, nearestPipe)

						end
					elseif dist1 > dist2 then
						if Pnt1 < Pnt2 then
							isCompliant = false;
							FXUtility.DisplaySolid_Error(washout,nearestPipe:GetAttri("ObjectType")..": "..washout:GetAttri("ObjectType").." is located at high point.")
							-- CheckReport.AddRelatedObj(nearestPipe)
						else
							table.insert(arr, washout)
							table.insert(arr1, nearestPipe)
						end
					end
				end
			else
				FXUtility.DisplaySolid_Warning(Building,"No sloped pipe detected.")
			end
		end)
		if isCompliant then
			for k,washout in pairs(arr) do
				FXUtility.DisplaySolid_Info(washout,arr1[k]:GetAttri("ObjectType")..": "..washout:GetAttri("ObjectType").." is located at low point.")
			end
		end
	end
end