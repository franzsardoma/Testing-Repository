--[[
	Implemented by: Jerrick Gillera
	Date: 2/1/2019	
]]--
local grpFlowTreatmentDevice = FXGroup.new()
local grpClosedDrain = FXGroup.new()
local grpCulvert = FXGroup.new()
local grpDriveWay = FXGroup.new()
local grpSideWalk = FXGroup.new()

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_12_1_GRATINGS_FOR_ENTRANCE_CULVERT")
	-- ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	local GrpObjs1 = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs1) do
		if (k == 2) then
			grpFlowTreatmentDevice = grpFlowTreatmentDevice + v
			grpFlowTreatmentDevice = grpFlowTreatmentDevice:Unique()
		end	    
		if (k == 3) then
			grpClosedDrain = grpClosedDrain + v
			grpClosedDrain = grpClosedDrain:Unique()
		end	
		if (k == 4) then
			grpCulvert = grpCulvert + v
			grpCulvert = grpCulvert:Unique()
		end
		if (k == 5) then
			grpDriveWay = grpDriveWay + v
			grpDriveWay = grpDriveWay:Unique()
		end	 
		if (k == 6) then
			grpSideWalk = grpSideWalk + v
			grpSideWalk = grpSideWalk:Unique()
		end	   	 
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 2) then
				ObjValue = v1["value"]
			end
		end		
	end	
end

function CheckRule(Building)	
	local DrivewayGrp = FXGroup.new()
	local compGratingGrp = FXGroup.new()
	local nonCompGratingGrp = FXGroup.new()

	grpDriveWay:ForEach(function ( DrivewayObj )
		grpCulvert:ForEach(function ( CulvertObj )
			if FXClashDetection.IsCollided( DrivewayObj , CulvertObj )then
				grpClosedDrain:ForEach(function ( ClosedDrainObj )
					if FXClashDetection.IsCollided( ClosedDrainObj , CulvertObj )then
						grpSideWalk:ForEach(function ( SideWalkObj )
							if FXClashDetection.IsCollided( SideWalkObj , CulvertObj )then
								local connObjGrp, x , y = getConnObj(SideWalkObj)
								if y ~= 0 or x ~= 0 then
									connObjGrp:ForEach(function ( connObj )
										if y ~= 0 then
											compGratingGrp:Add(connObj)
										else
											nonCompGratingGrp:Add(connObj)
										end											
									end)																
								elseif y == 0 and x == 0 then
									DrivewayGrp:Add(DrivewayObj)
								end
							end							
						end)						
					end					
				end)
			end
		end)
	end)

	compGratingGrp = compGratingGrp:Unique()
	DrivewayGrp = DrivewayGrp:Unique()
	nonCompGratingGrp = nonCompGratingGrp:Unique()

	compGratingGrp:ForEach(function ( GratingObj )
		FXUtility.DisplaySolid_Info ( GratingObj , ObjValue.. ": Gratings on both sides are provided.")
	end)
	DrivewayGrp:ForEach(function ( DrivewayObj )
		FXUtility.DisplaySolid_Error ( DrivewayObj , ObjValue.. ": Gratings are not provided.")
	end)
	nonCompGratingGrp:ForEach(function ( GratingObj )
		FXUtility.DisplaySolid_Error ( GratingObj , ObjValue.. ": Only One grating is provided.")
	end)
end

function getConnObj(obj)
	local connGrp = FXGroup.new()
	local x = 0
	local y = 0
	
	grpFlowTreatmentDevice:ForEach(function ( graiting )
		if FXClashDetection.IsCollided( graiting, obj )then
			connGrp:Add(graiting)
			x = x + 1
		else
			y = y + 1
		end
	end)
	connGrp = connGrp:Unique()	
	return connGrp, x , y
end