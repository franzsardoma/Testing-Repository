-- Implemented By: Lawrence Roy R. Quiling 1/16/2019
-- Updated By : Elcar Zarcilla 1/30/2019
local grpCloseDrain = FXGroup:new() --element 1
local grpNonSkid = FXGroup:new() -- element 2
local DepthOperator, DepthCondition, RungInterval
local RoadsideDrainVAL
local NonSkidVal

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_10_PRESENCE_OF_THE_RUNGS_FOR_CLOSED_DRAINS")
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- local SystemType = SystemTypes[1];
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	DepthOperator = ConditionValues[2]
	DepthCondition = ConditionValues[3]
	RungInterval = ConditionValues2[2]

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpCloseDrain = grpCloseDrain + v;
				grpCloseDrain = grpCloseDrain:Unique();
			end
			if (k == 3) then
				grpNonSkid = grpNonSkid + v;
				grpNonSkid = grpNonSkid:Unique();
			end
		end
	end

	local Values1 = {}
	local Values2 = {}

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
			if k == 2 then
				table.insert(Values2, v1["value"])
			end
		end
	end

	RoadsideDrainVAL = getValue(Values1)
	NonSkidVal = getValue(Values2)
end

function getValue( tab )
	local value = tab[1]
	local length = #tab

	for k,v in pairs(tab) do
		if k ~= 1 then
			if k ~= length then
				value = value..", "..v
			
			elseif k == length then 
				value = value.." or "..v
			end
		end
	end

	return value
end

function CheckWarning( Building )
	local flag = true

	if(#grpCloseDrain == 0) then
		flag = false	
		CheckReport.Warning( Building, RoadsideDrainVAL.." is not provided.")
	end

	return flag;
end

function checkRule( Building )
	if(CheckWarning(Building)) then
		---- Compliant with Rungs
		local Arr_CloseDrain1 = {}
		local Arr_TempObj1 = {}
		local Arr_grpRungInstalleds = {}
		local Arr_Arrows = {}
		local Arr_Depth1 = {}
		---- Compliant without Rungs
		local Arr_CloseDrain2 = {}
		local Arr_Depth2 = {}
		local Arr_TempObj2 = {}

		grpCloseDrain:ForEach(function ( CloseDrain )
			-- 1) Top Point
			local TopFace = getTopOpeningElement( CloseDrain )
			local TopPoint = getTopPoint( TopFace )
			-- 2) Depth
			local C3Channel = getC3Channel( CloseDrain, TopFace )
			local Depth = getDepth( CloseDrain, C3Channel, TopPoint )
			local grpRungInstalleds = getRungInstalled( TopFace, Depth )

			if FXRule.EvaluateNumber(DepthOperator, Depth, DepthCondition) then
				-- 3-a) Check Non Skid Aluminium Rung INSTALLED
				if #grpRungInstalleds ~= 0 then
					local arrows = getArrows( grpRungInstalleds )
					FXUtility.DisplaySolid_Info(CloseDrain, CloseDrain:GetAttri("ObjectType").." depth: "..Depth.." mm "..NonSkidVal.." is provided.")
					CheckReport.AddRelatedObj(C3Channel, C3Channel:GetAttri("ObjectType"))
					grpRungInstalleds:ForEach(function ( NonSkid )
						CheckReport.AddRelatedObj(NonSkid, NonSkid:GetAttri("ObjectType"))
					end)
					-- Display Interval
					if #arrows ~= 0 then
						for i,Arrow in pairs(arrows) do
							CheckReport.AddRelatedGeometry_Info(Arrow)
						end
					end
				else
					IsErrorNotFound = false
					FXUtility.DisplaySolid_Error(CloseDrain, CloseDrain:GetAttri("ObjectType").." depth: "..Depth.." mm "..NonSkidVal.." is not provided.")
					CheckReport.AddRelatedObj(C3Channel, C3Channel:GetAttri("ObjectType"))
				end

			else
				-- 3-b) Check Non Skid Aluminium Rung NOT INSTALLED
				if #grpRungInstalleds ~= 0 then
					IsErrorNotFound = false
					FXUtility.DisplaySolid_Error(CloseDrain, CloseDrain:GetAttri("ObjectType").." depth: "..Depth.." mm "..NonSkidVal.." is provided.")
					CheckReport.AddRelatedObj(C3Channel, C3Channel:GetAttri("ObjectType"))
					grpRungInstalleds:ForEach(function ( NonSkid )
						CheckReport.AddRelatedObj(NonSkid, NonSkid:GetAttri("ObjectType"))
					end)
				else
					FXUtility.DisplaySolid_Info(CloseDrain, CloseDrain:GetAttri("ObjectType").." depth: "..Depth.." mm "..NonSkidVal.." is not provided.")
				CheckReport.AddRelatedObj(C3Channel, C3Channel:GetAttri("ObjectType"))
				end
			end
		end)
	end
end

function getArrows( grpRungInstalleds )
	local Arrows = {}
	local Points = getPoints( grpRungInstalleds )

	if #Points > 1 then
		for k,Point in pairs(Points) do
			if k ~= #Points then
				local arrowGeom = DoubleArrow(Point,Points[k+1]);
				table.insert(Arrows,arrowGeom)
			end
		end
	end
	
	return Arrows
end

function getPoints( grpRungInstalleds )
	local Faces = {}
	local Points = {}

	grpRungInstalleds:ForEach(function ( RungInstall )
		for i=0, 5, 1 do 
			if FXMeasure.GetCircularFacesInDirection(RungInstall,i) ~= nil then
				local circleFace = FXMeasure.GetCircularFacesInDirection(RungInstall,i)
				table.insert(Faces,circleFace)
				break
			end
		end
	end)
	
	for k,Face in pairs(Faces) do
		table.insert(Points,getFaceCenterPoint( Face ))
	end

	return PointsSort( Points )
end

function PointsSort( Points )
	local SortPoints = {}
	local TempPoints = Points

	for i=1, #Points, 1 do 
		local TempPoint
		local index
		for k,Point in pairs(TempPoints) do
			if TempPoint == nil or TempPoint.z < Point.z then
				TempPoint = Point
				index = k
			end
		end
		table.insert(SortPoints,TempPoint)
		table.remove(TempPoints, index)
	end
	
	return SortPoints
end

function getRungInstalled( TopFace, Depth )
	local grpObjs = FXGroup:new()

	grpNonSkid:ForEach(function ( NonSkid )
		local extruded = TopFace:ExtrudedFace(Vector(0,0,-Depth))
		local nodeContainer	= FXUtility.CreateNodeFrom(extruded);

		if(FXClashDetection.IsCollided(NonSkid,nodeContainer))then
			grpObjs:Add(NonSkid)
		end
		FXClashDetection.DeleteNode(nodeContainer);
	end)

	return grpObjs
end

function getDepth( CloseDrain, C3Channel, TopPoint )
	local MaxDown = tonumber(FXGeom.GetBoundingBox(CloseDrain):HighPos().z - FXGeom.GetBoundingBox(CloseDrain):LowPos().z)
	local TempPoint = TopPoint

	for i = 1,MaxDown,1 do
		TempPoint = Point3D(TopPoint.x , TopPoint.y, TopPoint.z - i);
		local depthLine = Line3D(TopPoint , TempPoint);
		local depthLineNode = FXUtility.CreateNodeFrom(depthLine);

		if(FXClashDetection.IsCollided(depthLineNode, C3Channel))then
			FXClashDetection.DeleteNode(depthLineNode);
			break;
		end
		FXClashDetection.DeleteNode(depthLineNode);
	end

	return TopPoint.z - TempPoint.z
end

function getC3Channel( CloseDrain, TopFace )
	local obj = CloseDrain
	local Parent = CloseDrain:GetParent()
	local grpBuildingElementProxies = Parent:GetDescendants("BuildingElemementProxy") -- just get parent of closedDrain
	local CloseDrainHeight = FXGeom.GetBoundingBox(CloseDrain):HighPos().z - FXGeom.GetBoundingBox(CloseDrain):LowPos().z
	local extruded = TopFace:ExtrudedFace(Vector(0,0,-CloseDrainHeight))
	local nodeContainer	= FXUtility.CreateNodeFrom(extruded);

	grpBuildingElementProxies:ForEach(function ( elementProx )
		if FXUtility.HasPatterInString(elementProx:GetAttri("ObjectType"),"C3 Channel") then
			if(FXClashDetection.IsCollided(elementProx,nodeContainer))then
				obj = elementProx
			end
		end
	end)

	FXClashDetection.DeleteNode(nodeContainer);

	return obj
end

function getFaceCenterPoint( Face )
	local outerEdge = FXMeasure.GetOuterEdge(Face)
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local Point1 = outerEdge:GetPoint(0)
	local dist,Pnt

	for i=0,(PolyLinePointNumber-2) do
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2):Length()
		if( dist == nil or dist < Line ) then
			dist = Line
			Pnt = Point2
		end
	end

	return FXUtility.CenterPoint(Point1,Pnt);
end

function getTopPoint( TopFace )
	return getFaceCenterPoint( TopFace )
end

function getTopOpeningElement( CloseDrain )
	local grpOpeningElements = CloseDrain:GetChildren("OpeningElement")
	local TopFace = FXMeasure.GetTopFace(CloseDrain)

	if #grpOpeningElements ~= 0 then
		local nodeContainer	= FXUtility.CreateNodeFrom(TopFace);

		grpOpeningElements:ForEach(function ( OpeningElement )
			if(FXClashDetection.IsCollided(nodeContainer,OpeningElement))then
				TopFace = FXMeasure.GetTopFace(OpeningElement)
			end
		end)
		FXClashDetection.DeleteNode(nodeContainer);
	end

	return TopFace
end