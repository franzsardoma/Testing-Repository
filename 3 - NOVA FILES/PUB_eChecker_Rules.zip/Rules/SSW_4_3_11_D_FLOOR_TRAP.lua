local bldgStoreys = FXGroup:new();
local floorTrapGrp = FXGroup:new();
local roofGrp = FXGroup:new();
local openSpaceGrp = FXGroup:new();
local CollidedSpaceGrp = FXGroup:new();

local COMPLIANT = "%s: %s is not located."
local NONCOMPLIANT = "%s: %s is located."
local WARNING = "No open area found.";
local WARNING_FLOORTRAP = "Floor Trap is located inside the building.";

-- local tempGrp = FXGroup:new();

-- local NonCompliantObjs = FXGroup:new();
local NonCompliantObjs = {};
local XCollidedObjs = FXGroup:new();
local WarningObjs = FXGroup:new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_4_3_11_D_FLOOR_TRAP")
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");

	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	if #xmlObjs > 0 then
		for k,v in pairs(xmlObjs) do
			if (k == 2) then
				floorTrapGrp = floorTrapGrp + v
				floorTrapGrp = floorTrapGrp:Unique()
			end
		end
	end

	local GrpObjs = FXRule.filterObjects(parsedXml,Building);
	for k,v in pairs(GrpObjs) do

		if (k == 3) then
			roofGrp = roofGrp + v
		end

		if (k == 5) then
			bldgStoreys = bldgStoreys + v
		end
	end

	bldgStoreys:ForEach(function(storey)
		print("storey:" .. storey:GetAttri("Name"))
		local GrpObjs2 = FXRule.filterObjects(parsedXml,storey);
		for k,v in pairs(GrpObjs2) do
			if (k == 4) then
				openSpaceGrp = openSpaceGrp + v
			end
		end
	end)

	-- print("openSpaceGrp " .. #openSpaceGrp)
end


function checkRule(Building)
	local SpaceGrp = FXGroup:new();
	 bldgStoreys:ForEach(function(storey)
		SpaceGrp = SpaceGrp + storey:GetDescendants("Space");
	 	end)

	local isCompliant = true;

	if #openSpaceGrp == 0 then
		isCompliant = false
		FXUtility.DisplaySolid_Warning(Building, WARNING)
	end

	if isCompliant then
		local tempGrp = FXGroup:new();
		local compliantGrp = {}
		openSpaceGrp:ForEach(function(space)

			local slabPrj, spaceNode, spaceLowz = CheckSpace(space)

			floorTrapGrp:ForEach(function (floortrap)

				if FXClashDetection.IsCollided(spaceNode,floortrap) then
					tempGrp:Add(floortrap)

					local tempTbl = {}
					table.insert(tempTbl, floortrap);
					table.insert(tempTbl, space:GetAttri("LongName"));
					table.insert(compliantGrp, tempTbl);

					CollidedSpaceGrp:Add(space)
					local subPrj = CheckCover(floortrap, spaceLowz, slabPrj)

					if subPrj ~= nil then
						-- NonCompliantObjs:Add(floortrap)
						print("1 " ..floortrap:GetAttri("Name"))

						local tempTbl = {}
						table.insert(tempTbl, floortrap);
						table.insert(tempTbl, space:GetAttri("LongName"));
						table.insert(NonCompliantObjs, tempTbl);

					end
				end
			end)
			FXClashDetection.DeleteNode(spaceNode)

		end)


		-- NOT COLLIDED TO SPACE

		if #tempGrp ~= #floorTrapGrp then
			local noncompliantGrp = {}

			SpaceGrp = SpaceGrp - CollidedSpaceGrp

			XCollidedObjs = floorTrapGrp - tempGrp

			SpaceGrp:ForEach(function(space)

				local slabPrj, spaceNode, spaceLowz = CheckSpace(space)

				local tempTbl = {}
				XCollidedObjs:ForEach(function (floortrap)
					local subPrj = CheckCover(floortrap, spaceLowz, slabPrj)

					if subPrj == nil then
						WarningObjs:Add(floortrap)
					else
						local distance,nearSpace;
						CollidedSpaceGrp:ForEach(function(cspace)
							local tempDist = FXMeasure.Distance(floortrap,cspace)
							if distance == nil then
								distance = tempDist:Length()
								nearSpace = cspace
							elseif distance < tempDist:Length() then
								distance = tempDist:Length()
								nearSpace = cspace
							end
						end)
						print("2 " ..floortrap:GetAttri("Name") .. " " .. nearSpace:GetAttri("Name"))
						table.insert(tempTbl, floortrap);
						table.insert(tempTbl, nearSpace:GetAttri("LongName"));
						table.insert(noncompliantGrp, tempTbl);
					end

				end)
				FXClashDetection.DeleteNode(spaceNode)

			end)

			if #WarningObjs ~= 0 then
				WarningObjs:ForEach(function (Obj)
					FXUtility.DisplaySolid_Warning(Building, WARNING_FLOORTRAP)
					CheckReport.AddRelatedObj(Obj,Obj:GetAttri("ObjectType"))
				end)
				return
			else
				print("NONCOMPLIANT 2 " .. #noncompliantGrp)
				-- XCollidedObjs:ForEach(function (floortrap)
				-- 	DisplayNonCompliant(floortrap)
				-- end)
				for k,v in pairs(noncompliantGrp) do
					DisplayNonCompliant(v[1],v[2])
				end
				-- return
			end
		end

		if #NonCompliantObjs ~= 0 then
			print("NONCOMPLIANT 1 " .. #NonCompliantObjs)
			-- NonCompliantObjs:ForEach(function (floortrap)
			-- 	DisplayNonCompliant(floortrap)
			-- end)
			for k,v in pairs(NonCompliantObjs) do
				DisplayNonCompliant(v[1],v[2])
			end
			return
		else
			for k,v in pairs(compliantGrp) do
				print("COMPLIANT")
				local Storey = FXUtility.GetStorey(v[1]);
				FXUtility.DisplaySolid_Info(v[1], string.format(COMPLIANT, v[2],v[1]:GetAttri("ObjectType")))
				-- CheckReport.AddRelatedObj(v[1],v[1]:GetAttri("ObjectType"))
			end
			-- tempGrp:ForEach(function (floortrap)
			-- 	print("COMPLIANT")
			-- 	local Storey = FXUtility.GetStorey(floortrap);
			-- 	FXUtility.DisplaySolid_Info(Storey, string.format(COMPLIANT, floortrap:GetAttri("Name")))
			-- 	CheckReport.AddRelatedObj(floortrap,floortrap:GetAttri("Name"))
			-- end)
		end

	else
		return	
	end

end

function DisplayNonCompliant(floortrap, spaceName)
	local Storey = FXUtility.GetStorey(floortrap);
	FXUtility.DisplaySolid_Error(floortrap, string.format(NONCOMPLIANT, spaceName, floortrap:GetAttri("ObjectType")))
	-- CheckReport.AddRelatedObj(floortrap,floortrap:GetAttri("ObjectType"))
end

function CheckSpace (space)
	local spaceBbOx = FXGeom.GetBoundingBox(space)
	local spaceNode = FXUtility.CreateNodeFrom(spaceBbOx)
	local spaceLowz = spaceBbOx:LowPos().z
	local grpSlabsAbove = space:GetSlabsAbove();
	-- grpSlabsAbove:ForEach(function (slab)

	grpSlabsAbove = grpSlabsAbove:Filter(function(slab)
		local slabHighz = FXGeom.GetBoundingBox(slab):HighPos().z
		if slabHighz > spaceLowz then
			return true
		end
		-- FXPUB.DisplayTest(slab,slab:GetAttri("Name"))
	end)

	local slabPrj = FXMeasure.GetProjection(grpSlabsAbove,spaceLowz)

	return slabPrj, spaceNode, spaceLowz

end

function CheckCover(floortrap, spaceLowz, slabPrj)

	local box = FXGeom.GetBoundingBox(floortrap)
	local node = FXUtility.CreateNodeFrom(box)
	local floortrapPrj = FXMeasure.GetObjProjection(node, spaceLowz)
	FXClashDetection.DeleteNode(node)

	local subPrj = FXMeasure.SubtractProjection(floortrapPrj, slabPrj, spaceLowz)

	return subPrj;
end