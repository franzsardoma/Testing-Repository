
local Element1Grp = FXGroup:new();
local flowFittingGrp = FXGroup:new();
local ObjProp;
local ObjValue;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end



function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_2_2_PROHIBITED_MATERIALS_FOR_PIPING")
    local ConditionValues = FXRule.ParseValues(parsedXml, "Condition2");
    local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition4");
    materials = tostring (ConditionValues[1]);
    dzr = tostring (ConditionValues2[1]);

     local tblValues = FXRule.filterTableValues(parsedXml, Building)

    for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 2) then
				fittingProp = v1["property"];
				fittingValue = v1["value"];
			end
		end
	end
    systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
   local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			Element1Grp = Element1Grp + v;
			Element1Grp = Element1Grp:Unique();		
		end
		if (k == 3) then
			flowFittingGrp = flowFittingGrp + v;
			flowFittingGrp = flowFittingGrp:Unique();		
		end
	end
end

function checkRule(Building)
	local string = FXPUB.Split(materials,",")
	local count = #string
	local check = checkParseObj(Building)

	if check then
		local isCompliant = true
		local compliantMaterialsGrp = FXGroup:new();
		local nonCompliantMaterialsGrp = FXGroup:new();
		local withMaterialsGrp = FXGroup:new();

		-- Group pipes with attribute: Material
			Element1Grp:ForEach(function(Element1GrpEle)
					if Element1GrpEle:GetAuxAttri("Mechanical.Material") then
						withMaterialsGrp:Add(Element1GrpEle)
					end			
			end)
		if #withMaterialsGrp ~= 0 then	
			-- Checking for the Materials of the pipes
			withMaterialsGrp:ForEach(function(pipes)
			 getMaterial, attriPipe = FXPUB.CheckObjMaterial(pipes, materials)			
					if not getMaterial  then
							compliantMaterialsGrp:Add(pipes)				
					else
						FXUtility.DisplaySolid_Error(pipes, "Potable water pipe material is " .. attriPipe)
						isCompliant = false
					end		
			end)
		end
		if #flowFittingGrp ~= 0 then
		-- Checking Materials of the fittings
			flowFittingGrp:ForEach(function(fittings)
			local objTypeFitting = fittings:GetAttri(fittingProp)
				if (FXUtility.HasPatterInString(objTypeFitting,fittingValue)) then

					 getMaterial, attriFitting =  FXPUB.CheckObjMaterial(fittings, dzr)
				
					if getMaterial then
						compliantMaterialsGrp:Add(fittings)
					else
						isCompliant = false
						FXUtility.DisplaySolid_Error(fittings, fittings:GetAttri("ObjectType").. "pipe fitting is not dezincification resistant.")
					end
				end						
			end)
		else
			FXUtility.DisplaySolid_Warning(Building, "Pipe fitting is not provided.")
		end
		if isCompliant then
			compliantMaterialsGrp:ForEach(function(compliantMaterialsGrpEle)

				if compliantMaterialsGrpEle.Type =="FlowSegment" then
					FXUtility.DisplaySolid_Info(compliantMaterialsGrpEle, "Potable water pipe material is " .. attriPipe)
				else
					FXUtility.DisplaySolid_Info(compliantMaterialsGrpEle, compliantMaterialsGrpEle:GetAttri("ObjectType").. "pipe fitting is " .. attriFitting)
				end	
			end)
		end
	end
end

function checkParseObj(Building)
	if (#Element1Grp == 0) then
		FXUtility.DisplaySolid_Warning(Building, "Pipe is not provided.")
		return false;
	end
	return true;
end
