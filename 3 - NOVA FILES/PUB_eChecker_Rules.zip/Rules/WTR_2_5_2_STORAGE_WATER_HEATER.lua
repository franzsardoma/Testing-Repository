local NO_CHECK 			= "Anti-vacuum valve is provided but, check valve is not provided."
local NO_ANTIVACUUM 	= "Check valve is provided but, anti-vacuum relief valve is not provided."
local HAS_CHECK_ANTI 	= "Check valve and anti-vacuum relief valve are provided."
local HAS_DOUBLE_CHECK 	= "Double check valves is provided."
local NO_WATER_HEATER 	= "No water heater found."
local NO_BOTH			= "Double check valves or check valve with anti-vacuum relief valve are not provided."
local CLEARANCE_MSG 	= "Clearance between the top of water heater to the inverted \"U\" is %.1f mm."

-- local allWaterHeater 	= FXGroup.new();
local allDoubleCheck	= FXGroup.new();
local allCheck			= FXGroup.new();
local allAntiVacuum		= FXGroup.new();
local tblDoubleCheck 	= {}
local tblCheck 			= {}
local tblAntiVacuum 	= {}
local tblheater 	= {}
local systemType;
local parsedXml;
local minVerticalDist = 50 
local maxVerticalDist = 75
local condOperator;
local flag = true;
function main()

	CheckEngine.SetCheckType("Site")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Site)
	local ok, path = pcall(FXPUB.GetFilePath()) -- NOTE: path is a function
	-- print("LUA " .. path())
	-- parsedXml = FXPUB.ParseXml(path(), "WTR_2_5_2_STORAGE_WATER_HEATER") 
	parsedXml = FXPUB.ParseXml(path(), "WTR_2_5_2_STORAGE_WATER_HEATER") 

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	systemType = systemTypes[1]
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition2"); -- parse the condition values
	-- print(ConditionValues[2] .. ConditionValues[3])
	condOperator = ConditionValues[2]
	maxVerticalDist = tonumber(ConditionValues[3]) 

	local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	for k,v in pairs(tbl) do
		if k == 2 then
			tblheater = v
		end
		if k == 3 then
			tblCheck = v
		end
		if k == 4 then
			tblAntiVacuum = v
		end
		if k == 5 then
			tblDoubleCheck = v
		end
	end
	print("tblCheck " .. #tblCheck .. " tblAntiVacuum " .. #tblAntiVacuum .. " tblDoubleCheck" .. #tblDoubleCheck .. " Heater"..#tblheater)
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building); --filter objs from Building
	-- local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Site, systemTypes) --filter objs from System
	-- for k,v in pairs(xmlObjs) do -- get the model objects
	-- 	if k == 5 then
	-- 		allWaterHeater = allWaterHeater + v
	-- 		allWaterHeater = allWaterHeater:Unique()			
	-- 	end
	-- 	if k == 6 then
	-- 		allCheck = allCheck + v
	-- 		allCheck = allCheck:Unique()			
	-- 	end			
	-- 	if k == 7 then
	-- 		allAntiVacuum = allAntiVacuum + v
	-- 		allAntiVacuum = allAntiVacuum:Unique()			
	-- 	end
	-- 	if k == 8 then
	-- 		allDoubleCheck = allDoubleCheck + v
	-- 		allDoubleCheck = allDoubleCheck:Unique()			
	-- 	end
	-- end
end

function checkRule(Building)
	local systemGrp = (Building:GetParent():GetParent()):GetChildren("System")
	if #systemGrp == 0 then
		DisplayNoWaterHeater(Building)
		return false;
	end
	systemGrp:ForEach(function(system)
		local allWaterHeater = FXGroup.new();
		if FXUtility.HasPatterInString(system:GetAttri("Name"), systemType) then
		flag = false;
			local objGrp = FXRule.filterObjects(parsedXml, system);
			for k,v in pairs(objGrp) do 
				if k == 2 then
					allWaterHeater = allWaterHeater + v
				end
			end

			if #allWaterHeater == 0 then
				DisplayNoWaterHeater(Building)
				return false;
			end
			local tblPipeID = GetPipes(system) -- pipes in COLD SYSTEM

			allWaterHeater:ForEach(function (waterheater)
				for _, v in pairs(tblDoubleCheck) do
					local doubleCheck = FXPUB.GetConnectedObj(waterheater, "FlowController", "ObjectType", v, 10)
					if doubleCheck ~= nil then
						print("PASSED " .. waterheater:GetAttri("ObjectType"))
						-- FXUtility.DisplaySolid_Info(doubleCheck, HAS_DOUBLE_CHECK);
						FXUtility.DisplaySolid_Info(waterheater, HAS_DOUBLE_CHECK);
						CheckReport.AddRelatedObj( doubleCheck, doubleCheck:GetAttri("ObjectType"));
					else
						for _, v1 in pairs(tblAntiVacuum) do
							for _,v2 in pairs(tblCheck) do
								print(v1 .. " " .. v2)
								local antiVacuum = FXPUB.GetConnectedObj(waterheater, "FlowController", "ObjectType", v1, 10)
								print("antivaccuum is nil " .. tostring(antiVacuum == nil))
								if antiVacuum ~= nil then
										local check = GetConnectedCheckValve(antiVacuum, v2, 10)
										if check ~= nil then
											FXUtility.DisplaySolid_Info(waterheater, HAS_CHECK_ANTI);
											CheckReport.AddRelatedObj( check, check:GetAttri("Name"));
											CheckReport.AddRelatedObj( antiVacuum, antiVacuum:GetAttri("ObjectType"));
										else
											FXUtility.DisplaySolid_Error(waterheater, NO_CHECK);
											CheckReport.AddRelatedObj( antiVacuum, antiVacuum:GetAttri("ObjectType"));
										end
										-- WaterHeaterToPipeVerticalDistance(waterheater, antiVacuum)
								else
									local check = GetConnectedCheckValve(waterheater, 15)
									if check ~= nil then
										FXUtility.DisplaySolid_Error(waterheater, NO_ANTIVACUUM);
										CheckReport.AddRelatedObj( check, check:GetAttri("ObjectType"));
									else
										FXUtility.DisplaySolid_Error(waterheater, NO_BOTH);
									end
								end
							end
						end
					end
				end
				--Vertical clear distance between the top of water heater to the centerline of top pipe of inverted “U”
				PipeToWaterHeaterVerticalDistance(waterheater, tblPipeID);
			end)
		end
	end)

	if flag then
		DisplayNoWaterHeater(Building)
	end
end



function PipeToWaterHeaterVerticalDistance(waterheater, tblPipeID)  --Vertical clear distance between the top of water heater to the centerline of top pipe of inverted “U”
	local connectedObjs = waterheater:GetConnectedElement();
	connectedObjs:ForEach(function (pipe1) -- pipes connected to water heater
		for k, v in pairs(tblPipeID) do
			if pipe1.Id == v then -- checking if the connected pipe is in COLD SYSTEM
				local elbow = FXPUB.GetConnectedObj(pipe1, "FlowFitting", "Name", "elbow", 5)
				if elbow == nil then return nil end
				local connPipes = elbow:GetConnectedElement();
				connPipes:ForEach(function(pipe2)
					if pipe1.Id ~= pipe2.Id then
						local pipeGrp3 = GetConnectedFlowSegment(pipe2)
						pipeGrp3:ForEach(function(pipe3)
								if pipe3.Id ~= pipe1.Id then
									-- FXPUB.DisplayTest(pipe3,pipe3.Id)
									print(" isPipeHorizontal " .. tostring(isPipeHorizontal(pipe3)))
									-- if isPipeHorizontal(pipe3) then
										-- local pipePrj = GetPipeCenterPrj(pipe3)
										local waterheaterOBB = FXGeom.GetBoundingOBB(waterheater)
										local waterMaxPnt = waterheaterOBB:MaxPnt()
										local waterheaterPrj = FXMeasure.GetObjProjection(waterheater,waterMaxPnt.z)

										local pipeOBB = FXGeom.GetBoundingOBB(pipe3)
										local pipeCenterPnt = pipeOBB:GetPos()
										local pipePrj = FXMeasure.GetObjProjection(waterheater,pipeCenterPnt.z)

										local waterheatNode = FXUtility.CreateNodeFrom(waterheaterPrj);
										local pipeNode = FXUtility.CreateNodeFrom(pipePrj);
										local pipeToBldgObjDist = FXMeasure.Distance(pipeNode,waterheatNode );
										--------------------------------------------------------------------------
										-- Move the arrow in the center of waterheater
										local midPnt = waterheaterOBB:GetPos()
										local startPnt = Point3D(midPnt.x, midPnt.y, pipeToBldgObjDist:GetStartPoint().z)
										local endPnt = Point3D(midPnt.x, midPnt.y, pipeToBldgObjDist:GetEndPoint().z)
										pipeToBldgObjDist = Line3D(startPnt, endPnt)
										--------------------------------------------------------------------------

										local verticalDistLength = FXUtility.Round(pipeToBldgObjDist:Length())

										-- print(FXUtility.Round(pipeToBldgObjDist:Length()))
										local arrowGeom = DoubleArrow(pipeToBldgObjDist:GetStartPoint(),pipeToBldgObjDist:GetEndPoint());
										local pipeCenterLine = GetPipeCenterLine(pipe3)
										local newCenterLine = Line3D(pipeToBldgObjDist:GetStartPoint(), pipeCenterLine:GetStartPoint())

										-- if verticalDistLength >= minVerticalDist and verticalDistLength <= maxVerticalDist then
										-- print(tostring(FXRule.EvaluateRule("INTEGER", condOperator, maxVerticalDist, verticalDistLength)))
										-- if FXRule.EvaluateRule("INTEGER", condOperator, maxVerticalDist, verticalDistLength) then
										if verticalDistLength == maxVerticalDist then
											FXUtility.DisplaySolid_Info(pipe3,string.format(CLEARANCE_MSG, verticalDistLength), arrowGeom)
											CheckReport.AddRelatedGeometry_Info(newCenterLine, "msg")
										else
											FXUtility.DisplaySolid_Error(pipe3,string.format(CLEARANCE_MSG, verticalDistLength), arrowGeom)
											CheckReport.AddRelatedGeometry_Error(newCenterLine, "msg")
										end

										-- DisplayTest(waterheater,waterheater:GetAttri("Name"),arrowGeom)
										-- DisplayTest(waterheater,"pipeCenterLine",pipeCenterLine)
										-- DisplayTest(waterheater,"newCenterLine",newCenterLine)
									-- end
								end
						end)
						-- end
					end
				end)
			end
		end
	end)
end

function WaterHeaterToPipeVerticalDistance(waterheater, antiVacuum) --Vertical clear distance between the top of water heater to the centerline of top pipe of inverted “U”
	local connectedObjs = antiVacuum:GetConnectedElement();
	connectedObjs:ForEach(function(obj)
		if obj.Type == "FlowFitting" then 
			local connPipes = obj:GetConnectedSegment();
			print(#connPipes)
			connPipes:ForEach(function(conPipe)
				local faces = FXMeasure.GetALLCircularFaces(conPipe);
				if #faces == 2 then
					local center1 = FXMeasure.GetCenterPointsOfPolygon(faces[1])
					local center2 = FXMeasure.GetCenterPointsOfPolygon(faces[2])
					if center1.z == center2.z then -- getting the horizontal pipe
						print(conPipe.Id .. " " .. center1.z .. " " .. center2.z)
						local waterheaterBOX = FXGeom.GetBoundingBox(waterheater)
						local waterMaxPnt = waterheaterBOX:HighPos()
						local waterheaterPrj = FXMeasure.GetObjProjection(waterheater,waterMaxPnt.z)
						local pipeOBB = FXGeom.GetBoundingOBB(conPipe)
						local pipeCenterPnt = pipeOBB:GetPos()
						local pipePrj = FXMeasure.GetObjProjection(waterheater,pipeCenterPnt.z)

						local waterheatNode = FXUtility.CreateNodeFrom(waterheaterPrj);
						local pipeNode = FXUtility.CreateNodeFrom(pipePrj);
						local pipeToBldgObjDist = FXMeasure.Distance(pipeNode,waterheatNode );
						--------------------------------------------------------------------------
						-- Move the arrow in the center of waterheater
						local waterheaterOBB = FXGeom.GetBoundingOBB(waterheater)
						local midPnt = waterheaterOBB:GetPos()
						local startPnt = Point3D(midPnt.x, midPnt.y, pipeToBldgObjDist:GetStartPoint().z)
						local endPnt = Point3D(midPnt.x, midPnt.y, pipeToBldgObjDist:GetEndPoint().z)
						pipeToBldgObjDist = Line3D(startPnt, endPnt)
						--------------------------------------------------------------------------

						local verticalDistLength = FXUtility.Round(pipeToBldgObjDist:Length())

						-- print(FXUtility.Round(pipeToBldgObjDist:Length()))
						local arrowGeom = DoubleArrow(pipeToBldgObjDist:GetStartPoint(),pipeToBldgObjDist:GetEndPoint());
						local pipeCenterLine = GetPipeCenterLine(conPipe)
						local newCenterLine = Line3D(pipeToBldgObjDist:GetStartPoint(), pipeCenterLine:GetStartPoint())

						if verticalDistLength >= minVerticalDist and verticalDistLength <= maxVerticalDist then
						-- print(tostring(FXRule.EvaluateRule("INTEGER", condOperator, maxVerticalDist, verticalDistLength)))
						-- if FXRule.EvaluateRule("INTEGER", condOperator, maxVerticalDist, verticalDistLength) then
						-- print("TEST verticalDistLength")
						-- if verticalDistLength == maxVerticalDist then
							FXUtility.DisplaySolid_Info(conPipe,string.format(CLEARANCE_MSG, verticalDistLength), arrowGeom)
							CheckReport.AddRelatedGeometry_Info(newCenterLine, "msg")
						else
							FXUtility.DisplaySolid_Error(conPipe,string.format(CLEARANCE_MSG, verticalDistLength), arrowGeom)
							CheckReport.AddRelatedGeometry_Error(newCenterLine, "msg")
						end

						-- DisplayTest(waterheater,waterheater:GetAttri("Name"),arrowGeom)
						-- DisplayTest(waterheater,"pipeCenterLine",pipeCenterLine)
						-- DisplayTest(waterheater,"newCenterLine",newCenterLine) 
					end
				else
					print("ERRROR")
				end
			end)
		else
			print("ERROR in line 150 ...")
		end
	end)
end

function GetPipeCenterLine(pipe)
	local pipeOBB = FXGeom.GetBoundingOBB(pipe)
	local centerPnt = pipeOBB:GetPos()
	local line1 = FXMeasure.GetProjectionCenterLine(pipe)
	local startPnt = line1:GetStartPoint()
	local endPnt = line1:GetEndPoint()
	local pnt1 = Point3D(startPnt.x, startPnt.y, centerPnt.z)
	local pnt2 = Point3D(endPnt.x, endPnt.y, centerPnt.z)
	local centerLine = Line3D(pnt1, pnt2)
	return centerLine
end

function GetConnectedFlowSegment(pipe)
	local objGrp = FXGroup.new()
	local connObjs1 = pipe:GetConnectedElement();
	connObjs1:ForEach(function(obj1)
		if obj1.Type == "FlowSegment" then
			objGrp:Add(obj1)
		else
			local connObjs2 = obj1:GetConnectedElement()
			connObjs2:ForEach(function(obj2)
				if obj2.Type == "FlowSegment" then
					if pipe.Id ~= obj2.Id then
						objGrp:Add(obj2)
					end
				end
			end)
		end
	end) 
	return objGrp;
end

function isPipeHorizontal(pipe)
	local faces = FXMeasure.GetALLCircularFaces(pipe);
	if #faces == 2 then
		local center1 = FXMeasure.GetCenterPointsOfPolygon(faces[1])
		local center2 = FXMeasure.GetCenterPointsOfPolygon(faces[2])
		print("center1 " .. center1.z .. " center2 " .. center2.z)
		if FXUtility.Round(center1.z,0) == FXUtility.Round(center2.z,0)  then -- getting the vertical pipe
			return true;
		else
			return false;
		end
	end
end

function isPipeVertical(pipe)
	local faces = FXMeasure.GetALLCircularFaces(pipe);
	if #faces == 2 then
		local center1 = FXMeasure.GetCenterPointsOfPolygon(faces[1])
		local center2 = FXMeasure.GetCenterPointsOfPolygon(faces[2])

		if center1.x == center2.x or center1.y == center2.y then -- getting the vertical pipe
			return true;
		else
			return false;
		end
	end

	-- comment because not working
	-- if (FXMeasure.GetCircularFacesInDirection(pipe, 0) ~= nil) and (FXMeasure.GetCircularFacesInDirection(pipe, 1) ~= nil) then
	-- 	return true;
	-- else
	-- 	return false;
	-- end
	-- return FXPUB.IsVerticalPipe(pipe)
end



function DisplayNoWaterHeater(container)
	-- if FXUtility.HasPatterInString(container.Type, "Building") then
		FXUtility.DisplaySolid_Warning(container,NO_WATER_HEATER);
	-- elseif FXUtility.HasPatterInString(container.Type, "System") then
	-- 	local building = (container:GetParent()):GetDescendants("Building") -- building is fxGroup
	-- 	print(#building)
	-- 	building:ForEach(function(bldg)
	-- 		FXUtility.DisplaySolid_Warning(bldg,NO_WATER_HEATER);
	-- 	end)
	-- end
end

function GetPipes(System)
	local tblPipeID = {}
	local pipeGrp = System:GetDescendants("FlowSegment")
	pipeGrp:ForEach(function(pipe)
		table.insert(tblPipeID, pipe.Id);
	end)
	return tblPipeID;
end

function GetConnectedCheckValve(obj, checkValveName, loopCount)
	local check = FXPUB.GetConnectedObj(obj, "FlowController", "ObjectType", checkValveName, loopCount)
	return check;
end

function DisplayTest(obj1, msg, geom)
	FXUtility.DisplaySolid_Warning(obj1, msg, geom);
end