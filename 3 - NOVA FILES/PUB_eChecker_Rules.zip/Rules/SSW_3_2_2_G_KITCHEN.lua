--[[
	Modified by: Rafael Balanag
]]
local SystemType = "sanitary";
local FlowTerminalName = "water closet";
local SpaceName = "kitchen";
local StorageDeviceName = "balancing tank";
local minDist = 300;
local grpFlowSegment = FXGroup:new();
local WaterClosetGroup = FXGroup.new();
local isCompliant = true;

local grpFlowSegment1 = FXGroup:new();
local WaterClosetGroup1 = FXGroup.new();
local KitcheSpaceGroup = FXGroup.new();
local arrObj1 = {}
local arrObj2 = {}
local arrObj3 = {}
local arrObj4 = {}
local i = 0;
function main()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("ParseXml");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function ParseXml(Building)
	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_G_KITCHEN");

	
	local SpaceGrp = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- minHeight = ConditionValues[2];

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpFlowSegment = grpFlowSegment + v
			grpFlowSegment = grpFlowSegment:Unique()
		end
	end

	for k,v in pairs(SpaceGrp) do
		if (k == 4) then
			KitcheSpaceGroup = KitcheSpaceGroup + v
			KitcheSpaceGroup = KitcheSpaceGroup:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do
		if (k == 3) then
			WaterClosetGroup = WaterClosetGroup + v
			WaterClosetGroup = WaterClosetGroup:Unique()
		end
	end


end



function checkRule(Building)


	local grpKitchen = FXGroup.new();
	local grpStorey = FXGroup.new();
	local grpSlab = FXGroup.new();
	grpSlab = GetSlabAll(Building);
	local grpspace = FXGroup.new();
	local HighStorey;
	local extrudeFace;
	local grpSlabBelow = FXGroup.new();
	local grpSegNotCol = FXGroup.new();
	local flag98 = false;

	if #grpFlowSegment == 0 then
		FXUtility.DisplaySolid_Warning(Building, "No Sanitary Pipe found");
		return;
	end
	
	-- HighStorey = GetHighestStorey(Building);
	-- local obbStorey = FXGeom.GetBoundingBox(HighStorey);
	local HighEle = FXPUB.GetHighestElevation(Building);
	local BuildingStoreyGroup = Building:GetDescendants("BuildingStorey");
	
	local FlowTerminalGroup = Building:GetDescendants("FlowTerminal");
	-- BuildingStoreyGroup:ForEach(function(BuildingStorey)
		local isKitchenPresent = false;
		grpspace = Building:GetDescendants("Space");
		if #KitcheSpaceGroup ~= 0 then
			KitcheSpaceGroup:ForEach(function (Space)
				local name = Space:GetAttri("LongName");
				local flag = false;
					local grpSegmentCol = FXGroup.new();
					local grpSlabCol = FXGroup.new();

					isKitchenPresent = true;
					prjSpace = FXMeasure.GetObjProjection(Space, Space:GetParent("BuildingStorey"):Elevation());
					local edge = FXMeasure.GetOuterEdge(prjSpace);
					local noOfPnt1 = edge:GetPointNumber();
					local PlyLine = PolyLine3D(TRUE);
					
					for i = 1, noOfPnt1 -1, 1 do
						local pnt1 = edge:GetPoint(i);
						PlyLine:AddPoint(pnt1);
					end

					PlyLine:ClosePolyline();
					local face = PlyLine:Face3D()
					extrudeFace = face:ExtrudedFace(Vector(0,0,HighEle));
					local node = FXUtility.CreateNodeFrom(extrudeFace)
					grpSlab:ForEach(function (Slab)
						if FXClashDetection.IsCollided(node, Slab) then
							grpSlabCol:Add(Slab)
						end
					end)

					if(#WaterClosetGroup ~= 0)then 
						grpFlowSegment:ForEach(function (Segment)
							if FXClashDetection.IsCollided(node, Segment) then
								grpSegmentCol:Add(Segment)
							else
								grpSegNotCol:Add(Segment)
							end
						end)
						
						FXClashDetection.DeleteNode(node)
						grpSlabBelow = Space:GetSlabsBelow()
						grpSlabCol = grpSlabCol - grpSlabBelow	
						local lowSlab = GetLowestSlab(grpSlabCol)
						grpSlabBel = GetSlabBelowPipe(grpSlabCol,grpSegmentCol)
						
						local Flag69 = false;
						WaterClosetGroup:ForEach(function(WaterCloset)
							grpSegmentCol:ForEach(function(Object)
								if(FXPUB.IsObjsConnected(WaterCloset,Object))then 
									Flag69 = true;
								end
							end)
						end)
						
						if(Flag69)then

							if #grpSegmentCol ~= 0 then
								grpSegmentCol:ForEach(function (ColSeg)
									local obbslab = FXGeom.GetBoundingBox(lowSlab)
									local obbseg = FXGeom.GetBoundingBox(ColSeg)
					
									if obbslab:LowPos().z > obbseg:HighPos().z then
						 				FXUtility.DisplaySolid_Error(Space,ColSeg:GetAttri("Name").." in ".. Space:GetAttri("LongName"))
						 				CheckReport.AddRelatedObj(ColSeg, ColSeg:GetAttri("Name"))
						 				isCompliant = false;
									 else
									 	
						 				local prjSlab = FXMeasure.GetProjection(grpSlabBel, Space:GetParent("BuildingStorey"):Elevation());
										local prjSegment = FXMeasure.GetProjection(grpSegmentCol, Space:GetParent("BuildingStorey"):Elevation());
										local prjNew = FXMeasure.SubtractProjection(prjSegment,prjSlab, Space:GetParent("BuildingStorey"):Elevation());
										if prjNew ~= nil then
											local prjInter = IntersectProjection(prjSpace, prjNew);
											if prjInter ~= nil then
												FXUtility.DisplaySolid_Error(Space,ColSeg:GetAttri("Name").." in ".. Space:GetAttri("LongName"));
							 					CheckReport.AddRelatedObj(ColSeg, ColSeg:GetAttri("Name"));
							 					isCompliant = false;
											else
												flag = true
											end					
										else
											flag = true
											
										end		
									end
								end)
							else
								-- CompliantMessage(Space);
								i = i + 1
								arrObj1[i] = Space;
							end
						else
							-- CompliantMessage(Space);
							i = i + 1
							arrObj2[i] = Space;
						end
					else
						flag98 = true;
						-- CompliantMessage(Space);
						i = i + 1
						arrObj3[i] = Space;
					end			
				if(flag)then 
					-- CompliantMessage(Space);
					i = i + 1
					arrObj4[i] = Space;
				end
			end)
		else
			FXUtility.DisplaySolid_Warning(Building,"No Kitchen found");
		end
	-- end)
	if isCompliant then
		for k,Space in pairs(arrObj1) do
			FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe connected to Water Closet in Kitchen");
			CheckReport.AddRelatedObj(Space,Space:GetAttri("LongName"));
		end
		for k,Space in pairs(arrObj2) do
			FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe connected to Water Closet in Kitchen");
			CheckReport.AddRelatedObj(Space,Space:GetAttri("LongName"));
		end
		for k,Space in pairs(arrObj3) do
			FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe connected to Water Closet in Kitchen");
			CheckReport.AddRelatedObj(Space,Space:GetAttri("LongName"));
		end
		for k,Space in pairs(arrObj4) do
			FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe connected to Water Closet in Kitchen");
			CheckReport.AddRelatedObj(Space,Space:GetAttri("LongName"));
		end
	end
	if(#WaterClosetGroup == 0 and flag98 == false)then 
		FXUtility.DisplaySolid_Warning(Building,"No Water Closet found");		
	end
end

function CompliantMessage(Object)
	FXUtility.DisplaySolid_Info(Object,"No Sanitary Pipe connected to Water Closet in Kitchen");
	CheckReport.AddRelatedObj(Object,Object:GetAttri("LongName"));
end


function GetHighestStorey(Building)
	local HighStorey
	grpStorey = Building:GetDescendants("BuildingStorey")
	grpStorey:ForEach(function (Storey)
		if #FXUtility.GetAllUpperStorey(Storey) == 0 then
			HighStorey = Storey
		end
	end)
	if HighStorey ~= nil then
		return HighStorey
	end
end


function GetSlabAll(Building)
	local grpSlab = FXGroup.new()
	grpSlab = Building:GetDescendants("Slab") --+ Building:GetDescendants("Covering")
	return grpSlab
end


function GetLowestSlab(grpSlab)
	local lowSlab
	grpSlab:ForEach(function (Slab)
		if lowSlab == nil then
			lowSlab = Slab
		else
			local obblowslab = FXGeom.GetBoundingBox(lowSlab)
			local obbSlab = FXGeom.GetBoundingBox(Slab)
			if obblowslab:LowPos().z > obbSlab:LowPos().z then
				lowSlab = Slab
			end
		end
	end)
	return lowSlab
end


function GetSlabBelowPipe(grpSlabCol,grpSegmentCol)
	grpSlabBel = FXGroup.new()
	grpSegmentCol:ForEach(function (Seg)
		grpSlabCol:ForEach(function (Slab)
			if (FXRule.IsOverlap(Seg, Slab) == -1) then
				grpSlabBel:Add(Slab)
			end
		end)
	end)
	return grpSlabBel
end

function IntersectProjection(prj1, prj2)
	local node1 			= FXUtility.CreateNodeFrom(prj1);
	local node2 			= FXUtility.CreateNodeFrom(prj2); 
	local grpNode  			= FXGroup.new(); 
	grpNode:Add(node1);
	grpNode:Add(node2);						
	local prjSpaceCopy		= FXMeasure.IntersectProjection(grpNode)
	FXClashDetection.DeleteNode(node1);
	FXClashDetection.DeleteNode(node2);
	return prjSpaceCopy;
end 