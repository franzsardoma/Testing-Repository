local grpPipe = FXGroup.new()
local grpDrain = FXGroup.new()
local grpDrainageReserve = FXGroup.new()
local minimumDis
local operator

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_5_5_2_B_DRAINAGE_RESERVE_1500MM")

	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- local serviceSystemType = FXRule.ParseValues(parsedXml, "SystemType");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	operator = ConditionValues[2]
	minimumDis = tonumber( ConditionValues[3] ) -- for Condition Values 
	-- try = SystemTypes[1]
	-- print (try)
	for k,v in pairs( GrpObjs ) do    
		if (k == 2) then
			grpPipe = grpPipe + v
			grpPipe = grpPipe:Unique()
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 3) then
			grpDrain = grpDrain + v
			grpDrain = grpDrain:Unique()
		end	
	end

	grpPipe = grpPipe - grpDrain

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 4) then
			grpDrainageReserve = grpDrainageReserve + v
		end	
	end
end


function CheckRule(Building)
	local isErrorFound = false
	print (#grpPipe .." - "..#grpDrain .." - "..#grpDrainageReserve)
	if #grpDrain == 0 then
		FXUtility.DisplaySolid_Warning ( Building , "Earth drain not provided." )
		return
	end

	local lowestStoreyElev = LowestElev ( Building )
	local i = 0
	local comDrain = {}
	local comPipe  = {}
	local comProj  = {}
	local comLine  = {}
	local comDis   = {}

	grpDrainageReserve : ForEach ( function ( drainageSpace )
		local spaceBox = FXGeom.GetBoundingBox( drainageSpace ) 
		local spaceHighPosZ = spaceBox : HighPos ().z

		local positiveSpaceZ = toPositive ( spaceHighPosZ )
		local positiveLowestElev = toPositive ( lowestStoreyElev )

		local range = positiveSpaceZ + positiveLowestElev

		local spaceProj = FXMeasure.GetObjProjection( drainageSpace , spaceHighPosZ )

		local outerEdge = FXMeasure.GetOuterEdge( spaceProj )
		local spaceFace = outerEdge:Face3D()
		local extruded = spaceFace:ExtrudedFace(Vector(0, 0, -range ) )
		local extrudedNode = FXUtility.CreateNodeFrom( extruded )

		local grpCollidedDrain = FXGroup.new()
		local grpCollidedPipe = FXGroup.new()

		grpDrain : ForEach ( function ( drain )
			if FXClashDetection.IsCollided( extrudedNode , drain ) then
				grpCollidedDrain : Add ( drain )
			end
		end)

		grpPipe : ForEach ( function ( pipe )
			-- local systemType = pipe:GetAuxAttri ("Mechanical.System Type")
			if FXClashDetection.IsCollided( extrudedNode , pipe ) then
				grpCollidedPipe : Add ( pipe )
			end
		end)

		FXClashDetection.DeleteNode(extrudedNode);
 
 		if #grpPipe == 0 then
 			FXUtility.DisplaySolid_Warning ( drainageSpace , "No Service Pipe found." )
 			return;
 		end

		grpCollidedDrain : ForEach ( function ( colDrain )
			local colDrainBox = FXGeom.GetBoundingBox( colDrain ) 
			local newSpaceProj = FXMeasure.GetObjProjection( drainageSpace , colDrainBox:LowPos().z )

			grpCollidedPipe : ForEach ( function ( colPipe )
				local projNode = FXUtility.CreateNodeFrom( newSpaceProj )
				local Distance = FXMeasure.Distance( projNode , colPipe )
				FXClashDetection.DeleteNode( projNode );

				local doubleArrow = DoubleArrow( Distance:GetStartPoint() , Distance:GetEndPoint() );
				local dis = FXUtility.Round( Distance:Length() ,0)
				-- if dis >= minimumDis then
				if FXRule.EvaluateNumber( operator , dis , minimumDis ) then
					i = i + 1
					comDrain[i] = colDrain
					comPipe[i] = colPipe
					comLine[i] = Distance
					comProj[i] = newSpaceProj
					comDis[i] = dis
				elseif FXRule.EvaluateNumber( operator , dis , minimumDis ) == false then
					FXUtility.DisplaySolid_Error ( colDrain , colPipe:GetAuxAttri("Entity.ObjectType").." to "..colDrain:GetAuxAttri("Entity.ObjectType").." Distance: "..dis.." mm" , doubleArrow )
					CheckReport.AddRelatedObj ( colDrain , colDrain:GetAuxAttri("Entity.ObjectType") )
					CheckReport.AddRelatedObj ( colPipe , colPipe:GetAuxAttri("Entity.ObjectType") )
					CheckReport.AddRelatedGeometry_Error( newSpaceProj , "proj");
					isErrorFound = true
				end 
			end)
		end)
	end)

	if isErrorFound == false then
		local x = 1
		print (i)
		while x ~= i+1 do
			local doubleArrow = DoubleArrow ( comLine[x]:GetStartPoint() , comLine[x]:GetEndPoint() )
			FXUtility.DisplaySolid_Info ( comDrain[x] , comPipe[x]:GetAuxAttri("Entity.ObjectType").." to "..comDrain[x]:GetAuxAttri("Entity.ObjectType").." Distance: "..comDis[x].." mm", doubleArrow )
			CheckReport.AddRelatedObj ( comDrain[x] , comDrain[x]:GetAuxAttri("Entity.ObjectType") )
			CheckReport.AddRelatedObj ( comPipe[x] , comPipe[x]:GetAuxAttri("Entity.ObjectType") )
			CheckReport.AddRelatedGeometry_Info( comProj[x] , "proj");
			x = x + 1
		end
	end
end


function LowestElev( Building )
	local grpStorey = Building : GetChildren ("BuildingStorey")
	local lowestElev
	grpStorey : ForEach ( function ( storey )
		local elev = storey:Elevation();
		if lowestElev == nil or lowestElev > elev then
			lowestElev = elev 
		end
	end)

	return lowestElev
end


function toPositive ( num )
	local thisNum

	if num < 0 then
		thisNum = num * -1
	else
		thisNum = num
	end

	return thisNum
end