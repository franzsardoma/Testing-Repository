--Rafael 10/02/2018 Updated SWD 5.1

local groupDrainageReserve = FXGroup:new()
local groupStructure = FXGroup:new()
local drainageReserve;
local drainageReserveProjection;
local lowPos = 0
local isCompliant = true
local lowestStorey = FXGroup:new()
local highestStorey = FXGroup:new()
local zPoint = FXGroup:new();
local lowPoint;
local collidedObj = FXGroup:new()
local elevationStorey;
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckStorey");
	CheckEngine.RunCheckPipeline();

	-- CheckEngine.SetCheckType("BuildingStorey");
	-- CheckEngine.BindCheckFunc("CheckRuleForDrainageAndStructure");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckDrainageCount");
	CheckEngine.RunCheckPipeline();

end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_5_1_DRAINAGE_RESERVE")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- minHeight = ConditionValues[2];

	for k,v in pairs(GrpObjs) do
		-- if (k == 5) then
		-- 	roofSpacesGrp = roofSpacesGrp + v
		-- end
		if (k == 3) then
			groupDrainageReserve = groupDrainageReserve + v
			groupDrainageReserve = groupDrainageReserve:Unique()
		end
		if (k == 2) then
			groupStructure = groupStructure + v
			groupStructure = groupStructure:Unique()
		end
	end
	
end

function CheckStorey(Building)
	local storeys = Building:GetChildren();
	if storeys ~= nil then
		storeys:ForEach(function(storey)
			local below = storey:GetBelowStorey()
			if below <=0 then
				lowestStorey:Add(storey)
			end
		end)
	end

	if storeys ~= nil then
		storeys:ForEach(function(Storey)
			if #FXUtility.GetAllUpperStorey(Storey) == 0  then
				highestStorey:Add(Storey)
			end
		end)
	end
end

-- function CheckRuleForDrainageAndStructure(BuildingStorey)
-- 	local spaces = BuildingStorey:GetDescendants("Space")
-- 	if #spaces ~= 0 then
-- 		spaces:ForEach(function(dr)
-- 			local name = dr:GetAttri("LongName")
-- 			if FXUtility.HasPatterInString(name,"Drainage Reserve") == true or FXUtility.HasPatterInString(name,"Drainage_Reserve") == true then
-- 				groupDrainageReserve:Add(dr)
-- 			end
-- 		end)
-- 	end

-- 	local allObjs = BuildingStorey:GetDescendants("All")
-- 	if #allObjs ~= 0 then
-- 		allObjs:ForEach(function(obj)
-- 			local name = obj:GetAttri("Name")
-- 			if name ~= nil then
-- 				groupStructure:Add(obj)
-- 			end
-- 		end)
-- 	end

-- end

function CheckRule(Building)
	local lowPos;
	lowestStorey:ForEach(function(lowest)
		local box = FXGeom.GetBoundingBox(lowest);
		lowPos = box:LowPos().z
	end)

	local elevation = FXPUB.GetHighestElevation(Building) - lowPos;
	local newObjStructure = groupStructure - groupDrainageReserve;
	if #groupDrainageReserve == 0 then
		FXUtility.DisplaySolid_Warning(Building,"No Drainage Reserve found.")
	else
		groupDrainageReserve:ForEach(function(drainage)
			local drainageProj = FXMeasure.GetObjProjection(drainage, lowPos)
			
			local outer = FXMeasure.GetOuterEdge(drainageProj);
			local face = outer:Face3D();
			local extrudeFace = face:ExtrudedFace(Vector(0,0,elevation))
			-- FXUtility.DisplaySolid_Info(drainage,"Projection",extrudeFace)
			local node = FXUtility.CreateNodeFrom(extrudeFace)
			newObjStructure:ForEach(function(obj)
				if FXClashDetection.IsCollided(node,obj) then
					local objname = obj:GetAttri("Name")
					local structureProjection = FXMeasure.GetObjProjection(obj,lowPos)
					local drProjection

					if structureProjection ~= nil and drainageProj ~= nil then
						local intersectProjection = FXMeasure.IntersectTwoProjection(drainageProj,structureProjection,lowPos);

						if intersectProjection ~= nil then
							FXUtility.DisplaySolid_Error(obj,obj:GetAttri("Name").." is within "..drainage:GetAttri("LongName"),intersectProjection)
							CheckReport.AddRelatedObj(obj, obj:GetAttri("Name"),drainageProj)							
							CheckReport.AddRelatedGeometry_Wire(extrudeFace, "Drainage Reserve Wire Projection.")
							-- CheckReport.AddRelatedObj(dr, dr:GetAttri("Name"))
							isCompliant = false
						end
					end
				end
			end)
			FXClashDetection.DeleteNode(node);
		end)
		if isCompliant then
			groupDrainageReserve:ForEach(function(drainage)
				local drainageProj = FXMeasure.GetObjProjection(drainage, lowPos)
				
				local outer = FXMeasure.GetOuterEdge(drainageProj);
				local face = outer:Face3D();
				local extrudeFace = face:ExtrudedFace(Vector(0,0,elevation))
				-- FXUtility.DisplaySolid_Info(drainage,"Projection",extrudeFace)
				FXUtility.DisplaySolid_Info(Building, "No structures within "..drainage:GetAttri("LongName"));
				CheckReport.AddRelatedGeometry_Wire(extrudeFace, "Drainage Reserve Wire Projection.")
			end)
		end
	end
end