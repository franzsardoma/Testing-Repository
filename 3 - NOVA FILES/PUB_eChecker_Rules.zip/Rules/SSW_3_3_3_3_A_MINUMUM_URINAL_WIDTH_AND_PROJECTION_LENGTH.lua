local grpUrnl = FXGroup:new();
local wDist, lDist;
local COMPLIANT = true;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_3_3_A_MINUMUM_URINAL_WIDTH_AND_PROJECTION_LENGTH")
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpUrnl = grpUrnl + v;
			grpUrnl = grpUrnl:Unique();
		end
	end
	for k,v in pairs(ConditionValues1) do -- get the condition values
		if (k == 3) then
			wDist = tonumber(v); -- 300 Minimum Width --
		end
	end
	for k,v in pairs(ConditionValues2) do -- get the condition values
		if (k == 3) then
			lDist = tonumber(v); -- 300 Minimum Length --
		end
	end
end

function CheckRule( Building )
	local lArrow, lResult;
	local wArrow, wResult;

	if(#grpUrnl ~= 0)then
		grpUrnl:ForEach(function ( urinal )
			local OBB = FXGeom.GetBoundingOBB(urinal);
			local Node = FXUtility.CreateNodeFrom(OBB);
			local Projection = FXMeasure.GetObjProjection(Node, OBB:MinPnt().z);
			-- Width Operation --
			local wEdge = FXMeasure.GetOuterEdge(Projection);
			local wWidth = getWidth(wEdge)
			local wPoint1 = wWidth:GetStartPoint();
			local wPoint2 = wWidth:GetEndPoint();
			local wLength = wWidth:Length();
			wArrow = DoubleArrow(wPoint1 , wPoint2);
			wResult =  FXUtility.Round(wLength);
			-- Length Operation --
			local lEdge = FXMeasure.GetOuterEdge(Projection);
			local lWidth = getLength(lEdge)
			local lPoint1 = lWidth:GetStartPoint();
			local lPoint2 = lWidth:GetEndPoint();
			local lLength = lWidth:Length();
			lArrow = DoubleArrow(lPoint1 , lPoint2);

			lResult = FXUtility.Round(lLength);

			-- Condition --
			local flag;
			if(wResult < wDist and lResult >= lDist)then
				flag = 1;
			elseif(lResult < lDist and wResult >= wDist)then
				flag = 2;
			else
				flag = 3;
			end

			if(flag == 1)then
				FXUtility.DisplaySolid_Error(urinal, "Width = "..wResult.."mm",wArrow);
				CheckReport.AddRelatedObj(urinal,urinal:GetAttri("Description"));
			elseif(flag == 2)then
				FXUtility.DisplaySolid_Error(urinal, "Length = "..lResult.."mm",lArrow);
				CheckReport.AddRelatedObj(urinal,urinal:GetAttri("Description"));
			else
				FXUtility.DisplaySolid_Info(urinal, "Width = "..wResult.."mm",wArrow);
				FXUtility.DisplaySolid_Info(urinal, "Length = "..lResult.."mm",lArrow);
			end

		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Urinal is not provided.");
	end
end
-- to Get the smalles line of Urinal projection --
function getWidth( route )
	local PolyLinePointNumber = route:GetPointNumber();
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = route:GetPoint(i)
		local Point2 = route:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end
-- to Get the longest line of Urinal projection --
function getLength( route )
	local PolyLinePointNumber = route:GetPointNumber();
	local dist;

	for i=0,(PolyLinePointNumber-4) do
		local Point1 = route:GetPoint(i)
		local Point2 = route:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() <= Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end