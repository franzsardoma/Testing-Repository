local SystemTypes;
local InspectionChamberGrp = FXGroup:new()
local grpFlowSegment = FXGroup:new();
local pipeName;
local minDiameter;
local pipeNominalDiameter;
local isConnectedToChamber = false;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_2_A_MAIN_DRAIN_LINE_150MM")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	minDiameter = ConditionValues[3];

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpFlowSegment = grpFlowSegment + v;
			grpFlowSegment = grpFlowSegment:Unique();
		end
		if (k == 3) then
			InspectionChamberGrp = InspectionChamberGrp + v;
			InspectionChamberGrp = InspectionChamberGrp:Unique();
		end
	end
end


function checkRule(Building)
	print(#grpFlowSegment)
	if #grpFlowSegment ~= 0 then

		if #InspectionChamberGrp ~= 0 then

			grpFlowSegment:ForEach(function ( pipe )
				local isCompliant = false;

				InspectionChamberGrp:ForEach(function (chamber)

					local distance = FXMeasure.Distance(pipe, chamber)

					if FXClashDetection.IsCollided(pipe, chamber) then
						isConnectedToChamber = true
					else

						local flowFittingGrp = Building:GetDescendants("FlowFitting")
						flowFittingGrp:ForEach(function ( fitting )
							if FXClashDetection.IsCollided(chamber, fitting) then
								if FXClashDetection.IsCollided(fitting, pipe) then
									isConnectedToChamber = true
								end
							end
						end)

					end

					if isConnectedToChamber then
						pipeName = pipe:GetAttri("Name");
						pipeNominalDiameter = pipe:GetAuxAttri("AC_Pset_Pipe_Straight_21.Nominal Size")
						if pipeNominalDiameter == nil then
							pipeNominalDiameter = pipe:GetAuxAttri("Mechanical.Diameter");
						end
						pipeNominalDiameter = FXUtility.Round(tonumber(pipeNominalDiameter), 2)
							
						if pipeNominalDiameter >= tonumber(minDiameter) then
							isCompliant = true;
						end
					end
				end)
				if pipeNominalDiameter ~= nil then
					CheckResult(Building, isCompliant, pipeName, pipeNominalDiameter, pipe)
				end
			end)
			if isConnectedToChamber == false then
				FXUtility.DisplaySolid_Warning(chamber, "Inspection Chamber is not connected with main drain-line.")
			end

		else
			FXUtility.DisplaySolid_Warning(Building, MSG_NO_CHAMBER)
		end

	else
		FXUtility.DisplaySolid_Warning(Building, MSG_NO_MAIN_DRAIN)
	end
end

function CheckResult(Building, isCompliant, pipeName, pipeNominalDiameter, pipe)
	if isCompliant then
		FXUtility.DisplaySolid_Info(Building, pipeName..": Pipe nominal diameter = "..pipeNominalDiameter.."mm");
		CheckReport.AddRelatedObj( pipe, pipeName )
		
	else
		FXUtility.DisplaySolid_Error(Building, pipeName..": Pipe nominal diameter = "..pipeNominalDiameter.."mm");
		CheckReport.AddRelatedObj( pipe, pipeName )
	end
end

