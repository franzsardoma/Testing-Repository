
local Structure = FXGroup:new()
local RoadSide = FXGroup:new()
local Outlet = FXGroup:new()
local groupStructure = FXGroup:new()
local RoadSideBottomface
local lowestStorey = FXGroup:new()
local flag1 = true
local flag2 = true
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();


end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_4_7_1_NO_STRUCTURES_OVER_ROADSIDE_OUTLET_DRAIN")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- -- local SystemType = SystemTypes[1];
	-- local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	-- minHeight = ConditionValues[2];

	for k,v in pairs(GrpObjsBuilding) do
		if (k == 2) then
			Structure = Structure + v
			Structure = Structure:Unique()
		end
		if (k == 3) then
			RoadSide = RoadSide + v
			RoadSide = RoadSide:Unique()
		end
		if (k == 4) then
			Outlet = Outlet + v
			Outlet = Outlet:Unique()
		end
		
	end

	Structure = Structure - RoadSide;
	Structure = Structure - Outlet;
end

function checkRule(Building)
	local bldgMaxPnt = FXPUB.GetHighestElevation(Building)
	local node1 = FXClashDetection.CreateNode()
	local elevation1
	local theBOX1
	local node2 = FXClashDetection.CreateNode()
	local elevation2
	local theBOX2


	if(#RoadSide ~= 0) then
		RoadSide:ForEach(function( roadside )
			elevation1 = FXGeom.GetBoundingBox(roadside):LowPos().z
			local prj1 = FXMeasure.GetObjProjection(roadside, elevation1+1);
			local outerEdge1 = FXMeasure.GetOuterEdge( prj1 )
			local newFace1 = outerEdge1:Face3D()
			local solidObj =  FXMeasure.ShrinkFace(newFace1, 10);
			local outerEdge11 = FXMeasure.GetOuterEdge( solidObj )
			local newFace11 = outerEdge11:Face3D()

			theBOX1 = newFace11:ExtrudedFace(Vector(0,0,-(elevation1 - bldgMaxPnt)));
			node1 = FXUtility.CreateNodeFrom(theBOX1);
			if (#Structure ~= 0) then
					Structure:ForEach(function ( structure )
						if FXUtility.HasPatterInString(structure:GetAttri("ObjectType"),"Opening") == false and FXUtility.HasPatterInString(structure.Type,"BuildingStorey") == false then
							if FXClashDetection.IsCollided(node1,structure) then
								FXUtility.DisplaySolid_Error(structure,structure:GetAuxAttri("Entity.ObjectType").." is over "..roadside:GetAuxAttri("Entity.ObjectType"));
								-- CheckReport.AddRelatedObj(structure, structure:GetAttri("Name"))
								-- CheckReport.AddRelatedObj(roadside, roadside:GetAttri("ObjectType"))
								flag1 = false
							end
							
						end
					end)
					FXClashDetection.DeleteNode(node1);
			end
		end)
	end

	if(#Outlet ~= 0) then
		Outlet:ForEach(function( outlet )
			elevation2 = FXGeom.GetBoundingBox(outlet):LowPos().z
			local prj2 = FXMeasure.GetObjProjection(outlet, elevation2+1);
			local outerEdge2 = FXMeasure.GetOuterEdge( prj2 )
			local newFace2 = outerEdge2:Face3D()
			local solidObj =  FXMeasure.ShrinkFace(newFace2, 10);
			local outerEdge22 = FXMeasure.GetOuterEdge( solidObj )
			local newFace22 = outerEdge22:Face3D()

			theBOX2 = newFace22:ExtrudedFace(Vector(0,0,-(elevation2 - bldgMaxPnt)));
			node2 = FXUtility.CreateNodeFrom(theBOX2);

			if (#Structure ~= 0) then
				Structure:ForEach(function ( structure )
					if FXUtility.HasPatterInString(structure.Type,"Space") == false and FXUtility.HasPatterInString(structure.Type,"BuildingStorey") == false then
						if FXClashDetection.IsCollided(node2,structure) then
							FXUtility.DisplaySolid_Error(structure,structure:GetAuxAttri("Entity.ObjectType").." is over "..outlet:GetAttri("ObjectType"));
							-- CheckReport.AddRelatedObj(structure, structure:GetAttri("Name"))
							-- CheckReport.AddRelatedObj(outlet, outlet:GetAttri("ObjectType"))
							flag2 = false
								
						end
					end
				end)
				FXClashDetection.DeleteNode(node2);
			end
		end)
	end
	

	if (#RoadSide ~= 0) then
		if flag1 == true then
			RoadSide:ForEach(function( roadside )
				FXUtility.DisplaySolid_Info(roadside,"No structures over "..roadside:GetAttri("ObjectType"));
			end)
		end
	else
		if (#Outlet == 0) then
		FXUtility.DisplaySolid_Warning(Building,"RoadSide drain is not provided.");
		end
	end
	if (#Outlet ~= 0) then 
		if flag2 == true then
			Outlet:ForEach(function( outlet )
				FXUtility.DisplaySolid_Info(outlet,"No structures over "..outlet:GetAttri("ObjectType"));
			end)
		end
	else
		if (#RoadSide == 0) then
			FXUtility.DisplaySolid_Warning(Building,"Outlet drain is not provided.");
		end
	end
end