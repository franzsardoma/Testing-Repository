function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function checkRule(Building)

	local grpStorey = Building:GetChildren("BuildingStorey");
	local grpControllerService = FXGroup:new();
	local grpControllerStop = FXGroup:new();
	local grpStorage = FXGroup:new();
	
	local SystemParent = Building:GetParent():GetParent():GetChildren("System");
	SystemParent:ForEach(function (sys)
		if FXUtility.IsBelongToTableElement2(sys, {"cold water", "hot water"}) then
			
			local GrpVentPipe = sys:GetChildren("FlowController");
			GrpVentPipe:ForEach(function (obj)
				if FXUtility.IsBelongToTableElement2(obj, {"service valve"}) then
					grpControllerService:Add(obj)
				end
				if FXUtility.IsBelongToTableElement2(obj, {"stop valve"}) then
					grpControllerStop:Add(obj)
				end
			end)

			local tempGrpTrap = sys:GetChildren("FlowStorageDevice");
			tempGrpTrap = tempGrpTrap:Filter(
			function(ele)
				if FXUtility.IsBelongToTableElement2(ele, {"water tank"}) then
					return true;
				end
			end)
			grpStorage = tempGrpTrap + grpStorage;
		end
	end)
	
	grpControllerService = grpControllerService:Unique();
	grpStorage = grpStorage:Unique();
	
	if( #grpStorage == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"No water tank under cold/hot water system.");
	else
	
		grpStorage:ForEach(function (tank)
			local ConnectingTank = nil;
			grpStorage:ForEach(function (tank2)
				if( tank.Id ~= tank2.Id ) then
					local isConnTank = FXPUB.GetConnectedObj( tank2, "FlowStorageDevice", "Name", "water tank", 5);
					if( isConnTank ~=  nil ) then
						ConnectingTank = tank2;
					end
				end
			end)
				
			local connEle = tank:GetConnectedElement();
			local isCompliant = true;
			local compliantGrp = FXGroup:new();
			connEle:ForEach(function (ele)
				local isConn = FXPUB.GetConnectedObj( ele, "FlowController", "Name", "service valve", 3);
				if( isConn == nil ) then
					print("sample");
					isCompliant = false;
				else
					compliantGrp:Add(isConn);
				end
			end)
				
			compliantGrp = compliantGrp:Unique();
			if( #compliantGrp <= 1 ) then
				isCompliant = false;
			end
				
			local isConnStop = nil
			if( ConnectingTank ~= nil ) then
				isConnStop= FXPUB.GetConnectedObj( ConnectingTank, "FlowController", "Name", "stop valve", 5);
			end
			
			if( isCompliant == false and #compliantGrp == 0 and isConnStop == nil ) then
				FXUtility.DisplaySolid_Error(tank, "Service Valves are not provided");
				CheckReport.AddRelatedObj(tank, tank:GetAttri("Name"))
			end
			if( isCompliant == false and #compliantGrp == 1) then
				FXUtility.DisplaySolid_Error(tank, "Only "..#compliantGrp.." Service Valve is provided");
				CheckReport.AddRelatedObj(tank, tank:GetAttri("Name"))
				compliantGrp:ForEach(function (ele)
					CheckReport.AddRelatedObj(ele, ele:GetAttri("Name"))
				end)
			end
			if( isCompliant == true and #compliantGrp > 1 and isConnStop == nil and ConnectingTank ~= nil ) then
				FXUtility.DisplaySolid_Error(tank, "Stop Valve is not provided for the two connecting "..ConnectingTank:GetAttri("Name"));
				CheckReport.AddRelatedObj(tank, tank:GetAttri("Name"))
				compliantGrp:ForEach(function (ele)
					CheckReport.AddRelatedObj(ele, ele:GetAttri("Name"))
				end)
			end
				
			if( isCompliant == true ) then
				FXUtility.DisplaySolid_Info(tank, "Service Valves are provided");
				CheckReport.AddRelatedObj(tank, tank:GetAttri("Name"))
				compliantGrp:ForEach(function (ele)
					CheckReport.AddRelatedObj(ele, ele:GetAttri("Name"))
				end)
				if( isConnStop ~= nil ) then
					FXUtility.DisplaySolid_Info(tank, isConnStop:GetAttri("Name").." is provided for the two connecting ".. tank:GetAttri("Name"));
					CheckReport.AddRelatedObj(tank, tank:GetAttri("Name"))
					CheckReport.AddRelatedObj(ConnectingTank, ConnectingTank:GetAttri("Name"))
					CheckReport.AddRelatedObj(isConnStop, isConnStop:GetAttri("Name"))
				end
			end
				
		end)
	end
	
end