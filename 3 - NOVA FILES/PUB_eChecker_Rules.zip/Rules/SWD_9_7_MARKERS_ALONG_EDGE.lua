--[[
	Modefied by: Lawrence Roy Quiling 01/23/2019
]]

local grpDrainages = FXGroup:new()
local grpWallsRatings = FXGroup:new()
local grpConcreteMarkers = FXGroup:new()
local MaxDist
local ARRArrow = {}
local ARRNearDist = {}
local ARROBJ = {}
local ARRObj1 = {}
local grpDrainagesValue
local grpDrainagesProperty
local ConcreteMarkersValue
local ConcreteMarkersPROP

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_7_MARKERS_ALONG_EDGE")
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	operator = ConditionValues2[2]
	MaxDist = tonumber(ConditionValues2[3]);
	
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpDrainages = grpDrainages + v;
			grpDrainages = grpDrainages:Unique();
		end
		if (k == 3) then
			grpWallsRatings = grpWallsRatings + v;
			grpWallsRatings = grpWallsRatings:Unique();
		end
		if (k == 4) then
			grpConcreteMarkers = grpConcreteMarkers + v;
			grpConcreteMarkers = grpConcreteMarkers:Unique();
		end
	end

	local Values1 = {}
	local Values2 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
				grpDrainagesProperty = (v1["property"])
			end
			if(k == 3) then
				table.insert(Values2, v1["value"])
				ConcreteMarkersPROP = (v1["property"])
			end
		end
	end

	grpDrainagesValue = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			grpDrainagesValue = grpDrainagesValue.." or "..v
		end
	end

	ConcreteMarkersValue = Values2[1]
	for k,v in pairs(Values2) do
		if k ~= 1 then
			ConcreteMarkersValue = ConcreteMarkersValue.." or "..v
		end
	end
end

function CheckWarning( Building )
	local flag = true
	if(#grpDrainages == 0) then
		CheckReport.Warning( Building, grpDrainagesValue.." is not provided" )
		flag = false
	end

	if flag then
		grpDrainages:ForEach(function ( Drainage )
			local PlyLine  = PolyLine3D(TRUE);
			local BOX = FXGeom.GetBoundingBox(Drainage)
			local lowPnt = BOX:LowPos().z + 1;
			PlyLine:AddPoint(Point3D(BOX:HighPos().x-1,BOX:HighPos().y-1,lowPnt))
			PlyLine:AddPoint(Point3D(BOX:LowPos().x+1,BOX:HighPos().y-1,lowPnt))
			PlyLine:AddPoint(Point3D(BOX:LowPos().x+1,BOX:LowPos().y+1,lowPnt))
			PlyLine:AddPoint(Point3D(BOX:HighPos().x-1,BOX:LowPos().y+1,lowPnt))
			PlyLine:ClosePolyline();
 			local faceA = PlyLine:Face3D();
 			local extrude = faceA:ExtrudedFace(Vector(0, 0, BOX:HighPos().z));
 			local NODE = FXUtility.CreateNodeFrom(extrude);
 			
			grpWallsRatings:ForEach(function ( Obj )
				if(FXClashDetection.IsCollided(NODE, Obj))then
					flag = false
					CheckReport.Warning( Obj, Obj.Type.." found along edge of "..Drainage:GetAttri(grpDrainagesProperty) )
					CheckReport.AddRelatedObj(Obj, Obj.Type)
				end
			end)
			FXClashDetection.DeleteNode(NODE);
		end)
	end
	return flag;
end

function checkRule(Building)

	if CheckWarning( Building ) then
		
		local isErrorNotFound = true
		local ARR_SingleMarker = {}

		grpDrainages:ForEach(function ( Drainage )
			local proj = FXMeasure.GetObjProjection(Drainage,FXGeom.GetBoundingBox(Drainage):LowPos().z);
			local outer = FXMeasure.GetOuterEdge(proj);
			local Line1, Line2 = GetTwoLongestLine(outer);
			local grpCollMarkersLine1, Obj1 = getCollMarkers( Line1 )
			grpConcreteMarkers = grpConcreteMarkers - grpCollMarkersLine1
			local grpCollMarkersLine2, Obj2 = getCollMarkers( Line2 )

			if #grpCollMarkersLine1 == 0 and #grpCollMarkersLine2 == 0 then
				FXUtility.DisplaySolid_Error(Drainage, ConcreteMarkersValue.." is not provided");
				isErrorNotFound = false
			else
				if #grpCollMarkersLine1 == 1 then
					table.insert(ARR_SingleMarker, Obj1)
				elseif CheckError( grpCollMarkersLine1, Obj1 ) == false then
				 	isErrorNotFound = false
				end

				if #grpCollMarkersLine2 == 1 then
				 	table.insert(ARR_SingleMarker, Obj2)
				elseif CheckError( grpCollMarkersLine2, Obj2 ) == false then
				 	isErrorNotFound = false
				end
			end
		end)
		if isErrorNotFound then
			for i=1,(#ARRObj1) do
				FXUtility.DisplaySolid_Info(ARRObj1[i], ARRObj1[i]:GetAttri(ConcreteMarkersPROP)..": Distance from last "..ARROBJ[i]:GetAttri(ConcreteMarkersPROP).." is "..(ARRNearDist[i]/1000).." meters",ARRArrow[i]);
				CheckReport.AddRelatedObj(ARROBJ[i], ARROBJ[i]:GetAttri(ConcreteMarkersPROP))
				CheckReport.AddRelatedObj(ARRObj1[i], ARRObj1[i]:GetAttri(ConcreteMarkersPROP))
			end

			for k,SingleMarker in pairs(ARR_SingleMarker) do
				FXUtility.DisplaySolid_Info(SingleMarker, SingleMarker:GetAttri(ConcreteMarkersPROP).." is provided ")
			end
		end
	end
end

function CheckError( grpCollMarkersLine, Obj )
	local isErrorNotFound = true

	while #grpCollMarkersLine ~= 0 do
		local arrow
		local OBJ = Obj
		arrow, grpCollMarkersLine, Obj, near = getDArrow( grpCollMarkersLine, Obj )
		
		if arrow ~= nil then
			if FXRule.EvaluateNumber( "<=" , near, MaxDist) then
				table.insert(ARRObj1, Obj)
				table.insert(ARROBJ, OBJ)
				table.insert(ARRArrow, arrow)
				table.insert(ARRNearDist, near)
			else
				FXUtility.DisplaySolid_Error(Obj, Obj:GetAttri(ConcreteMarkersPROP)..": Distance from last "..OBJ:GetAttri(ConcreteMarkersPROP).." is more than 50 meters", arrow);
				CheckReport.AddRelatedObj(OBJ, OBJ:GetAttri(ConcreteMarkersPROP))
				CheckReport.AddRelatedObj(Obj, Obj:GetAttri(ConcreteMarkersPROP))
				isErrorNotFound = false
			end
		end
	end

	return isErrorNotFound;
end

function getCollMarkers( LINE )
	local Obj
	local grpObjs = FXGroup:new()

	if LINE ~= nil then
		local extended = FXMeasure.CreateFaceFromEdge(LINE, 250);
		local extendedNode = FXUtility.CreateNodeFrom(extended);
		local pnt = LINE:GetStartPoint();
		local nearDist = 0

		grpConcreteMarkers:ForEach(function ( Marker )
			if(FXClashDetection.IsCollided(extendedNode, Marker))then
				grpObjs:Add(Marker)
				local PntMarker = FXGeom.GetBoundingBox(Marker):MidPos();
				local dist = pnt:Distance_Pnt(PntMarker);

				if nearDist == 0 or nearDist > dist then
					nearDist = dist
					Obj = Marker
				end
			end
		end)
		FXClashDetection.DeleteNode(extendedNode);
	end

	return grpObjs, Obj;
end

function getDArrow( grpSub, ele )
	local arrow
	local Object
	local nearest = 0
	grpSub:Sub(ele)
	local cntPnt = FXGeom.GetBoundingBox(ele):MidPos();

	grpSub:ForEach(function ( Subele )
		local midPnt = FXGeom.GetBoundingBox(Subele):MidPos();
		local MAXz = FXGeom.GetBoundingBox(Subele):HighPos().z;
		local Line = Line3D(Point3D(cntPnt.x,cntPnt.y,MAXz),Point3D(midPnt.x,midPnt.y,MAXz))
		local Dist = FXUtility.Round(tonumber(Line:Length()))

		if nearest == 0 or nearest > Dist then
			nearest = Dist
			arrow = DoubleArrow(Line:GetStartPoint(), Line:GetEndPoint())
			Object = Subele
		end
	end)

	return arrow, grpSub, Object, nearest;
end

function GetTwoLongestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist, dist2;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		elseif dist:Length() == Line:Length() then
			dist2 = Line;
		end
	end

	return dist, dist2;
end