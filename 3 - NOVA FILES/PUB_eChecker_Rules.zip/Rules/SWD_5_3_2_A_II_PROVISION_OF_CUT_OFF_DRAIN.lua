local cutOffDrainGrp = FXGroup.new()
local coveringGrp = FXGroup.new()
local retainingWallGrp = FXGroup.new()
local higherGroundGrp = FXGroup.new()
local propertyGrp  = FXGroup.new()
local compliantWall = {}
local compliantCutOffDrain = {}
local compliantCovering = {}
local compliantHigherProperty = {}
local compliantLowerProperty = {}
local compliantHigherGround = {}
local isAllCompliant = true;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_5_3_2_A_II_PROVISION_OF_CUT_OFF_DRAIN")
	
	
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjsBuilding) do
		if (k == 2) then
			retainingWallGrp = retainingWallGrp + v;
			retainingWallGrp = retainingWallGrp:Unique();
		end
		if (k == 3) then
			cutOffDrainGrp = cutOffDrainGrp + v;
			cutOffDrainGrp = cutOffDrainGrp:Unique();
		end
		if (k == 4) then
			coveringGrp = coveringGrp + v;
			coveringGrp = coveringGrp:Unique();
		end
		if (k == 5) then
			higherGroundGrp = higherGroundGrp + v;
			higherGroundGrp = higherGroundGrp:Unique();
		end
		if (k == 6) then
			propertyGrp = propertyGrp + v;
			propertyGrp = propertyGrp:Unique();
		end
	end
end


function checkRule(Building)
	if #retainingWallGrp ~= 0 then
		if #propertyGrp ~= 0 then

			retainingWallGrp:ForEach(function ( retainingWall )
				local propertyGrpToCheck = FXGroup.new()
				local propertyAToCheck;
				local propertyBToCheck;
				local topDrain;
				local isSameLevel = false;
				local topDrainCovering;
				local collidedHigherGround;
				local higherProperty;
				local lowerProperty;
				local isCompliant = false;
				local hasWarning = false;
				local collidedDrain = FXGroup.new()

				propertyGrp:ForEach(function ( property )
					if FXClashDetection.IsCollided(retainingWall, property) or FXMeasure.Distance(retainingWall, property):Length() < 100 then
						propertyGrpToCheck:Add(property)
					end
				end)


				if #propertyGrpToCheck > 1 then

					propertyGrpToCheck:ForEach(function ( collidedProperty )
						if propertyAToCheck == nil then
							propertyAToCheck = collidedProperty;
						else
							propertyBToCheck = collidedProperty;
						end
					end)

					local propertyAElevation = FXGeom.GetBoundingBox(propertyAToCheck):LowPos().z
					local propertyBElevation = FXGeom.GetBoundingBox(propertyBToCheck):LowPos().z

					if propertyAElevation > propertyBElevation then
						higherProperty = propertyAToCheck;
						lowerProperty = propertyBToCheck
					else
						higherProperty = propertyBToCheck;
						lowerProperty = propertyAToCheck
					end

					if #higherGroundGrp ~= 0 then
						higherGroundGrp:ForEach(function ( higherGround )
							if FXClashDetection.IsCollided(higherGround, higherProperty) or FXMeasure.Distance(higherGround, higherProperty):Length() < 50 then
								collidedHigherGround = higherGround;
							end
						end)

						if collidedHigherGround ~= nil then
							local higherGroundMaxZ = FXGeom.GetBoundingBox(collidedHigherGround):HighPos().z
							local retainingWallMaxZ = FXGeom.GetBoundingBox(retainingWall):HighPos().z

							if higherGroundMaxZ == retainingWallMaxZ then
								isSameLevel = true;
							end
						end
					

						if isSameLevel then

							if #cutOffDrainGrp ~= 0 then
								local wallTopFace = FXMeasure.GetTopFace(retainingWall)
								local wallTopFaceNode = FXUtility.CreateNodeFrom(wallTopFace);

								cutOffDrainGrp:ForEach(function ( cutOffDrain )
									if FXClashDetection.IsCollided(retainingWall, cutOffDrain) or FXMeasure.Distance(wallTopFaceNode, cutOffDrain):Length() < 50 then
										collidedDrain:Add(cutOffDrain)
									end
								end)

								collidedDrain:ForEach(function ( collidedCutOffDrain )
									local hasCovering = false;
									if FXMeasure.Distance(wallTopFaceNode, collidedCutOffDrain):Length() < 50 then
										topDrain = collidedCutOffDrain;
										if #coveringGrp ~= 0 then
											coveringGrp:ForEach(function ( covering )
												if FXClashDetection.IsCollided(collidedCutOffDrain, covering) then
													topDrainCovering = covering
													hasCovering = true;
													isCompliant = true;
												end
											end)
										end

										if hasCovering == false then
											hasWarning = true;
											CheckReport.Warning(Building,"Cut-off drain has no covering.")
											CheckReport.AddRelatedObj( topDrain, topDrain:GetAttri("LongName") )
										end
									end
								end)
								
								FXClashDetection.DeleteNode(wallTopFaceNode)
							end
						else
							CheckReport.Warning(Building, collidedHigherGround:GetAttri("ObjectType").." is not same level with "..retainingWall:GetAttri("ObjectType") )
							hasWarning = true;
						end
					end
				else
					CheckReport.Warning(Building,"Only one property is collided to retaining wall")
					hasWarning = true;
				end
				if hasWarning == false then
					checkResult( Building, isCompliant, retainingWall, topDrain, topDrainCovering, lowerProperty, higherProperty, collidedHigherGround )
				end
			end)

		end
	end
	checkWarningMsgs(Building)
	finalResult()
end

function checkResult( Building, isCompliant, retainingWall, topDrain, topDrainCovering, lowerProperty, higherProperty, collidedHigherGround )
	if isCompliant then
		table.insert(compliantWall, retainingWall);
		table.insert(compliantCutOffDrain, topDrain);
		table.insert(compliantCovering, topDrainCovering);
		table.insert(compliantHigherProperty, higherProperty);
		table.insert(compliantLowerProperty, lowerProperty);
		table.insert(compliantHigherGround, collidedHigherGround);
	else
		isAllCompliant = false;
		-- FXUtility.DisplaySolid_Error(higherProperty, higherProperty:GetAttri("LongName")..": Top of "..retainingWall:GetAttri("ObjectType").." is same level from "..collidedHigherGround:GetAttri("ObjectType"));
		-- FXUtility.DisplaySolid_Error(higherProperty, retainingWall:GetAttri("ObjectType").." is not provided with Cut-off drain and removable cover")
		FXUtility.DisplaySolid_Error(higherProperty, "No Cut-off drain is found along the retaining wall on the higher ground");
		CheckReport.AddRelatedObj( higherProperty, higherProperty:GetAttri("LongName") )
		-- CheckReport.AddRelatedObj( lowerProperty, lowerProperty:GetAttri("LongName") )
		CheckReport.AddRelatedObj( retainingWall, retainingWall:GetAttri("ObjectType") )
		CheckReport.AddRelatedObj( collidedHigherGround, collidedHigherGround:GetAttri("ObjectType") )
	end
end

function finalResult()

	if isAllCompliant then
		for i=1, #compliantWall do
			-- FXUtility.DisplaySolid_Info(compliantHigherProperty[i], compliantHigherProperty[i]:GetAttri("LongName")..": Top of "..compliantWall[i]:GetAttri("ObjectType").." is same level with "..compliantHigherGround[i]:GetAttri("ObjectType")..": Cut-off drain and removable cover is provided");
			FXUtility.DisplaySolid_Info(compliantHigherProperty[i], "Cut-off drain is found along the retaining wall on the higher ground");
			CheckReport.AddRelatedObj( compliantHigherProperty[i], compliantHigherProperty[i]:GetAttri("LongName") )
			-- CheckReport.AddRelatedObj( compliantLowerProperty[i], compliantLowerProperty[i]:GetAttri("LongName") )
			CheckReport.AddRelatedObj( compliantWall[i], compliantWall[i]:GetAttri("ObjectType") )
			CheckReport.AddRelatedObj( compliantCutOffDrain[i], compliantCutOffDrain[i]:GetAttri("ObjectType") )
			CheckReport.AddRelatedObj( compliantCovering[i], compliantCovering[i]:GetAttri("ObjectType") )
			CheckReport.AddRelatedObj( compliantHigherGround[i], compliantHigherGround[i]:GetAttri("ObjectType") )
		end
	end
	
end

function checkWarningMsgs(Building)
	if #retainingWallGrp == 0 then
		CheckReport.Warning(Building,"Retaining wall is not provided.")
	end
	if #higherGroundGrp == 0 then
		CheckReport.Warning(Building,"Higher ground is not provided.")
	end
	if #propertyGrp == 0 then
		CheckReport.Warning(Building,"Property is not provided.")
	end
end
