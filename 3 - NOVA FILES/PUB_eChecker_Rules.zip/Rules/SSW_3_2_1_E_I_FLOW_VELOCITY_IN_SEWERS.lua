local pipeSegmentGrp = FXGroup.new()
local properValue

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end
function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_1_E_I_FLOW_VELOCITY_IN_SEWERS")
    local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	if GrpObjs1 ~= nil then
	    for k,v in pairs(GrpObjs1) do
			if (k == 2) then
				pipeSegmentGrp = pipeSegmentGrp + v;
				pipeSegmentGrp = pipeSegmentGrp:Unique()
			end	
		end
		local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
		properValue = tonumber(ConditionValues[4]);
	end
end
function checkRule(Building)
	local flag = true
	local check = true

	if #pipeSegmentGrp == 0 or #pipeSegmentGrp == nil then
		FXUtility.DisplaySolid_Warning(Building,"Sewer Pipe is not provided. ")
		check = false
	end
	pipeSegmentGrp:ForEach(function ( pipe )
		if pipe:GetAuxAttri("Mechanical.Material") == nil then
			FXUtility.DisplaySolid_Warning(Building,"Sewer Pipe material is not specified. ")
			check = false
		end
	end)
	if check then
		local pipeValue = {}
		local velocityValue = {}
		local i = 0
		pipeSegmentGrp:ForEach(function ( pipe )
			local material = tostring(pipe:GetAuxAttri("Mechanical.Material")) 
			local coeff = FXPUB.GetMaterialCoeff(pipe, material)  				-- returns coefficient value
			local diameter = FXPUB.GetDiameter(pipe);		   				-- returns inner pipe diameter
			--local diameter = tonumber(pipe:GetAuxAttri("Mechanical.Diameter"))
			local slope, cLine = FXMeasure.GetPipeProperty(pipe)  				-- returns a property in table, (1) slope, (2) inner center line 
			local Velocity = FXMeasure.GetFlowVelocity(diameter, slope, coeff)	-- returns flow velocity
			local round = FXUtility.Round(Velocity, 2)

			if round ~= properValue then
				FXUtility.DisplaySolid_Error(pipe, pipe:GetAttri("Name").." : Velocity = " ..round.." m/s")
				flag = false
			else
				i = i + 1
				velocityValue[i] = round
				pipeValue[i] = pipe
			end
		end)
		if flag then
			for k,velocityValue in pairs(velocityValue) do
				FXUtility.DisplaySolid_Info(pipeValue[k], pipeValue[k]:GetAttri("Name").." : Velocity = " ..velocityValue.." m/s")
			end
		end
	end
end