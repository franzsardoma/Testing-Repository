--[
	-- Rafael Balanag
--]

local DrainCommonGrp = FXGroup:new();
local minimumVal;
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end
function XMLParser(Storey)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_4_5_1_COMMON_DRAIN_INTERNAL_WIDTH")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	minimumVal = tonumber(ConditionValues[2]);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			DrainCommonGrp = DrainCommonGrp + v
			DrainCommonGrp = DrainCommonGrp:Unique()
		end
	end
	
end

function CheckRule(Building)
	if #DrainCommonGrp == 0  then
		FXUtility.DisplaySolid_Warning(Building,"Common drain is not provided.")
	else
		if #DrainCommonGrp ~= 0 then
			DrainCommonGrp:ForEach(function(drain)
				local drainBox = FXGeom.GetBoundingBox(drain);
				local midPoint = drainBox:MidPos();
				local centerline = FXPUB.GetProjectionCenterLineTemp(drain);
				local centerlineStart = centerline:GetStartPoint();
				local centerlineEnd = centerline:GetEndPoint();

				local lineFromFace;
				for i=0, 5, 1 do 
					if FXMeasure.GetCircularFacesInDirection(drain,i) ~= nil then
						local circleFace = FXMeasure.GetCircularFacesInDirection(drain,i)
						local outer = FXMeasure.GetOuterEdge( circleFace );

						local line1 = GetLongestLinePipe(outer);
						local centerPoint = FXUtility.CenterPoint(line1:GetStartPoint(),line1:GetEndPoint());

						lineFromFace = line1;
					end
				end
				if lineFromFace ~= nil then

					if drainBox:y_range() > drainBox:x_range() then
						local longestLine,internalDiameter,display = GetCircularWidth(lineFromFace,drain);
						local Result = DisplayArrowPipe(drainBox,drain,longestLine,internalDiameter);
					end
					
				else
					local longestLine,internalWidth,display = GetInternalElementWidth(centerlineStart,drain);
					local Result = DisplayArrow(drainBox,drain,longestLine,internalWidth);
				end
				
			end)
		end
	end
end
function GetInternalElementWidth(Point,Element)
	local i = 1;
	local width = 0;
	local Pnt1;
	local Pnt2;
	local eleBox = FXGeom.GetBoundingBox(Element);

	if eleBox:x_range() > eleBox:y_range() then
		Pnt1 = Point3D(Point.x+1, Point.y,Point.z-150)
		Pnt2 = Point3D(Point.x-1, Point.y,Point.z-150)
	else
		Pnt1 = Point3D(Point.x, Point.y+1,Point.z-150)
		Pnt2 = Point3D(Point.x, Point.y-1,Point.z-150)
	end
	
	local line = Line3D(Pnt1, Pnt2);
	while i > 0 do -- to get the width of the trench 			
		width = width + 1 ;
		local extended = FXMeasure.CreateFaceFromEdge(line, width); -- makes the line fatter everyloop incrementing 1mm
		local extendedNode = FXUtility.CreateNodeFrom(extended); -- node for the face, to make it work with IsCollided 
			if FXClashDetection.IsCollided ( extendedNode , Element ) then
				i = i - 1 	
				FXClashDetection.DeleteNode ( extendedNode );				
			end
		FXClashDetection.DeleteNode ( extendedNode );  -- always delete a node after using
	end

	local ElementWidth = width * 2
	local showWidth = FXMeasure.CreateFaceFromEdge(line, width);
	local outer = FXMeasure.GetOuterEdge( showWidth );
	local Line = GetLongestLine(outer)

	return Line, ElementWidth,showWidth;
end

function GetLongestLinePipe( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(1) --Remain 1 point because it is circular
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetLongestLine( outerEdge )

	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetCircularWidth(Line,Element)
	local eleBox = FXGeom.GetBoundingBox(Element);
	local centerPoint = FXUtility.CenterPoint(Line:GetStartPoint(),Line:GetEndPoint());

	local i = 1;
	local width = 0;
	local Pnt1;
	local Pnt2;
	if eleBox:x_range() > eleBox:y_range() then
		Pnt1 = Point3D(centerPoint.x+10, centerPoint.y,centerPoint.z) -- Minus 1 to z for the line to Collide in sump
		Pnt2 = Point3D(centerPoint.x-10, centerPoint.y,centerPoint.z)
	else
		Pnt1 = Point3D(centerPoint.x, centerPoint.y+10,centerPoint.z)
		Pnt2 = Point3D(centerPoint.x, centerPoint.y-10,centerPoint.z)
	end
	

	local line = Line3D(Pnt1, Pnt2);

	while i > 0 do -- to get the width of the trench 			
		width = width + 1 ;
		local extended = FXMeasure.CreateFaceFromEdge(line, width); -- makes the line fatter everyloop incrementing 1mm
		local extendedNode = FXUtility.CreateNodeFrom(extended); -- node for the face, to make it work with IsCollided 
			if FXClashDetection.IsCollided ( extendedNode , Element ) then
				i = i - 1 	
				FXClashDetection.DeleteNode ( extendedNode );				
			end
		FXClashDetection.DeleteNode ( extendedNode );  -- always delete a node after using
	end

	local Objwidth = width * 2
	local showWidth = FXMeasure.CreateFaceFromEdge(line, width);
	local outer = FXMeasure.GetOuterEdge( showWidth );
	local Line = GetLongestLine(outer)

	return Line, Objwidth,showWidth;
end

function DisplayArrowPipe(drainBox,drain,line,width)
	local point1
	local point2
	local point3
	local point4
	if drainBox:x_range() > drainBox:y_range() then
		if line:GetStartPoint().x < 0 then
			point1 = Point3D(line:GetStartPoint().x-11,line:GetStartPoint().y,line:GetStartPoint().z+350) --offset 150
			point2 = Point3D(line:GetEndPoint().x-11,line:GetEndPoint().y,line:GetEndPoint().z+350)
			point3 = Point3D(line:GetStartPoint().x-11,line:GetStartPoint().y,line:GetStartPoint().z) --offset 150
			point4 = Point3D(line:GetEndPoint().x-11,line:GetEndPoint().y,line:GetEndPoint().z)
		else
			point1 = Point3D(line:GetStartPoint().x+11,line:GetStartPoint().y,line:GetStartPoint().z+350) --offset 150
			point2 = Point3D(line:GetEndPoint().x+11,line:GetEndPoint().y,line:GetEndPoint().z+350)
			point3 = Point3D(line:GetStartPoint().x+11,line:GetStartPoint().y,line:GetStartPoint().z) --offset 150
			point4 = Point3D(line:GetEndPoint().x+11,line:GetEndPoint().y,line:GetEndPoint().z)
		end
	else
		if line:GetStartPoint().y < 0 then
			point1 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y-11,line:GetStartPoint().z+350) --offset 150
			point2 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y-11,line:GetEndPoint().z+350)
			point3 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y-11,line:GetStartPoint().z) --offset 150
			point4 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y-11,line:GetEndPoint().z)
		else
			point1 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y+11,line:GetStartPoint().z+350) --offset 150
			point2 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y+11,line:GetEndPoint().z+350)
			point3 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y+11,line:GetStartPoint().z) --offset 150
			point4 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y+11,line:GetEndPoint().z)
		end
	end
	

	local doubleArrow = DoubleArrow(point1,point2);
	local plyline = PolyLine3D(TRUE);
	plyline:AddPoint(point3);
	plyline:AddPoint(point1);
	plyline:AddPoint(point2);
	plyline:AddPoint(point4);

	if width >= minimumVal then
		FXUtility.DisplaySolid_Info(drain,width.." mm")
		CheckReport.AddRelatedGeometry_Solid(doubleArrow);
		CheckReport.AddRelatedGeometry_Solid(plyline);
	else
		FXUtility.DisplaySolid_Error(drain,width.." mm")
		CheckReport.AddRelatedGeometry_Error(doubleArrow);
		CheckReport.AddRelatedGeometry_Error(plyline);
	end
end
function DisplayArrow(drainBox,drain,line,width)
	local point1 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y,line:GetStartPoint().z+350) --offset 150
	local point2 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y,line:GetEndPoint().z+350)
	local point3 = Point3D(line:GetStartPoint().x,line:GetStartPoint().y,line:GetStartPoint().z) --offset 150
	local point4 = Point3D(line:GetEndPoint().x,line:GetEndPoint().y,line:GetEndPoint().z)
	
	local doubleArrow = DoubleArrow(point1,point2);
	local plyline = PolyLine3D(TRUE);
	plyline:AddPoint(point3);
	plyline:AddPoint(point1);
	plyline:AddPoint(point2);
	plyline:AddPoint(point4);

	if width >= minimumVal then
		FXUtility.DisplaySolid_Info(drain,width.." mm")
		CheckReport.AddRelatedGeometry_Solid(doubleArrow);
		CheckReport.AddRelatedGeometry_Solid(plyline);
	else
		FXUtility.DisplaySolid_Error(drain,width.." mm")
		CheckReport.AddRelatedGeometry_Error(doubleArrow);
		CheckReport.AddRelatedGeometry_Error(plyline);
	end
end