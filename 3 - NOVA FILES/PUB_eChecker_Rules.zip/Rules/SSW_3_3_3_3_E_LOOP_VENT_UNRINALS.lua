local Vent = FXGroup.new()
local airValve = FXGroup.new()
local Urinal = FXGroup.new()
local condi1

function main()
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser( Building )

	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_3_3_E_LOOP_VENT_URINALS.html")
    local systemTypes = FXRule.ParseValues(parsedXml, "SystemType") 
   	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

	if GrpObjs2 ~= nil then
		for k,v in pairs(GrpObjs2) do
			if ( k == 2 ) then
				Vent = Vent + v
				Vent = Vent:Unique()
			end
		end
	end
	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do		
			if ( k == 4 ) then
				airValve = airValve + v
				airValve = airValve:Unique()
			end						
		end
	end
	for k,v in pairs(GrpObjs) do		
		if ( k == 4 ) then
			Urinal = Urinal + v
			Urinal = Urinal:Unique()
		end						
	end	
end

function checkRule(Building)

	if CheckWarning(Building) then

		local grpStorey = Building:GetChildren("BuildingStorey");
		local grpVent = FXGroup:new();
		local GrpTrap = FXGroup:new();
		
		local SystemParent = Building:GetParent():GetParent():GetChildren("System");
		SystemParent:ForEach(function (sys)
			if FXUtility.IsBelongToTableElement2(sys, {"vent"}) then
				local GrpVentPipe = sys:GetChildren("FlowSegment");
				grpVent = grpVent + GrpVentPipe;	
			elseif FXUtility.IsBelongToTableElement2(sys, {"sanitary"}) then
				local tempGrpTrap = sys:GetChildren("FlowFitting");
				tempGrpTrap = tempGrpTrap:Filter(
				function(ele)
					if FXUtility.IsBelongToTableElement2(ele, {"trap"}) then
						return true;
					end
				end)
				GrpTrap = tempGrpTrap + GrpTrap;
			end
		end)
		
		grpVent = grpVent:Unique();
		GrpTrap = GrpTrap:Unique();
		
		grpStorey:ForEach(function (storeyEle)
		
			local grpSpace = storeyEle:GetChildren("Space");
			local grpFlowController = storeyEle:GetChildren("FlowController");
			grpSpace:ForEach(function (space)
				
				local grpFlowTerminal = FXGroup:new();
				local trapTemp = FXGroup:new();
				local grpFlowTerminalTemp = FXGroup:new();
				local spaceEle = space:GetInSpaceElement();
				spaceEle:ForEach(function (ele)
					
					if( FXUtility.IsBelongToTableElement2(ele, {"air admittence valve"}) ) then
						grpFlowController:Add(ele);
					end
					if( ele.Type == "FlowTerminal" ) then
						grpFlowTerminal:Add(ele);
					end
					if FXUtility.IsBelongToTableElement2(ele, {"trap"}) then
						trapTemp:Add(ele);
					end
					
					trapTemp = GrpTrap - trapTemp;
				
				end)
				
				local tempTbl = {};
				local cnt = 0;
				trapTemp:ForEach(function (ele1)
					grpFlowTerminal:ForEach(function (ele2)
						local isConnected = FXPUB.GetConnectedObjGrp(ele1, ele2.Type, "Name", ele2:GetAttri("Name"), 200);
						if( isConnected ) then
							local dist = FXMeasure.Distance(ele1,ele2);
							tempTbl[FXUtility.Round(dist:Length(), 0)] = ele2;
							cnt = cnt + 1;
						end
					end)
				end)

				for i = cnt,1,-1 do 
					local tempLowest = 0;
					for k, v in pairs(tempTbl) do
						if( v ~= nil and (tempLowest == 0 or k > tempLowest) ) then
							if( v ~= nil ) then
								tempLowest = k;
							end
						end
					end
					if( tempTbl[tempLowest] ~= nil ) then
						grpFlowTerminalTemp:Add(tempTbl[tempLowest]);
						tempTbl[tempLowest] = nil;
					end
				end
				
				if( #grpFlowTerminalTemp >= 5 ) then
					
					local count = 0;
					local isError = false;
					local grpCompliant = FXGroup:new();
					grpFlowTerminalTemp:ForEach(function (ele2)
						count = count + 1;
						if (count%3) == 0 or count == 1 then
						
							local connectedTerminalValve;
							local connectedTerminalVent;
							if( count == 1 and #grpFlowController ~= 0 ) then
								grpFlowController:ForEach(function (ele3)
									connectedTerminalValve = FXPUB.GetConnectedObj(ele2, ele3.Type, "Name", ele3:GetAttri("Name"), 15);
								end)
							end
						
							grpVent:ForEach(function (ele3)
								connectedTerminalVent = FXPUB.GetConnectedObj(ele2, ele3.Type, "Name", ele3:GetAttri("Name"), 10);
							end)

							if( (count == 1 and ((connectedTerminalValve ~= nil) or (connectedTerminalVent ~= nil))) or (count ~= 1 and (connectedTerminalVent ~= nil)) ) then
								grpCompliant:Add(ele2)
							else
								isError = true;
								FXUtility.DisplaySolid_Error(ele2, "No Loop vent or not properly installed.");
								CheckReport.AddRelatedObj(ele2, ele2:GetAttri("Name"))
							end
							
						end
					end)
					
					if not( isError ) then
						if( #grpCompliant == 0 ) then
							FXUtility.DisplaySolid_Info(space, "Loop vent is provided and properly installed.");
							CheckReport.AddRelatedObj(space, space:GetAttri("Name"))
						else
							grpCompliant:ForEach(function (ele2)
								FXUtility.DisplaySolid_Info(ele2, "Loop vent is provided and properly installed.");
								CheckReport.AddRelatedObj(ele2, ele2:GetAttri("Name"))
							end)
						end
					end
				
				end
				
			end)
			
		end)
	end
end

function CheckWarning( Building )
	
	local Warning = true

	if ( #Vent == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"Vent is not provided")	
		Warning = false
	end
	if ( #airValve == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"Air-admittance Valve is not provided")
		Warning = false
	end	
	if ( #Urinal == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"Urinal is not provided")
		Warning = false
	end	

	return Warning
end