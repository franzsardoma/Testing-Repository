--[[-----------------------------------------------------

Author: Monalyn L. Rueda

Rule ID: SSW 3.3.3.3 f
Rule Name: Flush Pipe Material for Urinal Flush Valve

All copyrights to novasolutions 
--]]-----------------------------------------------------
local FlowSegmentGrp = FXGroup:new()

local ComplianObjs = FXGroup:new()

function main()

	CheckEngine.SetCheckType("Site")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("CheckRules")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Site)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_3_3_F_FLUSH_PIPE_MATERIAL")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Site, systemTypes)

	for k,v in pairs(xmlObjs) do
		if (k == 2) then
			FlowSegmentGrp = FlowSegmentGrp + v;
			FlowSegmentGrp = FlowSegmentGrp:Unique();
		end	
	end
end

function CheckRules(Building)
local Urinals = Building:GetDescendants('FlowTerminal')
local FlowControllers = Building:GetDescendants('FlowController')
	
	if #FlowSegmentGrp == 0 then
		CheckReport.Warning(Building,"Flush Pipes not provided.")
		return;
	end

	-- if #Urinals == 0 then
	-- 	CheckReport.Warning(Building,"Urinals is not provided.")
	-- 	return;
	-- end

	-- if #FlowControllers == 0 then
	-- 	CheckReport.Warning(Building,"Flow Controllers is not provided.")
	-- 	return;
	-- end

	FlowSegmentGrp:ForEach(function(pipes)
		
		local PipeType = pipes:GetAuxAttri('Mechanical.Material')

		if FXUtility.HasPatterInString(PipeType, "Stainless") or FXUtility.HasPatterInString(PipeType, "Copper") then
			ComplianObjs:Add(pipes)
		end
	end)

	if #ComplianObjs ~= #FlowSegmentGrp then

		print(#FlowSegmentGrp)

		FlowSegmentGrp = FlowSegmentGrp - ComplianObjs

		FlowSegmentGrp:ForEach(function(pipes)
			local PipeName = pipes:GetAttri('Name')
			local PipeType = pipes:GetAuxAttri('Mechanical.Material')

			local ResultMessages, terminal = DisplayResult(Building, pipes, Urinals, FlowControllers)

			if ResultMessages == true then
				print('Non Compliant')
				FXUtility.DisplaySolid_Error(pipes, terminal:GetAttri('Name') .. " : " .. " Flush pipe: " ..  PipeName .. " material: " .. PipeType);
			end
		end)
		return
	else

		ComplianObjs:ForEach(function(pipes)
			local PipeName = pipes:GetAttri('Name')
			local PipeType = pipes:GetAuxAttri('Mechanical.Material')

			local ResultMessages, terminal = DisplayResult(Building, pipes, Urinals, FlowControllers)

			if ResultMessages == true then
				print('Compliant')
				FXUtility.DisplaySolid_Info(pipes, terminal:GetAttri('Name') .. " : " .. " Flush pipe: " .. PipeName .. " material: " .. PipeType);
			end
		end)
	end

end

function DisplayResult(building, pipes, Urinals, FlowControllers)
	local IsConnected = false
	local Connterminal 
	Urinals:ForEach(function(terminal)
		if FXPUB.IsObjsConnected(pipes, terminal) then
			Connterminal = terminal
			FlowControllers:ForEach(function(controller)

				if FXPUB.IsObjsConnected(pipes, controller) then
					IsConnected = true;
				end
			end)
		end
	end)

	return IsConnected, Connterminal
end
