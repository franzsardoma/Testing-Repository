local FireSystemRoomGroup = FXGroup.new();
local CHECK2 = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "WTR_2_8_4_DOUBLE_CHECK_VALVE_WITH_DRAIN_OUT_TEST_COCKS");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- -- IsConnected = ConditionValues[1];
	-- -- minDiameter = tonumber(ConditionValues[2])

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)		
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			FireSystemRoomGroup =   FireSystemRoomGroup + v;
		end	
		if (k == 3) then	
			CHECK2 = CHECK2 + v;
		end		
	end	
end

function CheckRule(Building)
	print(#FireSystemRoomGroup)
	print(#CHECK2)

	
	-- print(#FireSystemRoomGroup)
	local ValveWithTestCock;
	local ValveWithoutTestCock;
	local FireSystemRoom;
	local InSpaceElements;
	----------------------------
	local FittingsInSpace = FXGroup.new();
	local PipesAboveTestCock = FXGroup.new();
	----------------------------
	local PipeIsConnectedAfterBranch = false;

	local ColdWaterFitting= FXGroup.new();
	----------------------------
	if(#FireSystemRoomGroup ~= 0)then
		FireSystemRoomGroup:ForEach(function(Room)
			FireSystemRoom = Room;
		end)

		InSpaceElements = FireSystemRoom:GetInSpaceElement();
		if(#InSpaceElements ~= 0)then 
			InSpaceElements:ForEach(function(Element)
				if(Element.Type == "FlowController")then 
					local Name = Element:GetAttri("Name");
					-- print(Name.."<<<"..Element.Type)
					local CheckString = string.find(Name,"Double Check Valve");
					if(CheckString ~= nil)then 
						if(FXUtility.HasPatterInString(Element:GetAuxAttri("Entity.ObjectType"),"Test Cock") and CheckString > 0)then 
							ValveWithTestCock = Element;
						else
							if(CheckString > 0)then 
								ValveWithoutTestCock = Element;
							end
						end						
					end
				end

				if(Element.Type == "FlowFitting")then 
					local Classification = Element:GetAuxAttri("Mechanical.System Classification");
					if(FXUtility.HasPatterInString(Classification,"Cold Water"))then 
						ColdWaterFitting:Add(Element);
					end
				end
			end)
		end
		
		local FlagConnected = false;
		local FittingTee;

		if(#ColdWaterFitting ~= 0)then 
			if(ValveWithTestCock ~= nil)then 
				ColdWaterFitting:ForEach(function(Fitting)
					if(FXUtility.HasPatterInString(Fitting:GetAttri("Name"),"Tee"))then 				
						local PipeGroup = Fitting:GetConnectedSegment();				
						if(PipeGroup ~= nil)then 
							PipeGroup:ForEach(function(Pipe)						
								local Classification = Pipe:GetAuxAttri("Mechanical.System Classification");
								if(FXUtility.HasPatterInString(Classification,"Cold Water") == false)then 
									-------------------------------------------------------------------------
									local ConnectedElement = Pipe:GetConnectedElement();
									ConnectedElement:ForEach(function(Element) 
										if(Element.Id == ValveWithTestCock.Id)then 
											FlagConnected = true;
										end
									end)

									local ConnectedElement = FilterFitting(ConnectedElement,Fitting);
									-- print(#ConnectedElement)
									-- print(FlagConnected)
									if(FlagConnected == false)then 
										ConnectedElement:ForEach(function(Element)
											local ConnectedFitting = Element:GetConnectedFitting();
											local ConnectedElement2 = FilterFitting(ConnectedFitting,Fitting);
											------------------------------------------------------------------
											ConnectedElement2:ForEach(function(Element2)
												local ConnectedElemetn3 = Element2:GetConnectedElement();
												ConnectedElemetn3:ForEach(function(Element3)
													if(Element.Id == ValveWithTestCock.Id)then 
														FlagConnected = true;
													end
												end)
											end)
										end)
									end
								end
							end)
						end				
					end			
				end)

				if(FlagConnected)then 
					FXUtility.DisplaySolid_Info(FireSystemRoom,"Double check valve with drain-out test cocks is provided.");
					CheckReport.AddRelatedObj(ValveWithTestCock,ValveWithTestCock:GetAttri("Name"));
				else
					FXUtility.DisplaySolid_Error(ValveWithTestCock,ValveWithTestCock:GetAttri("Name").." is not connected after branch-off from the potable water pipe to serve the fire-fighting.")
				end
			else
				if(ValveWithoutTestCock ~= nil)then 
					FXUtility.DisplaySolid_Error(FireSystemRoom,"Double check valve is provided, yet it doesn\'t have drain-out test cocks.");
					CheckReport.AddRelatedObj(ValveWithoutTestCock,ValveWithoutTestCock:GetAttri("Name"));
				else
					FXUtility.DisplaySolid_Error(FireSystemRoom,"Double check valve with drain-out test cocks is not provided.");
					InSpaceElements:ForEach(function(Element) 
						if(Element.Type == "FlowSegment")then 
							local Classification = Element:GetAuxAttri("Mechanical.System Classification");
							if(FXUtility.HasPatterInString(Classification,"Cold Water") == false)then 
								CheckReport.AddRelatedObj(Element,Element:GetAttri("Name"));
							end
						end			
					end)	
				end			
			end
		else
			FXUtility.DisplaySolid_Warning(Building,"Fire Protection Wet is not provided.");	
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Fire-Fighting System Room is not provided.");
	end	
end


function FilterFitting(Group,Fitting)
	local Group = Group:Filter(function(Element)
		if(Element.Id == Fitting.Id)then 
			return true;
		end
	end)

	return Group;
end

