local grpPipeService = FXGroup:new();
local grpPipeDeSuc = FXGroup.new()

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_6_4_9_SERVICE_PIPE_CONNECTION")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");-- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	-- local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpPipeService = grpPipeService + v
 			grpPipeService = grpPipeService:Unique()			
		end		
		if k == 3 then
			grpPipeDeSuc = grpPipeDeSuc + v
 			grpPipeDeSuc = grpPipeDeSuc:Unique()			
		end
	end
end

function checkRule( Building )
	print(#grpPipeService.."ser")
	print(#grpPipeDeSuc.."de")
	local flag
	if #grpPipeService ~= 0 then
		grpPipeService:ForEach(function ( service )
			grpPipeDeSuc:ForEach(function ( desuc )
				if FXPUB.IsObjsConnected(service,desuc,2) == true then
					flag = false
					FXUtility.DisplaySolid_Error( service, "Have connected "..service:GetAttri("Name").." to "..desuc:GetAttri("Name"))
					CheckReport.AddRelatedObj(desuc, desuc:GetAttri("Name"));
				end
			end)
		end)
		if flag ~= false then
			grpPipeService:ForEach(function ( com )
				FXUtility.DisplaySolid_Info(com, "No connected service pipe to delivery pipe.")
				grpPipeService:ForEach(function ( com1 )
					CheckReport.AddRelatedObj(com1, com1:GetAttri("Name"));
				end)
				return false
			end)
		end
	else
		FXUtility.DisplaySolid_Warning(Building, "Service pipe is not provided.")
	end		
end