local grpFlowSegment = FXGroup.new()
local grpspace = FXGroup.new()

function main()
	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("GetSys")   
	.Run()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("checkRule")
	.Run()
end




function GetSys(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
  -- print("LUA " .. path())
  local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_G_SANITARY_PIPE_LOCATION_FOOD_PREPARATION")

  local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
  -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
  -- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
  -- for k,v in pairs(tbl) do
  --  if k == 5 then
  --    tblSpace = v
  --  end
  -- end
  local xmlObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
  if(xmlObjs1 ~= nil)then
  for k,v in pairs(xmlObjs1) do -- get the model objects
    if k == 2 then
      grpFlowSegment = grpFlowSegment + v
      grpFlowSegment = grpFlowSegment:Unique()      
    end    
  end
  local xmlObjs = FXRule.filterObjects(parsedXml, Building);
  for k,v in pairs(xmlObjs) do -- get the model objects
    if k == 3 then
      grpspace = grpspace + v
      grpspace = grpspace:Unique()      
    end    
  end
end
end

function checkRule(Building)
	local grpStorey = FXGroup.new()
	local grpSlab = FXGroup.new()
	grpSlab = GetSlabAll(Building)
	--local grpspace = FXGroup.new()
	local HighStorey 
	local extrudeFace
	local grpSlabBelow = FXGroup.new()
	local grpSegNotCol = FXGroup.new()
	local flag = false
	local flag1 = false
	if #grpFlowSegment == 0 then
		FXUtility.DisplaySolid_Warning(Building, "No PipeSegment found under Sanitary System.");
		return;
	end
	
	local HighEle = FXPUB.GetHighestElevation(Building);
	if #grpspace ~= 0 then
		grpspace:ForEach(function (Space)

			local grpSegmentCol = FXGroup.new()
			local grpSlabCol = FXGroup.new()
				
			prjSpace = FXMeasure.GetObjProjection(Space, Space:GetParent("BuildingStorey"):Elevation())
			local edge = FXMeasure.GetOuterEdge(prjSpace)
			local noOfPnt1 = edge:GetPointNumber();
			local PlyLine = PolyLine3D(TRUE);

			for i = 1, noOfPnt1 -1, 1 do
				local pnt1 = edge:GetPoint(i);
				PlyLine:AddPoint(pnt1);
			end

			PlyLine:ClosePolyline();
			local face = PlyLine:Face3D()
			extrudeFace = face:ExtrudedFace(Vector(0,0,HighEle))
			--FXUtility.DisplaySolid_Error(Space," ",extrudeFace)
			local node = FXUtility.CreateNodeFrom(extrudeFace)
			grpSlab:ForEach(function (Slab)
				if FXClashDetection.IsCollided(node, Slab) then
					grpSlabCol:Add(Slab)
				end
			end)

			if #grpFlowSegment ~= 0 then
				grpFlowSegment:ForEach(function (Segment)
					if FXClashDetection.IsCollided(node, Segment) then
						grpSegmentCol:Add(Segment)
					else
						grpSegNotCol:Add(Segment)
					end
				end)
			else
				FXUtility.DisplaySolid_Warning(Building,"No Sanitary Pipe found")
			end
			FXClashDetection.DeleteNode(node)
			grpSlabBelow = Space:GetSlabsBelow()
			grpSlabCol = grpSlabCol - grpSlabBelow	
			local lowSlab = GetLowestSlab(grpSlabCol)
			grpSlabBel = GetSlabBelowPipe(grpSlabCol,grpSegmentCol)
			
			if #grpSegmentCol ~= 0 then
				
				grpSegmentCol:ForEach(function (ColSeg)
					local obbslab = FXGeom.GetBoundingBox(lowSlab)
					local obbseg = FXGeom.GetBoundingBox(ColSeg)
					
					if obbslab:LowPos().z > obbseg:HighPos().z then
		 				FXUtility.DisplaySolid_Error(Space,ColSeg:GetAttri("Name").." in ".. Space:GetAttri("LongName"))
		 				CheckReport.AddRelatedObj(ColSeg, ColSeg:GetAttri("Name"))
					 
					 else
		 				local prjSlab = FXMeasure.GetProjection(grpSlabBel, Space:GetParent("BuildingStorey"):Elevation())
						local prjSegment = FXMeasure.GetProjection(grpSegmentCol, Space:GetParent("BuildingStorey"):Elevation())
						local prjNew = FXMeasure.SubtractProjection(prjSegment,prjSlab, Space:GetParent("BuildingStorey"):Elevation());
							
						if prjNew ~= nil then
							local prjInter = IntersectProjection(prjSpace, prjNew)
							
							if prjInter ~= nil then
								
								FXUtility.DisplaySolid_Error(Space,ColSeg:GetAttri("Name").." in ".. Space:GetAttri("LongName"))
			 					CheckReport.AddRelatedObj(ColSeg, ColSeg:GetAttri("Name"))
							
							-- else
							-- 	flag1 = true
								
							end					
						else
							flag = true
						end		
					
					end
				
				end)
			
			else
				FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe in "..Space:GetAttri("LongName"))
			
			end				
			if flag == true then
				FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe in "..Space:GetAttri("LongName"))
			end
			if flag1 == true then
				FXUtility.DisplaySolid_Info(Space,"No Sanitary Pipe in "..Space:GetAttri("LongName"))
			end	 
		
		end)
	else
		FXUtility.DisplaySolid_Warning(Building,"No Space found ")

	end

end

function GetHighestStorey(Building)
	local HighStorey
	grpStorey = Building:GetDescendants("BuildingStorey")
	grpStorey:ForEach(function (Storey)
		if #FXUtility.GetAllUpperStorey(Storey) == 0 then
			HighStorey = Storey
		end
	end)
	return HighStorey
end


function GetSlabAll(Building)
	local grpSlab = FXGroup.new()
	grpSlab = Building:GetDescendants("Slab") --+ Building:GetDescendants("Covering")
	return grpSlab
end


function GetLowestSlab(grpSlab)
	local lowSlab
	grpSlab:ForEach(function (Slab)
		if lowSlab == nil then
			lowSlab = Slab
		else
			local obblowslab = FXGeom.GetBoundingBox(lowSlab)
			local obbSlab = FXGeom.GetBoundingBox(Slab)
			if obblowslab:LowPos().z > obbSlab:LowPos().z then
				lowSlab = Slab
			end
		end
	end)
	return lowSlab
end


function GetSlabBelowPipe(grpSlabCol,grpSegmentCol)
	grpSlabBel = FXGroup.new()
	grpSegmentCol:ForEach(function (Seg)
		grpSlabCol:ForEach(function (Slab)
			if (FXRule.IsOverlap(Seg, Slab) == -1) then
				grpSlabBel:Add(Slab)
			end
		end)
	end)
	return grpSlabBel
end

function IntersectProjection(prj1, prj2)
	local node1 			= FXUtility.CreateNodeFrom(prj1);
	local node2 			= FXUtility.CreateNodeFrom(prj2); 
	local grpNode  			= FXGroup.new(); 
	grpNode:Add(node1);
	grpNode:Add(node2);						
	local prjSpaceCopy		= FXMeasure.IntersectProjection(grpNode)
	FXClashDetection.DeleteNode(node1);
	FXClashDetection.DeleteNode(node2);
	return prjSpaceCopy;
end 
