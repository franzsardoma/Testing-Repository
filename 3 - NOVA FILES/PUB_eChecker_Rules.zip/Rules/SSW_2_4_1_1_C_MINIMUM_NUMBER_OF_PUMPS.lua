local Duty = FXGroup:new()
local Standby = FXGroup:new()
local totalPumps
local pumpCondi
	
function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_4_1_1_C_MINIMUM_NUMBER_OF_PUMPS")
    local systemTypes = FXRule.ParseValues(parsedXml, "SystemType")
   	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
    local Condition2 = FXRule.ParseValues(parsedXml, "Condition2")

    pumpCondi = tonumber(Condition2[1])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if ( k == 2 ) then
				Duty = Duty + v
				Duty = Duty:Unique()
			end
			if ( k == 3 ) then
				Standby = Standby + v
				Standby = Standby:Unique()
			end
		end
	end

	totalPumps = Duty + Standby
end

function CheckRule(Building)
print(#totalPumps)

	local isCompliant = true
	local notConnected = true
	local dutyArr = {}
	local standbyArr = {}
	local dutyTable 
	local standbyTable 
	local check = CheckWarning(Building)
	if check  then

		if ( #totalPumps == pumpCondi ) then

			Duty:ForEach(function(dutyOb)
				Standby:ForEach(function(standbyOb)
						
					if isConnected(dutyOb, standbyOb, dutyOb ) then

						isCompliant = true
						dutyTable = dutyOb
						standbyTable = standbyOb				
					else 

						isCompliant = false
						FXUtility.DisplaySolid_Error(dutyOb,"Number of pumps: " ..#totalPumps)	
						-- CheckReport.AddRelatedObj(standbyOb,"Duty and Standby pump is not connected")					
						CheckReport.AddRelatedObj(dutyOb,"Duty and Standby pump is not connected")
						CheckReport.AddRelatedObj(dutyOb,dutyOb:GetAttri("Name"))
						CheckReport.AddRelatedObj(standbyOb,standbyOb:GetAttri("Name"))	
					end
				end)
			end)
		else
				
			if ( #Duty == 1 ) then 

				Duty:ForEach(function(dutyOb)

					isCompliant = false 
					FXUtility.DisplaySolid_Error(dutyOb, "Number of pumps: " ..#totalPumps)
					FXUtility.DisplaySolid_Error(dutyOb, "Standby Pump is not provided")
					CheckReport.AddRelatedObj(dutyOb, dutyOb:GetAttri("Name"))
				end)
			end 

			if ( #Standby == 1 ) then				
				Standby:ForEach(function(standbyOb)

					isCompliant = false 
					FXUtility.DisplaySolid_Error(standbyOb,"Number of pumps: " ..#totalPumps)
					FXUtility.DisplaySolid_Error(standbyOb, "Duty Pump is not provided")
					CheckReport.AddRelatedObj(standbyOb, standbyOb:GetAttri("Name"))
				end)
			end
		end

		if isCompliant then

			table.insert(dutyArr,dutyTable)
			table.insert(standbyArr,standbyTable)
		end	

		if isCompliant then

			for k=1, #dutyArr do

				FXUtility.DisplaySolid_Info(dutyArr[k],"Number of pumps: " ..#totalPumps)	
				-- FXUtility.DisplaySolid_Info(standbyArr[k], "Duty and Standby pump provided")
				FXUtility.DisplaySolid_Info(dutyArr[k], "Duty and Standby pump provided")
				CheckReport.AddRelatedObj(dutyArr[k],dutyArr[k]:GetAttri("Name"))
				CheckReport.AddRelatedObj(standbyArr[k],standbyArr[k]:GetAttri("Name"))						
			end
		end
	end
end	

function isConnected( ob1, ob2, obj3 ) --Checking  all the elements that is connected from Duty pump to Standby Pump

	local flag = false

	if(ob2 == nil) then
		return;
	end

	local grpConnObjs = ob1:GetConnectedElement();

	grpConnObjs:ForEach(function ( ConnObjEle )

		if(flag == true) then
			return;
		end

		--Filtering the third object 
		if(obj3.Id ~= ConnObjEle.Id) then 		
			if (ConnObjEle.Id == ob2.Id) then  

				flag = true
			else
				
				flag = isConnected( ConnObjEle, ob2, ob1 )
			end
		end
	end)

	return flag
end

function CheckWarning( Building )

	local Warning = true

	if (#Duty == 0) and (#Standby == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Pumps are not provided")	
		Warning = false
	end

	return Warning
end