local grpTanks = FXGroup:new()
local grpOverflows = FXGroup:new()
local grpInlets = FXGroup:new()
local TankVal, TankProp
local OverflowVal, OverflowProp
local OverflowTab = {}
local InletVal, InletProp
local DiameterOperator, VDistanceOperator

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_5_OVERFLOW_PIPE_DIAMETER_AND_LOCATION")
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	DiameterOperator = ConditionValues2[3]
	VDistanceOperator = ConditionValues2[6]

	if GrpObjs ~= nill then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpTanks = grpTanks + v;
				grpTanks = grpTanks:Unique();
			end
			if (k == 3) then
				grpOverflows = grpOverflows + v;
				grpOverflows = grpOverflows:Unique();
			end
			if (k == 4) then
				grpInlets = grpInlets + v;
				grpInlets = grpInlets:Unique();
			end
		end
	end

	local Values1 = {}
	local Values3 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
				TankProp = (v1["property"])
			end
			if(k == 2) then
				table.insert(OverflowTab, v1["value"])
				OverflowProp = (v1["property"])
			end
			if(k == 3) then
				table.insert(Values3, v1["value"])
				InletProp = (v1["property"])
			end
		end
	end

	TankVal = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			TankVal = TankVal.." or "..v
		end
	end

	OverflowVal = OverflowTab[1]
	for k,v in pairs(OverflowTab) do
		if k ~= 1 then
			OverflowVal = OverflowVal.." or "..v
		end
	end

	InletVal = Values3[1]
	for k,v in pairs(Values3) do
		if k ~= 1 then
			InletVal = InletVal.." or "..v
		end
	end
end

function CheckWarning( Building )
	local flag = true
	if(#grpTanks == 0) then
		flag = false	
		CheckReport.Warning( Building, TankVal.." is not provided.")
	end	
	if(#grpOverflows == 0) then
		flag = false	
		CheckReport.Warning( Building, OverflowVal.." is not provided.")
	end	
	if(#grpInlets == 0) then
		flag = false	
		CheckReport.Warning( Building, InletVal.." is not provided.")
	end	
	return flag;
end

function CheckWarning2( Tank, OverFlowPipe, InletPipe )
	local flag = true
	if(OverFlowPipe == nil) then
		CheckReport.Warning( Tank, OverflowVal.." is not provided.")
		flag = false
	end
	if(InletPipe == nil) then
		CheckReport.Warning( Tank, InletVal.." is not provided.")
		flag = false
	end
	return flag;
end

function checkRule( Building )
	if(CheckWarning(Building)) then
		local IsErrorNotFound = true
		local ARRTank = {}
		local ARROverFlowPipe = {}
		local ARRInletPipe = {}
		local ARRInsideDiameterOverFlow = {}
		local ARRInsideDiameterInlet = {}
		local ARRVerticalDistance = {}

		grpTanks:ForEach(function ( Tank )
			local OverFlowPipe, InletPipe = getOverflowANDInletPipe( Tank )

			if(CheckWarning2(Tank, OverFlowPipe, InletPipe)) then
				local InsideDiameterInlet = FXUtility.Round(getDiameter(InletPipe))
				local InsideDiameterOverFlow = FXUtility.Round(getDiameter(OverFlowPipe))
				local InletPOS = FXGeom.GetBoundingBox(InletPipe):HighPos().z
				local OverFlowPOS = FXGeom.GetBoundingBox(OverFlowPipe):LowPos().z
				local InletPipeElevation =  FXUtility.Round(tonumber(FXGeom.GetBoundingBox(InletPipe):LowPos().z))
				local OverFlowPipeElevation =  FXUtility.Round(tonumber(OverFlowPOS))
				local VerticalDistance = InletPipeElevation - OverFlowPipeElevation
				local flag = true;

				if FXRule.EvaluateNumber( DiameterOperator , InsideDiameterOverFlow, InsideDiameterInlet) == false then
					flag = false;
					if(InsideDiameterOverFlow < InsideDiameterInlet) then
						FXUtility.DisplaySolid_Error(Tank,OverFlowPipe:GetAttri(OverflowProp)..": Diameter = "..InsideDiameterOverFlow.." mm; is smaller than "..InletPipe:GetAttri(InletProp)..": Diameter = "..InsideDiameterInlet.." mm")
					elseif(InsideDiameterOverFlow == InsideDiameterInlet) then
						FXUtility.DisplaySolid_Error(Tank,OverFlowPipe:GetAttri(OverflowProp)..": Diameter = "..InsideDiameterOverFlow.." mm; is equal to "..InletPipe:GetAttri(InletProp)..": Diameter = "..InsideDiameterInlet.." mm")
					end
					CheckReport.AddRelatedObj(Tank, Tank:GetAttri(TankProp))
					CheckReport.AddRelatedObj(OverFlowPipe, OverFlowPipe:GetAttri(OverflowProp))
					CheckReport.AddRelatedObj(InletPipe, InletPipe:GetAttri(InletProp))
				end

				if((OverFlowPOS < InletPOS) == false) then
					flag = false;
					FXUtility.DisplaySolid_Error(Tank, OverFlowPipe:GetAttri(OverflowProp).." is located above "..InletPipe:GetAttri(InletProp))
					CheckReport.AddRelatedObj(Tank, Tank:GetAttri(TankProp))
					CheckReport.AddRelatedObj(OverFlowPipe, OverFlowPipe:GetAttri(OverflowProp))
					CheckReport.AddRelatedObj(InletPipe, InletPipe:GetAttri(InletProp))

				elseif FXRule.EvaluateNumber( VDistanceOperator , VerticalDistance, InsideDiameterOverFlow) == false then
					flag = false;
					FXUtility.DisplaySolid_Error(Tank, "Vertical Distance of "..OverFlowPipe:GetAttri(OverflowProp).." to "..InletPipe:GetAttri(InletProp).." = "..VerticalDistance.." mm : is less than "..OverFlowPipe:GetAttri(OverflowProp).." : Diameter = "..InsideDiameterOverFlow.." mm")
					CheckReport.AddRelatedObj(Tank, Tank:GetAttri(TankProp))
					CheckReport.AddRelatedObj(OverFlowPipe, OverFlowPipe:GetAttri(OverflowProp))
					CheckReport.AddRelatedObj(InletPipe, InletPipe:GetAttri(InletProp))
				end

				if(flag) then
					table.insert(ARRTank, Tank)
					table.insert(ARROverFlowPipe, OverFlowPipe)
					table.insert(ARRInletPipe, InletPipe)
					table.insert(ARRInsideDiameterOverFlow, InsideDiameterOverFlow)
					table.insert(ARRInsideDiameterInlet, InsideDiameterInlet)
					table.insert(ARRVerticalDistance, VerticalDistance)
				else
					IsErrorNotFound = false
				end
			end
		end)

		if IsErrorNotFound then
			for k,Tank in pairs(ARRTank) do
				FXUtility.DisplaySolid_Info(Tank, ARROverFlowPipe[k]:GetAttri(OverflowProp)..": Diameter = "..ARRInsideDiameterOverFlow[k].." mm; is larger than "..ARRInletPipe[k]:GetAttri(InletProp)..": Diameter = "..ARRInsideDiameterInlet[k].." mm");
				CheckReport.AddRelatedObj(Tank, Tank:GetAttri(TankProp))
				CheckReport.AddRelatedObj(ARROverFlowPipe[k], ARROverFlowPipe[k]:GetAttri(OverflowProp))
				CheckReport.AddRelatedObj(ARRInletPipe[k], ARRInletPipe[k]:GetAttri(InletProp))

				FXUtility.DisplaySolid_Info(Tank, ARROverFlowPipe[k]:GetAttri(OverflowProp).." is located below "..ARRInletPipe[k]:GetAttri(InletProp));
				CheckReport.AddRelatedObj(Tank, Tank:GetAttri(TankProp))
				CheckReport.AddRelatedObj(ARROverFlowPipe[k], ARROverFlowPipe[k]:GetAttri(OverflowProp))
				CheckReport.AddRelatedObj(ARRInletPipe[k], ARRInletPipe[k]:GetAttri(InletProp))

				FXUtility.DisplaySolid_Info(Tank, "Vertical Distance of "..ARROverFlowPipe[k]:GetAttri(OverflowProp).." to "..ARRInletPipe[k]:GetAttri(InletProp).." = "..ARRVerticalDistance[k].." mm : is greater than "..ARROverFlowPipe[k]:GetAttri(OverflowProp).." : Diameter = "..ARRInsideDiameterOverFlow[k].." mm");
				CheckReport.AddRelatedObj(Tank, Tank:GetAttri(TankProp))
				CheckReport.AddRelatedObj(ARROverFlowPipe[k], ARROverFlowPipe[k]:GetAttri(OverflowProp))
				CheckReport.AddRelatedObj(ARRInletPipe[k], ARRInletPipe[k]:GetAttri(InletProp))
			end
		end
	end
end

function getOverflowANDInletPipe( Tank )
	local Obj, Obj2;
	local grpConnObjs = Tank:GetConnectedElement();
	local ContainerZValue = 0;

	grpConnObjs:ForEach(function ( ConnObj )
		if HasValue(ConnObj:GetAttri(OverflowProp),OverflowTab) then
			Obj = ConnObj;
		else
			if ConnObj.Type == "FlowFitting" then
				local grpPIPES = ConnObj:GetConnectedElement();

				grpPIPES:ForEach(function ( PIPE )
					if PIPE.Type == "FlowSegment" then
						local pntZ = FXGeom.GetBoundingBox(PIPE):MidPos().z
						
						if(ContainerZValue == 0 or ContainerZValue < pntZ) then
							ContainerZValue = pntZ
							Obj2 = PIPE;
						end
					end
				end)
			else
				local pntZ = FXGeom.GetBoundingBox(ConnObj):MidPos().z
				
				if(ContainerZValue == 0 or ContainerZValue < pntZ) then
					ContainerZValue = pntZ
					Obj2 = ConnObj;
				end
			end
		end
	end)
	return Obj, Obj2;
end

function HasValue( val, tab )
    for index, value in pairs(tab) do
        if (FXUtility.HasPatterInString(value,val)) then
            return true
        end
    end
    return false
end

function getDiameter(pipe)
	local pipeDiameter = 10

	for i=0, 5, 1 do 
		if FXMeasure.GetCircularFacesInDirection(pipe,i) ~= nil then
			local circleFace = FXMeasure.GetCircularFacesInDirection(pipe,i)
			local closetEdge = FXMeasure.GetOuterEdge(circleFace)
			pipeDiameter = GetLength( closetEdge )
			break
		end
	end
	return pipeDiameter;
end

function GetLength( outerEdge, pipe )
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local Point1 = outerEdge:GetPoint(0)
	local dist

	for i=0,(PolyLinePointNumber-2) do
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2):Length()
		if( dist == nil or dist < Line ) then
			dist = Line;
		end
	end
	return dist
end