local Ramp = FXGroup.new();
-- local Group2 = FXGroup.new();
local Space = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function Parser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "SWD_2_2_A_MINIMUM_CREST_LEVEL_AT_BASEMENTS");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- -- IsConnected = ConditionValues[1];
	-- -- minDiameter = tonumber(ConditionValues[2])

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- print(#GrpObjs)
	if(GrpObjs ~= nil)then		
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				Ramp =   Ramp + v;
				Ramp = Ramp:Unique();
			end	
			-- if (k == 3) then	
			-- 	Group2 = Group2 + v;
			-- 	Group2 = Group2:Unique();
			-- end	
			if (k == 4) then	
				Space = Space + v;
				Space = Space:Unique();
			end		
		end
	end	
end

function CheckRule(Building)
	local Site = Building:GetParent();
	local SiteName = Site:GetAuxAttri("Other.Project Development Type");
	local SiteFlag = false;
	local SiteIsNil = false;
	-------------------------------------------------------------------------------
	local BuildingStorey = Building:GetDescendants("BuildingStorey");
	local FirstLevel;
	local BasementLevel;
	-------------------------------------------------------------------------------
	local RampGroup = FXGroup.new();
	local SpaceGroup = FXGroup.new();
	local IsRampInBasement = false;
	local BasementSpace;
	local RampObject;
	local OpeningObject;
	-------------------------------------------------------------------------------
	if(SiteName ~= nil)then 
		if(FXUtility.HasPatterInString(SiteName,"General Development"))then 
			SiteFlag = true;
		end
	else
		SiteIsNil = true;
	end
	-------------------------------------------------------------------------------
	BuildingStorey:ForEach(function(Storey)
		if( (FXUtility.HasPatterInString(Storey:GetAttri("Name"),"Level 01")) or 
			(FXUtility.HasPatterInString(Storey:GetAttri("Name"),"Storey 01")) or 
			(FXUtility.HasPatterInString(Storey:GetAttri("Name"),"Storey 1"))  or 
			(FXUtility.HasPatterInString(Storey:GetAttri("Name"),"Level 1")) )then 
			FirstLevel = Storey;
		elseif( (FXUtility.HasPatterInString(Storey:GetAttri("Name"),"Basement 01")) or (FXUtility.HasPatterInString(Storey:GetAttri("Name"),"Basement 1")) )then 
			SpaceGroup = Storey:GetDescendants("Space");
		end
		---------------------------------------------------------------------------
		
	end)	
	-------------------------------------------------------------------------------
	if(FirstLevel == nil)then 
		FXUtility.DisplaySolid_Warning(Building,"No Level 01.");
		return;
	end
	-------------------------------------------------------------------------------
	if(SiteIsNil)then 
		FXUtility.DisplaySolid_Warning(Building,"Project Development Type not specified.");
		return;
	end
	-------------------------------------------------------------------------------
	if(SiteFlag == false)then 
		FXUtility.DisplaySolid_Warning(Building,"Project Development Type does not match.");
		return;
	end
	-------------------------------------------------------------------------------
	local FirstLevelSlabs = FirstLevel:GetDescendants("Slab");
	-------------------------------------------------------------------------------
	Ramp:ForEach(function(Element)
		if(Element.Type == "RampFlight")then 
			RampGroup:Add(Element);
		end
	end)
	-- print(#RampGroup)
	-- RampGroup = BasementLevel:GetDescendants("RampFlight");
	
	-------------------------------------------------------------------------------
	if(#RampGroup == 0)then 
		FXUtility.DisplaySolid_Warning(Building,"Ramp is not provided.");
		return;
	end
	-------------------------------------------------------------------------------
	local DrivewaySlab;
	FirstLevelSlabs:ForEach(function(Element)
		local Name = Element:GetAttri("Name"); 
		if(DrivewaySlab == nil)then 
			DrivewaySlab = Element;
		else
			local TempBox = FXGeom.GetBoundingBox(DrivewaySlab);
			local ElementBox = FXGeom.GetBoundingBox(Element);
			-------------------------------------------------------------------
			if(TempBox:LowPos().z > ElementBox:LowPos().z)then 
				DrivewaySlab = Element;
			end
		end
	end)
	-------------------------------------------------------------------------------
	local WallGroup = FirstLevel:GetDescendants("Wall");
	WallGroup:ForEach(function(Element)
		if(FXClashDetection.IsCollided(Element,DrivewaySlab))then 
			local OpeningElement = Element:GetChildren("OpeningElement");
			if(#OpeningElement >= 1)then 
				OpeningElement:ForEach(function(Element)
					OpeningObject = Element;	
				end)				
			end
		end		
	end)
	-------------------------------------------------------------------------------
	if(OpeningObject == nil)then 
		FXUtility.DisplaySolid_Warning(Building,"Opening element is not provided.");
		return;
	end
	-------------------------------------------------------------------------------
	if(#Space == 0)then 
		FXUtility.DisplaySolid_Warning(Building,"Basement is not provided.");
		return;
	end
	-------------------------------------------------------------------------------
	Space:ForEach(function(Element)
		if(Element ~= nil)then 			
			BasementSpace = Element;
		end		
	end)
	-------------------------------------------------------------------------------
	RampGroup:ForEach(function(RampElement)
		if(RampObject == nil)then 
			RampObject = RampElement;
		else
			local RampObjectOBB = FXGeom.GetBoundingBox(RampObject);
			local RampElementOBB = FXGeom.GetBoundingBox(RampElement);

			if(RampObjectOBB:x_range() > RampObjectOBB:y_range())then 
				if(RampObjectOBB:x_range() < RampElementOBB:x_range())then 
					RampObject = RampElement;
				end
			else
				if(RampObjectOBB:y_range() < RampElementOBB:y_range())then 
					RampObject = RampElement;
				end
			end
		end
	end)
	-------------------------------------------------------------------------------
	local LowestSlab;

	local BasementSpaceStoreyLevel = BasementSpace:GetParent():GetAttri("Name");
	local RampFlightStoreyLevel = RampObject:GetParent():GetParent():GetAttri("Name");
	if(BasementSpaceStoreyLevel ~= RampFlightStoreyLevel)then 
		FXUtility.DisplaySolid_Warning("Ramp is not in the basement");
		return;
	end
	-------------------------------------------------------------------------------
	FirstLevelSlabs:ForEach(function(Element)
		local Name = Element:GetAttri("Name");
		if(FXUtility.HasPatterInString(Name,"Driveway") == false)then 
			if(LowestSlab == nil)then 
				LowestSlab = Element;
			else
				local TempBox = FXGeom.GetBoundingBox(LowestSlab);
				local ElementBox = FXGeom.GetBoundingBox(Element);
				-------------------------------------------------------------------
				if(TempBox:LowPos().z > ElementBox:LowPos().z)then 
					LowestSlab = Element;
				end
			end
		end
	end)
	--------------------------------------------------------------------------------	
	local RampBox = FXGeom.GetBoundingBox(RampObject);
	local RampZ = RampBox:HighPos().z;
	local RampX = RampBox:LowPos().x;
	local RampY = RampBox:LowPos().y;
	--------------------------------------------------------------------------------
	local RampHighX = RampBox:HighPos().x;
	local RampHighY = RampBox:HighPos().y;
	--------------------------------------------------------------------------------
	local RampHighestPoint = Point3D(RampX,RampY,RampZ);
	--------------------------------------------------------------------------------
	local SlabBox = FXGeom.GetBoundingBox(LowestSlab);
	local SlabZ = SlabBox:HighPos().z;
	local SlabX = SlabBox:LowPos().x;
	local SlabY = SlabBox:HighPos().y;
	local SlabHighestPoint = Point3D(RampX,RampHighY,SlabZ);	
	--------------------------------------------------------------------------------
	-- local PointSlab = Point3D(SlabX,SlabY,RampZ);
	local PointSlab = Point3D(RampX,RampHighY,RampZ);
	local LineSlab = Line3D(PointSlab,RampHighestPoint);
	--------------------------------------------------------------------------------
	local PointRamp = Point3D(RampX,RampY,SlabZ);
	local LineRamp = Line3D(PointRamp,SlabHighestPoint);
	--------------------------------------------------------------------------------
	local CrestLevelArrow1 = DoubleArrow(PointRamp, RampHighestPoint);
	local CrestLevelArrow2 = DoubleArrow(PointSlab, SlabHighestPoint);
	local Distance = Line3D(PointRamp, RampHighestPoint):Length();
	--------------------------------------------------------------------------------
	local PlatformProjection = FXMeasure.GetObjProjection(LowestSlab,FirstLevel:Elevation());
	--------------------------------------------------------------------------------
	local CrestLevel = FXUtility.Round(RampHighestPoint.z,2)/1000;
	local PlatformLevel = FXUtility.Round(SlabHighestPoint.z,2)/1000;
	--------------------------------------------------------------------------------
	if(Distance >= 150)then 
		FXUtility.DisplaySolid_Info(LowestSlab,"The Crest Level is higher than Platform Level by 150mm");
		CheckReport.AddRelatedObj(RampObject,"Crest Level: "..CrestLevel.." m; Platform Level: "..PlatformLevel.." m");
		----------------------------------------------------------------------------
		CheckReport.AddRelatedGeometry_Solid(LineSlab);
		CheckReport.AddRelatedGeometry_Solid(LineRamp);
		----------------------------------------------------------------------------
		CheckReport.AddRelatedGeometry_Solid(CrestLevelArrow1);
		CheckReport.AddRelatedGeometry_Solid(CrestLevelArrow2);
		----------------------------------------------------------------------------
		CheckReport.AddRelatedGeometry_Solid(PlatformProjection);
	else
		if(CrestLevel > PlatformLevel)then 
			FXUtility.DisplaySolid_Error(LowestSlab,"The Crest Level is higher than Platform Level by 100mm");
		else
			FXUtility.DisplaySolid_Error(LowestSlab,"The Crest Level is lower than Platform Level by 100mm");
		end
		CheckReport.AddRelatedObj(RampObject,"Crest Level: "..CrestLevel.." m; Platform Level: "..PlatformLevel.." m");
		----------------------------------------------------------------------------
		CheckReport.AddRelatedGeometry_Error(LineSlab);
		CheckReport.AddRelatedGeometry_Error(LineRamp);
		----------------------------------------------------------------------------
		CheckReport.AddRelatedGeometry_Error(CrestLevelArrow1);
		CheckReport.AddRelatedGeometry_Error(CrestLevelArrow2);
		----------------------------------------------------------------------------
		CheckReport.AddRelatedGeometry_Error(PlatformProjection);
	end
	--------------------------------------------------------------------------------
	CheckReport.AddRelatedObj(LowestSlab,LowestSlab:GetAttri("Name"));
	CheckReport.AddRelatedObj(OpeningObject,OpeningObject:GetAttri("Name"));
	--------------------------------------------------------------------------------
	RampGroup:ForEach(function(Element)
		CheckReport.AddRelatedObj(Element,Element:GetAttri("Name"));		
	end)
	--------------------------------------------------------------------------------
	CheckReport.AddRelatedObj(DrivewaySlab,DrivewaySlab:GetAttri("Name"));
	--------------------------------------------------------------------------------
end