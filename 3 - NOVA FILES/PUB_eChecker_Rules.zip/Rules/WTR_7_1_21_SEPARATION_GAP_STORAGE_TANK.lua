--[[
    Implemented by: Aires Marco S. Ladaga 14/01/2019
]]
local grpTankSpace = FXGroup.new();
local grpTankSlab = FXGroup.new();
local grpTankWall = FXGroup.new();
local bool = true;
local isErrorFound = false;
local wallMaterial;
local slabMaterial;
local slabOperator;
local distance;
local tankSpaceValue;
local tankSlabValue;
local tankSlabProperty;

function main()
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("XMLParser");
  CheckEngine.RunCheckPipeline();

  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
    local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_21_SEPARATION_GAP_STORAGE_TANK")
    local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);

    local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
    wallMaterial = ConditionValues2[4]; -- for Condition Values 

    local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
    slabMaterial = ConditionValues1[2]; -- for Condition Values 
    slabOperator = ConditionValues1[5];
    distance = tonumber(ConditionValues1[6]);

    for k,v in pairs(GrpBuildingObjs) do 
        if (k == 2) then
            grpTankSpace = grpTankSpace + v;
        end 
    end

    local tblValues = FXRule.filterTableValues(parsedXml, proj);

    for k,v in pairs(tblValues) do
        for k1,v1 in pairs(v) do
            if(k == 1) then
                tankSpaceValue = (v1["value"])
            end

            if(k == 2) then
                -- print (v1["value"])
                tankSlabValue = (v1["value"])
                tankSlabProperty = (v1["property"])
            end
        end
    end
end


function checkRule(Building)
    print (#grpTankSpace.." - "..#grpTankWall.." - "..#grpTankSlab.. " - ")
                    
    local grpTrueTankSpace = FXGroup.new();
    local printedAttention = false;

    if #grpTankSpace == 0 then
        FXUtility.DisplaySolid_Warning ( Building , "Tank space is not provided." );
        bool = false;
        printedAttention = true;
    end

    if bool then
        local comCounter = 0;
        local comSlabArr = {};
        local comStoreyArr = {};
        local comWallArr = {};

        grpTankSpace : ForEach ( function ( tankSpace )
            if FXUtility.IsStringEqual( tankSpace:GetAuxAttri("Entity.LongName") , tankSpaceValue ) then
                grpTrueTankSpace:Add ( tankSpace );
            end
        end)

        if #grpTrueTankSpace > 0 then
            grpTrueTankSpace:ForEach (function ( tankSpace )
                local spaceStorey = getStorey(tankSpace);
                local idUpper = spaceStorey:GetAboveStorey();
                local upperstorey = NewElement("BuildingStorey", idUpper);

                local grpThisStoreySlabs = spaceStorey:GetDescendants("Slab"); 
                local grpAboveStoreySlabs = upperstorey:GetDescendants("Slab");
                local grpSlabs = grpThisStoreySlabs + grpAboveStoreySlabs;

                local grpTankWalls = tankSpace:GetConnectedWall();
                local grpSlabAbove = FXGroup.new();

                if #grpSlabs > 0 then
                    local nextStoreyExtrude = FXGeom.GetBoundingBox(upperstorey):HighPos().z - FXGeom.GetBoundingBox(tankSpace):MidPos().z
                    local spaceProj =  FXMeasure.GetObjProjection(tankSpace, FXGeom.GetBoundingBox(tankSpace):MidPos().z);
                    local outerEdges = FXMeasure.GetOuterEdge(spaceProj);
                    local toFace = outerEdges:Face3D();
                    local extrudedFace = toFace:ExtrudedFace(Vector(0,0,nextStoreyExtrude));
                    local node = FXUtility.CreateNodeFrom(extrudedFace);
                      -- FXUtility.DisplaySolid_Warning( Building ,"Tank slab material does not match." ,extrudedFace)
                    grpSlabs:ForEach (function ( slab )
                        if FXClashDetection.IsCollided(slab,node)then
                            grpSlabAbove : Add ( slab );
                        end
                    end)
                    FXClashDetection.DeleteNode(node);
                end

                if #grpSlabAbove > 0 and #grpTankWalls > 0 then
                    local lowestSlab = getLowest( grpSlabAbove );
                    local grpWrongMaterialWalls = FXGroup.new();

                    grpTankWalls:ForEach(function ( walls )
                        local isComMaterial, material = FXPUB.CheckObjMaterial( walls , wallMaterial )
                        if isComMaterial == false then
                            grpWrongMaterialWalls:Add(walls);
                        end
                    end)

                    if FXUtility.HasPatterInString( lowestSlab:GetAttri( tankSlabProperty ) , tankSlabValue ) then                      
                        local isComMaterial, material = FXPUB.CheckObjMaterial( lowestSlab , slabMaterial )                             
                        grpSlabAbove:Sub(lowestSlab)
                        local secondLowestSlab = getLowest( grpSlabAbove );
                        local secondLowestSlabStorey = getStorey( secondLowestSlab );

                        local slabToSlabDis = tonumber(FXMeasure.Distance ( lowestSlab , secondLowestSlab ):Length());
                        
                        if not FXClashDetection.IsCollided( lowestSlab , secondLowestSlab ) and FXRule.EvaluateNumber( slabOperator , slabToSlabDis , distance ) then
                            comCounter = comCounter + 1;
                            comSlabArr[comCounter] = lowestSlab;
                            comWallArr[comCounter] = grpTankWalls;
                            comStoreyArr[comCounter] = secondLowestSlabStorey;
                        else
                            isErrorFound = true; 
                            FXUtility.DisplaySolid_Error( lowestSlab , lowestSlab:GetAuxAttri("Entity.ObjectType").." is not separated with slab ("..secondLowestSlabStorey:GetAttri("Name")..")");
                            grpTankWalls : ForEach( function ( obj )
                                CheckReport.AddRelatedObj( obj , obj:GetAttri("Name"));
                            end)   
                        end
                        -- To Display Attention message for wrong material regardless if its compliant or non-compliant
                        if isComMaterial == false and #grpWrongMaterialWalls > 0 then
                            if isComMaterial == false then
                                FXUtility.DisplaySolid_Warning( lowestSlab ,"Tank slab material does not match." )
                            end

                            if #grpWrongMaterialWalls > 0 then
                                grpWrongMaterialWalls : ForEach(function ( walls )
                                    FXUtility.DisplaySolid_Warning( walls ,"Tank wall material does not match." )
                                end)
                            end
                        end
                    else -- NO TANK SLAB
                        isErrorFound = true;
                        FXUtility.DisplaySolid_Error( tankSpace , "Tank slab is not provided." ); 
                        grpTankWalls : ForEach( function ( obj )
                            CheckReport.AddRelatedObj( obj , obj:GetAttri("Name"));
                        end)   
                        -- To Display Attention message for wrong material regardless if its compliant or non-compliant
                        if #grpWrongMaterialWalls > 0 then
                            if #grpWrongMaterialWalls > 0 then
                                grpWrongMaterialWalls : ForEach(function ( walls )
                                    FXUtility.DisplaySolid_Warning( walls ,"Tank wall material does not match." )
                                end)
                            end
                        end
                    end
                else
                    if #grpSlabAbove == 0 then
                        FXUtility.DisplaySolid_Warning( tankSpace , "Slab above tank is not provided." );
                    end

                    if #grpTankWalls == 0 then
                        FXUtility.DisplaySolid_Warning( tankSpace , "Tank wall is not provided." );
                    end
                end
            end)

            if isErrorFound == false then
                local x = 1;
                while x ~= comCounter + 1 do
                    FXUtility.DisplaySolid_Info( comSlabArr[x] , comSlabArr[x]:GetAuxAttri("Entity.ObjectType").." is separated from slab ("..comStoreyArr[x]:GetAttri("Name")..")");
                    comWallArr[x] : ForEach( function ( obj )
                        CheckReport.AddRelatedObj( obj , obj:GetAttri("Name"));
                    end)   

                    x = x + 1;
                end
            end
        elseif printedAttention == false then
            FXUtility.DisplaySolid_Warning ( Building , "Tank space is not provided." );
        end
    end
end


function getStorey( obj )   
    local storey = obj;
    for i=0, 10, 1 do 
        if storey.Type == "BuildingStorey" then
            return storey;
        end
        storey = storey:GetParent();
    end

    return nil;
end


function getLowest( grp )
    local lowestZ;
    local lowestObj;
    grp:ForEach (function ( obj )
        local lowPos = FXGeom.GetBoundingBox( obj ):LowPos().z;
        if lowestZ == nil or lowestZ > lowPos then
            lowestZ = lowPos;
            lowestObj = obj;
        end                      
    end)

    return lowestObj;
end