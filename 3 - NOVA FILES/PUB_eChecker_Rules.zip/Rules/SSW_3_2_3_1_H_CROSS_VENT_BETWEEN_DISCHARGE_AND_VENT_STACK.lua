--[[-----------------------------------------------------

Author: Monalyn L. Rueda

Rule ID: SSW 3.2.3.1 (h)
Rule Name: Minimum Transition Length

All copyrights to novasolutions 
--]]-----------------------------------------------------
local VentPipeGrp = FXGroup:new()
local SanitaryPipeGrp = FXGroup:new()
local NoCrossVent = FXGroup:new()

local count = 0



function main()

	CheckEngine.SetCheckType("System")
	CheckEngine.BindCheckFunc("getSystemPipes")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
    .BindCheckFunc("GetRequiredPipes")
    .RunCheckPipeline()
    
end

function getSystemPipes(System)

	if (FXUtility.HasPatterInString(System:GetAttri("Name"),"Vent")) then
		VentPipeGrp = VentPipeGrp + System:GetDescendants("FlowSegment");

	elseif (FXUtility.HasPatterInString(System:GetAttri("Name"),"Sanitary")) then
		SanitaryPipeGrp = SanitaryPipeGrp + System:GetDescendants("FlowSegment");
	end

end

function GetVerticalPipes(pipes)
	local pipeDiameter = FXPUB.GetDiameter(pipes);

	local pipeOBB = FXGeom.GetBoundingOBB(pipes);
	local pipeOBBmaxPnt = pipeOBB:MaxPnt()
	local pipeOBBminPnt = pipeOBB:MinPnt()
	local pipeLine = Line3D(pipeOBBmaxPnt, Point3D(pipeOBBmaxPnt.x,pipeOBBmaxPnt.y,pipeOBBminPnt.z))
	local pipeHeight = FXUtility.Round(pipeLine:Length(), 2); 

	return pipeHeight, pipeDiameter

end

function GetRequiredPipes(building)
	local DischargePipes = FXGroup:new()
	local VentilatingPipes = FXGroup:new()
	local VentVerticalPipes = FXGroup:new()
	local SanitaryVerticalPipes = FXGroup:new()
	local SanitaryFitting = FXGroup:new()
	local CrossVent = FXGroup:new()

	if #VentPipeGrp ~= 0 then
		if #SanitaryPipeGrp ~= 0 then

			VentPipeGrp:ForEach(function(pipes)

				local pipeHeight, pipeDiameter = GetVerticalPipes(pipes)

				if pipeHeight > pipeDiameter + 20 then
					if pipeDiameter >= 75 then 
						VentVerticalPipes:Add(pipes)
					end	
				end

			end)

			SanitaryPipeGrp = SanitaryPipeGrp - VentPipeGrp

			SanitaryPipeGrp:ForEach(function(pipes)
				local pipeHeight, pipeDiameter = GetVerticalPipes(pipes)

				if pipeHeight > pipeDiameter + 20 then
					if pipeDiameter >= 75 then 
						SanitaryVerticalPipes:Add(pipes)
					end	
				end
			end)

			if (#SanitaryVerticalPipes ~= 0 and #VentVerticalPipes ~= 0) then

				SanitaryVerticalPipes:ForEach(function(pipes)
					local ConnectedFitting = pipes:GetConnectedFitting()
					ConnectedFitting:ForEach(function(fit)
						SanitaryFitting:Add(fit)
					end)
				end)

				VentVerticalPipes:ForEach(function(pipes)
					local ConnectedFitting = pipes:GetConnectedFitting()

					ConnectedFitting:ForEach(function(connfit)

						SanitaryFitting:ForEach(function(fit)

							if (FXUtility.HasPatterInString(connfit.Id, fit.Id)) then	
								CrossVent:Add(pipes)
							end

						end)
					end)

				end)

			end

			if #CrossVent ~= 0 then

				VentVerticalPipes = VentVerticalPipes - CrossVent
				SanitaryVerticalPipes = SanitaryVerticalPipes + CrossVent

				local CheckProvisionFunc = CheckProvision(building, VentVerticalPipes, SanitaryVerticalPipes, CrossVent)
			else
				FXUtility.DisplaySolid_Warning(building, "Cross Vent is not provided.");
			end
		else
			print('No Discharge Pipes')
		end
	else
		print('No Ventilating Pipes')
	end

end

function CheckProvision(building, VentVerticalPipes, SanitaryVerticalPipes, CrossVent)
local BuildingStorey = building:GetDescendants('BuildingStorey')
local crossventTemp = FXGroup:new()
local storeyGrp = FXGroup:new()


BuildingStorey:ForEach(function(storey)
	count = count + 1

	if (count%10 == 0) then

		storeyGrp:Add(storey)
		local FlowSegments = storey:GetDescendants('FlowSegment')

		FlowSegments:ForEach(function(flowpipes)

			CrossVent:ForEach(function(pipes)

				if (FXUtility.HasPatterInString(flowpipes.Id, pipes.Id)) then
					crossventTemp:Add(pipes)
				end
			end)
		end)
	end
end)

 
	if #storeyGrp ~= 0 then

		storeyGrp:ForEach(function(storey)
			local crossvent

			local FlowSegments = storey:GetDescendants('FlowSegment')
			local FlowVerticalPipes = FXGroup:new()
			local DischargePipes = FXGroup:new()
			local VentilatingPipes = FXGroup:new()

			local dischargepipe, ventpipe

			print(storey:GetAttri('Name'))

			FlowSegments:ForEach(function(pipes)
			local pipeHeight, pipeDiameter = GetVerticalPipes(pipes)

				if pipeHeight > pipeDiameter + 20 then

					-- print(pipes:GetAttri('Name'))
					-- print(pipeHeight)
					-- print(pipeDiameter)

					if pipeDiameter >= 75 then
						FlowVerticalPipes:Add(pipes)
					end	
				end
			end)

			if #FlowVerticalPipes ~= 0 then

				FlowVerticalPipes:ForEach(function(flowpipes)

					VentVerticalPipes:ForEach(function(ventpipes)

						if (FXUtility.HasPatterInString(flowpipes.Id, ventpipes.Id)) then	
							DischargePipes:Add(flowpipes)
							-- dischargepipe = ventpipes
						end
					end)

					SanitaryVerticalPipes:ForEach(function(pipes)

						if (FXUtility.HasPatterInString(flowpipes.Id, pipes.Id)) then	
							VentilatingPipes:Add(flowpipes)
							-- ventpipe = pipes

						end
					end)

					CrossVent:ForEach(function(pipes)

						if (FXUtility.HasPatterInString(flowpipes.Id, pipes.Id)) then
							crossvent = pipes
						end
					end)

				end)


				if #crossventTemp == #storeyGrp then
					local Compliant = DisplayCompliantMessages(crossvent, storey)
				else
					local NonCompliant = DisplayNonCompliantMessages(crossvent, DischargePipes, VentilatingPipes, storey)
				end

			end

		end)
	end
end

function DisplayCompliantMessages(crossvent, storey)

	local crossventfitting = crossvent:GetConnectedFitting()

	FXUtility.DisplaySolid_Info(crossvent, " Cross vent pipe is provided between discharge pipe and ventilating pipe at every 10 storey.");
	crossventfitting:ForEach(function(fit)
		CheckReport.AddRelatedObj(fit, " Connected Flowfit : " .. fit:GetAttri("Name"));
	end)
end

function DisplayNonCompliantMessages(crossvent, dischargepipes, ventpipes, storey)

	if crossvent ~= nil then

		local crossventfitting = crossvent:GetConnectedFitting()

		FXUtility.DisplaySolid_Error(crossvent, " Cross vent pipe is provided between discharge pipe and ventilating pipe at more than 10 storey.");

		crossventfitting:ForEach(function(fit)
			CheckReport.AddRelatedObj(fit, " Connected Flowfit : " .. fit:GetAttri("Name"));
		end)

		local AddRelatedObjsFunc = AddRelatedObjs(dischargepipes, ventpipes)

	else
		FXUtility.DisplaySolid_Error(storey, "Cross vent pipe is not provided between discharge pipe and ventilating pipe");
		local AddRelatedObjsFunc = AddRelatedObjs(dischargepipes, ventpipes)
	end

end

function AddRelatedObjs(dischargepipes, ventpipes)
	dischargepipes:ForEach(function(pipes)
		CheckReport.AddRelatedObj(pipes, " Discharge Pipe : " .. pipes:GetAttri("Name"));
	end)
	ventpipes:ForEach(function(pipes)
		CheckReport.AddRelatedObj(pipes, " Ventilating Pipe : " .. pipes:GetAttri("Name"));
	end)
end