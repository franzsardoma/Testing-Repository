local grpManhole = FXGroup:new()
local grpPipe = FXGroup:new()
local grpPipeCon1 = FXGroup:new()
local grpPipeCon2 = FXGroup:new()
local soffitManhole = {}
local soffit1stPipe = {}
local soffit2ndPipe = {}

local invertManhole = {}
local invert1stPipe = {}
local invert2ndPipe = {}

local soffitFlag = true
local invertFlag = true

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_E_SEWER_JOINTS")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	if GrpObjsSystem ~= nil then
	for k,v in pairs(GrpObjsSystem) do
		if (k == 2) then
			grpManhole = grpManhole + v;
			grpManhole = grpManhole:Unique();
		end
		if (k == 3) then
			grpPipe = grpPipe + v;
			grpPipe = grpPipe:Unique();
		end
	end
	end
end

function checkRule(Building)
	if #grpManhole == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Manhole is not provided.");
		return false;
	end
	if #grpPipe == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Sewer pipe is not provided.");
		return false;
	end
	local pipeCount = checkConnectedPipes()
	if pipeCount == false then
		FXUtility.DisplaySolid_Warning(Building,"Only one sewer pipe is connected to Manhole.");
		return false;
	end
	grpManhole:ForEach( function ( Manhole )
		local checkPipe;
		local checkPipeOffset1 = nil
		local checkPipeOffset2 = nil
		local checkPipeDiam = nil
		local invert = nil
		local soffit = nil
		local checkface = nil
		grpPipe:ForEach(function ( Pipe )
			if FXClashDetection.IsCollided(Manhole,Pipe) then

				for i=0, 5 , 1 do 
					local circleFace = FXMeasure.GetCircularFacesInDirection(Pipe,i)
					if circleFace ~= nil then
						local outerEdge = FXMeasure.GetOuterEdge( circleFace )
						local newFace = outerEdge:Face3D()
						local faceExtrude = newFace:ExtrudedFace(Vector(0.5,0.5,0));
						local nodeFace = FXUtility.CreateNodeFrom(faceExtrude);	

							if FXClashDetection.IsCollided(Manhole,nodeFace) then
								local pipeDiam = FXPUB.GetDiameter(Pipe)
								local LowestPoint = GetLowestPoint( outerEdge )
								local HighestPoint = GetHighestPoint( outerEdge )
								
									if checkPipeOffset1 == nil and checkPipeDiam == nil and invert == nil and soffit == nil and circularface == nil and checkPipe == nil then
										checkPipe = Pipe
										checkPipeOffset1 = FXGeom.GetBoundingBox( Pipe ):HighPos().z;;
										checkPipeDiam = pipeDiam
										invert = LowestPoint
										soffit = HighestPoint
										checkface = circleFace
									else
										checkPipeOffset2 = FXGeom.GetBoundingBox( Pipe ):HighPos().z;;
										invert.z = (math.floor(invert.z/10)*10)
										soffit.z = (math.floor(soffit.z/10)*10)

										if tonumber(checkPipeOffset1) > tonumber(checkPipeOffset2) then
											if checkPipeDiam > pipeDiam then
												if invert.z == (math.floor(LowestPoint.z/10)*10) then
													table.insert(invertManhole, Manhole)
													table.insert(invert1stPipe, checkPipe)
													table.insert(invert2ndPipe, Pipe)

												else
													print("Invert Error")
													print(invert.z .." 1st Pipe")
													print((math.floor(LowestPoint.z/10)*10) .." 2ndPipe")
													FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on invert levels.");
													CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
													CheckReport.AddRelatedObj(checkPipe, checkPipe:GetAttri("Name"))
													invertFlag = false
												end
											else
												if soffit.z == (math.floor(HighestPoint.z/10)*10) then
													table.insert(soffitManhole, Manhole)
													table.insert(soffit1stPipe, checkPipe)
													table.insert(soffit2ndPipe, Pipe)
												else
													print("soffit Error")
													print(soffit.z .." 1st Pipe")
													print((math.floor(HighestPoint.z/10)*10) .." 2ndPipe")
													FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on soffit levels.");
													CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
													CheckReport.AddRelatedObj(checkPipe, checkPipe:GetAttri("Name"))
													soffitFlag = false
												end
											end
										else
											if pipeDiam > checkPipeDiam then
												if invert.z == (math.floor(LowestPoint.z/10)*10) then
													table.insert(invertManhole, Manhole)
													table.insert(invert1stPipe, checkPipe)
													table.insert(invert2ndPipe, Pipe)
												else
													print("Invert Error")
													print(invert.z .." 1stPipe")
													print((math.floor(LowestPoint.z/10)*10) .." 2ndPipe")
													FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on invert levels.");
													CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
													CheckReport.AddRelatedObj(checkPipe, checkPipe:GetAttri("Name"))
													invertFlag = false
												end
											else
												if soffit.z == (math.floor(HighestPoint.z/10)*10) then
													table.insert(soffitManhole, Manhole)
													table.insert(soffit1stPipe, checkPipe)
													table.insert(soffit2ndPipe, Pipe)
												else
													print("soffit Error")
													print(soffit.z .." 1stPipe")
													print((math.floor(HighestPoint.z/10)*10) .." 2ndPipe")
													FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on soffit levels.");
													CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
													CheckReport.AddRelatedObj(checkPipe, checkPipe:GetAttri("Name"))
													soffitFlag = false
												end
											end
										end
									end
								-- local Line = Line3D(Point, Point3D(Point.x,Point.y,Point.z + diameter))
								-- FXUtility.DisplaySolid_Error(Manhole,"fsdfsdfdsfsdfsdfds",Line);
								-- print(pipeDiam)
								break;
							end
							FXClashDetection.DeleteNode(nodeFace);
					end
				end
			end
		end)
	end)

	if soffitFlag == true and invertFlag == true then
		for i=1, #soffitManhole,1 do
			FXUtility.DisplaySolid_Info(soffitManhole[i],"Sewer pipes are aligned on soffit levels.");
			CheckReport.AddRelatedObj(soffit2ndPipe[i], soffit2ndPipe[i]:GetAttri("Name"))
			CheckReport.AddRelatedObj(soffit1stPipe[i], soffit1stPipe[i]:GetAttri("Name"))
		end

		for i=1, #invertManhole,1 do
			FXUtility.DisplaySolid_Info(invertManhole[i],"Sewer pipes are aligned on invert levels.");
			CheckReport.AddRelatedObj(invert2ndPipe[i], invert2ndPipe[i]:GetAttri("Name"))
			CheckReport.AddRelatedObj(invert1stPipe[i], invert1stPipe[i]:GetAttri("Name"))
		end
	end

end

function GetLowestPoint( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local Point
	local dist
	for i=0,(PolyLinePointNumber-2) do
		local tempPoint = (outerEdge:GetPoint(i))
		if( dist == nil or dist > tempPoint.z ) then
			dist = tempPoint.z
			Point = tempPoint
		end
	end
	return Point
end

function GetHighestPoint( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local Point
	local dist
	for i=0,(PolyLinePointNumber-2) do
		local tempPoint = (outerEdge:GetPoint(i))
		if( dist == nil or dist < tempPoint.z ) then
			dist = tempPoint.z
			Point = tempPoint
		end
	end
	return Point
end

function  checkConnectedPipes()
	local flag = true
	local count = FXGroup:new()
	grpManhole:ForEach( function ( Manhole )
		grpPipe:ForEach( function ( Pipe )
			if FXClashDetection.IsCollided(Manhole,Pipe) then
				count:Add(Pipe)
			end
		end)
	end)
	if #count < 2 then
		flag = false
	end
	return flag
end