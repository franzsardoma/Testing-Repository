local Roadside_Drain = FXGroup.new();
local Entrance_Culvert = FXGroup.new();
local Min_Width, Min_Depth;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser( Building )
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_4_3_1_ROADSIDE_DRAIN_DIMENSION")
	local Condition1 = FXRule.ParseValues(parsedXml, "Condition1");
	local Condition2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			Roadside_Drain = Roadside_Drain + v;
			Roadside_Drain = Roadside_Drain:Unique();
		end
		if (k == 3) then
			Entrance_Culvert = Entrance_Culvert + v;
			Entrance_Culvert = Entrance_Culvert:Unique();
		end
	end
	for k,v in pairs(Condition1) do -- get the condition values
		if (k == 3) then
			Min_Width = tonumber(v); -- 300 Minimum Width --
		end
	end
	for k,v in pairs(Condition2) do -- get the condition values
		if (k == 3) then
			Min_Depth = tonumber(v); -- 300 Minimum Length --
		end
	end
end

function CheckRule( Building )
	-- body
	print("Roadside Drain: " .. #Roadside_Drain);
	print("Entrance Culvert: " .. #Entrance_Culvert);
	print("Minimum Width: " .. Min_Width);
	print("Minimum Depth: " .. Min_Depth);

	if (#Roadside_Drain ~= 0 and #Entrance_Culvert ~= 0) then
		-- ROADSIDE DRAIN --
		Roadside_Drain:ForEach(function ( RD )
			-- Depth --
			local CenterLine = FXMeasure.GetProjectionCenterLine(RD);
			local StartPoint = CenterLine:GetStartPoint();
			
			local BOX = FXGeom.GetBoundingBox(RD);
			local BOX_HighPos = BOX:HighPos().z;
			local High_Point3D = Point3D(StartPoint.x, StartPoint.y, BOX_HighPos)
			
			local OBB = FXGeom.GetBoundingOBB(RD);
			local Center_OBB = OBB:GetPos();

			local Point1 = Point3D(StartPoint.x , StartPoint.y, Center_OBB.z);
			local Point2, LinePoint1, Node1;
			local Point3, LinePoint2, Node2;
			local zPoint = 0;
			local zPoint2 = 0;
			local x = 1;

			while (x > 0) do
				zPoint = zPoint + 1;
				Point2 = Point3D(StartPoint.x , StartPoint.y, Center_OBB.z + zPoint);
				LinePoint1 = Line3D(Point1 , Point2);
				Node1 = FXUtility.CreateNodeFrom(LinePoint1);
				
				if (FXClashDetection.IsCollided(Node1 , RD)) then
					FXClashDetection.DeleteNode(Node1);
					break;
				end
				FXClashDetection.DeleteNode(Node1);
			end

			while (x > 0) do
				zPoint2 = zPoint2 + 1;
				Point3 = Point3D(StartPoint.x , StartPoint.y, Center_OBB.z - zPoint2);
				LinePoint2 = Line3D(Point1 , Point3);
				Node2 = FXUtility.CreateNodeFrom(LinePoint2);
				
				if (FXClashDetection.IsCollided(Node2 , RD)) then
					FXClashDetection.DeleteNode(Node2);
					break;
				end
				FXClashDetection.DeleteNode(Node2);
			end

			local POINT3D_LINE = Line3D(Point2 , Point3); -- Final Line Get the Point(POINT2_3D) , Point(POINT3_3D) and convert to line 3D--
			local FINAL_DEPTH = FXUtility.Round(Point2:Distance_Pnt(Point3));
			local DEPTH_ARROW = DoubleArrow(POINT3D_LINE:GetStartPoint(),POINT3D_LINE:GetEndPoint());

			-- Width --
			local DEPTH_CENTERPOINT = FXUtility.CenterPoint(POINT3D_LINE:GetStartPoint(), POINT3D_LINE:GetEndPoint());
			local PROJECTION_CL = FXMeasure.GetProjectionCenterLine(RD);
			local CL_S = PROJECTION_CL:GetStartPoint();
			local CL_E = PROJECTION_CL:GetEndPoint();
			local CL_S_POINT3D = Point3D(CL_S.x , CL_S.y , DEPTH_CENTERPOINT.z);
			local CL_E_POINT3D = Point3D(CL_E.x , CL_E.y , DEPTH_CENTERPOINT.z);
			local CL_POINT3D_LINE = Line3D(CL_S_POINT3D , CL_E_POINT3D);
			local FACE1, NODE3;
			local W1 = 0;
			local j = 1;

			while (j > 0) do
				W1 = W1 + 1;
				FACE1 = FXMeasure.CreateFaceFromEdge(CL_POINT3D_LINE , W1);
				NODE3 = FXUtility.CreateNodeFrom(FACE1);

				if (FXClashDetection.IsCollided(RD, NODE3)) then
					j = j - 1;
					FXClashDetection.DeleteNode(NODE3);
				end
				FXClashDetection.DeleteNode(NODE3);
			end

			local W2 = W1;
			local FACE2 = FXMeasure.CreateFaceFromEdge(CL_POINT3D_LINE, W2);
			local OUTEREDGE = FXMeasure.GetOuterEdge(FACE2);
			local SHORTLINE = SmallestLine1(OUTEREDGE);
			local SHORTLINE_P1 = SHORTLINE:GetStartPoint();
			local SHORTLINE_P2 = SHORTLINE:GetEndPoint();
			local WIDTH_ARROW = DoubleArrow(SHORTLINE_P1, SHORTLINE_P2);
			local FINAL_WIDTH = SHORTLINE:Length();
			
			-- RESULT --
			if (FINAL_WIDTH > Min_Width and FINAL_DEPTH < Min_Depth) then -- if Depth is non compliant only --

					FXUtility.DisplaySolid_Error(RD, "Depth: " .. FINAL_DEPTH .. "mm", DEPTH_ARROW);

			elseif (FINAL_WIDTH < Min_Width and FINAL_DEPTH > Min_Depth) then -- if Width is non compliant only --

					FXUtility.DisplaySolid_Error(RD, "Width: " .. FINAL_WIDTH .. "mm", WIDTH_ARROW);

			elseif (FINAL_WIDTH < Min_Width and FINAL_DEPTH < Min_Depth) then -- if Width and Depth are both non compliant --

					FXUtility.DisplaySolid_Error(RD, "Width: " .. FINAL_WIDTH .. "mm", WIDTH_ARROW);
					FXUtility.DisplaySolid_Error(RD, "Depth: " .. FINAL_DEPTH .. "mm", DEPTH_ARROW);

			elseif (FINAL_WIDTH > Min_Width and FINAL_DEPTH > Min_Depth) then -- both compliant --

					FXUtility.DisplaySolid_Info(RD, "Width: " .. FINAL_WIDTH .. "mm", WIDTH_ARROW);
					FXUtility.DisplaySolid_Info(RD, "Depth: " .. FINAL_DEPTH .. "mm", DEPTH_ARROW);
			end
		end)

		-- ENTRANCE CULVERT --
		Entrance_Culvert:ForEach(function ( EC )
			-- Width --
			local BOX = FXGeom.GetBoundingBox(EC);
			local CL_MID = BOX:MidPos();
			local BOTTOMFACE = FXMeasure.GetBottomFace(EC);
			local SHORTLINE = SmallestLine2(BOTTOMFACE);
			local CL_S = SHORTLINE:GetStartPoint();
			local CL_E = SHORTLINE:GetEndPoint();
			local CL_S_POINT3D = Point3D(CL_S.x , CL_S.y , CL_MID.z);
			local CL_E_POINT3D = Point3D(CL_E.x , CL_E.y , CL_MID.z);
			local CL_POINT3D_LINE = Line3D(CL_S_POINT3D , CL_E_POINT3D);
			local SHRINK_LINE, NODE3;
			local W1 = 0;
			local j = 1;

			while (j > 0) do
				W1 = W1 + 1;
				-- FACE1 = FXMeasure.CreateFaceFromEdge(CL_POINT3D_LINE , W1);
				SHRINK_LINE = FXGFA.ShrinkageLine( CL_POINT3D_LINE,-W1);
				NODE3 = FXUtility.CreateNodeFrom(SHRINK_LINE);
				if  (FXClashDetection.IsCollided(EC, NODE3)) then
					j = j - 1;
					FXClashDetection.DeleteNode(NODE3);
				end
				FXClashDetection.DeleteNode(NODE3);
			end

			local SHORTLINE_P1 = SHRINK_LINE:GetStartPoint();
			local SHORTLINE_P2 = SHRINK_LINE:GetEndPoint();
			local WIDTH_ARROW_EC = DoubleArrow(SHORTLINE_P1, SHORTLINE_P2);
			local FINAL_WIDTH_EC = SHRINK_LINE:Length();
			-- FXUtility.DisplaySolid_Info(EC, "Width: " .. FINAL_WIDTH_EC .. "mm", WIDTH_ARROW_EC);

			-- Depth --
			local WIDTH_CENTERPOINT = FXUtility.CenterPoint(SHORTLINE_P1, SHORTLINE_P2);
			local POINT1_3D_EC = Point3D(WIDTH_CENTERPOINT.x , WIDTH_CENTERPOINT.y, WIDTH_CENTERPOINT.z);
			local POINT2_3D_EC, LINE1_3D_EC, NODE1_EC;
			local POINT3_3D_EC, LINE2_3D_EC, NODE2_EC;
			local D1_EC = 0;
			local D2_EC = 0;
			local i = 1;

			while (i > 0) do
				D1_EC = D1_EC + 1;
				POINT2_3D_EC = Point3D(WIDTH_CENTERPOINT.x , WIDTH_CENTERPOINT.y, WIDTH_CENTERPOINT.z + D1_EC);
				LINE1_3D_EC = Line3D(POINT1_3D_EC , POINT2_3D_EC);
				NODE1_EC = FXUtility.CreateNodeFrom(LINE1_3D_EC);

				if (FXClashDetection.IsCollided(EC, NODE1_EC)) then
					FXClashDetection.DeleteNode(NODE1_EC);
					break;
				end
				FXClashDetection.DeleteNode(NODE1_EC);
			end

			while (i > 0) do
				D2_EC = D2_EC + 1;
				POINT3_3D_EC = Point3D(WIDTH_CENTERPOINT.x , WIDTH_CENTERPOINT.y, WIDTH_CENTERPOINT.z - D2_EC);
				LINE2_3D_EC = Line3D(POINT1_3D_EC , POINT3_3D_EC);
				NODE2_EC = FXUtility.CreateNodeFrom(LINE2_3D_EC);

				if (FXClashDetection.IsCollided(EC, NODE2_EC)) then
					FXClashDetection.DeleteNode(NODE2_EC);
					break;
				end
				FXClashDetection.DeleteNode(NODE2_EC);
			end

			local POINT3D_LINE_EC = Line3D(POINT2_3D_EC , POINT3_3D_EC);
			local FINAL_DEPTH_EC = FXUtility.Round(POINT2_3D_EC:Distance_Pnt(POINT3_3D_EC));
			local DEPTH_ARROW_EC = DoubleArrow(POINT3D_LINE_EC:GetStartPoint(),POINT3D_LINE_EC:GetEndPoint());

			-- CENTER POSITION WIDTH --
			local DEPTH_CENTERPOINT_EC = FXUtility.CenterPoint(POINT3D_LINE_EC:GetStartPoint(), POINT3D_LINE_EC:GetEndPoint());
			local BOTTOMFACE_2 = FXMeasure.GetBottomFace(EC);
			local SHORTLINE_2 = SmallestLine2(BOTTOMFACE_2);
			local CL_S_2 = SHORTLINE_2:GetStartPoint();
			local CL_E_2 = SHORTLINE_2:GetEndPoint();
			local CL_S_POINT3D_2 = Point3D(CL_S_2.x , CL_S_2.y , DEPTH_CENTERPOINT_EC.z);
			local CL_E_POINT3D_2 = Point3D(CL_E_2.x , CL_E_2.y , DEPTH_CENTERPOINT_EC.z);
			local CL_POINT3D_LINE_2 = Line3D(CL_S_POINT3D_2 , CL_E_POINT3D_2);
			local SHRINK_LINE_2, NODE3_2;
			local W2 = 0;
			local k = 1;

			while (k > 0) do
				W2 = W2 + 1;
				SHRINK_LINE_2 = FXGFA.ShrinkageLine(CL_POINT3D_LINE_2,-W2);
				NODE3_2 = FXUtility.CreateNodeFrom(SHRINK_LINE_2);

				if(FXClashDetection.IsCollided(EC, NODE3_2)) then
					k = k - 1;
					FXClashDetection.DeleteNode(NODE3_2);
				end
				FXClashDetection.DeleteNode(NODE3_2);
			end

			local SHORTLINE_P1_2 = SHRINK_LINE_2:GetStartPoint();
			local SHORTLINE_P2_2 = SHRINK_LINE_2:GetEndPoint();
			local WIDTH_ARROW_EC_2 = DoubleArrow(SHORTLINE_P1_2, SHORTLINE_P2_2);
			local FINAL_WIDTH_EC_2 = SHRINK_LINE_2:Length();


			-- FXUtility.DisplaySolid_Info(EC, "Width: " .. FINAL_WIDTH_EC_2 .. "mm", WIDTH_ARROW_EC_2);
			-- FXUtility.DisplaySolid_Info(EC, "Depth: " .. FINAL_DEPTH_EC .. "mm", DEPTH_ARROW_EC);
			-- RESULT --
			if (FINAL_WIDTH_EC_2 > Min_Width and FINAL_DEPTH_EC < Min_Depth) then -- if Depth is non compliant only --

					FXUtility.DisplaySolid_Error(EC, "Depth: " .. FINAL_DEPTH_EC .. "mm", DEPTH_ARROW_EC);

			elseif (FINAL_WIDTH_EC_2 < Min_Width and FINAL_DEPTH_EC > Min_Depth) then -- if Width is non compliant only --

					FXUtility.DisplaySolid_Error(EC, "Width: " .. FINAL_WIDTH_EC_2 .. "mm", WIDTH_ARROW_EC_2);

			elseif (FINAL_WIDTH_EC_2 < Min_Width and FINAL_DEPTH_EC < Min_Depth) then -- if Width and Depth are both non compliant --

					FXUtility.DisplaySolid_Error(EC, "Width: " .. FINAL_WIDTH_EC_2 .. "mm", WIDTH_ARROW_EC_2);
					FXUtility.DisplaySolid_Error(EC, "Depth: " .. FINAL_DEPTH_EC .. "mm", DEPTH_ARROW_EC);

			elseif (FINAL_WIDTH_EC_2 > Min_Width and FINAL_DEPTH_EC > Min_Depth) then -- both compliant --

					FXUtility.DisplaySolid_Info(EC, "Width: " .. FINAL_WIDTH_EC_2 .. "mm", WIDTH_ARROW_EC_2);
					FXUtility.DisplaySolid_Info(EC, "Depth: " .. FINAL_DEPTH_EC .. "mm", DEPTH_ARROW_EC);
			end

		end)

	else
		FXUtility.DisplaySolid_Warning(Building, "Roadside Drain is not provided.");
		FXUtility.DisplaySolid_Warning(Building, "Entrance Culvert is not provided.");
	end
end

-- To Get the smallest line in the Projection --
function SmallestLine1( line )
	local LinePointNumber = line:GetPointNumber();
	local dist;

	for i=0,(LinePointNumber-2) do
		local Point1 = line:GetPoint(i)
		local Point2 = line:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

-- To Get the smallest line in the Projection --
function SmallestLine2( line )
	local edge = FXMeasure.GetOuterEdge(line);
	local LinePointNumber = edge:GetPointNumber();
	local dist;

	for i=0,(LinePointNumber-2) do
		local Point1 = edge:GetPoint(i)
		local Point2 = edge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end