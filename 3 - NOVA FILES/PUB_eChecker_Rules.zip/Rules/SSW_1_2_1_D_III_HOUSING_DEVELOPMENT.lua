local grpSewerConns = FXGroup:new();
local grpPublicSewers = FXGroup:new();
local grpJunctions = FXGroup:new();
local grpManhole = FXGroup:new();
local grpLots = FXGroup:new();
local conValue_Junction;
local conValue_Manhole;
local PipeDrainLineDIS = "Main Drain Line";
local SewerConnValues
local PublicSewerValues
local HousingUnitValues
local operatorJunction
local operatorManhole1
local operatorManhole2
local ManholeValues = {}
local JunctionValues = {}
local ManholeValuesString
local JunctionValuesString

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_1_D_III_HOUSING_DEVELOPMENT")
	
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpSewerConns = grpSewerConns + v;
				grpSewerConns = grpSewerConns:Unique();
			end
			if (k == 3) then
				grpPublicSewers = grpPublicSewers + v;
				grpPublicSewers = grpPublicSewers:Unique();
			end
			if (k == 4) then
				grpJunctions = grpJunctions + v;
				grpJunctions = grpJunctions:Unique();
			end
			if (k == 5) then
				grpManhole = grpManhole + v;
				grpManhole = grpManhole:Unique();
			end
		end
	end
	grpLots = grpLots + GrpObjsBuilding[6]
	grpLots = grpLots:Unique();

	local Values1 = {}
	local Values2 = {}
	local Values5 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
			if(k == 2) then
				table.insert(Values2, v1["value"])
			end
			if(k == 3) then
				table.insert(JunctionValues, v1["value"])
			end
			if(k == 4) then
				table.insert(ManholeValues, v1["value"])
			end
			if(k == 5) then
				table.insert(Values5, v1["value"])
			end
		end
	end

	SewerConnValues = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			SewerConnValues = SewerConnValues.." or "..v
		end
	end

	PublicSewerValues = Values2[1]
	for k,v in pairs(Values2) do
		if k ~= 1 then
			PublicSewerValues = PublicSewerValues.." or "..v
		end
	end

	HousingUnitValues = Values5[1]
	for k,v in pairs(Values5) do
		if k ~= 1 then
			HousingUnitValues = HousingUnitValues.." or "..v
		end
	end

	ManholeValuesString = ManholeValues[1]
	for k,v in pairs(ManholeValues) do
		if k ~= 1 then
			ManholeValuesString = ManholeValuesString.." or "..v
		end
	end

	JunctionValuesString = JunctionValues[1]
	for k,v in pairs(JunctionValues) do
		if k ~= 1 then
			JunctionValuesString = JunctionValuesString.." or "..v
		end
	end

	operatorJunction = ConditionValues1[2]
	conValue_Junction = tonumber(ConditionValues1[3]);
	conValue_Manhole = tonumber(ConditionValues2[5]);
	operatorManhole1 = ConditionValues2[2]
	operatorManhole2 = ConditionValues2[4]
end

function checkRule( Building )
	local flag = true;
	local grpFlowFittings = Building:GetDescendants("FlowFitting")
	local grpConn = grpJunctions + grpManhole;

	grpFlowFittings:ForEach(function ( FittingEle )
		if (FXUtility.HasPatterInString(FittingEle:GetAttri("ObjectType"),"Tee Junction")) then
			grpConn:Add(FittingEle);
		end
	end)
	-- print(#grpLots)
	if (#grpLots == 0) then
		CheckReport.Warning( Building, HousingUnitValues.." is not provided." )
		flag = false;
	end
	-- print(#grpSewerConns)
	if (#grpSewerConns == 0) then
		CheckReport.Warning( Building, SewerConnValues.." is not provided." )
		flag = false;
	end
	-- print(#grpPublicSewers)
	if (#grpPublicSewers== 0) then
		CheckReport.Warning( Building, PublicSewerValues.." is not provided." )
		flag = false;
	end
	-- print(#grpConn)
	if (#grpConn == 0) then
		CheckReport.Warning( Building, "Junction or Manhole is not provided." )
		flag = false
	end
-- flag = false;
	if (flag) then
		local grpFlowSegments = Building:GetDescendants("FlowSegment")
		local grpDrainLines = FXGroup:new();
		local grpChambers = Building:GetDescendants("DistributionChamberElement")
		local grpInspectionChambers = FXGroup:new();
		local grpMinorSewers = FXGroup:new();

		grpChambers:ForEach(function ( ChamberEle )
			if (FXUtility.HasPatterInString(ChamberEle:GetAttri("ObjectType"),"Inspection Chamber")) then
				grpInspectionChambers:Add(ChamberEle);
				grpInspectionChambers = grpInspectionChambers:Unique();
			end
		end)
		-- print(#grpInspectionChambers)
		grpFlowSegments:ForEach(function ( FlowSegmentEle )
			if (FXUtility.HasPatterInString(FlowSegmentEle:GetAttri("ObjectType"),PipeDrainLineDIS)) then
				grpDrainLines:Add(FlowSegmentEle);
				grpDrainLines = grpDrainLines:Unique();
			end
		end)

		grpFlowSegments:ForEach(function ( FlowSegmentEle )
			if (FXUtility.HasPatterInString(FlowSegmentEle:GetAttri("ObjectType"),"Minor Sewer")) then
				grpMinorSewers:Add(FlowSegmentEle);
				grpMinorSewers = grpMinorSewers:Unique();
			end
		end)

		local grpConnObjs = getConnectionToPublicSewer(grpConn, (grpFlowFittings - grpConn) + ((((grpFlowSegments - grpSewerConns) - grpPublicSewers) - grpDrainLines) - grpMinorSewers))
		
		if(grpConnObjs ~= nil) then
			local flowObjs = (((( grpFlowSegments + grpInspectionChambers + grpFlowFittings) - grpConnObjs) - grpPublicSewers) - grpDrainLines )
			local ARRCconnObjManhole = {}
			local ARRCnumLotManhole = {}
			local ARRCconnObjJunction = {}
			local ARRCnumLotJUnction = {}
			local isErrorNotFound = true

			grpConnObjs:ForEach(function ( connObj )
				local numLot = 0;
				grpLots:ForEach(function ( LotEle )
					grpDrainLines:ForEach(function ( DrainLineEle )
						if (FXClashDetection.IsCollided(LotEle, DrainLineEle)) then
							if(CheckObjsConn(connObj, DrainLineEle, flowObjs)) then
								numLot = numLot + 1
								print("dsads")
							end
						end
					end)
				end)
				
				if HasValue(connObj:GetAttri("ObjectType"),ManholeValues) then
					if(FXRule.EvaluateNumber( operatorManhole1 , numLot, conValue_Manhole) or FXRule.EvaluateNumber( operatorManhole2 , numLot , conValue_Manhole)) then
						table.insert(ARRCconnObjManhole, connObj)
						table.insert(ARRCnumLotManhole, numLot)
					else
						isErrorNotFound = false
						FXUtility.DisplaySolid_Error( connObj, "Housing Unit = "..numLot.."; "..ManholeValuesString.." is not provided.")
						CheckReport.AddRelatedObj(connObj, connObj:GetAttri("ObjectType"));
					end
				elseif HasValue(connObj:GetAttri("ObjectType"),JunctionValues) then
					if FXRule.EvaluateNumber( operatorJunction , numLot, conValue_Junction) then
						table.insert(ARRCconnObjJunction, connObj)
						table.insert(ARRCnumLotJUnction, numLot)
					else
						isErrorNotFound = false
						FXUtility.DisplaySolid_Error( connObj, "Housing Unit = "..numLot.."; "..JunctionValuesString.." is not provided." )
						CheckReport.AddRelatedObj(connObj, connObj:GetAttri("ObjectType"));
					end
				else
					if FXRule.EvaluateNumber( operatorJunction , numLot, conValue_Junction) then
						isErrorNotFound = false
						FXUtility.DisplaySolid_Error( connObj, "Housing Unit = "..numLot.."; "..JunctionValuesString.." is not provided." )
						CheckReport.AddRelatedObj(connObj, connObj:GetAttri("ObjectType"));
					else
						isErrorNotFound = false
						FXUtility.DisplaySolid_Error( connObj, "Housing Unit = "..numLot.."; "..ManholeValuesString.." is not provided.")
						CheckReport.AddRelatedObj(connObj, connObj:GetAttri("ObjectType"));
					end
				end
			end)

			if isErrorNotFound then
				for k,connObj in pairs(ARRCconnObjManhole) do
					FXUtility.DisplaySolid_Compliant( connObj, "Housing Unit = "..ARRCnumLotManhole[k].."; "..connObj:GetAttri("ObjectType").." is provided" )
					CheckReport.AddRelatedObj(connObj, connObj:GetAttri("ObjectType"));
				end
				for k,connObj in pairs(ARRCconnObjJunction) do
					FXUtility.DisplaySolid_Compliant( connObj, "Housing Unit = "..ARRCnumLotJUnction[k].."; "..connObj:GetAttri("ObjectType").." is provided" )
					CheckReport.AddRelatedObj(connObj, connObj:GetAttri("ObjectType"));
				end
			end
		end
	end
end

function getConnectionToPublicSewer( grpConn, grpFlowFittings )
	local Obj = FXGroup:new();

	grpConn:ForEach(function ( ConnEle )
		grpSewerConns:ForEach(function ( SewerEle )
			if(CheckObjsConn(ConnEle, SewerEle, grpFlowFittings))then
				grpPublicSewers:ForEach(function ( PublicSewerEle )
					if(CheckObjsConn(PublicSewerEle, ConnEle, grpFlowFittings))then
						Obj:Add(ConnEle);
					end
				end)
			end
		end)
	end)
	return Obj;
end

function CheckObjsConn( obj1, obj2, grpFlowObjs ) -- check if obj2 is connected to obj1 through FlowObjs(third parameter)
	local flag = false
	local connectedFlowObjs = FXGroup:new();
	if(FXClashDetection.IsCollided(obj1,obj2))then
		flag = true
	elseif (FXUtility.HasPatterInString(obj1.Type,"DistributionChamberElement") and FXUtility.HasPatterInString(obj2.Type,"FlowFitting")) then
		if (FXRelation.Distance(obj2, obj1):Length() <= 0.5) then
			flag = true;
			return;
		end
	end
	grpFlowObjs:ForEach(function ( FlowEle )
		if flag == true then
			return;
		end
		if(FXClashDetection.IsCollided(FlowEle,obj2))then
			if (FXUtility.HasPatterInString(obj1.Type,"DistributionChamberElement") and FXUtility.HasPatterInString(FlowEle.Type,"FlowFitting")) then
				if (FXRelation.Distance(FlowEle, obj1):Length() <= 0.5) then
					flag = true;
					return;
				end
			end
			if (FXClashDetection.IsCollided(FlowEle, obj1)) then
				
				flag = true;
				return;
			end
			connectedFlowObjs:Add(FlowEle);
		end
	end)
	if flag == false then
		grpFlowObjs = grpFlowObjs - connectedFlowObjs;
		connectedFlowObjs:ForEach(function ( connObj )
			if flag == true then
				return;
			end
			if (CheckObjsConn( obj1, connObj, grpFlowObjs )) then
				flag = true;
			end
		end)
	end
	return flag;
end

function HasValue( val, tab )
    for index, value in pairs(tab) do
        if (FXUtility.HasPatterInString(value,val)) then
            return true
        end
    end
    return false
end