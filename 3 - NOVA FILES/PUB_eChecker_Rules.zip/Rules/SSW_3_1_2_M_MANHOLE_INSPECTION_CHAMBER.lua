--[[
	Modefied by: Jayson Barateta 07-01-2019
	---------------------------------------
	Changes on line 40-41 and 47-53.
]]

local flowSegmentGrp 		= FXGroup.new();
local manholeGrp 			= FXGroup.new();
local inspectionChamberGrp 	= FXGroup.new();
local systemTypes;
local minDiameter 			= 200; 
local isErrorFound = false ;
local x = 0;
local comPipe = {};
local comPipeName = {};
local comPipeDesc = {};
local comDiam = {};
local comObjType = {};


function main()
	CheckEngine.SetCheckType("Site")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Site)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_2_M_MANHOLE_INSPECTION_CHAMBER")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1"); -- parse the condition values
	minDiameter = tonumber(ConditionValues[3])
	
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Site, systemTypes)

	local Building = Site:GetChildren("Building");
	local GrpObjs = FXGroup.new();
	Building:ForEach(function(bldg)
		GrpObjs = FXRule.filterObjects(parsedXml, bldg); -- parse objects using the function in FXRule.lua
	end)

	for k,v in pairs(GrpObjs) do -- get the model objects
		if (k == 3) then
			flowSegmentGrp = flowSegmentGrp + v;
		end
	end
	
	if xmlObjs ~= nil then
		for k,v in pairs(xmlObjs) do -- get the model objects
			if (k == 2) then
				manholeGrp = manholeGrp + v;
				manholeGrp = manholeGrp:Unique();
			end			
			if (k == 4) then
				inspectionChamberGrp = inspectionChamberGrp + v;
				inspectionChamberGrp = inspectionChamberGrp:Unique();
			end
		end
	end
end
function getChambers(Building)
	print (minDiameter)
	local chamberGrp = FXGroup.new();
	local grp = Building:GetDescendants("DistributionChamberElement")
	grp:ForEach(function(obj)
		if FXUtility.HasPatterInString(obj:GetAttri("Name"), "Inspection Chamber") then
			chamberGrp:Add(obj);
		end
	end)

	return chamberGrp
end

function checkRule(Building)
	if #manholeGrp ~= 0 and #inspectionChamberGrp ~= 0 then
		local connPipes = FXGroup.new()
		local chamberGrp = getChambers(Building)
		if #flowSegmentGrp > 0 then
			flowSegmentGrp:ForEach(function(pipe)
				local pipeName = pipe:GetAttri("Name");
				local pipeDesc = pipe:GetAttri("Description");
				local pipeObjType = pipe:GetAttri("ObjectType");
				local pipeDiameter = FXUtility.Round(pipe:GetAuxAttri("Mechanical.Diameter"),2)

				if ((FXUtility.HasPatterInString(pipeName, "PVC") or 
					FXUtility.HasPatterInString(pipeObjType, "PVC"))) then
					FXUtility.DisplaySolid_Error(pipe,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. pipeDiameter .. " mm; " .. pipeObjType);
					isErrorFound = true;
					-- CheckReport.AddRelatedObj( pipe, pipeName )
					return false
				else
					-- check if passed in minimum diameter
					if pipeDiameter >=  minDiameter then
						x = x + 1;
						comPipe[x] = pipe;
						comPipeDesc[x] = pipeDesc;
						comPipeName[x] = pipeName;
						comDiam[x] = pipeDiameter;
						comObjType[x] = pipeObjType;
						-- CheckReport.AddRelatedObj( pipe, pipeName )
					else
						FXUtility.DisplaySolid_Error(pipe,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. pipeDiameter .. " mm; " .. pipeObjType);
						isErrorFound = true;
						-- CheckReport.AddRelatedObj( pipe, pipeName )
					end
				end
			end)

			if isErrorFound == false then
				local y = 1;
				while y ~= x+1 do
					FXUtility.DisplaySolid_Info(comPipe[y],comPipeDesc[y] .. " " ..  comPipeName[y] .. ": Diameter = " .. comDiam[y] .. " mm; " .. comObjType[y]);
					y = y + 1;
				end
			end
			-- local isConnectManhole = false;
			-- -- checking for connection to manhole
			-- manholeGrp:ForEach(function(manhole)
			-- 	flowSegmentGrp:ForEach(function(prevPipe)
			-- 		local connObjs = FXGroup.new();
			-- 		local connFitting = prevPipe:GetConnectedFitting();
			-- 		connObjs:Add(prevPipe)
			-- 		if #connFitting ~= 0 then
			-- 			connObjs  = connObjs + connFitting
			-- 			connFitting:ForEach(function(fitting)
			-- 				local newPipes = fitting:GetConnectedSegment();
			-- 				connObjs  = connObjs + newPipes
			-- 			end)
			-- 			connObjs = connObjs:Unique()
			-- 			DisplayTest(prevPipe, #connObjs)
			-- 			connObjs:ForEach(function(obj)
			-- 				local manholeOBB = FXGeom.GetBoundingOBB(manhole)
			-- 				local manholeNode = FXUtility.CreateNodeFrom(manholeOBB);
			-- 				if FXClashDetection.IsCollided(manholeNode,obj) then
			-- 					isConnectManhole = true
			-- 				end
			-- 				FXClashDetection.DeleteNode(manholeNode);
			-- 			end)
			-- 		else
			-- 			local manholeOBB = FXGeom.GetBoundingOBB(manhole)
			-- 			local manholeNode = FXUtility.CreateNodeFrom(manholeOBB);
			-- 			if FXClashDetection.IsCollided(manholeNode,obj) then
			-- 				isConnectManhole = true
			-- 			end
			-- 			FXClashDetection.DeleteNode(manholeNode);
			-- 		end
			-- 		return false
			-- 	end)
			-- end)
			-- local isConnectIC = false;
			-- -- checking for connection to IC
			-- inspectionChamberGrp:ForEach(function(inspectionChamber)
			-- 	flowSegmentGrp:ForEach(function(prevPipe)
			-- 		local connObjs = FXGroup.new();
			-- 		local connFitting = prevPipe:GetConnectedFitting();
			-- 		connObjs:Add(prevPipe)
			-- 		if #connFitting ~= 0 then
			-- 			connObjs  = connObjs + connFitting
			-- 			connFitting:ForEach(function(fitting)
			-- 				local newPipes = fitting:GetConnectedSegment();
			-- 				connObjs  = connObjs + newPipes
			-- 			end)
			-- 			connObjs = connObjs:Unique()
			-- 			DisplayTest(prevPipe, #connObjs)
			-- 			connObjs:ForEach(function(obj)
			-- 				local icOBB = FXGeom.GetBoundingOBB(inspectionChamber)
			-- 				local icNode = FXUtility.CreateNodeFrom(icOBB);
			-- 				if FXClashDetection.IsCollided(icNode,obj) then
			-- 					isConnectIC = true
			-- 				end
			-- 				FXClashDetection.DeleteNode(icNode);
			-- 			end)
			-- 		else
			-- 			local icOBB = FXGeom.GetBoundingOBB(inspectionChamber)
			-- 			local icNode = FXUtility.CreateNodeFrom(icOBB);
			-- 			if FXClashDetection.IsCollided(icNode,obj) then
			-- 				isConnectIC = true
			-- 			end
			-- 			FXClashDetection.DeleteNode(icNode);
			-- 		end
			-- 		return false
			-- 	end)
			-- end)
			-- print(isConnectManhole)
			-- print(isConnectIC)
			-- if isConnectManhole and isConnectIC then
			-- 	print("YES")
			-- 	CheckPipeDiameter( pipe )
			-- end

		else
			FXUtility.DisplaySolid_Warning(Building,"No Sewer Connection found.")
		end
	else
		-- FXUtility.DisplaySolid_Warning(Building,"No Inspection Chamber/Manhole to check.")
		FXUtility.DisplaySolid_Warning(Building,"No Inspection Chamber/Manhole connected.")
	end
end
-- function CheckPipeDiameter( pipe )
-- 	local pipeName = pipe:GetAttri("Name");
-- 	local pipeDesc = pipe:GetAttri("Description");
-- 	local pipeObjType = pipe:GetAttri("ObjectType");
-- 	local pipeDiameter = FXUtility.Round(pipe:GetAuxAttri("Mechanical.Diameter"),2)

-- 	if ((FXUtility.HasPatterInString(pipeName, "PVC") or 
-- 		FXUtility.HasPatterInString(pipeObjType, "PVC"))) then
-- 		FXUtility.DisplaySolid_Error(pipe,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. pipeDiameter .. " mm; " .. pipeObjType);
-- 		-- CheckReport.AddRelatedObj( pipe, pipeName )
-- 		return false
-- 	else
-- 		-- check if passed in minimum diameter
-- 		if pipeDiameter >=  minDiameter then
-- 			FXUtility.DisplaySolid_Info(pipe,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. pipeDiameter .. " mm; " .. pipeObjType);
-- 			-- CheckReport.AddRelatedObj( pipe, pipeName )
-- 		else
-- 			FXUtility.DisplaySolid_Error(pipe,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. pipeDiameter .. " mm; " .. pipeObjType);
-- 			-- CheckReport.AddRelatedObj( pipe, pipeName )
-- 		end
-- 	end
-- end

function DisplayTest(obj1, msg, geom)
	FXUtility.DisplaySolid_Warning(obj1, msg, geom);
end