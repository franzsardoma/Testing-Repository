local SystemType;
local SpaceName = "swimming pool";
local StorageDeviceName = "balancing tank";
local minDist = 300;
local grpFlowSegment = FXGroup:new();
local isPassedPool = true;
local isPassedStorage = true;
local Element1 = FXGroup.new();
local Element2 = FXGroup.new();
local offset;
local checkBox1;
local checkBox2;


function main()
	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("System")
	CheckEngine.BindCheckFunc("getSystems")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckResult");
	CheckEngine.RunCheckPipeline();
end

function script_path() -- get the parent path of the lua files
    local str = debug.getinfo(2, "S").source:sub(2)
	local str2 = string.gsub(str,str:match("^.*/(.*).lua$")..".lua","")
	local str3 = string.gsub(str2,"/Rules","")
	return string.gsub(str3,"/","\\")
end 


function XMLParser(Storey)
	local myfile = io.open(script_path().."HTML\\SSW_3_2_2_G_SWIMMING_POOLS.html", "r"); --open the html file
	local tempTxt = "";
	for line in myfile:lines() do
		if( line ~= nil ) then
			tempTxt = tempTxt..line;
		end
	end
	local xmlTxt = string.match(tempTxt,'<%?xml.*</FORMPARAMETER>') -- get the xml part embedded in the html file
	local xml = newParser();
	local parsedXml = xml:ParseXmlText(xmlTxt); -- parse xml
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Storey); -- parse objects using the function in FXRule.lua
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	

	for k,v in pairs(SystemTypes) do --if only 1 system type is checked
		SystemType = v;
	end

	for k,v in pairs(ConditionValues) do -- get the condition values
		if (k == 1) then
			offset = v;
		elseif (k == 2) then
			checkBox1 = v;
		elseif (k == 3) then
			checkBox2 = v;
		end
	end
	
	for k,v in pairs(GrpObjs) do -- get the model objects
		v:ForEach(function(obj)
			if (k == 5) then
				Element1:Add(obj);
			end
			if (k == 6) then
				Element2:Add(obj);
			end
		end)
	end
end

function getSystems(system)

	local name = system:GetAttri("Name");
	bRet = FXRule.EvaluateString("Contains", string.lower(name), SystemType);
	if not bRet then
		return;
	end
	
	local flowSegments = system:GetDescendants("FlowSegment");
	grpFlowSegment = grpFlowSegment + flowSegments;
	
end

function checkRule(Building)

	-- local grpSpaces = Building:GetDescendants("Space");
	local strName;

	Element2:ForEach(function (element)
		local tempName;
		if (element.Type == "Space") then
			strName = "LongName"
		else
			strName = "Name"
		end
		-- bRet = FXRule.EvaluateString("Contains", string.lower(tempName), SpaceName);
		-- if not bRet then
		-- 	return;
		-- end
		Element1:ForEach(function (FlowSegment)
			if element ~= nil and FlowSegment ~= nil then
				if( isPassedPool  ) then
					isPassedPool = compareObjs(element, FlowSegment, strName);
				else
					compareObjs(element, FlowSegment, strName);
				end
			end
		end)
	end)
	
	-- strName = "Name";
	-- local grpStorageDevices = Building:GetDescendants("FlowStorageDevice");
	-- grpStorageDevices:ForEach(function (FlowStorageDevice)
	-- 	local tempName = FlowStorageDevice:GetAttri(strName);
	-- 	bRet = FXRule.EvaluateString("Contains", string.lower(tempName), StorageDeviceName);
	-- 	if not bRet then
	-- 		return;
	-- 	end

	-- 	grpFlowSegment:ForEach(function (FlowSegment)
	-- 		if FlowStorageDevice ~= nil and FlowSegment ~= nil then
	-- 			if isPassedStorage then
	-- 				isPassedStorage = compareObjs(FlowStorageDevice, FlowSegment, strName);
	-- 			else
	-- 				compareObjs(FlowStorageDevice, FlowSegment, strName);
	-- 			end
	-- 		end
	-- 	end)
	-- end)
	
end

function CheckResult(Building)
	
	if isPassedPool then
		FXUtility.DisplaySolid_Info(Building, "No Sanitary Pipe above Swimming Pool");
	end
	
	if isPassedStorage then
		FXUtility.DisplaySolid_Info(Building, "No Sanitary Pipe above Balancing Tank");
	end

end

function compareObjs(Space, FlowSegment, strName)

	local obb1 =  FXGeom.GetBoundingOBB(Space);
	local zValue1 = obb1:MinPnt().z;
	local obb2 =  FXGeom.GetBoundingOBB(FlowSegment);
	local zValue2 = obb2:MinPnt().z;
			
	if zValue1 > zValue2 then
		--FXUtility.DisplaySolid_Warning(Space, FlowSegment:GetAttri("Name")..Space:GetAttri(strName));
		--CheckReport.AddRelatedObj(Space, Space.Id);
		--CheckReport.AddRelatedObj(FlowSegment, FlowSegment.Id);
		return false;
	end

	local isPassed = true;
	local isOverlap = FXRelation.IsOverlap(Space, FlowSegment);
	if isOverlap == -1 then
		isPassed = false;
		FXUtility.DisplaySolid_Error(Space, FlowSegment:GetAttri("Name").." is above "..Space:GetAttri(strName));
		CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("Name"));
	else
		local nodeContainer	= FXUtility.CreateNodeFrom(obb1);
		local SpaceProj =  FXMeasure.GetObjProjection(nodeContainer, 0.0);
		local FlowSegmentProj =  FXMeasure.GetObjProjection(FlowSegment, 0.0);
		
		if( SpaceProj ~= nil and FlowSegmentProj ~=  nil ) then
			SpaceProj = FXMeasure.MoveProjection(SpaceProj,0);
			FlowSegmentProj = FXMeasure.MoveProjection(FlowSegmentProj,0)
			local node1		= FXUtility.CreateNodeFrom(SpaceProj);
			local node2		= FXUtility.CreateNodeFrom(FlowSegmentProj);

			local distance =  FXRelation.Distance(node1, node2);				
			if distance:Length() < minDist then
				isPassed = false;
				FXUtility.DisplaySolid_Error(Space, FlowSegment:GetAttri("Name").." is above "..Space:GetAttri(strName));
				CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("Name"));
			end			
			FXClashDetection.DeleteNode(node1);
			FXClashDetection.DeleteNode(node2);
		end
		
		FXClashDetection.DeleteNode(nodeContainer);
	end
	
	return isPassed;
end