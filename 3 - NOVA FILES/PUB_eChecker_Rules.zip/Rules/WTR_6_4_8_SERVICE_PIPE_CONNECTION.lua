local grpServicePipes = FXGroup:new();
local grpDistributingPipes = FXGroup:new();
local grpTanks = FXGroup:new();
local ServiceTab = {}
local DistributingTab = {}
local ServiceTabVal
local DistTabVal
local ServiceProperty
local DistProperty

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_4_8_SERVICE_PIPE_CONNECTION")
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpServicePipes = grpServicePipes + v;
				grpServicePipes = grpServicePipes:Unique();
			end
			if (k == 3) then
				grpDistributingPipes = grpDistributingPipes + v;
				grpDistributingPipes = grpDistributingPipes:Unique();
			end
		end
	end
	
	local tblValues = FXRule.filterTableValues(parsedXml, proj);

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(ServiceTab, v1["value"])
				ServiceProperty = (v1["property"])
			end
			if(k == 2) then
				table.insert(DistributingTab, v1["value"])
				DistProperty = (v1["property"])
			end
		end
	end

	ServiceTabVal = ServiceTab[1]
	for k,v in pairs(ServiceTab) do
		if k ~= 1 then
			ServiceTabVal = ServiceTabVal.." or "..v
		end
	end

	DistTabVal = DistributingTab[1]
	for k,v in pairs(DistributingTab) do
		if k ~= 1 then
			DistTabVal = DistTabVal.." or "..v
		end
	end
end

function CheckWarning( Building )
	local flag = true
	if(#grpServicePipes == 0) then
		flag = false	
		CheckReport.Warning( Building, ServiceTabVal.." is not provided.")
	end
	if(#grpDistributingPipes == 0) then
		flag = false	
		CheckReport.Warning( Building, DistTabVal.." is not provided.")
	end		
	return flag;
end

function checkRule( Building )

	if(CheckWarning(Building)) then
		local IsErrorNotFound = true
		local ARRConnServPipe = {}
		local ARRgrpConnFlows = {}
		local grpTanks = FXGroup:new()
		local grpStorage = Building:GetDescendants("FlowStorageDevice")
		
		grpStorage:ForEach(function ( Storage )
			if (FXUtility.HasPatterInString(Storage:GetAttri("ObjectType"),"Tank")) then
				grpTanks:Add(Storage)
			end
		end)
		
		grpTanks:ForEach(function ( Tank )
			local grpConnServPipes = getConnectedServicePipes( Tank )
			
			grpConnServPipes:ForEach(function ( ConnServPipe )
				local grpConnFlows = getConnFlows(ConnServPipe, Tank)
				local grpConnDistriPipes, grpEX = getConnDistributingPipes(grpConnFlows)

				if(#grpConnDistriPipes ~= 0) then
					IsErrorNotFound = false
					grpConnDistriPipes:ForEach(function ( ConnDistriPipe )
						local grpConnDistFlows = getConnFlowsDISTIBUTINGPIPE(ConnDistriPipe, ConnServPipe, grpEX)

						FXUtility.DisplaySolid_Error( ConnDistriPipe, ConnDistriPipe:GetAttri(DistProperty).." is connected to distributing pipe." )
						CheckReport.AddRelatedObj( ConnDistriPipe, ConnDistriPipe:GetAttri(DistProperty) )
						grpConnDistFlows:ForEach(function ( ConnDistFlow )
							CheckReport.AddRelatedObj( ConnDistFlow, ConnDistFlow:GetAttri(DistProperty) )
						end)
					end)
				else
					table.insert(ARRConnServPipe, ConnServPipe)
					table.insert(ARRgrpConnFlows, grpConnFlows)
					-- FXUtility.DisplaySolid_Info( ConnServPipe, ConnServPipe:GetAttri(ServiceProperty).." is not connected to distributing pipe." )
					-- CheckReport.AddRelatedObj( ConnServPipe, ConnServPipe:GetAttri(ServiceProperty) )
					-- grpConnFlows:ForEach(function ( ConnFlow )
					-- 	CheckReport.AddRelatedObj( ConnFlow, ConnFlow:GetAttri(ServiceProperty) )
					-- end)
				end
			end)
		end)

		if IsErrorNotFound then
			for k,ConnServPipe in pairs(ARRConnServPipe) do
				FXUtility.DisplaySolid_Info( ConnServPipe, ConnServPipe:GetAttri(ServiceProperty).." is not connected to distributing pipe." )
				CheckReport.AddRelatedObj( ConnServPipe, ConnServPipe:GetAttri(ServiceProperty) )
				ARRgrpConnFlows[k]:ForEach(function ( ConnFlow )
					CheckReport.AddRelatedObj( ConnFlow, ConnFlow:GetAttri(ServiceProperty) )
				end)
			end
		end
	end
end

function getConnectedServicePipes( Tank )
	local grpObjs = FXGroup:new()
	local grpConnPipes = Tank:GetConnectedElement();

	grpConnPipes:ForEach(function ( ConnPipe )
		if HasValue(ConnPipe:GetAttri(ServiceProperty),ServiceTab) then
			grpObjs:Add(ConnPipe)
		end
	end)
	return grpObjs;
end

function getConnFlows( CurrObj, PrevObj )
	local grpObjs = FXGroup:new()
	grpObjs:Add(CurrObj)
	if(PrevObj == nil) then
		return;
	end

	local grpConnObjs = CurrObj:GetConnectedElement();
	grpConnObjs:Sub(PrevObj)

	grpConnObjs:ForEach(function ( ConnObjEle )
		if HasValue(ConnObjEle:GetAttri(DistProperty),DistributingTab) == false then
			grpObjs = grpObjs + getConnFlows( ConnObjEle, CurrObj )
		end
	end)
	return grpObjs;
end

function getConnDistributingPipes( grpConnFlows ) -------------this function will get all Distributing pipes that connected on service pipes
	local grpObjs = FXGroup:new()
	local gepObjs2 = FXGroup:new()

	grpConnFlows:ForEach(function ( ConnFlow )
		local grpConnObjs = ConnFlow:GetConnectedElement();
		grpConnObjs:ForEach(function ( ConnObj )
			if HasValue(ConnObj:GetAttri(DistProperty),DistributingTab) then
				grpObjs:Add(ConnObj)
				gepObjs2:Add(ConnFlow)
			end
		end)
	end)
	return grpObjs, gepObjs2;
end

function getConnFlowsDISTIBUTINGPIPE( CurrObj, PrevObj, grpEX )
	local grpObjs = FXGroup:new()
	grpObjs:Add(CurrObj)
	if(PrevObj == nil) then
		return;
	end

	local grpConnObjs = CurrObj:GetConnectedElement();
	grpConnObjs = grpConnObjs - grpEX;
	grpConnObjs:Sub(PrevObj)
	-- print(#grpConnObjs)
	if(#grpConnObjs == 1) then
		grpConnObjs:ForEach(function ( ConnObjEle )
			if (HasValue(ConnObjEle:GetAttri(DistProperty),DistributingTab) or FXUtility.HasPatterInString(ConnObjEle.Type,"FlowFitting")) then
				grpObjs = grpObjs + getConnFlowsDISTIBUTINGPIPE( ConnObjEle, CurrObj, grpEX )
			end
		end)
	end
	return grpObjs;
end

function HasValue( val, tab )
    for index, value in pairs(tab) do
        if (FXUtility.HasPatterInString(value,val)) then
            return true
        end
    end
    return false
end