local cover = FXGroup.new()
local sewage = FXGroup.new()
local cCondi

function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser( Building )

	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_8_G_VIII_PROVISION_OF_COVER_FOR_SEWERAGE")
    systemTypes = FXRule.ParseValues(parsedXml, "SystemType") 
   	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
   	local GrpObjs2 = FXRule.filterObjects(parsedXml, Building)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

    cCondi = tostring(Condition1[2], Condition1[4], Condition1[6])

	if GrpObjs2 ~= nil then
		for k,v in pairs(GrpObjs2) do
			if ( k == 2 ) then
				cover = cover + v
				cover = cover:Unique()
			end
		end
	end

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do		
			if ( k == 4 ) then
				sewage = sewage + v
				sewage = sewage:Unique()
			end						
		end
	end

	for k,v in pairs(GrpObjs) do		
		if ( k == 4 ) then
			sewage = sewage + v
			sewage = sewage:Unique()
		end						
	end	
end

function CheckRule( Building )

	local openingTable
	local coverGrp  = FXGroup.new()
	
	if CheckWarning(Building) then

		local notCollided = true
		local isCompliant = true
		local arraySewage = {}
		local arrayCover = {}
		local arrayOpening = {}

		sewage:ForEach(function( sewageEle )
			
			local openingElement = sewageEle:GetChildren("OpeningElement")

			if CheckWarning2(openingElement) then

				openingElement:ForEach(function( openingEle )			
					cover:ForEach(function( coverEle )

						if FXClashDetection.IsCollided( coverEle, openingEle ) == true then

							openingTable = openingEle

							if ( (FXUtility.HasPatterInString(coverEle:GetAuxAttri("Other.Airtight"), cCondi)) and (FXUtility.HasPatterInString(coverEle:GetAuxAttri("Other.Lightweight"), cCondi)) and (FXUtility.HasPatterInString(coverEle:GetAuxAttri("Other.Removable"), cCondi))  ) == true then
								
								isCompliant = true
								coverGrp:Add(coverEle)

							else

								isCompliant = false
								FXUtility.DisplaySolid_Error(sewageEle,"The cover provided for the opening to the Sewage Treatment Plant is not airtight, lightweight, nor removable")
								CheckReport.AddRelatedObj(coverEle, coverEle:GetAttri("Name")..";"..openingEle:GetAttri("Name")..";"..sewageEle:GetAttri("Name"))
							end
						
							notCollided = false
						end
					end)

					if notCollided == true then

						isCompliant = false
						FXUtility.DisplaySolid_Error(openingEle,"Cover is not provided for the opening to the Sewage Treatment Plant")
						CheckReport.AddRelatedObj(openingEle, openingEle:GetAttri("Name").. ";" ..sewageEle:GetAttri("Name")) 
					end
				end)

				if isCompliant then

					table.insert(arraySewage, sewageEle)
					table.insert(arrayOpening, openingTable)
					table.insert(arrayCover, coverGrp)
				end
			end
		end)

		if isCompliant then

			for k=1, #arraySewage do
							
				FXUtility.DisplaySolid_Info(arraySewage[k],"Airtight,lightweight and removable cover is provided for the opening to the Sewage Treatment Plant")
				
				arrayCover[k]:ForEach(function( covEle )
					
					CheckReport.AddRelatedObj(covEle, covEle:GetAttri("Name").. ";" ..arrayOpening[k]:GetAttri("Name").. ";" ..arraySewage[k]:GetAttri("Name"))	
				end)
			end
		end
	end
end

function CheckWarning( Building )

	local Warning = true

	if (#cover == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Cover is not provided")	
		Warning = false
	end
	if (#sewage == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Sewage Treatment Plant is not provided")
		Warning = false
	end	

	return Warning
end

function CheckWarning2( OpeningElement )

	local Warning2 = true

	if (#OpeningElement == 0) then
		FXUtility.DisplaySolid_Warning(Building,"Opening Element is not provided in Sewage Treatment Plant")
		Warning2 = false
	end

	return Warning2
end
