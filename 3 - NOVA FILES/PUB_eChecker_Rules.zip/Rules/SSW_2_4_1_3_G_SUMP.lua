--[[-----------------------------------------------------

Author: Monalyn L. Rueda

Rule ID: SSW 2.4.1.3 (g)
Rule Name: Submersible Pump for Ejector/Divertor Pit

All copyrights to novasolutions 
--]]-----------------------------------------------------
local EjectorPit = FXGroup:new()
local SumpPump = FXGroup:new()
local SumpPipeGrp = FXGroup:new()
local DischargePipeGrp = FXGroup:new()
local ConnectedPipes = FXGroup:new()
local XConnectedPipes = FXGroup:new()
local ObjPump 


local BuildingStorey


function main()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
    .BindCheckFunc("CheckProvision")
    .Run()
    
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_4_1_3_G_SUMP")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			EjectorPit = EjectorPit + v;
			EjectorPit = EjectorPit:Unique();
		end	
	end

	for k,v in pairs(xmlObjs) do
		if (k == 3) then
			SumpPump = SumpPump + v;
			SumpPump = SumpPump:Unique();			    
		end

		if (k == 4) then
			SumpPipeGrp = SumpPipeGrp + v;
			SumpPipeGrp = SumpPipeGrp:Unique();			    
		end

		if (k == 5) then
			DischargePipeGrp = DischargePipeGrp + v;
			DischargePipeGrp = DischargePipeGrp:Unique();			    
		end
	end
end

function CheckProvision(Building)

if #EjectorPit ~= 0 then

	EjectorPit:ForEach(function(space)
	BuildingStorey = FXUtility.GetStorey(space);

		if #SumpPump ~= 0 then

			local SpaceOBB = FXGeom.GetBoundingOBB(space)
			local ExtrudeDir = Vector(0,0,-1000)
			SpaceOBB:Enlarge(ExtrudeDir)
			local newSpace = FXClashDetection.CreateNode()
			FXClashDetection.AddGeometry(newSpace,SpaceOBB)

			SumpPump:ForEach(function(pump)
				if FXClashDetection.IsCollided(newSpace,pump) then
					ObjPump = pump
				end
			end)
			FXClashDetection.DeleteNode(newSpace);
		end

		if (ObjPump ~= nil) then
			local Connection = BasinToSump(space, ObjPump)
		else
			FXUtility.DisplaySolid_Error(BuildingStorey, space:GetAttri('LongName') .. ": Submersible sump pump is not found.")
		end

	end)
else
	FXUtility.DisplaySolid_Warning(Building, "No Ejector/Divertor Pit found.")
end
	
end

function BasinToSump(space, pump)

if (#SumpPipeGrp ~= 0) then
	if (#DischargePipeGrp ~= 0) then
		SumpPipeGrp:ForEach(function(sump)

		if FXPUB.IsObjsConnected(sump, pump) then
			DischargePipeGrp:ForEach(function(discharge)
				if FXPUB.IsObjsConnected(sump, discharge) then
					ConnectedPipes:Add(sump)
				end
			end)
		end
		end)

		if  (#ConnectedPipes == #SumpPipeGrp) then
			FXUtility.DisplaySolid_Info(BuildingStorey, space:GetAttri('LongName') .. ": Submersible sump pump is provided and connected");
			local AddRelatedObj = DisplayRelatedObj()
		else
			XConnectedPipes = SumpPipeGrp - ConnectedPipes
			FXUtility.DisplaySolid_Error(BuildingStorey, space:GetAttri('LongName') .. ": Sump pipes not connected to discharge pipe");
			local AddRelatedObj = DisplayRelatedObj()
		end
	else
		FXUtility.DisplaySolid_Error(BuildingStorey, space:GetAttri('LongName') .. ": Sump pipes not connected to discharge pipe");
	end
else
	FXUtility.DisplaySolid_Error(BuildingStorey, space:GetAttri('LongName') .. ": Sump pipes not connected to discharge pipe");
end

end

function DisplayRelatedObj()

if(#XConnectedPipes ~= 0) then
	XConnectedPipes:ForEach(function(sump)
		CheckReport.AddRelatedObj(sump, " Sump Pipes " .. sump:GetAttri("Name"));
	end)
else
	ConnectedPipes:ForEach(function(sump)
		CheckReport.AddRelatedObj(sump, " Sump Pipes " .. sump:GetAttri("Name"));
	end)
end

DischargePipeGrp:ForEach(function(disc)
	CheckReport.AddRelatedObj(disc, " Discharge Pipes " .. disc:GetAttri("Name"));
end)

end




