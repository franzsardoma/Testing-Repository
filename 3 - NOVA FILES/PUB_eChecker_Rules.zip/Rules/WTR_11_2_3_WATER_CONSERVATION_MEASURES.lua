local grpSpaceCommons = FXGroup:new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_11_2_3_WATER_CONSERVATION_MEASURES")
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	for k,v in pairs(GrpObjs) do
		if (k == 2) then 
			grpSpaceCommons = grpSpaceCommons + v;
			grpSpaceCommons = grpSpaceCommons:Unique();
		end
	end
	for k,v in pairs(tblValues) do		
		for k1,v1 in pairs(v) do
			if (k == 2) then
				ObjProp = v1["property"]				
				ObjValue = v1["value"]
			end	
			if (k == 3) then
				ObjProp2 = v1["property"]				
				ObjValue2 = v1["value"]		
			end	
		end
	end
end

function CheckWarning( Building )
	local flag = true
	if(#grpSpaceCommons == 0) then
		flag = false	
		CheckReport.Warning( Building, "No Common Toilet or Washroom found.")
	end	
	return flag;
end

function checkRule( Building )

	if(CheckWarning(Building)) then
		grpSpaceCommons:ForEach(function ( SpaceCommon )
			local grpCheckableObjs = getCheckableObjects(SpaceCommon);

			if(#grpCheckableObjs == 0) then
				CheckReport.Warning( Building, "No Wash Basin or Shower found in "..SpaceCommon:GetAttri("LongName"))
			else
				grpCheckableObjs:ForEach(function ( CheckableObj )
					if (FXUtility.HasPatterInString(CheckableObj:GetAttri("Name"),"Self Closing")) then
						FXUtility.DisplaySolid_Info( CheckableObj, SpaceCommon:GetAttri("LongName").."; "..CheckableObj:GetAttri("Name") )
						-- CheckReport.AddRelatedObj( CheckableObj, CheckableObj:GetAttri("Name") )
					else
						FXUtility.DisplaySolid_Error( CheckableObj, SpaceCommon:GetAttri("LongName").."; "..CheckableObj:GetAttri("Name").." is not provided with self-closing delayed-action tap." )
						-- CheckReport.AddRelatedObj( CheckableObj, CheckableObj:GetAttri("Name") )
					end
				end)
			end
		end)
	end
end

function getCheckableObjects( Space )
	local grpObjs = Space:GetChildren(FlowTerminal)
	local grpReturnObjs = FXGroup:new()

	grpObjs:ForEach(function ( Obj )
		if (FXUtility.HasPatterInString(Obj:GetAttri(ObjProp),ObjValue) or FXUtility.HasPatterInString(Obj:GetAttri(ObjProp2),ObjValue2)) then
			grpReturnObjs:Add(Obj)
		end 
	end)
	return grpReturnObjs;
end