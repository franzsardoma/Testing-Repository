local grpSpaceCommons = FXGroup:new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_11_2_5_WATER_CONSERVATION_CANTEENS")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");-- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- endlocal xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	 local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpSpaceCommons = grpSpaceCommons + v
 			grpSpaceCommons = grpSpaceCommons:Unique()			
		end		
	end
end

function CheckWarning( Building )
	local flag = true
	if(#grpSpaceCommons == 0) then
		flag = false	
		CheckReport.Warning( Building, "No Canteen found.")
	end	
	return flag;
end

function checkRule( Building )
print(#grpSpaceCommons)
	if(CheckWarning(Building)) then
		grpSpaceCommons:ForEach(function ( SpaceCommon )
			local grpCheckableObjs = getCheckableObjects(SpaceCommon);

			if(#grpCheckableObjs == 0) then
				CheckReport.Warning( Building, "No Wash Basin or Shower found in "..SpaceCommon:GetAttri("LongName"))
			else
				grpCheckableObjs:ForEach(function ( CheckableObj )
					if (FXUtility.HasPatterInString(CheckableObj:GetAttri("Name"),"Self Closing")) then
						FXUtility.DisplaySolid_Compliant( CheckableObj, SpaceCommon:GetAttri("LongName").."; "..CheckableObj:GetAttri("Name") )
						-- CheckReport.AddRelatedObj( CheckableObj, CheckableObj:GetAttri("Name") )
					else
						FXUtility.DisplaySolid_Error( CheckableObj, SpaceCommon:GetAttri("LongName").."; "..CheckableObj:GetAttri("Name").." is not provided with self-closing delayed-action tap." )
						-- CheckReport.AddRelatedObj( CheckableObj, CheckableObj:GetAttri("Name") )
					end
				end)
			end
		end)
	end
end

function getCheckableObjects( Space )
	local grpObjs = Space:GetChildren(FlowTerminal)
	local grpReturnObjs = FXGroup:new()

	grpObjs:ForEach(function ( Obj )
		if (FXUtility.HasPatterInString(Obj:GetAttri("Name"),"Wash Basin") or FXUtility.HasPatterInString(Obj:GetAttri("Name"),"Wash Trough")) then
			grpReturnObjs:Add(Obj)
		end 
	end)
	return grpReturnObjs;
end