--[[ 
	Implemented by : Aires Marco S. Ladaga /01/2019
]]
local minimumUrinals = 1;
local maximumUrinals = 10;
local grpSpace = FXGroup.new();
local grpDischarge = FXGroup.new();
local grpUrinalTrap = FXGroup.new();
local grpUrinal = FXGroup.new();
local grpChamber = FXGroup.new();
-------------VALUE FROM PARSING
local storeyArr = {};

local distanceOperator;
local distanceValue;
local minGradientOperator;
local minGradientValue;
local maxGradientOperator;
local maxGradientValue;
local diameterOperatorForThree;
local diameterValueForThree;
local diameterOperatorForTen;
local diameterValueForTen;
-------------

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("FilterObjsViaStorey");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_4_2_1_A_III_URINAL_TRAP")

	
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition2");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	distanceOperator = ConditionValues3[3];
	distanceValue = ConditionValues3[4];
	minGradientOperator = ConditionValues3[7];
	minGradientValue = ConditionValues3[8];
	maxGradientOperator = ConditionValues3[10];
	maxGradientValue = ConditionValues3[11];
	diameterOperatorForThree = ConditionValues3[14];
	diameterValueForThree = ConditionValues3[15];
	diameterOperatorForTen = ConditionValues3[19];
	diameterValueForTen = ConditionValues3[20];

	local tblValues = FXRule.filterTableValues(parsedXml, proj);

    for k,v in pairs(tblValues) do
        for k1,v1 in pairs(v) do
            if(k == 1) then
                table.insert( storeyArr , v1["value"] )
            end
        end
    end

    for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 3 ) then
			grpDischarge = grpDischarge + v
			grpDischarge = grpDischarge:Unique()
		end
		if ( k == 4 ) then
			grpUrinalTrap = grpUrinalTrap + v
			grpUrinalTrap = grpUrinalTrap:Unique()
		end
		if ( k == 5 ) then
			grpUrinal = grpUrinal + v
			grpUrinal = grpUrinal:Unique()
		end
		if ( k == 6 ) then
			grpChamber = grpChamber + v
			grpChamber = grpChamber:Unique()
		end
	end

	grpUrinal = grpUrinal - grpUrinalTrap;
	grpUrinalTrap = grpUrinalTrap - grpUrinal;
end


function FilterObjsViaStorey(Building) -- to make sure all objects are at storey 1
	local grpNotInObjsStorey = FXGroup.new();

	grpDischarge : ForEach (function ( obj )
		local storey = getStorey(obj);
		if FXUtility.IsBelongToTableElement(storey, storeyArr) == false then
			grpNotInObjsStorey : Add(obj)
		end
	end)
	grpUrinalTrap : ForEach (function ( obj )
		local storey = getStorey(obj);
		if FXUtility.IsBelongToTableElement(storey, storeyArr) == false then
			grpNotInObjsStorey : Add(obj)
		end
	end)
	grpUrinal : ForEach (function ( obj )
		local storey = getStorey(obj);
		if FXUtility.IsBelongToTableElement(storey, storeyArr) == false then
			grpNotInObjsStorey : Add(obj)
		end
	end)
	grpChamber : ForEach (function ( obj )
		local storey = getStorey(obj);
		if FXUtility.IsBelongToTableElement(storey, storeyArr) == false then
			grpNotInObjsStorey : Add(obj)
		end
	end)
	grpDischarge = grpDischarge - grpNotInObjsStorey;
	grpUrinalTrap = grpUrinalTrap - grpNotInObjsStorey;
	grpUrinal = grpUrinal - grpNotInObjsStorey;
	grpChamber = grpChamber - grpNotInObjsStorey;
end


function CheckRule(Building)
	-- print (#grpDischarge.." - "..#grpUrinalTrap.." - "..#grpUrinal.." - "..#grpChamber);
	-- print (distanceOperator)
	-- print (distanceValue)
	-- print (minGradientOperator)
	-- print (minGradientValue)
	-- print (maxGradientOperator )
	-- print (maxGradientValue )
	-- print (diameterOperatorForThree )
	-- print (diameterValueForThree )
	-- print (diameterOperatorForTen )
	-- print (diameterValueForTen )
	local flag = true;

	if #grpDischarge == 0 then
		FXUtility.DisplaySolid_Warning ( Building , "Discharge Pipe is not provided.");
		flag = false;
	end

	if #grpUrinal == 0 then
		FXUtility.DisplaySolid_Warning ( Building , "Urinal is not provided.");
		flag = false;
	end

	if #grpChamber == 0 then
		FXUtility.DisplaySolid_Warning ( Building , "Inspection Chamber is not provided.");
		flag = false;
	end

	if flag then
		local grpAttentionDrainage = FXGroup.new();
		local grpNonAndComDrainage = FXGroup.new();

		grpDischarge:ForEach ( function ( drainageObj )
			local conUrinalTrap;
			local conChamber;

			grpUrinalTrap:ForEach(function ( urinalTrap )
				if FXPUB.ObjToObjIsConnected(drainageObj, urinalTrap, 5) then -- doesn't pass through DistributionChamberElement
					conUrinalTrap = urinalTrap ;
				end
			end)

			grpChamber:ForEach(function ( chamber )
				if FXPUB.IsConnectedChamberElement(getStorey(drainageObj),chamber, drainageObj) then -- chambers checks if pipe is collided to it or its fitting
					conChamber = chamber;
				end
			end)

			if conUrinalTrap ~= nil and conChamber ~= nil then -- checks pipe only that has both, else attention.		
	
				local grpConnectedUrinals = FXGroup.new();

				grpUrinal:ForEach(function ( urinal )
					if FXPUB.IsTwoObjsConnected(conUrinalTrap, urinal, 100) then
						grpConnectedUrinals:Add(urinal) -- GET all connected urinals to urinalTrap, API wont pass through DistributionChamberElement
					end
				end)
				grpConnectedUrinals = grpConnectedUrinals:Unique();

				if #grpConnectedUrinals >= minimumUrinals and #grpConnectedUrinals <= maximumUrinals then
					local centerPntsArr = GetClosestCircularFacesCenterPnt(conUrinalTrap)-- used connected ELements, since trap's faces isnt considered as circular
																						-- get closest centerPnts from circular faces of connected elements, returns array points
					local centerPntOfUrinalTrap = getFurthestCenterPoint(centerPntsArr , drainageObj); -- futhest CenterPointArr from connected elem of Trap from Drainage Pipe

					local chamberBox = FXGeom.GetBoundingBox(conChamber);
					local centerPntOfChamber = chamberBox:MidPos();

					local pnt1;
					local pnt2;
					if centerPntOfUrinalTrap.z < centerPntOfChamber.z then -- adjust the points
						pnt1 = Point3D(centerPntOfUrinalTrap.x , centerPntOfUrinalTrap.y ,centerPntOfUrinalTrap.z - 300 ); 
						pnt2 = Point3D(centerPntOfChamber.x , centerPntOfChamber.y , centerPntOfUrinalTrap.z - 300 );
					else
						pnt1 = Point3D(centerPntOfUrinalTrap.x , centerPntOfUrinalTrap.y , centerPntOfChamber.z - 300 );
						pnt2 = Point3D(centerPntOfChamber.x , centerPntOfChamber.y , centerPntOfChamber.z - 300 );
					end

					local distance = pnt1:Distance_Pnt(pnt2); -- distance center pnt from Inspection Chamber to UrinalTrap
					local doubleArrow = DoubleArrow(pnt1 , pnt2);
					local polyLine = PolyLine3D(TRUE);
					polyLine:AddPoint(centerPntOfUrinalTrap);
					polyLine:AddPoint(pnt1);
					polyLine:AddPoint(pnt2);
					polyLine:AddPoint(centerPntOfChamber);

					local diameterLine, slopeLineOfPipe = GetDiameterLineAndSlopeLineOfPipe(drainageObj); -- get diameter line of the pipe and the slope line
					local distanceLineOfPipe, heightLineOfPipe = GetFlatDistanceLineAndHeightLine(slopeLineOfPipe); -- get Run and fall of the slope line 

					local slopeGradient = FXUtility.Round(distanceLineOfPipe:Length() / heightLineOfPipe:Length() , 2); -- Slope GRADIENT = RUN / FALL
					local gradientRatio = "1:"..slopeGradient;
					local minRatioArr = FXPUB.Split(minGradientValue,":") -- to get the value without "1:" 
					local maxRatioArr = FXPUB.Split(maxGradientValue,":") -- to get the value without "1:" 
					local diameterOfPipe = FXUtility.Round(diameterLine:Length() , 2); -- diameter of pipe
					local distanceFromICToTrap = FXUtility.Round(distance , 2);

					if  FXRule.EvaluateNumber( distanceOperator , distance , distanceValue ) and
						FXRule.EvaluateNumber( minGradientOperator , slopeGradient , tonumber(minRatioArr[2]) ) and 
						FXRule.EvaluateNumber( maxGradientOperator , slopeGradient , tonumber(maxRatioArr[2]) ) then

						if #grpConnectedUrinals >= 1 and #grpConnectedUrinals <=3 then
							if FXRule.EvaluateNumber( diameterOperatorForThree , diameterOfPipe , diameterValueForThree ) then
								print ("COMNPLANT 1")
								grpNonAndComDrainage : Add(drainageObj)
								FXUtility.DisplaySolid_Info ( drainageObj , drainageObj:GetAuxAttri("Entity.ObjectType").." Diameter : "..diameterOfPipe.." ; Gradient : "..gradientRatio.." ; Length: "..distanceFromICToTrap.."mm", doubleArrow );
								CheckReport.AddRelatedGeometry_Info(polyLine)
								CheckReport.AddRelatedObj( conUrinalTrap, conUrinalTrap:GetAuxAttri("Entity.ObjectType"))
								CheckReport.AddRelatedObj( conChamber, conChamber:GetAuxAttri("Entity.ObjectType"))
								grpConnectedUrinals:ForEach(function ( uri )
									CheckReport.AddRelatedObj( uri, uri:GetAuxAttri("Entity.ObjectType"))
								end)
							else 
								print ("NonCompliant 1")
								grpNonAndComDrainage : Add(drainageObj)
								FXUtility.DisplaySolid_Error ( drainageObj , drainageObj:GetAuxAttri("Entity.ObjectType").." Diameter : "..diameterOfPipe.." ; Gradient : "..gradientRatio.."; Length : "..distanceFromICToTrap.."mm", doubleArrow );
								CheckReport.AddRelatedGeometry_Error(polyLine)
								CheckReport.AddRelatedObj( conUrinalTrap, conUrinalTrap:GetAuxAttri("Entity.ObjectType"))
								CheckReport.AddRelatedObj( conChamber, conChamber:GetAuxAttri("Entity.ObjectType"))
								grpConnectedUrinals:ForEach(function ( uri )
									CheckReport.AddRelatedObj( uri, uri:GetAuxAttri("Entity.ObjectType"))
								end)
							end
								
						elseif #grpConnectedUrinals >3 and #grpConnectedUrinals <= 10 then

							if FXRule.EvaluateNumber( diameterOperatorForTen , diameterOfPipe , diameterValueForTen ) then
								print ("COMNPLANT 2")
								grpNonAndComDrainage : Add(drainageObj)
								FXUtility.DisplaySolid_Info ( drainageObj , drainageObj:GetAuxAttri("Entity.ObjectType").." Diameter : "..diameterOfPipe.." ; Gradient : "..gradientRatio.." ; Length: "..distanceFromICToTrap.."mm", doubleArrow );
								CheckReport.AddRelatedGeometry_Info(polyLine)
								CheckReport.AddRelatedObj( conUrinalTrap, conUrinalTrap:GetAuxAttri("Entity.ObjectType"))
								CheckReport.AddRelatedObj( conChamber, conChamber:GetAuxAttri("Entity.ObjectType"))
								grpConnectedUrinals:ForEach(function ( uri )
									CheckReport.AddRelatedObj( uri, uri:GetAuxAttri("Entity.ObjectType"))
								end)
							else 
								print ("NonCompliant 2")
								grpNonAndComDrainage : Add(drainageObj)
								FXUtility.DisplaySolid_Error ( drainageObj , drainageObj:GetAuxAttri("Entity.ObjectType").." Diameter : "..diameterOfPipe.." ; Gradient : "..gradientRatio.." ; Length : "..distanceFromICToTrap.."mm", doubleArrow );
								CheckReport.AddRelatedGeometry_Error(polyLine)
								CheckReport.AddRelatedObj( conUrinalTrap, conUrinalTrap:GetAuxAttri("Entity.ObjectType"))
								CheckReport.AddRelatedObj( conChamber, conChamber:GetAuxAttri("Entity.ObjectType"))
								grpConnectedUrinals:ForEach(function ( uri )
									CheckReport.AddRelatedObj( uri, uri:GetAuxAttri("Entity.ObjectType"))
								end)
							end
						end
					else
						print ("NonCompliant 3")
						grpNonAndComDrainage : Add(drainageObj)
						FXUtility.DisplaySolid_Error ( drainageObj , drainageObj:GetAuxAttri("Entity.ObjectType").." Diameter : "..diameterOfPipe.." ; Gradient : "..gradientRatio.." ; Length : "..distanceFromICToTrap.."mm", doubleArrow );
						CheckReport.AddRelatedGeometry_Error(polyLine)
						-- CheckReport.AddRelatedGeometry_Error(slopeLineOfPipe)
						-- CheckReport.AddRelatedGeometry_Error(distanceLineOfPipe)
						-- CheckReport.AddRelatedGeometry_Error(heightLineOfPipe)
						CheckReport.AddRelatedObj( conUrinalTrap, conUrinalTrap:GetAuxAttri("Entity.ObjectType"))
						CheckReport.AddRelatedObj( conChamber, conChamber:GetAuxAttri("Entity.ObjectType"))
						grpConnectedUrinals:ForEach(function ( uri )
							CheckReport.AddRelatedObj( uri, uri:GetAuxAttri("Entity.ObjectType"))
						end)
					end	
				else
					FXUtility.DisplaySolid_Warning ( conUrinalTrap , "No connected Urinals/ Exceeding connected Urinals to Urinal Floor Trap.")
				end			
			else
				grpAttentionDrainage : Add(drainageObj)
			end
		end)
		if #grpAttentionDrainage > 0 and #grpNonAndComDrainage > 0 then
			local grpConnectedDrains = FXGroup.new();
			grpNonAndComDrainage:ForEach(function ( comNonCom )
				grpAttentionDrainage:ForEach(function ( attention )
					if FXPUB.IsTwoObjsConnected(comNonCom, attention, 20) then
						grpConnectedDrains:Add(attention) -- to remove attentions drainage pipe thats connected to compliant or non compliant pipe
					end
				end)
			end)
			grpAttentionDrainage = grpAttentionDrainage - grpConnectedDrains;

			grpAttentionDrainage:ForEach(function ( attentionDrainage )
				FXUtility.DisplaySolid_Warning ( attentionDrainage , "No Inspection Chamber or Urinal Trap connected to "..attentionDrainage:GetAuxAttri("Entity.ObjectType"))
			end)
		end
	end
end


function getStorey( obj )   
    local storey = obj;
    for i=0, 10, 1 do 
        if storey.Type == "BuildingStorey" then
            return storey;
        end
        storey = storey:GetParent();
    end
    return nil;
end


function GetDiameterLineAndSlopeLineOfPipe( pipe )
	local faces = FXMeasure.GetALLCircularFaces(pipe);
	local verticalLine1 = FXMeasure.GetOuterDiameterLines(faces[1]);
	local verticalLine2 = FXMeasure.GetOuterDiameterLines(faces[2]);

	local line1Pnt1 = verticalLine1:GetStartPoint();
	local line1Pnt2 = verticalLine1:GetEndPoint();
	local line2Pnt1 = verticalLine2:GetStartPoint();
	local line2Pnt2 = verticalLine2:GetEndPoint();

	local lowestPntOf1;
	local lowestPntOf2;

	if line1Pnt1.z > line1Pnt2.z then
		lowestPntOf1 = line1Pnt2;
	else
		lowestPntOf1 = line1Pnt1;
	end

	if line2Pnt1.z > line2Pnt2.z then
		lowestPntOf2 = line2Pnt2;
	else
		lowestPntOf2 = line2Pnt1;
	end

	return verticalLine1, Line3D(lowestPntOf1,lowestPntOf2)
end


function GetFlatDistanceLineAndHeightLine( line )
	local startPnt = line:GetStartPoint();
	local endPnt = line:GetEndPoint();

	local pnt1;
	local pnt2;
	local distanceLine;
	local heightLine;
	if startPnt.z > endPnt.z then -- bring down the elevation of the highest Point to the lowest point elevation
		pnt1 = endPnt;
		pnt2 = Point3D(startPnt.x , startPnt.y , endPnt.z);
		distanceLine = Line3D(pnt1, pnt2)
		heightLine = Line3D(startPnt, pnt2) -- get the fall line while at it
	else
		pnt1 = Point3D(endPnt.x , endPnt.y , startPnt.z);
		pnt2 = startPnt;
		distanceLine = Line3D(pnt1, pnt2)
		heightLine = Line3D(endPnt, pnt1)
	end

	return distanceLine,heightLine
end


function GetClosestCircularFacesCenterPnt( trap)
	local urinalTrapConElem = trap:GetConnectedElement();
	local centerPntTrap = FXGeom.GetBoundingBox(trap):MidPos();
	local closestPntArr = {};

	if #urinalTrapConElem > 0 then
		urinalTrapConElem:ForEach(function ( conElem )
			local faces = FXMeasure.GetALLCircularFaces(conElem);
			if faces ~= nil and #faces == 2 then
				local verticalLine1 = FXMeasure.GetOuterDiameterLines(faces[1]);
				local verticalLine2 = FXMeasure.GetOuterDiameterLines(faces[2]);

				local line1CenterPnt = FXUtility.CenterPoint(verticalLine1:GetStartPoint(),verticalLine1:GetEndPoint())
				local line2CenterPnt = FXUtility.CenterPoint(verticalLine2:GetStartPoint(),verticalLine2:GetEndPoint())

				if centerPntTrap:Distance_Pnt(line1CenterPnt) > centerPntTrap:Distance_Pnt(line2CenterPnt) then
					table.insert( closestPntArr ,line2CenterPnt ) 
				else
					table.insert( closestPntArr ,line1CenterPnt ) 
				end
			else
				table.insert( closestPntArr ,FXGeom.GetBoundingBox(conElem):MidPos() ) 
			end
		end)
	else
		return centerPntTrap
	end

	return closestPntArr
end


function getFurthestCenterPoint( pntArr , drainagePipe)
	local centerPntOfDrainage = FXGeom.GetBoundingBox(drainagePipe):MidPos();
	local furthestPnt;

	for k,v in pairs(pntArr) do
		if furthestPnt == nil or centerPntOfDrainage:Distance_Pnt(v) > centerPntOfDrainage:Distance_Pnt(furthestPnt) then
			furthestPnt = v
		end
	end
	return furthestPnt;
end