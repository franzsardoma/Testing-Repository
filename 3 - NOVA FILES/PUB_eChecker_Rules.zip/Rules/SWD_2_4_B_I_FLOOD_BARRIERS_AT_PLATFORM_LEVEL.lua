local BuildingStoreyGroup = FXGroup.new()
local DoorGroup = FXGroup.new()
local SlabGrp = FXGroup.new()
local FloodBarrierGrp=FXGroup.new()
function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SWD_2_4_B_I_FLOOD_BARRIERS_AT_PLATFORM_LEVEL");
  local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
  -- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  -- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 3) then
      BuildingStoreyGroup = BuildingStoreyGroup + v;
      BuildingStoreyGroup = BuildingStoreyGroup:Unique();
    end
    if (k == 4) then
      DoorGroup = DoorGroup + v;
      DoorGroup = DoorGroup:Unique();
    end
    if (k == 5) then
      FloodBarrierGrp = FloodBarrierGrp + v;
      FloodBarrierGrp = FloodBarrierGrp:Unique();
    end
    if (k == 6) then
      SlabGrp = SlabGrp + v;
      SlabGrp = SlabGrp:Unique();
    end
  end
end

function checkRule(Building)
    local site = Building:GetParent(); 
    if FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Commercial") == true or
        FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Multi-Unit Residential") == true or
        FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Special Facilities") == true then
        if(FloodBarrierGrp == nil or #FloodBarrierGrp == 0) then
            FXUtility.DisplaySolid_Warning(Building, "Flood Barrier is not provided.")
        else
            local ARRDoor = {}
            local ARRGrpBar = {}
            local isCompliant = true;
            local relatedBarGrp = FXGroup.new()
            local i = 0;
            BuildingStoreyGroup:ForEach(function(buildingstoreytocheckElement)
                local externalDoorGrp = FXGroup.new();
                local WallGrp = buildingstoreytocheckElement:GetDescendants("Wall")
                local WallCollidedSlabGrp = FXGroup.new()
                local externalWallGrp = FXGroup.new();
                DoorGroup:ForEach(function(doorElement)
                    local isExternal = doorElement:GetAuxAttri("Pset_DoorCommon.IsExternal");
                    if(isExternal == "true") then
                        externalDoorGrp:Add(doorElement);
                    end 
                end)  

                local externalSlabGrp = FXGroup.new();
                SlabGrp:ForEach(function(slabEle)
                    local isExternal = slabEle:GetAuxAttri("Pset_SlabCommon.IsExternal");
                    if(isExternal == "true") then
                        externalSlabGrp:Add(slabEle);
                    end
                end) 

                WallGrp:ForEach(function(wallEle)
                    local isExternal = wallEle:GetAuxAttri("Pset_WallCommon.IsExternal");
                    if(isExternal == "true") then
                        externalWallGrp:Add(wallEle);
                    end
                end) 
               
                externalSlabGrp:ForEach(function(extSlabEle)
                    externalWallGrp:ForEach(function(extWallEle)
                        if FXClashDetection.IsCollided(extWallEle, extSlabEle) then
                            WallCollidedSlabGrp:Add(extWallEle);
                        end
                    end)
                end)
                local flag = false;
                externalDoorGrp:ForEach(function(doorEle) 
                    FloodBarrierGrp:ForEach(function(floodbarrierEle)
                        if flag == false then
                            if FXClashDetection.IsCollided(doorEle, floodbarrierEle) then
                                i = i + 1;
                                relatedBarGrp:Add(floodbarrierEle)
                                ARRDoor[i] = doorEle
                                ARRGrpBar = relatedBarGrp
                                FXUtility.DisplaySolid_Info(buildingstoreytocheckElement,"Flood barrier provided.",doorEle);
                                flag = true;
                            else
                                flag = false;
                            end
                        end    
                    end) 
                    local collidedBarriersGrp = FXGroup.new();

                    if flag == false then
                        externalSlabGrp:ForEach(function(slabEle)
                            if FXClashDetection.IsCollided(doorEle, slabEle) then
                                FloodBarrierGrp:ForEach(function(floodbarrierEle)
                                    if FXClashDetection.IsCollided(slabEle, floodbarrierEle) then
                                        collidedBarriersGrp:Add(floodbarrierEle) 
                                    end   
                                end)
                            end    
                        end)
                    end

                    local collidecount = 0;
                    local notcollidedGrp = FXGroup.new();
                 
                    if #collidedBarriersGrp ~= 0 then
                        collidedBarriersGrp:ForEach(function(barrierEle)

                            WallCollidedSlabGrp:ForEach(function(wallEle)                       
                                if FXClashDetection.IsCollided(doorEle, wallEle) and FXClashDetection.IsCollided(barrierEle, wallEle) then                     
                                    collidecount = collidecount + 1;
                                else
                                    notcollidedGrp:Add(barrierEle);
                                end     
                            end)
                        end)

                        local isCompliant = false;
                        if #notcollidedGrp ~= 0 then
                            if collidecount <= 1 then
                                isCompliant = false
                                FXUtility.DisplaySolid_Error(doorEle,"Flood barrier provided but not enclosed.",buildingstoreytocheckElement);
                                collidedBarriersGrp:ForEach(function(barrierEle)
                                    CheckReport.AddRelatedObj( barrierEle,barrierEle:GetAttri("Name"))
                                end)
                            else
                                notcollidedGrp:ForEach(function(notcollidedEle)
                                    local bartobarCollidecnt=0;
                                    collidedBarriersGrp:ForEach(function(collidedEle)
                                        if FXClashDetection.IsCollided(notcollidedEle, collidedEle) then
                                            bartobarCollidecnt = bartobarCollidecnt + 1;
                                        end  
                                    end)

                                    if bartobarCollidecnt <= 1 then
                                        isCompliant = false
                                        FXUtility.DisplaySolid_Error(doorEle,"Flood barrier provided but not enclosed.",buildingstoreytocheckElement); 
                                        collidedBarriersGrp:ForEach(function(barrierEle)
                                            CheckReport.AddRelatedObj( barrierEle,barrierEle:GetAttri("Name"))
                                        end)
                                        return
                                    else
                                        isCompliant = true;
                                    end  
                                     
                                end)
                            end
                            if isCompliant then
                                i = i + 1;
                                ARRDoor[i] = doorEle
                                ARRGrpBar[i]= collidedBarriersGrp
                            end 
                        else
                            FXUtility.DisplaySolid_Error(doorEle,"Flood barrier provided but not enclosed.",buildingstoreytocheckElement);  
                            collidedBarriersGrp:ForEach(function(barrierEle)
                                CheckReport.AddRelatedObj( barrierEle,barrierEle:GetAttri("Name"))
                            end)  
                        end     
                    else
                        FXUtility.DisplaySolid_Error(doorEle,"Flood barrier not provided.",buildingstoreytocheckElement);    
                    end 
                end) 
                if isCompliant then
                    for i,door in pairs(ARRDoor) do
                    FXUtility.DisplaySolid_Info(door,"Flood barrier provided.",buildingstoreytocheckElement);
                    ARRGrpBar[i]:ForEach(function(barrierEle)
                        CheckReport.AddRelatedObj( barrierEle,barrierEle:GetAttri("Name"))
                    end)  
                end
            end     
            end)     
        end  
    else
        FXUtility.DisplaySolid_Warning(Building, "Project Development Type is not provided or does not match.")
    end
end 
