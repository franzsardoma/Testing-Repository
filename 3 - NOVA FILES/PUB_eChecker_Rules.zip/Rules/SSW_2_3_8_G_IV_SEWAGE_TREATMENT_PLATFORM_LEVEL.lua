local FlowStorageDevGrp = FXGroup.new()
function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_8_G_IV_SEWAGE_TREATMENT_ABOVE_PLATFORM_LEVEL")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	
	-- isRemovable = ConditionValues[1]; -- for Condition Values 

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)		
	for k,v in pairs(GrpObjs1) do
		if (k == 2) then
			FlowStorageDevGrp =   FlowStorageDevGrp + v;
			FlowStorageDevGrp = FlowStorageDevGrp:Unique()
		end
	end
end

function checkRule( Building )

local slabsInLevel1 = FXGroup.new()
	local bldgStoreyGrp = Building:GetDescendants("BuildingStorey")
	local flowStorageGrp, flowStorage
	local flowStorageHighPos, lowestSlabHighPos
	local bldgStorey = false
	local slab = false
	local flowStorageDev = false

	local flowStorageTable = {}
	local lowestSlabTable = {}
	local flowStorageLevelTable = {}
	local lowestSlabLevelTable = {}
	local arrowTable = {}
	local line1Table = {}
	local line2Table = {}
	local flowStorageHighPosTable = {}
	local lowestSlabHighPosTable = {}

	local flag

	bldgStoreyGrp:ForEach(function ( bldgStoreyObj )
		if ( FXUtility.HasPatterInString(bldgStoreyObj:GetAttri("Name"),"01" ) ) then
			slabsInLevel1 = bldgStoreyObj:GetDescendants("Slab")
			slabsInLevel1:ForEach(function ( slabsInLevel1Obj )
				slab = true
			end)
			FlowStorageDevGrp:ForEach(function ( flowStorageObj )
					flowStorageHighPos = FXGeom.GetBoundingBox(flowStorageObj):HighPos()
					flowStorage = flowStorageObj
					flowStorageDev = true
			end)
			bldgStorey = true          
		end	
	end)

	if ( slab == true and flowStorageDev == true and bldgStorey == true) then

		local lowestSlab = GetLowestElement( slabsInLevel1 )
		lowestSlabHighPos = FXGeom.GetBoundingBox(lowestSlab):HighPos()
		local flowStorageLevel = flowStorageHighPos.z / 1000
		local lowestSlabLevel = lowestSlabHighPos.z / 1000
		local line1 = Line3D(Point3D(lowestSlabHighPos.x,lowestSlabHighPos.y,flowStorageHighPos.z),flowStorageHighPos)
		local line2 = Line3D(Point3D(flowStorageHighPos.x,flowStorageHighPos.y,lowestSlabHighPos.z),lowestSlabHighPos)
		local point1 = FXUtility.CenterPoint(Point3D(lowestSlabHighPos.x,lowestSlabHighPos.y,flowStorageHighPos.z),flowStorageHighPos);
		local point2 = FXUtility.CenterPoint(Point3D(flowStorageHighPos.x,flowStorageHighPos.y,lowestSlabHighPos.z),lowestSlabHighPos);
		local arrow = DoubleArrow(point1, point2)

		if ( lowestSlabHighPos.z < flowStorageHighPos.z ) then
			table.insert(flowStorageTable, flowStorage)
			table.insert(lowestSlabTable, lowestSlab)
			table.insert(flowStorageLevelTable, flowStorageLevel)
			table.insert(lowestSlabLevelTable, lowestSlabLevel)
			table.insert(arrowTable, arrow)
			table.insert(line1Table, line1)
			table.insert(line2Table, line2)
			table.insert(flowStorageHighPosTable, flowStorageHighPos.z)
			table.insert(lowestSlabHighPosTable, lowestSlabHighPos.z)
			flag = true
		else
			flag = false
		end

		if (flag == false) then
			res = lowestSlabHighPos.z - flowStorageHighPos.z
			FXUtility.DisplaySolid_Error(flowStorage, "The Top Level of the Sewage Treatment Plant is lower than the Platform Level")
			CheckReport.AddRelatedObj(lowestSlab, "Sewage Treatment Plant Level: " .. FXUtility.Round(flowStorageLevel, 2) .. " m; Platform Level: " .. FXUtility.Round(lowestSlabLevel, 2).. " m")
			CheckReport.AddRelatedGeometry_Error(arrow, FXUtility.Round(res, 2));
			CheckReport.AddRelatedGeometry_Error(line1);
			CheckReport.AddRelatedGeometry_Error(line2);

		elseif (flag == true) then

			local FlowStorage1
			local LowestSlab
			local FlowStorageLevel
			local LowestSlabLevel
			local Arrow
			local Line1
			local Line2
			local FlowStorageHighPos
			local LowestSlabHighPos 

			for a = 1, #flowStorageTable do

				FlowStorage1 = flowStorageTable[a]
				LowestSlab = lowestSlabTable[a]
				FlowStorageLevel = flowStorageLevelTable[a]
				LowestSlabLevel = lowestSlabLevelTable[a]
				Arrow = arrowTable[a]
				Line1 = line1Table[a]
				Line2 = line2Table[a]
				FlowStorageHighPos = flowStorageHighPosTable[a]
				LowestSlabHighPos = lowestSlabHighPosTable[a]

				FXUtility.DisplaySolid_Info(FlowStorage1, "The Top Level of the Sewage Treatment Plant is higher than the Platform Level")
				CheckReport.AddRelatedObj(LowestSlab, "Sewage Treatment Plant Level: " .. FXUtility.Round(FlowStorageLevel, 2) .. " m; Platform Level: " .. FXUtility.Round(LowestSlabLevel, 2).. " m")
				CheckReport.AddRelatedGeometry_Info(Arrow, FXUtility.Round(LowestSlabLevel, 2));
				CheckReport.AddRelatedGeometry_Info(Line1)
				CheckReport.AddRelatedGeometry_Info(Line2)

			end			
		end

	elseif (flowStorageDev == false) then
		FXUtility.DisplaySolid_Warning(Building, "No Sewage Treatment Plant found. ")
	elseif (slab == false) then
		FXUtility.DisplaySolid_Warning(Building, "No Slab on BuildingStorey 01 found. ")
	elseif (bldgStorey == false) then
		FXUtility.DisplaySolid_Warning(Building, "No BuildingStorey 01 found. ")
	end	
end

function GetLowestElement(grp)
	local lowest
	grp:ForEach(function (ele)
		if lowest == nil then
			lowest = ele
		else
			local lowBox = FXGeom.GetBoundingOBB(lowest)
			local eleBox = FXGeom.GetBoundingOBB(ele)
			local lowpoint = lowBox:GetPos()
			local elepoint = eleBox:GetPos()
			if elepoint.z < lowpoint.z then
				lowest = ele
			end
		end
	end)
	return lowest
end