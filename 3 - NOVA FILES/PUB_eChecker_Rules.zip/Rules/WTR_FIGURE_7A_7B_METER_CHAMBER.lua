local GroupMeterChamber = FXGroup.new();
local GroupWaterMeter = FXGroup.new();
local GroupWall = FXGroup.new();
local GroupValve = FXGroup.new();
local WithValves = false;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("CheckRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "WTR_FIGURE_7A_7B_HEIGHT_OF_METER_CHAMBER_WITH_VALVES");

    --local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	--SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	--local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	WithValves = ConditionValues[3];

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);		
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			GroupMeterChamber =  GroupMeterChamber + v;
		end	
		if (k == 3) then			    
			GroupWaterMeter = GroupWaterMeter + v;
		end	
		if (k == 4) then
			GroupValve = GroupValve + v;
		end			
	end	
end

function CheckRule(Building)
	BuildingStoreyGroup = Building:GetDescendants("BuildingStorey");

	local WaterMeterGroup = FXGroup.new();
	local ValveGroup = FXGroup.new();
	
	local CurrentStorey;
	local SpaceWithValveGroup = FXGroup.new();
	
	if(#GroupMeterChamber ~= 0)then 
		
		GroupMeterChamber:ForEach(function(Object) 
			local WaterMeterWithoutValve;
			BuildingStoreyGroup:ForEach(function(BuildingStoreyElement) 
				local SpaceGroup = BuildingStoreyElement:GetDescendants("Space");
				SpaceGroup:ForEach(function(SpaceElement)
					if(FXUtility.HasPatterInString(SpaceElement:GetAttri("LongName"),Object:GetAttri("LongName")) ==  true)then 
						CurrentStorey = BuildingStoreyElement;
					end
				end)
			end)

			if(CurrentStorey ~= nil)then
				GroupWaterMeter:ForEach(function(MeterObject)
					if(FXClashDetection.IsCollided(Object,MeterObject) == true)then 
						WaterMeterGroup:Add(MeterObject);
						WaterMeterWithoutValve = MeterObject;
					end
				end)

				local InSpaceEle = Object:GetInSpaceElement();
				InSpaceEle:ForEach(function(ElementInSpace)
					if(FXUtility.HasPatterInString(ElementInSpace:GetAttri("Name"),"Valve"))then 
						ValveGroup:Add(ElementInSpace);
					end
				end)

			end
			
			if(WithValves)then 
				if(#ValveGroup ~= 0)then 
					SpaceWithValveGroup:Add(Object);
				else
					if(WaterMeterWithoutValve ~= nil)then 
						FXUtility.DisplaySolid_Warning(Object,Object:GetAttri("LongName"));
						CheckReport.AddRelatedObj(WaterMeterWithoutValve,"Valve(s) is not provided.")
						return;	
					end				
				end
			else
				SpaceWithValveGroup:Add(Object);
			end

			if(#WaterMeterGroup == 0)then 
				CheckReport.Error(Object,"Water Meter(s) is not provided.");	
			end	
		end)
	else
		FXUtility.DisplaySolid_Warning(Building,"Meter Chamber is not provided.");
		return;
	end

	if(#SpaceWithValveGroup ~= 0)then 
		SpaceWithValveGroup:ForEach(function(SpaceWithValve)
			local ConnectedWallsGroup = SpaceWithValve:GetConnectedWall();

			local CurrentValveGroup = FXGroup.new();
			local CurrentMeterGroup = FXGroup.new();
			local InSpaceEle2 = SpaceWithValve:GetInSpaceElement();
			InSpaceEle2:ForEach(function(ElementInSpace2)
				if(FXUtility.HasPatterInString(ElementInSpace2:GetAttri("Name"),"Valve"))then 
					CurrentValveGroup:Add(ElementInSpace2);
				end

				if(FXUtility.HasPatterInString(ElementInSpace2:GetAttri("Name"),"Water Meter"))then 
					CurrentMeterGroup:Add(ElementInSpace2);
				end
			end)		

			local SpaceOBB = FXGeom.GetBoundingOBB(SpaceWithValve);
			local SpaceBox = FXGeom.GetBoundingBox(SpaceWithValve);
			local SpaceHeight = SpaceBox:HighPos().z;
			local Point1 = Point3D(SpaceOBB:MaxPnt().x,SpaceOBB:MaxPnt().y,SpaceBox:HighPos().z);
			local Point2 = Point3D(SpaceOBB:MaxPnt().x,SpaceOBB:MaxPnt().y,SpaceBox:LowPos().z);
			-------------------------------------------------------------------------------------
			local elevation = CurrentStorey:Elevation();
			local projection = FXMeasure.GetProjection(ConnectedWallsGroup,elevation);
			local outerEdges = FXMeasure.GetOuterEdge(projection);

			local ArrayTemp = {};
			local noOfPnt 	= outerEdges:GetPointNumber();
			for i = 1, noOfPnt - 1, 1  do
				ArrayTemp[i] = outerEdges:GetPoint(i);
			end
			-- print(#ArrayTemp);

			local Point;
			for i = 1, noOfPnt -3, 1  do
				Point = outerEdges:GetPoint(i);
			end

			PointTop = Point3D(Point.x,Point.y,SpaceHeight);

			local Line = Line3D(Point,PointTop);
			-- local Wallyrange = WallBox:y_range();
			-- local Wallxrange = WallBox:x_range();
			local Pnt1, Pnt2;

			if(#ArrayTemp > 4)then 
				Pnt1 = Point3D(Point.x,Point.y,SpaceHeight);
				Pnt2 = Point3D(Point.x,Point.y,Point.z);
			else
				Pnt1 = Point3D(Point.x,Point.y,SpaceHeight);
				Pnt2 = Point3D(Point.x,Point.y,Point.z);
			end


			local arrowGeom = DoubleArrow(Pnt1, Pnt2);
			local polyline = PolyLine3D(TRUE);
			polyline:AddPoint(Line:GetEndPoint());
			polyline:AddPoint(Pnt1);

			if(SpaceHeight <= 900)then
				FXUtility.DisplaySolid_Info(SpaceWithValve,SpaceHeight.."mm");
				CheckReport.AddRelatedObj(SpaceWithValve,SpaceWithValve:GetAttri("LongName"));
				CheckReport.AddRelatedGeometry_Solid(arrowGeom);
				-- CheckReport.AddRelatedGeometry_Solid(polyline);
			else
				FXUtility.DisplaySolid_Error(SpaceWithValve,SpaceHeight.."mm");
				CheckReport.AddRelatedObj(SpaceWithValve,SpaceWithValve:GetAttri("LongName"));
				CheckReport.AddRelatedGeometry_Error(arrowGeom);
				-- CheckReport.AddRelatedGeometry_Error(polyline);
			end

			CurrentValveGroup = CurrentValveGroup:Unique();
			CurrentValveGroup:ForEach(function(ValveElement)
				CheckReport.AddRelatedObj(ValveElement,ValveElement:GetAttri("Name"));
			end)

			ConnectedWallsGroup:ForEach(function(Wall)
				CheckReport.AddRelatedObj(Wall,Wall:GetAttri("Name"));
			end)

			if(#WaterMeterGroup ~= 0)then 
				WaterMeterGroup:ForEach(function(MeterElement)
					CurrentMeterGroup:ForEach(function(WaterMeterElement)
						if(MeterElement.Id == WaterMeterElement.Id)then 
							CheckReport.AddRelatedObj(MeterElement,MeterElement:GetAttri("Name"));
						end
					end)					
				end)
			end		
			
		end)
	end
end