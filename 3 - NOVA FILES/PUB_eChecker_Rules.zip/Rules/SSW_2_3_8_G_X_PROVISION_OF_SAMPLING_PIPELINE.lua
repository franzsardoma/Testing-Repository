local FlowStorageDevGrp = FXGroup.new()
local ConnSegmentDevGrp = FXGroup.new()
local ObjProp;
local ObjValue;

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_3_8_G_X_PROVISION_OF_SAMPLING_PIPELINE")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	-- isRemovable = ConditionValues[1]; -- for Condition Values 

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				ObjProp = v1["property"];
				ObjValue = v1["value"];
			end
		end
	end

	for k,v in pairs(GrpObjs1) do
		
		if (k == 3) then
			FlowStorageDevGrp =   FlowStorageDevGrp + v;
			FlowStorageDevGrp = FlowStorageDevGrp:Unique()
		end
	end
end

function checkRule( Building )
	local FlowStorageCompTable = {}
	local ConnSegmentCompTable = {}
	local flowStorage
	local connSegment = false
	local FlowStorageDev = false
	local cntr = 0

	FlowStorageDevGrp:ForEach(function ( FlowStorageDevObj )

		flowStorage = FlowStorageDevObj
		local ConnSegment = FlowStorageDevObj:GetConnectedSegment()

		ConnSegment:ForEach(function ( ConnSegmentDevObj )
			local ConnSegmentDevObjName = ConnSegmentDevObj:GetAttri(ObjProp)
			if ( FXUtility.HasPatterInString(ConnSegmentDevObjName,ObjValue) ) then
				table.insert(FlowStorageCompTable, FlowStorageDevObj)
				table.insert(ConnSegmentCompTable, ConnSegmentDevObj)
				connSegment = true
			end
			
		end)

		FlowStorageDev = true
	end)

	if ( FlowStorageDev == false ) then
		FXUtility.DisplaySolid_Warning(Building, "Sewage Treatment Plant is not provided.")
	elseif ( FlowStorageDev == true ) then
		if ( connSegment == false ) then
			FXUtility.DisplaySolid_Error(flowStorage, "Sampling Pipeline for the Sewage Treatment Plant is not provided.")			
			CheckReport.AddRelatedObj(flowStorage, flowStorage:GetAttri("Name"))
		else
			local FlowStorage, ConnSegment

			for i = 1, #FlowStorageCompTable do
				FlowStorage = FlowStorageCompTable[i]
				ConnSegment = ConnSegmentCompTable[i]

				FXUtility.DisplaySolid_Info(FlowStorage, "A Sampling Pipeline is provided for the Sewage Treatment Plant.")
				CheckReport.AddRelatedObj(ConnSegment, ConnSegment:GetAttri("Name").."; ".. FlowStorage:GetAttri("Name"))				
			end
		end
	end
end