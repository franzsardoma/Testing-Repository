
local SewerPipes = FXGroup:new()
local bldgSewerPipes = FXGroup:new()
local Manhole = FXGroup:new()

local checkBooleanExpression

local istrue = 0
local isfalse = 0
local cnt = 0

function main()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
    .BindCheckFunc("GetRequiredEle")
    .Run()
    
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_9_C_JOINT_CONNECTIONS")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)

	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- checkBooleanExpression = tostring(ConditionValues[2] );

	repeat
		cnt = cnt + 2

		checkBooleanExpression = tostring(ConditionValues[cnt] );

			if checkBooleanExpression == "true" then
				istrue = istrue + 1 
			end

			if checkBooleanExpression == "false" then
				isfalse = isfalse + 1 
			end

	until (checkBooleanExpression == "nil")


	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			bldgSewerPipes = bldgSewerPipes + v;
			bldgSewerPipes = bldgSewerPipes:Unique();
		end	
	end

	for k,v in pairs(xmlObjs) do
		if (k == 2) then
			SewerPipes = SewerPipes + v;
			SewerPipes = SewerPipes:Unique();			    
		end

		if (k == 3) then
			Manhole = Manhole + v;
			Manhole = Manhole:Unique();			    
		end
	end

end

function GetRequiredEle(Building)
local BuildingStorey = Building:GetDescendants("BuildingStorey")

local IsCompliant = false

BuildingStorey:ForEach(function(storey)

	if #Manhole == 0 then
		CheckReport.Warning(storey,"Manhole is not provided.")
		return;
	end

	if #SewerPipes == 0 then
		CheckReport.Warning(storey,"Sewer pipes not provided.")
		return;
	end

end)

	local CollidedPipes = FXGroup:new()
	local NoParamManhole = FXGroup:new()
	local nilTbl = 0
	local trueTbl = 0
	local falseTbl = 0

	Manhole:ForEach(function(manhole)
		local CollidedPipesTemp = FXGroup:new()
		local checkWatertightA = manhole:GetAuxAttri("Mechanical.Point A Watertight")
		local checkWatertightB = manhole:GetAuxAttri("Mechanical.Point B Watertight")
		local checkWatertightC = manhole:GetAuxAttri("Mechanical.Point C Watertight")

		local names = {checkWatertightA, checkWatertightB, checkWatertightC}

		for cnt = 1, 3 do
			if names[cnt] == "true" then
				trueTbl = trueTbl + 1
			end

			if names[cnt] == "false" then
				falseTbl = falseTbl + 1
			end

			if names[cnt] == nil then
				nilTbl = nilTbl + 1
				NoParamManhole:Add(manhole)
			end
		end

		if #bldgSewerPipes ~= 0 then

			bldgSewerPipes:ForEach(function(pipe)

				if FXClashDetection.IsCollided(pipe,manhole) then
					CollidedPipes:Add(pipe)
					CollidedPipesTemp:Add(pipe)
				end
			end)
		end

		if #CollidedPipesTemp > 3 then
			FXUtility.DisplaySolid_Warning(manhole,"Connected sewer pipes are more than 3.")
			CollidedPipesTemp:ForEach(function(pipe)
				CheckReport.AddRelatedObj(pipe, " Connected Sewer Pipes : " .. pipe:GetAttri("Name"));
			end)
			return;
		end

	end)

	if nilTbl ~= 0 then
		NoParamManhole:ForEach(function(manhole)
			CheckReport.Warning(manhole,"No watertight parameters found in manhole property.")
		end)
		return;
	end

	Manhole:ForEach(function(manhole)
		local ColPipeTemp = FXGroup:new()
		if (istrue) == ((cnt - 2)/ 2) then
			IsCompliant = true
		end

		if IsCompliant == false then
				local ColManhole, ColPipes = GetColManholePipes(manhole, ColPipeTemp, bldgSewerPipes)

				local IsNonCompliant = IsNonCompliantAll(ColPipes, ColManhole)
			return
		else
			if falseTbl ~= 0 then

				local ColManhole, ColPipes = GetColManholePipes(manhole, ColPipeTemp, bldgSewerPipes)

				local IsNonCompliant = IsNonCompliantAll(ColPipes, ColManhole)

				return
			else
				if #CollidedPipes == #bldgSewerPipes then
					local ColManhole, ColPipes = GetColManholePipes(manhole, ColPipeTemp, bldgSewerPipes)

					local CompliantFunc = IsCompliantAll(ColPipes, ColManhole)
					
				else
					local ColManhole, ColPipes = GetColManholePipes(manhole, ColPipeTemp, bldgSewerPipes)

					local IsNonCompliant = IsNonCompliantAll(ColPipes, ColManhole)

				end
			end
		end

	end) 

end

function GetColManholePipes(manhole, ColPipeTemp, bldgSewerPipes)

local manholetemp = manhole 
	bldgSewerPipes:ForEach(function(pipe)

		if FXClashDetection.IsCollided(pipe,manhole) then
			ColPipeTemp:Add(pipe)
			manholetemp = manhole
		end
	end)

	return manholetemp, ColPipeTemp
end

function IsCompliantAll(CollidedPipes, manhole)
	
	FXUtility.DisplaySolid_Info(manhole, " Sewer pipe joint are Watertight.");
	CollidedPipes:ForEach(function(pipes)
		CheckReport.AddRelatedObj(pipes, " " .. pipes:GetAttri("Name"));
	end)
end

function IsNonCompliantAll(CollidedPipes, manhole)
	
	FXUtility.DisplaySolid_Error(manhole, " Sewer pipe joint are not Watertight.");

	if #CollidedPipes ~= 0 then
		CollidedPipes:ForEach(function(pipes)
			CheckReport.AddRelatedObj(pipes, " " .. pipes:GetAttri("Name"));
		end)
	end
end





