local grpAccessGrating = FXGroup.new()
local grpAccessFrame = FXGroup.new()
local grpDrain = FXGroup.new()

local minWidthOperator
local minWidth

local equalLengthOperator
local equalLength

local equalWidthOperator
local equalWidth

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_11_2_PROVISION_OF_ACCESS_OPENING_4M_X_2M_FOR_DRAINS")

	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3");
	local tblValues = FXRule.filterTableValues(parsedXml,Building)
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	minWidthOperator = ConditionValues1[2]
	minWidth = tonumber(ConditionValues1[3])
	minWidth = FXUtility.Round( minWidth , 0 )

	equalLengthOperator = ConditionValues2[2]
	equalLength = tonumber(ConditionValues2[3])
	equalLength = FXUtility.Round( equalLength , 0 )

	equalWidthOperator = ConditionValues3[2]
	equalWidth = tonumber(ConditionValues3[3])
	equalWidth = FXUtility.Round( equalWidth , 0 )
	-- for k,v in pairs(tblValues) do    
	-- 	for k1,v1 in pairs(v) do
	-- 		table.insert( railingTypes , v1["value"] )
	-- 	end
	-- end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 2) then
			grpAccessGrating = grpAccessGrating + v
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 3) then
			grpAccessFrame = grpAccessFrame + v
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do    
		if (k == 4) then
			grpDrain = grpDrain + v
		end	
	end
end


function CheckRule(Building)
	-- print (#grpAccessGrating.." - "..#grpAccessFrame.." - "..#grpDrain)
	local isErrorFound = false
	local x = 0
	local comObjArr = {}
	local comLengthLine = {}
	local comLengthPoly = {}
	local comWidthLine = {}
	local comWidthPoly = {}
	local grpCollidedSlab = FXGroup.new()

	if #grpDrain > 0 then
		grpDrain : ForEach ( function ( drainObj )

			local drainBox = FXGeom.GetBoundingBox( drainObj )

			local objproject = FXMeasure.GetObjProjection( drainObj , drainBox:HighPos().z - 100)
			local edges = FXMeasure.GetOuterEdge( objproject )
			local toface = edges:Face3D()
			local shrinkedFace

			local adder = 0
			while adder ~= 10000 do
				adder = adder + 1
				shrinkedFace = FXMeasure.ShrinkFace( toface , adder )
				local node = FXUtility.CreateNodeFrom( shrinkedFace )

				if FXClashDetection.IsCollided( node , drainObj ) == false then
					break;
				end
				FXClashDetection.DeleteNode(node)
			end 

			local longestLine , shortestLine = projLongestShortestLine ( shrinkedFace )
			local drainDoubleArrow = DoubleArrow ( longestLine:GetStartPoint() , longestLine:GetEndPoint() )	

			if FXRule.EvaluateNumber( minWidthOperator , FXUtility.Round( longestLine : Length() , 0 ) , minWidth ) then -- is >= minimum Drain width, then proceed to the main checking
				local grpSlab = drainObj:GetParent() : GetDescendants("Slab") -- get slabs on the same storey

				local grpColSlab = FXGroup.new()
				grpSlab : ForEach ( function ( slabObj )

					if FXClashDetection.IsCollided( drainObj , slabObj ) then 
						grpColSlab : Add ( slabObj ) -- get collided slab to drain
					end
				end)			

				local grpColFrame = FXGroup.new ()
				grpColSlab : ForEach (function ( slabObj )
					
					grpAccessFrame : ForEach ( function ( accessFrameObj )

						grpAccessGrating : ForEach ( function ( accessGratingObj )
							if FXClashDetection.IsCollided( accessFrameObj , accessGratingObj ) then -- to make sure the frame has grating inside
								-- local isAccessFrameInsideSlab = boundingBoxToProjectionCollidedToObj( slabObj , accessFrameObj )
								
								-- if isAccessFrameInsideSlab then -- to make sure the frame is inside the slab
								if FXClashDetection.IsCollided( accessFrameObj , slabObj ) then 
									grpColFrame : Add ( accessFrameObj) -- get the frame that has a grating, thats in the slab
								end
							end
						end)					
					end)				
				end)

				grpColFrame : ForEach ( function ( accessFrameObj )			
					local accessFrameHighPos = FXGeom.GetBoundingBox ( accessFrameObj ) : HighPos().z
		
					local topface = FXMeasure.GetTopFace ( accessFrameObj )
					local longestLine1 , shortestLine2 = projLongestShortestLine ( topface )

					local longestLinee , longestLineePoly = elevateLineWithPolyLine ( longestLine1 , accessFrameHighPos + 200) -- Elevate Line with PolyLine
					local shortestLinee , shortestLineePoly = elevateLineWithPolyLine ( shortestLine2 , accessFrameHighPos + 200) -- Elevate Line with PolyLine
					
					local doubleArrowLength = DoubleArrow ( longestLinee:GetStartPoint() , longestLinee:GetEndPoint() )
					local doubleArrowWidth = DoubleArrow ( shortestLinee:GetStartPoint() , shortestLinee:GetEndPoint() )
				
					local frameLength = tonumber( longestLinee:Length() )
					frameLength = FXUtility.Round( frameLength , 0 ) -- rounded off because sometimes having problem comparing 2000.0 and 2000, some works, some does not, in this case length is the problem

					local frameWidth = tonumber( shortestLinee:Length() )
					frameWidth = FXUtility.Round( frameWidth , 0 ) -- rounded off because sometimes having problem comparing 2000.0 and 2000, some works, some does not

					local isLengthCompliant = FXRule.EvaluateNumber( equalLengthOperator , frameLength , equalLength )
					local isWidthCompliant = FXRule.EvaluateNumber( equalWidthOperator , frameWidth , equalWidth ) 
			
					if isLengthCompliant == true and isWidthCompliant == true then
						x = x + 1
						-- comDrainArr   [x] = drainObj
						comObjArr     [x] = accessFrameObj
						comLengthLine [x] = longestLinee
						comLengthPoly [x] = longestLineePoly
						comWidthLine  [x] = shortestLinee
						comWidthPoly  [x] = shortestLineePoly

						print ( longestLinee:Length().. " -Compliant- " .. shortestLinee:Length())

					elseif isLengthCompliant == true and isWidthCompliant == false then
						FXUtility.DisplaySolid_Error ( accessFrameObj , accessFrameObj:GetAuxAttri("Entity.ObjectType").." : Opening Length = "..frameLength.." mm; is compliant." , doubleArrowLength)
						CheckReport.AddRelatedGeometry_Error( longestLineePoly , "Length")

						FXUtility.DisplaySolid_Error ( accessFrameObj , accessFrameObj:GetAuxAttri("Entity.ObjectType").." : Opening Width = "..frameWidth.." mm; is less than the required Width of "..equalWidth.." mm." , doubleArrowWidth)
						CheckReport.AddRelatedGeometry_Error( shortestLineePoly , "Width")
			
						isErrorFound = true

					elseif isLengthCompliant == false and isWidthCompliant == true then
						FXUtility.DisplaySolid_Error ( accessFrameObj , accessFrameObj:GetAuxAttri("Entity.ObjectType").." : Opening Length = "..frameLength.." mm; is less than the required length of "..equalLength.." mm." , doubleArrowLength)
						CheckReport.AddRelatedGeometry_Error( longestLineePoly , "Length")

						FXUtility.DisplaySolid_Error ( accessFrameObj , accessFrameObj:GetAuxAttri("Entity.ObjectType").." : Opening Width = "..frameWidth.." mm; is compliant." , doubleArrowWidth)
						CheckReport.AddRelatedGeometry_Error( shortestLineePoly , "Width")

						print ( longestLinee:Length().. " -Not- " .. shortestLinee:Length())

						isErrorFound = true

					elseif isLengthCompliant == false and isWidthCompliant == false then
						FXUtility.DisplaySolid_Error ( accessFrameObj , accessFrameObj:GetAuxAttri("Entity.ObjectType").." : Opening Length = "..frameLength.." mm; is less than the required length of "..equalLength.." mm." , doubleArrowLength)
						CheckReport.AddRelatedGeometry_Error( longestLineePoly , "Length")

						FXUtility.DisplaySolid_Error ( accessFrameObj , accessFrameObj:GetAuxAttri("Entity.ObjectType").." : Opening Width = "..frameWidth.." mm; is than the required Width of "..equalWidth.." mm." , doubleArrowWidth)
						CheckReport.AddRelatedGeometry_Error( shortestLineePoly , "Width")
				
						isErrorFound = true
					end			
				end)
			else
				FXUtility.DisplaySolid_Warning ( drainObj , "Width of Roadside Drain is less than "..minWidth.." mm." , drainDoubleArrow )
			end
		end)

		if isErrorFound == false then
			local y = 1 
			while y ~= x+1 do
				local DAlength = DoubleArrow ( comLengthLine[y]:GetStartPoint() , comLengthLine[y]:GetEndPoint() )
				local DAwidth = DoubleArrow ( comWidthLine  [y]:GetStartPoint() , comWidthLine [y]:GetEndPoint() )

				FXUtility.DisplaySolid_Info ( comObjArr     [y] , comObjArr[y]:GetAuxAttri("Entity.ObjectType").." : Opening Length = "..comLengthLine[y]:Length().." mm; is compliant." , DAlength )
				CheckReport.AddRelatedObj ( comObjArr		[y] , comObjArr[y]:GetAttri("Name") )
				CheckReport.AddRelatedGeometry_Info( comLengthPoly[y] , "Length")

				FXUtility.DisplaySolid_Info ( comObjArr		[y] , comObjArr[y]:GetAuxAttri("Entity.ObjectType").." : Opening Width = "..comWidthLine  [y]:Length().." mm; is compliant." , DAwidth )
				CheckReport.AddRelatedObj ( comObjArr		[y] , comObjArr[y]:GetAttri("Name") )
				CheckReport.AddRelatedGeometry_Info( comWidthPoly          [y] , "Width")

				y = y + 1
			end
		end
	else
		FXUtility.DisplaySolid_Warning ( Building , "Roadside Drain is not provided.");
	end
end


function SetSamplePoint( StartPoint,EndPoint,MatrixUnitWidth)
	local SamplePoints = {};
	if(StartPoint~=nil and EndPoint~= nil) then
		local Line = EndPoint:Sub_Pnt(StartPoint);
		if(Line~=nil) then
			local LineVec = Vector(Line.x,Line.y,Line.z);
			if(LineVec ~= nil) then
				LineVec:Normalize();
				local SamplePointNumber = math.floor((Line3D(StartPoint,EndPoint):Length())/MatrixUnitWidth);
				if(SamplePointNumber ~= nil) then
					for i=0,SamplePointNumber-1 do
						SamplePoints[#SamplePoints+1] = StartPoint:Add_Vec(Vector(i*MatrixUnitWidth*LineVec.x,i*MatrixUnitWidth*LineVec.y,i*MatrixUnitWidth*LineVec.z))
					end
				end
			end
			SamplePoints.Vector = LineVec;
		end
	end
	return SamplePoints;
end


function projLongestShortestLine( projection )
	local outerPrj = FXMeasure.GetOuterEdge( projection );
    local noOfEdgePnt = outerPrj:GetPointNumber();  
    local longestLine
    local shortestLine

    for i = 0, noOfEdgePnt -2, 1  do 
    	local pnt1  		    = outerPrj:GetPoint( i );
		local pnt2		 	    = outerPrj:GetPoint( i + 1 );
		local thisLine      	= Line3D( pnt1 , pnt2 );
		
		if longestLine == nil or longestLine:Length() < thisLine:Length() then
			longestLine = thisLine
		end

		if shortestLine == nil or shortestLine:Length() > thisLine:Length() then
			shortestLine = thisLine
		end
    end

    return longestLine , shortestLine
end


-- function boundingBoxToProjectionCollidedToObj( obj , objToCollide )
-- 	local bool = false

-- 	local box = FXGeom.GetBoundingBox( obj )
-- 	local node = FXUtility.CreateNodeFrom( box )
-- 	local proj = FXMeasure.GetObjProjection( node , box:LowPos().z)
-- 	FXClashDetection.DeleteNode(node)

-- 	local outerPrj = FXMeasure.GetOuterEdge( proj )
-- 	local face = outerPrj : Face3D()
-- 	local extrudedFace = face:ExtrudedFace(Vector(0, 0, box:HighPos().z + 100 ))

-- 	local node2 = FXUtility.CreateNodeFrom( extrudedFace )
-- 	if FXClashDetection.IsCollided( node2 , objToCollide ) then
-- 		bool = true
-- 	end
-- 	FXClashDetection.DeleteNode( node2 )

-- 	return bool
-- end


function elevateLineWithPolyLine( line , elevation )
	local polyLine = PolyLine3D(TRUE)
	local startPoint = line:GetStartPoint()
	local endPoint = line:GetEndPoint()

	local pnt1 = Point3D ( startPoint.x , startPoint.y , elevation )
	local pnt2 = Point3D ( endPoint.x , endPoint.y , elevation )

	polyLine:AddPoint( startPoint );
	polyLine:AddPoint( pnt1 );
	polyLine:AddPoint( pnt2 );
	polyLine:AddPoint( endPoint );

	local line = Line3D ( pnt1 , pnt2 )

	return line , polyLine
end