--[[
	Modified By: Lawrence Roy R. Quiling 01/30/2019
]]

local grpTanks 			= FXGroup:new()
local grpWarningLevels 	= FXGroup:new()
local grpWaterLines		= FXGroup:new()
local OperatorDistance, ConditionDistance
local WarningLevel_Val, WaterLine_Val, Tank_Val

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRules");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_7_WATER_LINE_FOR_WATER_STORAGE_TANK")
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	OperatorDistance 	= ConditionValues[2]
	ConditionDistance 	= tonumber(ConditionValues[3])

	if GrpObjsBuilding ~= nil then
		for k,v in pairs(GrpObjsBuilding) do
			if (k == 2) then
				grpWarningLevels = grpWarningLevels + v;
				grpWarningLevels = grpWarningLevels:Unique();
			end
	 
			if (k == 3) then
				grpWaterLines = grpWaterLines + v;
				grpWaterLines = grpWaterLines:Unique();
			end
		end
	end

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 4) then
				grpTanks = grpTanks + v;
				grpTanks = grpTanks:Unique();
			end
		end
	end
	
	local Values1 = {}
	local Values2 = {}
	local Values3 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
			if(k == 2) then
				table.insert(Values2, v1["value"])
			end
			if(k == 3) then
				table.insert(Values3, v1["value"])
			end
		end
	end

	WarningLevel_Val = getValue( Values1 )
	WaterLine_Val 	 = getValue( Values2 )
	Tank_Val 		 = getValue( Values3 )
end

function getValue( tab )
	local value = tab[1]
	local length = #tab

	for k,v in pairs(tab) do
		if k ~= 1 then
			if k ~= length then
				value = value..", "..v
			
			elseif k == length then 
				value = value.." or "..v
			end
		end
	end
	return value
end

function CheckWarning( Building )
	local flag = isNotWarning( grpWarningLevels, Building, WarningLevel_Val, true )
	flag = isNotWarning( grpWaterLines, Building, WaterLine_Val, flag )
	return isNotWarning( grpTanks, Building, Tank_Val, flag )
end

function isNotWarning( grpObjs, Building, Value, currentResult )
	if(#grpObjs == 0) then
		CheckReport.Warning( Building, Value.." is not provided.")
		return false
	end
	return currentResult
end

function checkRules(Building)
	if(CheckWarning(Building)) then
		local NoWarningFound = true
		local TabDistances = {}
		local TabTanks = {}
		local TabWarningLevels = {}
		local TabWaterLines = {}

		grpTanks:ForEach(function ( Tank )
			local tempWarningLevel, tempWaterLine = getInside( Tank )
		
			if tempWarningLevel == nil then
				CheckReport.Warning( Tank, WarningLevel_Val.." is not detected.")
				NoWarningFound = false
			end
			if tempWaterLine == nil then
				CheckReport.Warning( Tank, WaterLine_Val.." is not detected.")
				NoWarningFound = false
			end
			if CheckWarningLevelIsAbove( tempWarningLevel, tempWaterLine ) == false then
				CheckReport.Warning( tempWaterLine, tempWaterLine:GetAttri("ObjectType").." is above "..tempWarningLevel:GetAttri("ObjectType"))
				CheckReport.AddRelatedObj(tempWarningLevel, tempWarningLevel:GetAttri("ObjectType"))
				NoWarningFound = false
			end
			if NoWarningFound then
				-- table.insert(TabTanks, Tank)
				-- table.insert(TabWarningLevels, tempWarningLevel)
				-- table.insert(TabWaterLines, tempWaterLine)
				-- table.insert(TabDistances, getDistance( tempWarningLevel, tempWaterLine ))
				local Dist = getDistance( tempWarningLevel, tempWaterLine )
				-- local IsErroNotFound = true
				-- local TabCom_Tank = {}
				-- local TabCom_Dist = {}
				-- local TabCom_WarningLevels = {}
				-- local TabCom_WaterLines = {}

				-- for k,Dist in pairs(TabDistances) do
					if FXRule.EvaluateNumber( OperatorDistance  , Dist:Length() , ConditionDistance ) then
						-- table.insert(TabCom_Tank, TabTanks[k])
						-- table.insert(TabCom_Dist, Dist)
						-- table.insert(TabCom_WarningLevels, TabWarningLevels[k])
						-- table.insert(TabCom_WaterLines, TabWaterLines[k])
						FXUtility.DisplaySolid_Info(Tank, "Distance between "..tempWarningLevel:GetAttri("ObjectType").." and "..tempWaterLine:GetAttri("ObjectType").." is "..FXUtility.Round(tonumber(Dist:Length())).." mm")
						CheckReport.AddRelatedObj(tempWarningLevel, tempWarningLevel:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(tempWaterLine, tempWaterLine:GetAttri("ObjectType"))
						CheckReport.AddRelatedGeometry_Info(DoubleArrow(Dist:GetStartPoint(), Dist:GetEndPoint()))

					else
						FXUtility.DisplaySolid_Error(Tank, "Distance between "..tempWarningLevel:GetAttri("ObjectType").." and "..tempWaterLine:GetAttri("ObjectType").." is "..FXUtility.Round(tonumber(Dist:Length())).." mm")
						CheckReport.AddRelatedObj(tempWarningLevel, tempWarningLevel:GetAttri("ObjectType"))
						CheckReport.AddRelatedObj(tempWaterLine, tempWaterLine:GetAttri("ObjectType"))
						CheckReport.AddRelatedGeometry_Error(DoubleArrow(Dist:GetStartPoint(), Dist:GetEndPoint()))
						-- IsErroNotFound = false
					end
				-- end

				-- if IsErroNotFound then
				-- 	for k,Dist in pairs(TabCom_Dist) do
				-- 		FXUtility.DisplaySolid_Info(TabCom_Tank[k], "Distance between "..TabCom_WarningLevels[k]:GetAttri("ObjectType").." and "..TabCom_WaterLines[k]:GetAttri("ObjectType").." is "..FXUtility.Round(tonumber(Dist:Length())).." mm")
				-- 		CheckReport.AddRelatedObj(TabCom_WarningLevels[k], TabCom_WarningLevels[k]:GetAttri("ObjectType"))
				-- 		CheckReport.AddRelatedObj(TabCom_WaterLines[k], TabCom_WaterLines[k]:GetAttri("ObjectType"))
				-- 		CheckReport.AddRelatedGeometry_Info(DoubleArrow(Dist:GetStartPoint(), Dist:GetEndPoint()))
				-- 	end
				-- end
			end
		end)
		
		-- if NoWarningFound then
		-- 	local IsErroNotFound = true
		-- 	local TabCom_Tank = {}
		-- 	local TabCom_Dist = {}
		-- 	local TabCom_WarningLevels = {}
		-- 	local TabCom_WaterLines = {}

		-- 	for k,Dist in pairs(TabDistances) do
		-- 		if FXRule.EvaluateNumber( OperatorDistance  , Dist:Length() , ConditionDistance ) then
		-- 			table.insert(TabCom_Tank, TabTanks[k])
		-- 			table.insert(TabCom_Dist, Dist)
		-- 			table.insert(TabCom_WarningLevels, TabWarningLevels[k])
		-- 			table.insert(TabCom_WaterLines, TabWaterLines[k])
		-- 		else
		-- 			FXUtility.DisplaySolid_Error(TabTanks[k], "Distance between "..TabWarningLevels[k]:GetAttri("ObjectType").." and "..TabWaterLines[k]:GetAttri("ObjectType").." is "..FXUtility.Round(tonumber(Dist:Length())).." mm")
		-- 			CheckReport.AddRelatedObj(TabWarningLevels[k], TabWarningLevels[k]:GetAttri("ObjectType"))
		-- 			CheckReport.AddRelatedObj(TabWaterLines[k], TabWaterLines[k]:GetAttri("ObjectType"))
		-- 			CheckReport.AddRelatedGeometry_Error(DoubleArrow(Dist:GetStartPoint(), Dist:GetEndPoint()))
		-- 			IsErroNotFound = false
		-- 		end
		-- 	end

		-- 	if IsErroNotFound then
		-- 		for k,Dist in pairs(TabCom_Dist) do
		-- 			FXUtility.DisplaySolid_Info(TabCom_Tank[k], "Distance between "..TabCom_WarningLevels[k]:GetAttri("ObjectType").." and "..TabCom_WaterLines[k]:GetAttri("ObjectType").." is "..FXUtility.Round(tonumber(Dist:Length())).." mm")
		-- 			CheckReport.AddRelatedObj(TabCom_WarningLevels[k], TabCom_WarningLevels[k]:GetAttri("ObjectType"))
		-- 			CheckReport.AddRelatedObj(TabCom_WaterLines[k], TabCom_WaterLines[k]:GetAttri("ObjectType"))
		-- 			CheckReport.AddRelatedGeometry_Info(DoubleArrow(Dist:GetStartPoint(), Dist:GetEndPoint()))
		-- 		end
		-- 	end
		-- end
	end
end

function CheckWarningLevelIsAbove( WarningLevel, WaterLine )
	local MidPosWarningLevel = FXGeom.GetBoundingBox(WarningLevel):MidPos().z
	local MidPosWaterLine = FXGeom.GetBoundingBox(WaterLine):MidPos().z

	if tonumber(MidPosWarningLevel) < tonumber(MidPosWaterLine) then
		return false
	end
	return true
end

function getDistance( tempWarningLevel, tempWaterLine  )
	local MidPosTempWarningLevel = FXGeom.GetBoundingBox(tempWarningLevel):MidPos().z
	local MidPostempWaterLine = FXGeom.GetBoundingBox(tempWaterLine):MidPos().z
	local dist = FXRelation.Distance(tempWarningLevel, tempWaterLine);
	return Line3D(Point3D(dist:GetStartPoint().x, dist:GetStartPoint().y, MidPosTempWarningLevel), Point3D(dist:GetEndPoint().x, dist:GetEndPoint().y, MidPostempWaterLine))
end

function getInside( Tank )
	local TankMaxZ = tonumber(FXGeom.GetBoundingBox(Tank):HighPos().z)
	local TankMinZ = tonumber(FXGeom.GetBoundingBox(Tank):LowPos().z)
	local TankMidPos = FXGeom.GetBoundingBox(Tank):MidPos()
	local limit = TankMaxZ - TankMinZ
	local MaxInsidePoint = TankMidPos

	while limit > 0 do
		limit = limit - 1

		MaxInsidePoint = Point3D(MaxInsidePoint.x , MaxInsidePoint.y, MaxInsidePoint.z + 1);
		local TempLine = Line3D(TankMidPos , MaxInsidePoint);
		local TempLineNode = FXUtility.CreateNodeFrom(TempLine);
		
		if(FXClashDetection.IsCollided(TempLineNode, Tank))then
			FXClashDetection.DeleteNode(TempLineNode);
			break;
		end
		FXClashDetection.DeleteNode(TempLineNode);
	end

	local limit = TankMaxZ - TankMinZ
	local MinInsidePoint = TankMidPos

	while limit > 0 do
		limit = limit - 1

		MinInsidePoint = Point3D(MinInsidePoint.x , MinInsidePoint.y, MinInsidePoint.z - 1);
		local TempLine = Line3D(TankMidPos , MinInsidePoint);
		local TempLineNode = FXUtility.CreateNodeFrom(TempLine);
		
		if(FXClashDetection.IsCollided(TempLineNode, Tank))then
			FXClashDetection.DeleteNode(TempLineNode);
			break;
		end
		FXClashDetection.DeleteNode(TempLineNode);
	end

	TankMaxZ = tonumber(MaxInsidePoint.z)
	TankMinZ = tonumber(MinInsidePoint.z)

	local TankPrj = FXMeasure.GetObjProjection(Tank, 0);
	local tempWarningLevel, tempWaterLine

	grpWarningLevels:ForEach(function ( WaterLevel )
		if tempWarningLevel ~= nil then return end
		local WaterLevelMidZ = tonumber(FXGeom.GetBoundingBox(WaterLevel):MidPos().z)

		if WaterLevelMidZ < TankMaxZ and WaterLevelMidZ > TankMinZ then
			local WaterLevelPrj = FXMeasure.GetObjProjection(WaterLevel, 0);
			local PrjFinal = FXMeasure.SubtractProjection(WaterLevelPrj, TankPrj, 0);
		
			if PrjFinal == nil then
				tempWarningLevel = WaterLevel
			end
		end
	end)

	grpWaterLines:ForEach(function ( WaterLine )
		if tempWaterLine ~= nil then return end
		local WaterLineMidZ = tonumber(FXGeom.GetBoundingBox(WaterLine):MidPos().z)

		if WaterLineMidZ < TankMaxZ and WaterLineMidZ > TankMinZ then
			local WaterLinePrj = FXMeasure.GetObjProjection(WaterLine, 0);
			local PrjFinal = FXMeasure.SubtractProjection(WaterLinePrj, TankPrj, 0);

			if PrjFinal == nil then
				tempWaterLine = WaterLine
			end
		end
	end)
	return tempWarningLevel, tempWaterLine
end