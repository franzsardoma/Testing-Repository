local grpManhole = FXGroup.new()
local grpSewerConnection = FXGroup.new()
local grpPublicSewer = FXGroup.new()
local grpVortexDrop = FXGroup.new()
local hasVortexDrop = false
local publicSewerNominalDiameter
local verticalDistance
local lowerSewer
local highestSewer
local connectedVortexDrop
local highestSewerMinZ
local publicSewerMinZ
local currentManhole
local connectedPublicSewer
local operator
local condiValue


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_8_C_VORTEXDROP")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building)
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType")
	local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

	operator = Condition1[2]
	condiValue = tonumber(Condition1[3])

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpManhole = grpManhole + v
			grpManhole = grpManhole:Unique()	
		end
		if (k == 3) then
			grpSewerConnection = grpSewerConnection + v
			grpSewerConnection = grpSewerConnection:Unique()
		end
		if (k == 4) then
			grpPublicSewer = grpPublicSewer + v
			grpPublicSewer = grpPublicSewer:Unique()
		end
		if (k == 5) then
			grpVortexDrop = grpVortexDrop + v
			grpVortexDrop = grpVortexDrop:Unique()
		end
	end
end

function checkRule(Building)

	if CheckWarning(Building) then

		grpManhole:ForEach(function(Manhole)
						
			currentManhole = Manhole
			local isCompliant = false
			local manholeName = Manhole:GetAttri("Name")
			local msg = ""
			local relatedObj

			grpPublicSewer:ForEach(function(publicSewer)

				if ( FXPUB.CheckConnectedChamberElement(Building, Manhole, publicSewer) ) then
								
					connectedPublicSewer = publicSewer
					local publicSewerOBB = FXGeom. GetBoundingOBB(publicSewer)
					local minPnt = publicSewerOBB:GetPos()
					publicSewerMinZ = minPnt.z
					publicSewerNominalDiameter = FXPUB.GetDiameter(publicSewer)
					publicSewerNominalDiameter = tonumber(publicSewerNominalDiameter)
				end
			end)

			if ( publicSewerNominalDiameter ~= nil and publicSewerNominalDiameter > 450 ) then

				if ( #grpVortexDrop ~= 0 )then
					grpVortexDrop:ForEach(function(vortexDrop)
						if ( #grpSewerConnection ~= 0 ) then
							grpSewerConnection:ForEach(function(sewer)
											
								if ( FXPUB.IsObjsConnected(vortexDrop, sewer, 2) ) then
									
									connectedVortexDrop = vortexDrop
								end
								GetHighAndLowSewer(sewer)
							end)
						end
					end)
					isCompliant = CheckVortexDrop(Building, Manhole)
				else

					FXUtility.DisplaySolid_Error(Manhole, manholeName..":  Vortex Drop connection is not provided.")
					-- CheckReport.AddRelatedObj(relatedObj, msg)
				end
			else						
				if ( #grpSewerConnection ~= 0 ) then
					grpSewerConnection:ForEach(function(sewer)
												
						GetHighAndLowSewer(sewer)								
					end)
				end		           

				if ( publicSewerMinZ ~= nil and highestSewerMinZ ~= nil ) then

					verticalDistance = FXUtility.Round(highestSewerMinZ - publicSewerMinZ, 0)
					
					if ( FXRule.EvaluateNumber(operator,verticalDistance,condiValue) ) == true then

						if ( #grpVortexDrop ~= 0 ) then
							grpVortexDrop:ForEach(function (vortexDrop)
								
								if ( #grpSewerConnection ~= 0 ) then
									grpSewerConnection:ForEach(function(sewer)
														
										if ( FXPUB.IsObjsConnected(vortexDrop, sewer, 2) ) then
											connectedVortexDrop = vortexDrop
											GetHighAndLowSewer(sewer)
										end
									end)
								end
							end)

							if ( FXPUB.CheckConnectedChamberElement(Building, Manhole, lowerSewer) ) then
								if ( FXPUB.IsObjsConnected(lowerSewer, connectedVortexDrop) ) then
									isCompliant = true
								end
							end						
						else

							FXUtility.DisplaySolid_Error(Manhole, manholeName..":  Vortex Drop connection is not provided.")
							CheckReport.AddRelatedObj(relatedObj, msg)	
						end
					else
						FXUtility.DisplaySolid_Warning(Building, "Vertical Distance between Sewer Connection and Public Sewer is less than 6 mm")
						return
					end
				end							
			end
			if ( verticalDistance ~= nil ) then
				msg = "Vertical Distance: "..verticalDistance.." mm"
				relatedObj = currentManhole
			else
				msg = "Public Sewer Nominal Diameter: "..publicSewerNominalDiameter.." mm"
				relatedObj = connectedPublicSewer
			end

			CheckResult(Manhole, isCompliant, manholeName, relatedObj, msg, connectedVortexDrop)								
		end)
	end
end

function GetHighAndLowSewer(sewer)
	
	local sewerOBB = FXGeom. GetBoundingOBB(sewer)
	local minPnt = sewerOBB:MinPnt()
	local sewerMinZ = minPnt.z
	if ( highestSewerMinZ == nil ) then
		highestSewerMinZ = sewerMinZ
		highestSewer = sewer
		lowerSewer = sewer
	else
		if ( highestSewerMinZ < sewerMinZ ) then
			highestSewerMinZ = sewerMinZ;
			highestSewer = sewer
		else
			lowerSewer = sewer
		end
	end			
end

function CheckVortexDrop(Building, Manhole)
	local isCompliant = false
	if  ( FXClashDetection.IsCollided(lowerSewer, Manhole) ) then
		if ( FXPUB.IsObjsConnected(lowerSewer, connectedVortexDrop) ) then
			isCompliant = true
		end
	else

		local pipeReducer = Building:GetDescendants("FlowFitting")
		pipeReducer:ForEach(function ( reducer )
			if ( FXClashDetection.IsCollided(reducer, Manhole) ) then
				if ( FXPUB.IsObjsConnected(reducer, connectedVortexDrop) ) then
					isCompliant = true
				end
			end
		end)
	end
	return isCompliant
end

function CheckResult(Manhole, isCompliant, manholeName, relatedObj, msg, connectedVortexDrop)
	
	if isCompliant then

		FXUtility.DisplaySolid_Info(Manhole, manholeName..":  Vortex Drop connection is provided.")
		CheckReport.AddRelatedObj(relatedObj, msg)
		CheckReport.AddRelatedObj(connectedVortexDrop, connectedVortexDrop:GetAttri("Name"))
	end
end

function CheckWarning(Building)

	local noWarning = true

	if ( #grpManhole == 0 ) then

		FXUtility.DisplaySolid_Warning(Building, "Manhole is not provided")
		noWarning = false
	end

	if ( #grpSewerConnection == 0 ) then

		FXUtility.DisplaySolid_Warning(Building, "Sewer Connection is not provided")
		noWarning = false
	end

	if ( #grpPublicSewer == 0 ) then

		FXUtility.DisplaySolid_Warning(Building, "Public Sewer is not provided")
		noWarning = false
	end

	return noWarning
end


