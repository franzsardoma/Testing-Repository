--[[-----------------------------------------------------

Author: Monalyn L. Rueda

Rule ID: SSW 2.4.1.3 (a) (6)
Rule Name: Lifting Equipment for Ejector/Divertor Pit

All copyrights to novasolutions 
--]]-----------------------------------------------------
local EDPitGrp = FXGroup:new()
local LiftGrp = FXGroup:new()
local CollidedWalls = FXGroup:new()
local IsCompliant, Lift


function main()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("CheckRules")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("Building")
 --    .BindCheckFunc("CheckProvision")
 --    .Run()
    
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_4_1_3_a_6_LIFT")

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			EDPitGrp = EDPitGrp + v;
			EDPitGrp = EDPitGrp:Unique();
		end	
		
		if (k == 3) then
			LiftGrp = LiftGrp + v;
			LiftGrp = LiftGrp:Unique();			    
		end
	end
end

function CheckRules(Building)
local CollidedLift = FXGroup:new()
local CollidedSpaces = FXGroup:new()

if #EDPitGrp == 0 then
	print("No Ejector/Divertor Pit found.")
	FXUtility.DisplaySolid_Warning(Building, "Ejector/Divertor Pit is not provided.")
	return;
end

	EDPitGrp:ForEach(function(space)
		local Lift
		local ColLift = CheckCollidedObj(space, CollidedLift, CollidedSpaces, LiftGrp, Lift)
	end)

	if #CollidedLift ~= #LiftGrp or #LiftGrp == 0 then

		EDPitGrp = EDPitGrp - CollidedSpaces
		EDPitGrp:ForEach(function(space)
			FXUtility.DisplaySolid_Error(space, "Lifting equipment is not provided");
		end)
		return
	else

		EDPitGrp:ForEach(function(space)
			local Lift
			local ColLift = CheckCollidedObj(space, CollidedLift, CollidedSpaces, LiftGrp, Lift)

			FXUtility.DisplaySolid_Info(space, "Lifting equipment is provided");
			CheckReport.AddRelatedObj(ColLift, ColLift:GetAttri("Name"));

		end)
	end

end

function CheckCollidedObj(space, CollidedLift, CollidedSpaces, LiftGrp, Lift)

	local SpaceOBB = FXGeom.GetBoundingOBB(space)
	local SpaceNode =  FXClashDetection.CreateNode()
	FXClashDetection.AddGeometry(SpaceNode, SpaceOBB)

	if (#LiftGrp ~= 0) then
		LiftGrp:ForEach(function(lift)
			if FXClashDetection.IsCollided(SpaceNode,lift) then
				CollidedLift:Add(lift)
				CollidedSpaces:Add(space)
				Lift = lift
			end
		end)
	end
	FXClashDetection.DeleteNode(SpaceNode);

	return Lift
end




