local grpStopValves = FXGroup:new();
local grpWaterMeters = FXGroup:new();
local grpSubMeters = FXGroup:new(); 
local Element1Tab = {}
local StopValveValues
local MainWMValues

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_4_7_PROVISION_OF_STOPVALVES")
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	-- print(#GrpObjs)
	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			-- if (k == 2) then
			-- 	grpStopValves = grpStopValves + v;
			-- 	grpStopValves = grpStopValves:Unique();
			-- end
			if (k == 3) then
				grpWaterMeters = grpWaterMeters + v;
				grpWaterMeters = grpWaterMeters:Unique();
			end
			if (k == 4) then
				grpSubMeters = grpSubMeters + v;
				grpSubMeters = grpSubMeters:Unique();
			end
		end
	end

	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	
	local Values2 = {}

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Element1Tab, v1["value"])
			end
			if(k == 2) then
				table.insert(Values2, v1["value"])
			end
		end
	end

	StopValveValues = Element1Tab[1]
	for k,v in pairs(Element1Tab) do
		if k ~= 1 then
			StopValveValues = StopValveValues.." or "..v
		end
	end

	MainWMValues = Values2[1]
	for k,v in pairs(Values2) do
		if k ~= 1 then
			MainWMValues = MainWMValues.." or "..v
		end
	end
end

function checkRule( Building )
	local flag = true
	local grpSegments = Building:GetDescendants("FlowSegment")
	local grpFittings = Building:GetDescendants("FlowFitting")
	local grpFlowConTrollers = Building:GetDescendants("FlowController")
	local grpFlowObjs = grpSegments + grpFittings + grpFlowConTrollers;
	local PipePUB;
	
	grpSegments:ForEach(function ( Segment )
		if (FXUtility.HasPatterInString(Segment:GetAttri("ObjectType"),"PUB Mains")) then
			PipePUB = Segment;
		end
	end)

	if(PipePUB == nil) then
		flag = false	
		CheckReport.Warning( Building, "PUB Main pipe is not provided" )
	end

	if(#grpWaterMeters == 0) then
		flag = false	
		CheckReport.Warning( Building, MainWMValues.." is not provided" )
	end

	if(flag == true) then
		local IsErrorNotFound = true
		
		if (#grpSubMeters ~= 0) then        ---------------------------------- Sub meter -----------------------------------
			local ARRComStopValve2 = {}
			local ARRNonSubMeterEle = {}
			local ARRgrOBJS = {}
			local count = 0

			grpSubMeters:ForEach(function ( SubMeterEle )
				local grpConnObjs = SubMeterEle:GetConnectedElement();
				local IsBothError = true
				local grpCONNOBJS1 = FXGroup:new()
				local grpCONNOBJS2 = FXGroup:new()
				local ARRNonConnObj = {}
				local ARRNonObj = {}

				local i = 0
				grpConnObjs:ForEach(function ( ConnObj )
					i = i + 1
					local StopValve2, grpObjsToBuilding = getStopValve( ConnObj, SubMeterEle )

					if(StopValve2 ~= nil) then
						table.insert(ARRComStopValve2,StopValve2)
						IsBothError = false
					else
						IsErrorNotFound = false

						if i == 1 then
							grpCONNOBJS1 = grpObjsToBuilding
						else
							grpCONNOBJS2 = grpObjsToBuilding
						end
						if count == 0 or count > #grpObjsToBuilding then
							count = #grpObjsToBuilding
						end
						table.insert(ARRNonConnObj,ConnObj)
						table.insert(ARRNonObj,grpObjsToBuilding)
					end
				end)

				if IsBothError then
					table.insert(ARRNonSubMeterEle,SubMeterEle)
					FXUtility.DisplaySolid_Error( SubMeterEle, StopValveValues.." is not provided." )
					CheckReport.AddRelatedObj( SubMeterEle, SubMeterEle:GetAttri("ObjectType") )
					
					local z = 0
					grpCONNOBJS1:ForEach(function ( Obj )
						z = z + 1
						if(z > count) then
							return;
						end
						CheckReport.AddRelatedObj( Obj, Obj:GetAttri("ObjectType") )
					end)
					z = 0
					grpCONNOBJS2:ForEach(function ( Obj )
						z = z + 1
						if(z > count) then
							return;
						end
						CheckReport.AddRelatedObj( Obj, Obj:GetAttri("ObjectType") )
					end)
				else
					for k,ConnObj in pairs(ARRNonConnObj) do
						FXUtility.DisplaySolid_Error( ConnObj, StopValveValues.." is not provided" )
						ARRNonObj[k]:ForEach(function ( Obj )
							CheckReport.AddRelatedObj( Obj, Obj:GetAttri("ObjectType") )
						end)
						
					end
				end
			end)

			if IsErrorNotFound then
				for k,StopValve2 in pairs(ARRComStopValve2) do
					FXUtility.DisplaySolid_Info( StopValve2, StopValve2:GetAttri("ObjectType").." is provided" )
					CheckReport.AddRelatedObj( StopValve2, StopValve2:GetAttri("ObjectType") )
				end
			end

		else                  	 		---------------------------------- Main meter ----------------------------------
			
			local grpStopValveCompliant = FXGroup:new()
			local ARRComStopValve = {}

			grpWaterMeters:ForEach(function ( WaterMeter )
				local connObj = getConnObjToBuilding( WaterMeter, grpFlowObjs, PipePUB )
				
				if(connObj ~= nil) then
					local StopValve, grpObjsToBuilding = getStopValve( connObj, WaterMeter )
					if(StopValve ~= nil) then
						table.insert(ARRComStopValve, StopValve)
					else
						IsErrorNotFound = false
						FXUtility.DisplaySolid_Error( connObj, StopValveValues.." is not provided." )
						grpObjsToBuilding:ForEach(function ( ObjsToBuildingEle )
							CheckReport.AddRelatedObj( ObjsToBuildingEle, ObjsToBuildingEle:GetAttri("ObjectType") )
						end)
					end
				else
					FXUtility.DisplaySolid_Error( WaterMeter, "There is no pipe segment connected to building" )
				end
			end)

			if IsErrorNotFound then
				for k,StopValve in pairs(ARRComStopValve) do
					FXUtility.DisplaySolid_Info( StopValve, StopValve:GetAttri("ObjectType").." is provided" )
					CheckReport.AddRelatedObj( StopValve, StopValve:GetAttri("ObjectType") )
				end
			end
		end
	end
end

function getStopValve( ConnObj, PrevObj )
	local StopValve;
	local grpObjsToBuilding = FXGroup:new()
	local grpObjsToBuilding2 = FXGroup:new();
	local grpConnObjs = ConnObj:GetConnectedElement();
	grpConnObjs:Sub(PrevObj)
	grpObjsToBuilding:Add(ConnObj)

	grpConnObjs:ForEach(function ( ConnObjEle )
		if (HasValue(ConnObjEle:GetAttri("ObjectType"),Element1Tab) and FXUtility.HasPatterInString(ConnObjEle.Type,"FlowController")) then
			StopValve = ConnObjEle;
		else
			if (FXUtility.HasPatterInString(ConnObjEle.Type,"FlowFitting")) then
				local grpConnObjs2 = ConnObjEle:GetConnectedElement();
				if(#grpConnObjs2 ~= 3) then
					StopValve, grpObjsToBuilding2 = getStopValve( ConnObjEle, ConnObj )
				end
			else
				StopValve, grpObjsToBuilding2 = getStopValve( ConnObjEle, ConnObj )
			end
			grpObjsToBuilding = grpObjsToBuilding + grpObjsToBuilding2
		end
		grpObjsToBuilding2 = FXGroup:new();
	end)
	return StopValve, grpObjsToBuilding;
end

function getConnObjToBuilding( WaterMeter, grpFlowObjs, PipePUB)
	local obj1;
	local flowExcluded = FXGroup:new()
	flowExcluded:Add(WaterMeter)
	flowExcluded:Add(PipePUB)
	local grpConnObjs = WaterMeter:GetConnectedElement();
	
	grpConnObjs:ForEach(function ( ConnObj )
		if(CheckObjsConn(PipePUB, ConnObj, (grpFlowObjs - flowExcluded)) == false) then
			obj1 = ConnObj;
		end
	end)
	return obj1;
end

function CheckObjsConn( obj1, obj2, grpFlowObjs ) -- check if obj2 is connected to obj1 through FlowObjs(third parameter)
	local flag = false
	local connectedFlowObjs = FXGroup:new();

	if(FXClashDetection.IsCollided(obj1,obj2))then
		flag = true
	elseif(FXUtility.HasPatterInString(obj2.Type,"FlowController")) then
		if ((FXRelation.Distance(obj2, obj1):Length() <= 0.5)) then
			flag = true
		end
	else
		grpFlowObjs:ForEach(function ( FlowEle )
			if flag == true then
				return;
			end
			if(FXClashDetection.IsCollided(FlowEle,obj2))then
				if (FXClashDetection.IsCollided(FlowEle, obj1)) then
					flag = true;
					return;
				end
				connectedFlowObjs:Add(FlowEle);
			end
		end)
	end
	if flag == false then
		grpFlowObjs = grpFlowObjs - connectedFlowObjs;
		connectedFlowObjs:ForEach(function ( connObj )
			if flag == true then
				return;
			end
			if (CheckObjsConn( obj1, connObj, grpFlowObjs )) then
				flag = true;
			end
		end)
	end
	return flag;
end

function HasValue( val, tab )
    for index, value in pairs(tab) do
        if (FXUtility.HasPatterInString(value,val)) then
            return true
        end
    end
    return false
end