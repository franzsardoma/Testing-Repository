
local ParseManhole = FXGroup:new();
local ParseInspectionChamber = FXGroup:new();
local ChamberTRUEObjs = FXGroup:new();
local ChamberFALSEObjs = FXGroup:new();

local compliantManhole = {}
local compliantChamber = {}

local tblManhole = {}
local tblChamber = {}
local tblDistance = {}

local XtblManhole = {}
local XtblChamber = {}
local XtblDistance = {}

local isNotCompliant = 0;
local isConnected = false;

local lowestStorey

local WARNING = "Manhole is not provided.";
local WARNING2 = "Inspection Chamber is not provided.";
local WARNING3 = "No connection between Manhole and Inspection Chamber.";


function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_WRN_STD_007A_TOP_LEVEL_MANHOLE")
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			ParseManhole = ParseManhole + v;
			ParseManhole = ParseManhole:Unique();
			
		end

		if (k == 3) then
			ParseInspectionChamber = ParseInspectionChamber + v;
			ParseInspectionChamber = ParseInspectionChamber:Unique();
		end
	end
	
end

function checkRule(building)
local storeys = building:GetChildren();

if #ParseManhole == 0 then
	FXUtility.DisplaySolid_Warning(building, WARNING)
	return;
end

if #ParseInspectionChamber == 0 then
	FXUtility.DisplaySolid_Warning(building, WARNING2)
	return;
end

if storeys ~= nil then
	storeys:ForEach(function(storey)
		local below = storey:GetBelowStorey()
		if below <=0 then
			lowestStorey = storey
		end
	end)
end
		
	local grpPipe = lowestStorey:GetDescendants("FlowSegment")
	local grpFitting = lowestStorey:GetDescendants("FlowFitting")

	ParseManhole:ForEach(function (manhole)

		ParseInspectionChamber:ForEach(function (chamber)
			local IsConnectedToManhole, ChamberObj = CheckConnection(manhole, chamber, grpPipe, grpFitting, temp) 

			if IsConnectedToManhole == true then
				ChamberTRUEObjs = ChamberTRUEObjs + ChamberObj
			else
				ChamberFALSEObjs = ChamberFALSEObjs + ChamberObj
			end
			table.insert(compliantChamber, chamber)
		end)

		
		if #ParseInspectionChamber > 1 then
			ChamberTRUEObjs:ForEach(function (obj)
				ChamberFALSEObjs:ForEach(function (obj2)
					if obj.Id == obj2.Id then
						isConnected = true
					end
				end)
			end)
		else
			if ChamberTRUEObjs ~= 0 then
				isConnected = true
			end
		end

		if isConnected == true then
			table.insert(compliantManhole, manhole)	
		end
	end)

	if #compliantManhole == 0 then
		FXUtility.DisplaySolid_Warning(building, WARNING3)
		return;	
	end

	CompareHeight()
end

function CompareHeight()

	for m=1, #compliantManhole,1 do
		table.insert(tblManhole, compliantManhole[m])
		for c=1, #compliantChamber,1 do
			local manholeObj = FXGeom.GetBoundingOBB(compliantManhole[m]):MaxPnt().z;
			local otherObj = FXGeom.GetBoundingOBB(compliantChamber[c]):MaxPnt().z;
			local dist = FXUtility.Round(otherObj - manholeObj, 2);	
				
			if( manholeObj >= otherObj ) then
				isNotCompliant = isNotCompliant + 1
				table.insert(XtblDistance, dist)
				table.insert(XtblChamber, compliantChamber[c])
			else				
				table.insert(tblDistance, dist)
				table.insert(tblChamber, compliantChamber[c])
			end
		end
	end

	displayResult()
end

function displayResult()
	if isNotCompliant == 0 then

		for m=1, #tblManhole,1 do
			for i=1, #tblChamber,1 do
				FXUtility.DisplaySolid_Info(compliantChamber[i], "The top level of the Manhole is higher than the top level of the Inspection Chamber.")
				CheckReport.AddRelatedObj(tblChamber[i], tblDistance[i] .. "mm; " .. tblChamber[i]:GetAttri("Name") .. "; " .. tblManhole[m]:GetAttri("Name"));
			end
		end
	else
		for m=1, #tblManhole,1 do
			for i=1, #XtblChamber,1 do
				FXUtility.DisplaySolid_Error(XtblChamber[i], "The top level of the Manhole is lower than the top level of the Inspection Chamber.")
				CheckReport.AddRelatedObj(XtblChamber[i], XtblDistance[i] .. "mm; " .. XtblChamber[i]:GetAttri("Name") .. "; " .. tblManhole[m]:GetAttri("Name"));
			end
		end
	end
end

function CheckConnection(manhole, chamber, grpPipe, grpFitting, temp)
	local CollidedEle1 = FXGroup:new();
	local CollidedEle2 = FXGroup:new();
	local AllEle = FXGroup:new();
	local IsConnected = false;

	local ChamberConnObjs = FXGroup:new();
	local ManholeConnObjs = FXGroup:new();

	local manholeContainer = manhole:GetParent()
	local chamberContainer = chamber:GetParent()

	grpPipe = grpPipe + manholeContainer:GetDescendants("FlowSegment")
	grpFitting = grpFitting + manholeContainer:GetDescendants("FlowFitting")

	grpPipe = grpPipe + chamberContainer:GetDescendants("FlowSegment")
	grpFitting = grpFitting + chamberContainer:GetDescendants("FlowFitting")

	grpPipe:ForEach(function (pipe)
		local ConnectedFitting = pipe:GetConnectedFitting()
		grpFitting = grpFitting + ConnectedFitting

	end)

	grpFitting = grpFitting:Unique();

	grpFitting:ForEach(function (pipe)
		local ConnectedPipes = pipe:GetConnectedSegment()
		grpPipe = grpPipe + ConnectedPipes

	end)

	grpPipe = grpPipe:Unique();

	AllEle = grpPipe + grpFitting

	AllEle:ForEach(function (ele)
		if FXClashDetection.IsCollided(manhole,ele) then
			CollidedEle1:Add(ele)
		end

		if FXClashDetection.IsCollided(chamber,ele) then
			CollidedEle2:Add(ele)
		end
	end)

	print(chamber:GetAttri("Name"))

	AllEle:ForEach(function (ele)

		CollidedEle1:ForEach(function (col1)

			ManholeConnObjs:Add(col1)
			if FXPUB.IsTwoObjsConnected(ele,col1,1) == true then
				ManholeConnObjs:Add(ele)
			end
		end)

		CollidedEle2:ForEach(function (col2)

			ChamberConnObjs:Add(col2)
			if FXPUB.IsTwoObjsConnected(ele,col2,1) == true then
				ChamberConnObjs:Add(ele)
			end
		end)

	end)

	ManholeConnObjs = ManholeConnObjs:Unique();

	ManholeConnObjs:ForEach(function (hole)

		ChamberConnObjs:ForEach(function (obj)

			if FXClashDetection.IsCollided(hole,obj) then
				IsConnected = true
			else
				if FXPUB.IsTwoObjsConnected(hole,obj,1) == true then
					IsConnected = true
				end
			end
		end)	
	end)

	ChamberConnObjs = ChamberConnObjs:Unique();

	return IsConnected, ChamberConnObjs

end