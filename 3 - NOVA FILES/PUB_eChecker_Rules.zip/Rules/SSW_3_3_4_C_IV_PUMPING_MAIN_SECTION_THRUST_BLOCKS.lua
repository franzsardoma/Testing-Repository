
--[[ 
	Implemented by: Lemuel B. Echague
	NovaSolutions(Philippines), Inc.
  ]]--



function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end



function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_4_C_IV_PUMPING_MAIN_SECTION_THRUST_BLOCKS")
    systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
   local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
   local bldgGrpObjs = FXRule.filterObjects(parsedXml, Building);
   local tblValues = FXRule.filterTableValues(parsedXml, Building)

 --   	for k,v in pairs(GrpObjs) do
	-- 	if (k == 2) then
	-- 		pipeGrp = pipeGrp + v;
	-- 		pipeGrp = pipeGrp:Unique();		
	-- 	end

	-- 	if (k == 3) then
	-- 		fittingGrp = fittingGrp + v;
	-- 		fittingGrp = fittingGrp:Unique();		
	-- 	end
	-- end

	-- for k,v in pairs(bldgGrpObjs) do
	-- 	if (k == 4) then
	-- 		BEPGrp = BEPGrp + v;
	-- 		BEPGrp = BEPGrp:Unique();		
	-- 	end
	-- end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				pipeProp = v1["property"];
				pipeValue = v1["value"];
			end
		end
	end
	-- for k,v in pairs(tblValues) do
	-- 	for k1,v1 in pairs(v) do
	-- 		if (k == 2) then
	-- 			fittingProp = v1["property"];
	-- 			fittingValue = v1["value"];
	-- 		end
	-- 	end
	-- end
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 3) then
				BEPProp = v1["property"];
				BEPValue = v1["value"];
			end
		end
	end



end

function checkRule(Building)

	local pipeGrp = FXGroup:new();
	local fittingGrp = FXGroup:new();
	local BEPGrp = FXGroup:new();
	local isCompliant = true
	local ARRCompFittings = {}
	local ARRCompBlocks = {}
	local ARRNonComp = {}
	local i = 0
	local pipeFittingConnected = false;
	local fittingConnectedGrp = FXGroup.new();

	-- Checking the elements on the desired level of the building
	local storey = Building:GetChildren("BuildingStorey")
	local isGroundLevel = true 

	storey:ForEach(function(level)

		local name = level:GetAttri("Name")
		if FXUtility.HasPatterInString(name,"Level 1") or  FXUtility.HasPatterInString(name,"Storey 1")  or isGroundLevel == true then
			local segmentGrp = level:GetDescendants("FlowSegment")
			local BEP = level:GetDescendants("BuildingElementProxy")
			fittingGrp = level:GetDescendants("FlowFitting")

			segmentGrp:ForEach(function(segments)
				if (FXUtility.HasPatterInString(segments:GetAttri(pipeProp), pipeValue)) then
					pipeGrp:Add(segments)
				end		
			end)
			BEP:ForEach(function(eleProxy)
				if (FXUtility.HasPatterInString(eleProxy:GetAttri(BEPProp), BEPValue)) then
					BEPGrp:Add(eleProxy)
				end		
			end)

			isGroundLevel = false
		end
	end)
	-- Checking the main object
	if (#pipeGrp == 0) then
		FXUtility.DisplaySolid_Warning(Building, "Pumping main is not provided.")
	end	

	-- Check first if there is flow fitting connected to the flow segments
	if #pipeGrp ~= 0 then
		pipeGrp:ForEach(function(pipes)		
		if (FXUtility.HasPatterInString(pipes:GetAttri(pipeProp),pipeValue)) then
			if #fittingGrp ~=0 then
				fittingGrp:ForEach(function(fitting)			
					if FXPUB.ObjToObjIsConnected(pipes,fitting,3) then
						pipeFittingConnected = true;
						fittingConnectedGrp:Add(fitting)
					end
				end)
			else
				isCompliant = false	
				FXUtility.DisplaySolid_Warning(pipes, " Pipe fitting on pumping main is not provided.")	
			end
		end
		end)
	end
	-- Checking of collieded Thrusts Block on fitting
	if pipeFittingConnected then
		fittingConnectedGrp:ForEach(function(fitting)
			if #BEPGrp ~= 0 then
				BEPGrp:ForEach(function(blocks)
				local objTypeBEP = blocks:GetAttri(BEPProp)
					if (FXUtility.HasPatterInString(objTypeBEP,BEPValue)) then	
						if FXClashDetection.IsCollided(fitting, blocks) then								
							i = i+1;
							ARRCompFittings[i] = fitting
							ARRCompBlocks[i] = blocks
						end
					end
				end)
			else
				isCompliant = false		
				FXUtility.DisplaySolid_Warning(fitting, " Thrust block is not provided.")	
				FXUtility.DisplaySolid_Warning(fitting, " Submit the maximum operating pressure report.")						
			end					
		end)
	end
	-- Display of compliant results			
	if isCompliant then	
		for i,fittings in pairs(ARRCompFittings) do
			FXUtility.DisplaySolid_Info(fittings, " Thrust block is provided.")
			CheckReport.AddRelatedObj(ARRCompBlocks[i],ARRCompBlocks[i]:GetAttri("ObjectType").. ": " .. ARRCompBlocks[i]:GetAttri("Tag"))
		end
	end		
end	


