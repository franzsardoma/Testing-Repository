local Grp_ex_Gate = FXGroup.new();
local Grp_ex_Slab = FXGroup.new();
local Grp_FloodBarrier = FXGroup.new();
local SiteTbl = {};

local First_Storey = FXGroup.new();
local Grp_Columns = FXGroup.new();
local Grp_Gate_FloodBarrier = FXGroup.new();
local Grp_Gate_FloodBarrier_Columns = FXGroup.new();

local Grp_Wall = FXGroup.new()
local Grp_FrontBarrier = FXGroup.new();
local Grp_SideBarrier = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("GetObject");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_2_4_B_II_INSTALLATION_OF_FLOOD_BARRIER")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local tblValues = FXRule.filterTableValues(parsedXml,Building)

	for k,v in pairs(tblValues) do    
		for k1,v1 in pairs(v) do
			table.insert( SiteTbl , v1["value"] )
		end
	end
	for k,v in pairs(GrpObjs) do
		if (k == 3) then
			Grp_ex_Gate = Grp_ex_Gate + v;
			Grp_ex_Gate = Grp_ex_Gate:Unique();
		end
		if (k == 4) then
			Grp_ex_Slab = Grp_ex_Slab + v;
			Grp_ex_Slab = Grp_ex_Slab:Unique();
		end
		if (k == 5) then
			Grp_FloodBarrier = Grp_FloodBarrier + v;
			Grp_FloodBarrier = Grp_FloodBarrier:Unique();
		end
	end
end

function GetObject( Building )
	local BuildingElementProxy = Building:GetDescendants("BuildingElementProxy");
	local BuildingStorey = Building:GetDescendants("BuildingStorey");
	local Wall = Building:GetDescendants("Wall");

	BuildingStorey:ForEach(function ( buildingstorey )
		if(FXUtility.HasPatterInString(buildingstorey:GetAttri("Name"), "Level 1"))then
			First_Storey:Add(buildingstorey);
		end
	end)
	BuildingElementProxy:ForEach(function ( buildingelementproxy )
		if(FXUtility.HasPatterInString(buildingelementproxy:GetAttri("Name"), "Gate Columns"))then
			Grp_Columns:Add(buildingelementproxy);
		end
	end)
	Wall:ForEach(function ( wall )
		if(FXUtility.HasPatterInString(wall:GetAttri("Name"), "Basic Wall"))then
			Grp_Wall:Add(wall);
		end
	end)
end

function CheckRule( Building )
	-- print(#Grp_ex_Gate.." Gate");
	-- print(#Grp_ex_Slab.." Slab");
	-- print(#Grp_FloodBarrier.." Flood Barrier");
	-- print(#First_Storey.." First Storey");
	-- print(#Grp_Columns.." Columns");
	-- print(#Grp_Wall.." Wall")
	-- print(SiteTbl[1], SiteTbl[2], SiteTbl[3])

	local Site = Building:GetParent();
	local siteName = Site:GetAuxAttri("Other.Project Development Type");

	if(FXUtility.HasPatterInString(siteName,"Commercial") == true or 
	FXUtility.HasPatterInString(siteName,"Multi-Unit Residential") == true or 
	FXUtility.HasPatterInString(siteName,"Special Facilities") == true)then

	-- if(FXUtility.HasPatterInString(siteName,SiteTbl[1]) or FXUtility.HasPatterInString(siteName,SiteTbl[2]) or FXUtility.HasPatterInString(siteName,SiteTbl[3]))then	
	
		First_Storey:ForEach(function ( FIRST_STOREY )
			if(#Grp_ex_Gate ~= 0)then
				-- print("With Gate");
				local Projection, OuterEdge, Point, LineLength, EdgeLine;
				local sPnt, ePnt, PntLine, EdgeLine, Face, Node;
				local Obj_FloodBarrier;

				Grp_ex_Gate:ForEach(function ( GATE )
					Projection = FXMeasure.GetObjProjection(GATE , FIRST_STOREY:Elevation());
					OuterEdge = FXMeasure.GetOuterEdge(Projection);
					Point = OuterEdge:GetPointNumber();
					LineLength = 0;

					for i = 1, Point -1, 1
					do
						local sPnt = OuterEdge:GetPoint(i - 1);
						local ePnt = OuterEdge:GetPoint(i);
						local PntLine = Line3D(sPnt , ePnt);
						local EdgeLineLen = PntLine:Length();
						
						if(EdgeLineLen > LineLength)then
							LineLength = EdgeLineLen;
							EdgeLine = PntLine;
						end
					end

					Face = FXMeasure.CreateFaceFromEdge(EdgeLine,500);
					Node = FXUtility.CreateNodeFrom(Face);
					Obj_Gate = GATE;
				end)

				if(#Grp_FloodBarrier ~= 0)then
					Grp_FloodBarrier:ForEach(function ( FLOODBARRIER )
						if(FXClashDetection.IsCollided(FLOODBARRIER, Node))then
							Grp_Gate_FloodBarrier:Add(FLOODBARRIER);
						end
						Obj_FloodBarrier = FLOODBARRIER;
					end)

					Grp_Gate_FloodBarrier:ForEach(function ( GATE_FLOODBARRIER )
						Grp_Columns:ForEach(function ( COLUMNS )
							if(FXClashDetection.IsCollided(GATE_FLOODBARRIER, COLUMNS))then
								Grp_Gate_FloodBarrier_Columns:Add(COLUMNS);
							end
						end)
					end)
				else
					FXUtility.DisplaySolid_Error(Building , "No flood barriers are installed on Entry Point A and B");
					-- Grp_ex_Gate:ForEach(function ( GATE )
					-- 	FXUtility.DisplaySolid_Error(GATE , "No flood barriers are installed on Entry Point A and B");
					-- end)
				end

				if(#Grp_Gate_FloodBarrier_Columns == 2)then
					Grp_ex_Gate:ForEach(function ( GATE )
						FXUtility.DisplaySolid_Info(GATE , "Flood Barriers are installed on all entry/exit points on site with perimeter fence.");
					end)
					Grp_FloodBarrier:ForEach(function ( Obj_FloodBarrier )
						CheckReport.AddRelatedObj(Obj_FloodBarrier, Obj_FloodBarrier:GetAuxAttri("Entity.ObjectType"));
					end)
				end
			else
				-- print("No Gate")
				local collidedFrontBarrier_into_EntryExit = FXGroup.new();
				local sideBarrier = FXGroup.new();
				local objectSlab = FXGroup.new();
		 		
		 		Grp_ex_Slab:ForEach(function ( slab )
		 			Grp_FloodBarrier:ForEach(function ( barrier )
		 				if(FXClashDetection.IsCollided(slab , barrier))then
							collidedFrontBarrier_into_EntryExit:Add(barrier);
		 				end
		 			end)
		 		end)
		 		Grp_FloodBarrier = Grp_FloodBarrier - collidedFrontBarrier_into_EntryExit;
		 		local flag;

		 		if(#Grp_FloodBarrier ~= 0)then
			 		collidedFrontBarrier_into_EntryExit:ForEach(function ( front )	
			 			
			 			Grp_FloodBarrier:ForEach(function ( side )
			 				if(FXClashDetection.IsCollided(front , side))then
			 					sideBarrier:Add(side);
			 				end
			 			end)
			 			if(#sideBarrier == 2)then
				 			sideBarrier:ForEach(function ( sideBarrier )
				 				local collided_Barrier_Into_Wall = FXGroup.new();
				 				Grp_Wall:ForEach(function ( wall )
				 					if(FXClashDetection.IsCollided(sideBarrier , wall))then
				 						collided_Barrier_Into_Wall:Add(wall);
				 					end
				 				end)

				 				if(#collided_Barrier_Into_Wall ~= nil)then
				 					if(flag ~= true)then
				 						flag = false;
				 					end
				 				else
				 					flag = true;
				 				end
				 			end)
				 		end
			 		end)
			 	else
			 		-- Grp_ex_Slab:ForEach(function ( ObjSlab )
			 			FXUtility.DisplaySolid_Error(Building, "No flood barriers are installed on Entry Point A and B")
			 		-- end)
			 	end
			 	if(flag == false)then
			 		collidedFrontBarrier_into_EntryExit:ForEach(function ( front )
						FXUtility.DisplaySolid_Info(front,"Flood Barriers enclose slabs on Entry Point A and B.")
					end)
	 				sideBarrier:ForEach(function ( allBar )
	 					CheckReport.AddRelatedObj(allBar, allBar:GetAttri("Name"))
	 				end)
			 	end
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Project Development Type is not provided.");
	end
end