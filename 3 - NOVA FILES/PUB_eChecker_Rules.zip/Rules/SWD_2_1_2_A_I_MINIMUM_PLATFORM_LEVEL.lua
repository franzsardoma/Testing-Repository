
local VerticalGratingGroup = FXGroup.new();
local SiteLocation = FXGroup.new();
local NorthernMRL;
local SouthernMRL;

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function Parser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "SWD_2_1_2_A_I_MINIMUM_PLATFORM_LEVEL");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SouthernMRL = tonumber(ConditionValues[3]);
	NorthernMRL = tonumber(ConditionValues[6]);

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- print(#GrpObjs)
	-- if(GrpObjs ~= nil)then		
	-- 	for k,v in pairs(GrpObjs) do
	-- 		if (k == 3) then
	-- 			VerticalGratingGroup =   VerticalGratingGroup + v;
	-- 			VerticalGratingGroup = VerticalGratingGroup:Unique();
	-- 		end		
	-- 	end
	-- end	
end

function CheckRule( Building )
	if(NorthernMRL ~= nil and SouthernMRL ~= nil)then 
		local Site = Building:GetParent();
		local SiteName = Site:GetAuxAttri("Other.Project Location");
		local FlagLocation;
		local Compliance;

		local BuildingStoreyGroup = Building:GetDescendants("BuildingStorey");
		local FirstStorey;

		BuildingStoreyGroup:ForEach(function(Element)
			if(FXUtility.HasPatterInString(Element:GetAttri("Name"),"01"))then 
				FirstStorey = Element;
			end
		end)

		if(FirstStorey == nil)then 
			FXUtility.DisplaySolid_Warning(Building,"No Level 01.");
			return;
		end


		if(SiteName ~= nil)then 
			if(FXUtility.HasPatterInString(SiteName,"Northern Coast"))then 
				FlagLocation = true;
			elseif(FXUtility.HasPatterInString(SiteName,"Southern Coast"))then 
				FlagLocation = false;
			else
				FXUtility.DisplaySolid_Warning(Building,"Project Location does not match.");
				return;
			end
		else
			FXUtility.DisplaySolid_Warning(Building,"Project Location not specified.");
			return;
		end	

		local SlabGroup = FirstStorey:GetDescendants("Slab");
		local LowestSlab;
		local LowestSlabElevation;
		SlabGroup:ForEach(function(Element)
			if(LowestSlab == nil)then 
				LowestSlab = Element;
			else
				local Box1 = FXGeom.GetBoundingBox(LowestSlab);
				local Box2 = FXGeom.GetBoundingBox(Element);
				local Z1 = Box1:HighPos().z;
				local Z2 = Box2:HighPos().z;
				print(Z1.." > "..Z2)
				if(Z1 > Z2)then 
					LowestSlab = Element;
					LowestSlabElevation = Z2;
				else
					LowestSlabElevation = Z1;
				end
			end
		end)

		LowestSlabElevation = LowestSlabElevation/1000;
		LowestSlabElevation = LowestSlabElevation - 100;

		if(FlagLocation)then 
			if(LowestSlabElevation >= NorthernMRL)then 
				FXUtility.DisplaySolid_Info(FirstStorey,"Platform Level: "..LowestSlabElevation.." m above SHD ("..(LowestSlabElevation+100).."mRL); "..SiteName..";");
				CheckReport.AddRelatedObj(LowestSlab,"Platform Level is above required mRL (104 mRL).");
			else
				FXUtility.DisplaySolid_Error(FirstStorey,"Platform Level: "..LowestSlabElevation.." m above SHD ("..(LowestSlabElevation+100).."mRL); "..SiteName..";");
				CheckReport.AddRelatedObj(LowestSlab,"Platform Level is below required mRL (104 mRL).");
			end
		else
			if(LowestSlabElevation >= SouthernMRL)then 
				FXUtility.DisplaySolid_Info(FirstStorey,"Platform Level: "..LowestSlabElevation.." m above SHD ("..(LowestSlabElevation+100).."mRL); "..SiteName..";");
				CheckReport.AddRelatedObj(LowestSlab,"Platform Level is above required mRL (103.5 mRL).");
			else
				FXUtility.DisplaySolid_Error(FirstStorey,"Platform Level: "..LowestSlabElevation.." m above SHD ("..(LowestSlabElevation+100).."mRL); "..SiteName..";");
				CheckReport.AddRelatedObj(LowestSlab,"Platform Level is below required mRL (103.5 mRL).");
			end
		end
	end
end