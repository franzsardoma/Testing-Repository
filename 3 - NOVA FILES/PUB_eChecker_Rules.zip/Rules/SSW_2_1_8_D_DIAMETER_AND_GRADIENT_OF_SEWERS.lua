local sewerCons = FXGroup:new();
local pipes = FXGroup:new();  --Consist of BackDrop and Tumbling Bay
local sewerManholes = FXGroup:new();
local grpPipes = FXGroup:new();
local grpFittings = FXGroup:new();
local maxSlope;
local maxSlope2;
local diaVal;
local diaVal2;
local isColSeg1 = FXGroup:new()
local isColSeg2 = FXGroup:new()
local isCompliant = true;

function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("Building");
	-- CheckEngine.BindCheckFunc("CheckRuleforDrainage");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_8_D_DIAMETER_AND_GRADIENT_OF_SEWERS")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition2");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	diaVal = tonumber(ConditionValues[2]);
	maxSlope = tonumber(ConditionValues[4])/100;
	diaVal2 = tonumber(ConditionValues[6]);
	maxSlope2 = tonumber(ConditionValues[8])/100;



	if GrpObjSystem ~= nil then
		for k,v in pairs(GrpObjSystem) do
			if (k == 2) then
				sewerCons = sewerCons + v
				sewerCons = sewerCons:Unique()
			end
			if (k == 3) then
				pipes = pipes + v
				pipes = pipes:Unique()
			end
			if (k == 4) then
				sewerManholes = sewerManholes + v
				sewerManholes = sewerManholes:Unique()
			end
		end
	else
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				sewerCons = sewerCons + v
				sewerCons = sewerCons:Unique()
			end
			if (k == 3) then
				pipes = pipes + v
				pipes = pipes:Unique()
			end
			if (k == 4) then
				sewerManholes = sewerManholes + v
				sewerManholes = sewerManholes:Unique()
			end
		end
	end
end

function CheckRule(Building)
	print(maxSlope2)
	local chamber = Building:GetDescendants("DistributionChamberElement")
	local inspectorChambers = chamber - sewerManholes;
	local Project = Building:GetParent():GetParent();
	local systems = Project:GetChildren();
	local i = 0;
	if SystemTypes ~= nil then
		for k, v in pairs(SystemTypes) do
			systems:ForEach(function(sys)
				local name = sys:GetAttri("Name");
				if FXUtility.HasPatterInString(name,v) then
					local Pipes = sys:GetDescendants("FlowSegment");
					local Fittings = sys:GetDescendants("FlowFitting");
					if Pipes ~= nil then
						grpPipes = grpPipes + Pipes;
					end
					if Fittings ~= nil and #Fittings ~= 0 then
						grpFittings = grpFittings + Fittings;
					end
				end
			end)
		end
	end

	if #sewerCons == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Sewer Connection is not provided.")
	else
		if #sewerManholes == 0 then
			FXUtility.DisplaySolid_Warning(Building,"Sewer Manhole is not provided.")
		else
			local arrObj = {}
			local arrObj1 = {}
			local temp;
			local newGrpPipe = FXGroup:new()
			sewerCons:ForEach(function(pipe)
				-- print(pipe:GetAttri("Name"))
				inspectorChambers:ForEach(function(inspection)
					local isContoIns = FXPUB.IsConnectedChamberElement(Building,inspection,pipe)
					sewerManholes:ForEach(function(manhole)
						local isContoSewer = FXPUB.IsConnectedChamberElement(Building,manhole,pipe)
						if isContoSewer or isContoIns then
							newGrpPipe:Add(pipe);
						end
					end)
				end)
			end)
			local tempPipe;
			local tempFtng;
			local mainFtng = FXGroup:new();
			local mainPipe;
			local diameter
			local slope
			------------------------------------------------------------------
			----newGrpPipe not SewerCons
			newGrpPipe:ForEach(function(pipe)
				local connectedFtngs = pipe:GetConnectedFitting();
				connectedFtngs:ForEach(function(ftngs)
					if tempFtng == nil then
						tempFtng = ftngs;
						tempPipe = pipe;
					else
						if tempFtng.Id == ftngs.Id then
							mainFtng:Add(tempFtng);
						else
							tempFtng = ftngs;
							tempPipe = pipe;
						end
					end
				end)
			end)
			if #mainFtng ~= 0 then
				mainFtng:ForEach(function(ftngs)
					local ports = ftngs:GetRelatedPort()
					if #ports == 3 then
						local conEle = ftngs:GetConnectedElement()
						local segCon = ftngs:GetConnectedSegment();
						conEle:ForEach(function(pipe)
							local name = pipe:GetAttri("Description")
							if FXUtility.HasPatterInString(name,"Sewer Connection") then
								slope = pipe:GetAuxAttri("Constraints.Slope")
								diameter = tonumber(pipe:GetAuxAttri("Mechanical.Diameter"))
								if tonumber(slope) > maxSlope and diameter == diaVal then
									i = i + 1
									arrObj[i] = pipe;
									arrObj1[i] = segCon;
								else
									isCompliant = false;
									FXUtility.DisplaySolid_Error(pipe,pipe:GetAttri("Name").." Diameter = "..diameter.."; "..pipe:GetAttri("Name").." Grade = "..slope)
									segCon:ForEach(function(pipe)
										CheckReport.AddRelatedObj(pipe,pipe:GetAttri("Name"))
									end)
								end
							end
						end)
					end
				end)
			else
				newGrpPipe:ForEach(function(pipe)
					print(pipe:GetAttri("Name"))
					slope = pipe:GetAuxAttri("Constraints.Slope")
					diameter = tonumber(pipe:GetAuxAttri("Mechanical.Diameter"))
					local connectedFtngs = pipe:GetConnectedFitting();
					connectedFtngs:ForEach(function(ftngs)
						local ports = ftngs:GetRelatedPort();
						if #ports == 3 then
							local seg = ftngs:GetConnectedSegment();
							if tonumber(slope) > maxSlope and diameter == diaVal then
								i = i + 1
								arrObj[i] = pipe;
								arrObj1[i] = seg;
							else
								isCompliant = false;
								FXUtility.DisplaySolid_Error(pipe,pipe:GetAttri("Name").." Diameter = "..diameter.."; "..pipe:GetAttri("Name").." Grade = "..slope)
								seg:ForEach(function(pipe)
									CheckReport.AddRelatedObj(pipe,pipe:GetAttri("Name"))
								end)
							end
						end
					end)
				end)
			end
			if isCompliant then
				for k,pipe in pairs(arrObj) do
					FXUtility.DisplaySolid_Info(pipe,pipe:GetAttri("Name").." Diameter = "..diameter.."; "..pipe:GetAttri("Name").." Grade = "..slope)

					arrObj1[i]:ForEach(function(pipe)
						CheckReport.AddRelatedObj(pipe,pipe:GetAttri("Name"))
					end)
				end
			end
		end
	end
end