
--[[ 
	Implemented by: Lemuel B. Echague
	NovaSolutions(Philippines), Inc.
	January 22, 2019
  ]]--



local pipePropTbl = {};
local pipeValTbl = {};


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end


function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_5_2_DRAIN_CONNECTION_WITHIN_DRAINAGE_RESERVE")
	-- systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local bldgGrpObjs = FXRule.filterObjects(parsedXml, Building);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)


	-- for k,v in pairs(GrpObjs) do
	-- 	if (k == 2) then
	-- 		pipeGrp = pipeGrp + v;
	-- 		pipeGrp = pipeGrp:Unique();		
	-- 	end
	-- end


	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 2) then
				spaceProp = v1["property"];
				spaceValue = v1["value"];
			end
		end
		for k1,v1 in pairs(v) do
			if (k == 1) then
				pipeDrainProp = v1["property"];
				pipeDrainValue = v1["value"];
				table.insert(pipePropTbl, pipeDrainProp)
				table.insert(pipeValTbl, pipeDrainValue)
			end	

		end
	end

end

function checkRule(Building)

	local level1 = true; 
	local segmentGrp = Building:GetDescendants("FlowSegment")
	local drainageGrp = FXGroup:new();
	local pipeGrp = FXGroup:new();
	local RDGrp = FXGroup:new();
	local isCollided = false;
	local isCompliant = false;
	local compliantDrain = {};
	local i = 0;

	if FXUtility.HasPatterInString(name,"Level 1") or FXUtility.HasPatterInString(name,"Storey 1")  or level1 == true then
		segmentGrp:ForEach(function ( segments )
			if(FXUtility.HasPatterInString(segments:GetAttri(pipePropTbl[1]), pipeValTbl[1])) or (FXUtility.HasPatterInString(segments:GetAttri(pipePropTbl[2]), pipeValTbl[2]) or (FXUtility.HasPatterInString(segments:GetAttri(pipePropTbl[3]), pipeValTbl[3]))) then
			pipeGrp:Add(segments)
			end
		end)
		isGroundLevel = false
	end

	local spaceGrp = Building:GetDescendants("Space")
	spaceGrp:ForEach(function ( space )
		if(FXUtility.HasPatterInString(space:GetAttri(spaceProp), spaceValue)) then
		drainageGrp:Add(space)
		end
	end)

	if ( #drainageGrp == 0 ) then
		FXUtility.DisplaySolid_Warning(Building,"Drainage Reserve is not detected.")
	end
	drainageGrp:ForEach(function ( space )
		pipeGrp:ForEach(function ( pipe )	
		local spaceHighPos = FXGeom.GetBoundingBox(space):HighPos().z
		local lineDrainLowPos = FXGeom.GetBoundingBox(pipe):LowPos().z
		local drainReserveProj = FXMeasure.GetObjProjection(space,lineDrainLowPos) 
		local spaceDrainDiff= spaceHighPos - lineDrainLowPos
		local drainReserveOuter = FXMeasure.GetOuterEdge(drainReserveProj)
		local drainReserveOuterFace = drainReserveOuter:Face3D()
		local drainReserveOuterExtrude = drainReserveOuterFace:ExtrudedFace(Vector(0, 0, spaceDrainDiff)) 							
		local drainReserveOuterNode = FXUtility.CreateNodeFrom(drainReserveOuterExtrude)
			if FXClashDetection.IsCollided(drainReserveOuterNode, pipe) then
				RDGrp:Add(pipe)
			end
		end)
	end)

	if #RDGrp ~= 0 then
		RDGrp:ForEach(function ( drain )		
			local drainLine = FXPUB.GetVerticalPipeCenterLine(drain)
			local centerPoint = FXGeom.GetBoundingBox(drain):MidPos()
			local pnt = getHighestPoint ( drainLine )
			local pnt2 = Point3D(pnt.x, pnt.y, centerPoint.z)
			local line = Line3D(pnt, pnt2)
			local lineNode =  FXUtility.CreateNodeFrom(line)
		
			if FXClashDetection.IsCollided(lineNode, drain) then
				i = i + 1 	
				compliantDrain[i] = drain
				isCompliant = true;
			else
				isCompliant = false;
				FXUtility.DisplaySolid_Error(drain, drain:GetAttri("ObjectType") .. " is open within Drainage Reserve perimeter.");
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Roadside Drain is not detected");
	end

	if isCompliant then
		for i,drain in pairs(compliantDrain) do
			FXUtility.DisplaySolid_Info(drain, drain:GetAttri("ObjectType") .. " is closed within Drainage Reserve perimeter." );		
		end
	end		
end
function getHighestPoint( line )
	local pnt1 = line:GetStartPoint();
	local pnt2 = line:GetEndPoint();

	if pnt1.z > pnt2.z then
		return pnt1;
	else
		return pnt2;
	end
end
