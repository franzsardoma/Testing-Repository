--[[ 
	Implemented by : Aires Marco S. Ladaga 22/01/2019
]]

local grpMinorSewer = FXGroup.new();
local grpChamber = FXGroup.new()
local grpCover = FXGroup.new()
local coverMaterial;
local trenchMaterial;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_ANNEX_A_C_PROVISION_OF_REMOVABLE_TRENCH_COVER")

	
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- print (#GrpBuildingObjs)
	for k,v in pairs(GrpObjs) do -- Checking in System
		if (k == 2) then
			grpMinorSewer = grpMinorSewer + v
			grpMinorSewer = grpMinorSewer:Unique()
		end	
	end

	for k,v in pairs(GrpBuildingObjs) do -- Checking in Building
		if (k == 3) then
			grpChamber = grpChamber + v
		end
	end

	for k,v in pairs(GrpBuildingObjs) do -- Checking in Building
		if (k == 4) then
			grpCover = grpCover + v
		end
	end
end

function CheckRule(Building)
	local flag = true 
	local x = 0
	local isErrorFound = false

	if #grpMinorSewer == 0 then
		FXUtility.DisplaySolid_Warning ( Building , "Minor Sewer not provided.")
		flag = false
	end
	if #grpChamber == 0 then
		FXUtility.DisplaySolid_Warning ( Building , "Trench not provided.")
		flag = false
	end

	print ( #grpMinorSewer.." - "..#grpChamber.." - "..#grpCover )
	local comMinorArr = {};
	local comTrenchArr = {};
	local comCoverArr = {};

	if flag == true then
		grpMinorSewer:ForEach(function ( minorSewer )
			local grpHasTrench = FXGroup.new();

			grpChamber:ForEach(function ( trench )	
				local trenchBox = FXGeom.GetBoundingBox(trench);

				local bottomFace = FXMeasure.GetBottomFace(trench);	
				local extruded = bottomFace:ExtrudedFace(Vector(0,0,trenchBox:HighPos().z - trenchBox:LowPos().z ))
				
				local nodeExtrude = FXUtility.CreateNodeFrom( extruded );
				if FXClashDetection.IsCollided ( nodeExtrude , minorSewer ) then  -- CHECK IF MINOR SEWER IS WITHIN TRENCH
					grpHasTrench:Add ( trench);	
				end
				FXClashDetection.DeleteNode ( nodeExtrude );							
			end)

			if #grpHasTrench > 0 then
				grpHasTrench :ForEach (function ( trench )
					local grpHasCovers = FXGroup.new();
					local trenchFace = FXMeasure.GetBottomFace(trench);
					local chamberProj = FXMeasure.CreateShellsolid(trenchFace);
					local pipeProj = FXMeasure.GetObjProjection( minorSewer , 0 );

					local intersectProj = FXMeasure.IntersectTwoProjection(chamberProj,pipeProj, FXGeom.GetBoundingBox ( minorSewer ):HighPos().z); -- get the projection of pipe thats only within the trench
					local shrinkedProj =  FXMeasure.ShrinkFace(intersectProj, 1); -- shrinked because it also collides with other covers

					local projToFace = FXMeasure.GetOuterEdge(shrinkedProj):Face3D();
					local chamberHeight = FXGeom.GetBoundingBox ( trench ):HighPos().z - FXGeom.GetBoundingBox ( minorSewer ):HighPos().z;
					local extruded = projToFace:ExtrudedFace(Vector(0,0,chamberHeight))
					-- FXUtility.DisplaySolid_Error ( Building , "awd", extruded);
					local node = FXUtility.CreateNodeFrom( extruded )
					grpCover:ForEach (function ( coverObj )
						if FXClashDetection.IsCollided ( node , coverObj ) then 
							grpHasCovers:Add(coverObj);	
						end
					end)
					FXClashDetection.DeleteNode ( node );

					if #grpHasCovers > 0 then
						grpHasCovers:ForEach (function ( coverObj )
							local coverTopFace = FXMeasure.GetTopFace( coverObj );	
							local edges = FXMeasure.GetOuterEdge(coverTopFace);
							local pointNumber = edges:GetPointNumber();
							local voidFace = coverTopFace:GetVoidFace(0); -- get it to only get the first hole, since i only need to know if it has any holes at all.
							-- FXUtility.DisplaySolid_Error ( Building , "awd", voidFace:Face3D());
							if voidFace~= nil then 
								x = x + 1;
								comTrenchArr[x] = trench;
								comCoverArr[x] = coverObj;
							else
								print (pointNumber)
								if pointNumber > 5 then
									x = x + 1;
									comTrenchArr[x] = trench;
									comCoverArr[x] = coverObj;
								else
									isErrorFound = true;
									FXUtility.DisplaySolid_Error ( coverObj , coverObj:GetAttri("ObjectType").." is not removable.");
									-- CheckReport.AddRelatedObj( coverObj, coverObj:GetAttri("Name"));
								end
							end
						end)
					else
						isErrorFound = true;
						FXUtility.DisplaySolid_Error ( trench , "Trench cover is not provided.");
						-- CheckReport.AddRelatedObj( trench, trench:GetAttri("Name"));
					end
				end)
			else
				-- FXUtility.DisplaySolid_Warning ( minorSewer , "Trench not provided for "..minorSewer:GetAttri("Name") );
			end
		end)			
	end

	if isErrorFound == false then
		local y = 1
		while y ~= x + 1 do
			FXUtility.DisplaySolid_Info ( comCoverArr[y] , comCoverArr[y]:GetAttri("ObjectType").." is provided.");
			FXUtility.DisplaySolid_Info ( comCoverArr[y] , comCoverArr[y]:GetAttri("ObjectType").." is removable.")
			-- CheckReport.AddRelatedObj( comCoverArr[y] , comCoverArr[y]:GetAttri("Name"));
			-- CheckReport.AddRelatedObj( comTrenchArr[y] , comTrenchArr[y]:GetAttri("Name"));
			y = y + 1
		end
	end
end