--SWD 5.4 (d)
--Implemented by Elcar Zarcilla
--01-23-2019

local roadsideDrainGrp=FXGroup.new();
local slabGrp = FXGroup.new()
function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end



function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SWD_5_4_D_SLOPED_SLAB_OVER_A_ROADSIDE_DRAIN");
  local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
  -- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  -- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2 ) then
      roadsideDrainGrp = roadsideDrainGrp + v;
      roadsideDrainGrp = roadsideDrainGrp:Unique();
    end
    if (k == 3 ) then
      slabGrp = slabGrp + v;
      slabGrp = slabGrp:Unique();
    end
  end
end

function checkRule(Building)
  local isCompliant = true;
  local check = true;

  if #roadsideDrainGrp == 0 or roadsideDrainGrp == nil then
    check = false;
    FXUtility.DisplaySolid_Warning(Building,"Roadside Drain is not detected ")
  end

  if #slabGrp == 0 or roadsideDrainGrp == nil then
    check = false;
    FXUtility.DisplaySolid_Warning(Building,"Sidewalk is not detected ")
  end

  local site = Building:GetParent()
  if site:GetAttri("ObjectType") ~= "Development Site" then
    FXUtility.DisplaySolid_Warning(Building,"Site is not detected ")
    check = false;
  end

  if check then
    local slabOverDrainGrp = FXGroup.new()
    local slabToCheck;
    
    slabGrp:ForEach(function(slab)
      roadsideDrainGrp:ForEach(function(drain)
        local drainBox = FXGeom.GetBoundingBox(drain)
        local slabZ = FXGeom.GetBoundingBox(slab):HighPos().z
        local drainProj = FXMeasure.GetObjProjection(drain,drainBox:LowPos().z)
        local edge = FXMeasure.GetOuterEdge(drainProj)
        local noOfPnt1 = edge:GetPointNumber();
        local PlyLine = PolyLine3D(TRUE);

        for i = 1, noOfPnt1 -1, 1 do
          local pnt1 = edge:GetPoint(i);
          PlyLine:AddPoint(pnt1);
        end

        PlyLine:ClosePolyline();
        local face = PlyLine:Face3D()
        extrudeFace = face:ExtrudedFace(Vector(0,0,slabZ-drainBox:LowPos().z))
        local node = FXUtility.CreateNodeFrom(extrudeFace);
        if FXClashDetection.IsCollided(slab,node) then
          slabOverDrainGrp:Add(slab)
        end
        FXClashDetection.DeleteNode(node)
      end)
    end)
    
    local InletChamber;
    local isCompliant = true;
    slabOverDrainGrp:ForEach(function(slab)
    --getting the slope
      local Face =FXMeasure.GetTopFace(slab) 
      local PolyLine = Face:GetMainFace()
      local PolyNum = PolyLine:GetPointNumber()
      local tempLine;
      for i=0,PolyNum-2 do
        local Point1 = PolyLine:GetPoint(i)
        local Point2 = PolyLine:GetPoint(i+1)
        if Point1.z ~= Point2.z then
          tempLine = Line3D(Point1,Point2)
          break;
        end
      end

      if tempLine ~= nil then 
        local point1 = tempLine:GetStartPoint();
        local point2 = tempLine:GetEndPoint();
        local point;
        if point1.z < point2.z then
          point = point2;
          point2 = point1;
          point1 = point;
        end
        local point3=Point3D(point1.x,point1.y,point2.z)
        local rise = point1:Distance_Pnt(point3)
        rise = FXUtility.Round(rise)
        local run = point3:Distance_Pnt(point2)
        local slope = (rise/run)
        local BEPGrp = Building:GetDescendants("BuildingElementProxy")
        local DICGrp = FXGroup.new()

        BEPGrp:ForEach(function(bep)
          if FXUtility.HasPatterInString(bep:GetAttri("Object Type","Drop-inlet chamber")) == true then
            DICGrp:Add(bep)
          end
        end)

        local distance;
        DICGrp:ForEach(function(DICele)
          local Dist = FXMeasure.Distance(slab,DICele)
          if distance == nil then
            distance = Dist
            InletChamber = DICele
          else
            if Dist:Length() < distance:Length() then
              distance = Dist;
              InletChamber = DICele
            end
          end
        end)

        if slope ~= nil then
          local InletChamberZ = FXGeom.GetBoundingBox(InletChamber):HighPos()
          local fromHighestPnt = point1:Distance_Pnt(InletChamberZ)
          local fromLowestPnt = point2:Distance_Pnt(InletChamberZ)
          if fromLowestPnt < fromHighestPnt then
            FXUtility.DisplaySolid_Info(slab,slab:GetAttri("ObjectType") ..": Slope Direction; Towards the Drain.");
          else
            isCompliant = false;
            FXUtility.DisplaySolid_Error(slab,slab:GetAttri("ObjectType") ..": Slope Direction; Opposite to the Drain.");
          end
        end
      else
        isCompliant = false;
        FXUtility.DisplaySolid_Error(slab,slab:GetAttri("ObjectType") ..": Slope Direction is not defined.");
      end
    end)
  end
end