local SystemTypes; 
local grpFlowSegment = FXGroup:new();
local parapetWallGrp = FXGroup:new()
local ventSystemPipes = FXGroup:new()
local minHeight;
local ventStackTerminate = false;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end




function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_3_4_G_II_VENTILATION_STACK_ABOVE_PARAPET_WALL")

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	minHeight = ConditionValues[2];
	minHeightSlopingRoof = ConditionValues[4];

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpFlowSegment = grpFlowSegment + v
			grpFlowSegment = grpFlowSegment:Unique()
		end
		-- if (k == 6) then
		-- 	parapetWallGrp = parapetWallGrp + v
		-- end
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				ventProp = v1["property"];
				ventValue = v1["value"];
			end
		end
	end
end


function checkRule(Building)

	
	local BuildingStorey = Building:GetChildren("BuildingStorey")
	local HighestStorey;
	local roofSpace;
	local isPassed = true


	BuildingStorey:ForEach(function(storey)
		HighestStorey = storey;
	end)
	local ElevationStorey = HighestStorey:Elevation();
	
	local roofSlabs = HighestStorey:GetDescendants("Slab");
	roofSpace = HighestStorey:GetDescendants("Space");
	local roofElement = FXGroup.new()
	local slopingRoof = FXGroup.new()
	roofSlabs:ForEach(function ( slab )
		local  slabParent = slab:GetParent()
		if FXUtility.HasPatterInString(slab:GetAttri("Name"), "Roof") or FXUtility.HasPatterInString(slabParent:GetAttri("Name"), "Roof")then
			roofElement:Add(slab)
			local slabAngle = tonumber(slab:GetAuxAttri("Pset_SlabCommon.PitchAngle"))
			if slabAngle ~= nil and slabAngle > 0 then
				slopingRoof:Add(slab)
			end
		end
	end)

	local wallGrp = HighestStorey:GetDescendants("Wall");
	wallGrp:ForEach(function ( wall )
		if FXUtility.HasPatterInString(wall:GetAttri("Name"), "Parapet") then
			parapetWallGrp:Add(wall)
		end
	end)
	print(#grpFlowSegment)
	-- Warning Messages
	if #grpFlowSegment == 0 then
		FXUtility.DisplaySolid_Warning(Building, "No Vent Stack found.")
		isPassed = false
	end
	if #parapetWallGrp ~= 0 or #slopingRoof ~= 0 then
		isPassed = true	
	else
		FXUtility.DisplaySolid_Warning(Building, "No Parapet Wall or Sloping Roof found.")
		isPassed = false
	end
	

	if isPassed then

	if #grpFlowSegment ~= 0 then
		local roofSlabsPrj = FXMeasure.GetProjection(roofElement, ElevationStorey)
		local roofSlabsNode = FXUtility.CreateNodeFrom(roofSlabsPrj)
		local isCompliant = false;
		local pipeHeight;
		local collidedSpace;
		local nearestParapetWall = nil;
		local ArrPipe = {};
		local ArrPipeObj= {};
		local ArrPipeHeight= {};
		local ArrArrowGeom = {};
		local ArrCollidedSpace= {};
		local ArrTerminatePipe= {};
		local warning = false;
		local i = 0;
		grpFlowSegment:ForEach(function ( pipe )
			pipeObj = pipe:GetAttri(ventProp)
			if roofSpace ~= nil then
				roofSpace:ForEach(function ( space )
					if FXClashDetection.IsCollided(pipe, space) then
						collidedSpace = space
					end
				end)
			end
			if #parapetWallGrp ~= 0 then	
				if FXClashDetection.IsCollided(pipe, roofSlabsNode) then
				ventStackTerminate = true;
					local nearestDistance;
					parapetWallGrp:ForEach(function ( wall )
						local distLine = FXMeasure.Distance(pipe, wall)
						local distance = distLine:Length()
						
						if nearestParapetWall == nil then
							nearestParapetWall = wall;
							nearestDistance = distance;
						else
							if nearestDistance > distance then
								nearestParapetWall = wall;
								nearestDistance = distance;
							end
						end
					end)
					if nearestParapetWall ~= nil then
						local box = FXGeom. GetBoundingOBB(pipe)
						local centerPnt = box:GetPos()
						local maxPnt = box:MaxPnt()
						local topLine = Line3D(maxPnt, Point3D(centerPnt.x,centerPnt.y,maxPnt.z))

						local wallOBB = FXGeom. GetBoundingOBB(nearestParapetWall)
						local wallOBBmaxPnt = wallOBB:MaxPnt()
						local wallOBBcenterPnt = wallOBB:GetPos()
						local wallOBBtopLine = Line3D(wallOBBmaxPnt, Point3D(wallOBBcenterPnt.x, wallOBBcenterPnt.y, wallOBBmaxPnt.z))
						
						local topLineNode = FXUtility.CreateNodeFrom(topLine)
						local wallOBBtopLineNode = FXUtility.CreateNodeFrom(wallOBBtopLine)
						local distLine1 = FXMeasure.Distance(topLineNode, roofSlabsNode)
						
						local distLine2 = FXMeasure.Distance(wallOBBtopLineNode, roofSlabsNode)
						
						pipeHeight = distLine1:Length()-distLine2:Length();
						pipeHeight = FXUtility.Round(pipeHeight, 2)

						local arrowGeom = DoubleArrow(maxPnt, Point3D(maxPnt.x,maxPnt.y,maxPnt.z-pipeHeight));
						FXClashDetection.DeleteNode(topLineNode)
						FXClashDetection.DeleteNode(wallOBBtopLineNode)
						if (pipeHeight >= tonumber(minHeight))then
							isCompliant = true;
							i = i + 1
							ArrPipe[i] = pipe
							ArrPipeObj[i] = pipeObj
							ArrArrowGeom[i] = arrowGeom
							ArrPipeHeight[i] = pipeHeight
							ArrCollidedSpace[i] = collidedSpace
						else
							FXUtility.DisplaySolid_Error(collidedSpace, pipeObj.." = "..pipeHeight.." mm");
							CheckReport.AddRelatedObj( pipe, pipeObj )
							CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
						end
						if collidedSpace == nil then
							collidedSpace = Building;
						end
					end
				end
			end

			if #slopingRoof  ~= 0 then
				local pipeHeight;
				local arrowGeom;
				if collidedSpace == nil then
					collidedSpace = Building;
				end
				slopingRoof:ForEach(function ( roof )
					if FXClashDetection.IsCollided(pipe, roof) then
						ventStackTerminate = true;
						local box = FXGeom. GetBoundingOBB(pipe)
						local maxPnt = box:MaxPnt()
						local pipeProjection = FXMeasure.GetObjProjection(pipe, maxPnt.z)
						-- local topFace = FXMeasure.GetCircularFacesInDirection(pipe, 0)
						-- local extrtopFace = topFace:ExtrudedFace(Vector(0,0,1));
						local topFaceNode = FXUtility.CreateNodeFrom(pipeProjection)

						local geo = FXClashDetection.GetIntersection(pipe, roof);

						local node2;
						if geo ~= nil then
							node2 = FXUtility.CreateNodeFrom(geo);
						end 

						local distLine = FXMeasure.Distance(node2, topFaceNode)
						pipeHeight = FXUtility.Round(distLine:Length(), 0)
						arrowGeom = DoubleArrow(distLine:GetStartPoint(), distLine:GetEndPoint());
						FXClashDetection.DeleteNode(topFaceNode)
						FXClashDetection.DeleteNode(node2)

						if (pipeHeight >= tonumber(minHeightSlopingRoof))then
							isCompliant = true;	
							i = i + 1
							ArrPipe[i] = pipe
							ArrPipeObj[i] = pipeObj
							ArrArrowGeom[i] = arrowGeom
							ArrPipeHeight[i] = pipeHeight
							ArrCollidedSpace[i] = collidedSpace
						else
							FXUtility.DisplaySolid_Error(collidedSpace, pipeObj.." = "..pipeHeight.." mm");
							CheckReport.AddRelatedObj( pipe, pipeObj )
							CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")	
						end			
					end
				end)
			end
		 if not ventStackTerminate  then
		 	ArrTerminatePipe[i] = pipe
		 	ArrPipeObj[i] = pipeObj
		 	warning = true
		 end

		end)
	
	if warning then
		for i,pipe in pairs(ArrTerminatePipe) do
				FXUtility.DisplaySolid_Warning(pipe, pipe:GetAttri("ObjectType") .. " does not terminate through the highest roof element")
		end		
	else

		if isCompliant then
			for i,pipe in pairs(ArrPipe) do
				if ArrCollidedSpace[i] ~= nil then
					FXUtility.DisplaySolid_Info(ArrCollidedSpace[i], ArrPipeObj[i].." = "..ArrPipeHeight[i].." mm");
					CheckReport.AddRelatedObj( pipe, ArrPipeObj[i] )
					CheckReport.AddRelatedGeometry_Info(ArrArrowGeom[i], "Arrow3D")
				else
					FXUtility.DisplaySolid_Info(Building, ArrPipeObj[i].." = "..ArrPipeHeight[i].." mm");
					CheckReport.AddRelatedObj( pipe, ArrPipeObj[i] )
					CheckReport.AddRelatedGeometry_Info(ArrArrowGeom[i], "Arrow3D")
				end
			end
		end
	end
	end
	end
end

-- function CheckResult(collidedSpace, isCompliant, pipeObj, pipe, pipeHeight, arrowGeom)
	
-- 	if isCompliant then
-- 		FXUtility.DisplaySolid_Info(collidedSpace, pipeObj.." = "..pipeHeight.." mm");
-- 		CheckReport.AddRelatedObj( pipe, pipeObj )
-- 		CheckReport.AddRelatedGeometry_Solid(arrowGeom, "Arrow3D")
-- 	else
-- 		FXUtility.DisplaySolid_Error(collidedSpace, pipeObj.." = "..pipeHeight.." mm");
-- 		CheckReport.AddRelatedObj( pipe, pipeObj )
-- 		CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
-- 	end
-- end

