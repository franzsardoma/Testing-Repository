--[[
	Implemented By: Jerrick Gillera
]]--

local spaceGrp = FXGroup:new()
local flowStorageDeviceGrp = FXGroup:new()
local flowMovingDeviceGrp = FXGroup:new()
local wallGrp = FXGroup:new()
local railingGrp = FXGroup:new()
local wallPropTbl = {}
local wallValTbl = {}
local elemTypeTbl = {}

function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_19_D_STORAGE_FENCING_ENCLOSURE")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3");
	ConditionValues4 = FXRule.ParseValues(parsedXml, "Condition4");

	-- local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	-- isRemovable = ConditionValues[1]; -- for Condition Values 

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)		
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			spaceGrp =   spaceGrp + v;
			spaceGrp = spaceGrp:Unique()
		end	
		if (k == 3) then
			flowStorageDeviceGrp =   flowStorageDeviceGrp + v;
			flowStorageDeviceGrp = flowStorageDeviceGrp:Unique()
		end
		if (k == 5) then
			wallGrp =   wallGrp + v;
			wallGrp = wallGrp:Unique()
		end	
		if (k == 6) then
			railingGrp =   railingGrp + v;
			railingGrp = railingGrp:Unique()
		end
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				ObjProp = v1["property"]
				ObjValue = v1["value"]
			end		
			if (k == 4) then				
				table.insert(wallPropTbl, v1["property"])
				table.insert(wallValTbl, v1["value"])
			end
			if (k == 6) then				
				table.insert(elemTypeTbl, v1["type"])
			end
		end		
	end	
end

function checkRule(Building)

	local flag2 = true
	local space, wall, flag3
	
	if #spaceGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building, "Tank area is not provided.")
		flag2 = false
	end
	if #flowStorageDeviceGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building, "Tank is not provided.")
		flag2 = false
	end
	if #wallGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building, "Fencing is not provided.")
		flag2 = false
	else
		flag3 = true
		wallGrp:ForEach(function ( wallObj )
			space = wallObj:GetConnectedSpace()
			wall = wallObj
		end)
	end
	if #railingGrp == 0 then
		if flag3 == true then
			if getCeiling( space ) == 0 then
				FXUtility.DisplaySolid_Warning(Building, "Outrigger is not provided")
				flag2 = false
			end
		else
			FXUtility.DisplaySolid_Warning(Building, "Outrigger is not provided")
			flag2 = false
		end
	end

	if flag2 == false then
		return
	end

	local connElem, railing, material, tank, connWall, space2
	local flag = true
	local railingHeight, railingHighPos, railingLowPos
	local wallGrp2 = FXGroup:new()
	local railGrp2 = FXGroup:new()
	local wallHeight = tonumber(ConditionValues1[1])
	local railingHeight = tonumber(ConditionValues2[1])
	local wallMaterial = tostring(ConditionValues3[1])
	local wallMaterial2 = tostring(ConditionValues4[1])	

	flowStorageDeviceGrp:ForEach(function ( flowStorageDeviceObj )
		tank = flowStorageDeviceObj
	end)

	spaceGrp:ForEach(function ( space )
		if FXUtility.HasPatterInString(space:GetAttri(ObjProp),ObjValue) then
			connWall = space:GetConnectedWall()
			connWall:ForEach(function ( connWallObj )
				for i=1,#wallPropTbl do
					if FXUtility.HasPatterInString(connWallObj:GetAttri(wallPropTbl[i]), wallValTbl[i]) then
						wallGrp2:Add(connWallObj)
					end
				end				
			end)
			railingGrp:ForEach(function ( railingObj )
				if FXClashDetection.IsCollided(railingObj,space) then
	    			railGrp2:Add(railingObj)	
	    		end
			end)
			space2 = space
		end
	end)

	if FXUtility.HasPatterInString(wall:GetAuxAttri("Material.Layer.0.material"),wallMaterial) then
		material = (wall:GetAuxAttri("Material.Layer.0.material"))
	elseif FXUtility.HasPatterInString(wall:GetAuxAttri("Material.Layer.0.material"),wallMaterial2) then
		material = (wall:GetAuxAttri("Material.Layer.0.material"))
	else
		material = (wall:GetAuxAttri("Material.Layer.0.material"))
		flag = false
	end
	
	if getCeiling( space ) ~= 0 then
		if getObjHeight( wallGrp2 ) < wallHeight then
			flag = false			
		end
	else
		if ( getObjHeight( wallGrp2 ) >= wallHeight ) then	
			if getObjHeight( railGrp2 ) < railingHeight then
				flag = false				
			end
			
		else
			flag = false
		end
	end

	if flag == true then
		if #railGrp2 ~=0 then
			FXUtility.DisplaySolid_Info(space2, "Outrigger vertical height : " .. getObjHeight( railGrp2 ).." mm")
			railGrp2:ForEach(function ( railingObj )				
				CheckReport.AddRelatedObj(railingObj, "Outrigger vertical height : " .. getObjHeight( railGrp2 ).." mm")
			end)
		end
		FXUtility.DisplaySolid_Info(space2, "Fencing enclosure vertical height : " .. getObjHeight( wallGrp2 ).." mm")
		FXUtility.DisplaySolid_Info(space2, "Fencing enclosure material : " .. material)
		wallGrp2:ForEach(function ( wallObj )		
			CheckReport.AddRelatedObj(wallObj, wallObj:GetAttri("ObjectType"))
		end)
	else
		if #railGrp2 ~=0 then
			FXUtility.DisplaySolid_Error(space2, "Outrigger vertical height : " .. getObjHeight( railGrp2 ).." mm")
			getLowestHeightObj( railGrp2, getObjHeight( railGrp2 ) ):ForEach(function ( railingObj )				
				CheckReport.AddRelatedObj(railingObj, railingObj:GetAttri("ObjectType"))
			end)
		end
		FXUtility.DisplaySolid_Error(space2, "Fencing enclosure vertical height : " .. getObjHeight( wallGrp2 ).." mm")
		FXUtility.DisplaySolid_Error(space2, "Fencing enclosure material : " .. material)
		getLowestHeightObj( wallGrp2, getObjHeight( wallGrp2 ) ):ForEach(function ( wallObj )
			CheckReport.AddRelatedObj(wallObj, wallObj:GetAttri("ObjectType"))
		end)
	end

end

function getObjHeight( grp )
	local fenceHighPos, fenceLowPos
	local height
	local arr = {}
	grp:ForEach(function ( grpObj )
		fenceHighPos = FXGeom.GetBoundingBox(grpObj):HighPos().z
		fenceLowPos = FXGeom.GetBoundingBox(grpObj):LowPos().z
		table.insert(arr, fenceHighPos - fenceLowPos)
	end)
	for i=1,#arr do
		if arr[i+1] ~= nil then 
			if arr[i] < arr[i+1] then
				height = arr[i]
			else
				height = arr[i]
			end
		end
	end	
	return FXUtility.Round(height, 0)
end

function getLowestHeightObj( grp, height )
	local fenceHighPos, fenceLowPos
	local elemGrp = FXGroup.new()
	grp:ForEach(function ( grpObj )
		fenceHighPos = FXGeom.GetBoundingBox(grpObj):HighPos().z
		fenceLowPos = FXGeom.GetBoundingBox(grpObj):LowPos().z
		if fenceHighPos - fenceLowPos == height then
			 elemGrp:Add(grpObj)
		end		
	end)
	return elemGrp
end

function getCeiling( space )
	local ceiling
	local ceilingGrp = FXGroup.new()
	space:ForEach(function ( spaceObj )
		if FXUtility.HasPatterInString(spaceObj:GetAttri(ObjProp),ObjValue) then
			ceiling = spaceObj:GetAboveSpaceElement()
			ceiling:ForEach(function ( ceilingObj )
				for i=1,#elemTypeTbl do
					if FXUtility.HasPatterInString(ceilingObj:GetAttri("Type"),elemTypeTbl[i]) then
						ceilingGrp:Add(ceilingObj)
					end
				end
			end)					
		end		
	end)
	return ceilingGrp		
end