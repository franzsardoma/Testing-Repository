local flowFittingGrp 		= FXGroup.new();
local flowSegmentGrp 		= FXGroup.new();
local manholeGrp 			= FXGroup.new();
local inspectionChamberGrp 	= FXGroup.new();
local systemTypes;
local minDiameter 			= 150.00; 

function main()
	-- CheckEngine.SetCheckType("System")
	-- CheckEngine.BindCheckFunc("XMLParser")
	-- CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("System");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function script_path() -- FOR CONSOLE
    local str = debug.getinfo(2, "S").source:sub(2)
	local str2 = string.gsub(str,str:match("^.*/(.*).lua$")..".lua","")
	local str3 = string.gsub(str2,"/Rules","")
	return string.gsub(str3,"/","\\")
end 

-- function script_path() -- FOR RULESET
--     local var = FX_PATH.ConfigPath();
-- 	return string.gsub(var,"\\Rules","")
-- end

function XMLParser(System)
	local myfile = io.open(script_path().."HTML\\SSW_3_1_2_N_MANHOLE_INSPECTION_CHAMBER.html", "r"); --open the html file
	-- local myfile = io.open("D:\\Git\\PUB_eChecker_Rules\\HTML\\SWD_2_1_1_A_I_GENERAL_DEVELOPMENTS.html", "r"); --open the html file
	local tempTxt = "";
	for line in myfile:lines() do
		if( line ~= nil ) then
			tempTxt = tempTxt..line;
		end
	end
	local xmlTxt = string.match(tempTxt,'<%?xml.*</FORMPARAMETER>') -- get the xml part embedded in the html file
	local xml = newParser();
	local parsedXml = xml:ParseXmlText(xmlTxt); -- parse xml
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building); -- parse objects using the function in FXRule.lua
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s

	minDiameter = tonumber(ConditionValues[2])
	
	for k,v in pairs(GrpObjs) do -- get the model objects
		v:ForEach(function(obj)
			if (k == 5) then
				flowSegmentGrp:Add(obj);
			elseif (k == 6) then
				manholeGrp:Add(obj);
			elseif (k == 7) then
				inspectionChamberGrp:Add(obj);
			end
		end)
	end
end

function checkRule(System) -- hardcoded

	local objGrp = System:GetChildren()
	-- print("#objGrp " .. #objGrp)

	local lastChamberGrp = FXGroup:new();
	local drainLineGrp = FXGroup:new();
	local sewerLineGrp = FXGroup:new();
	local yJunctionGrp = FXGroup:new();


	objGrp:ForEach(function (obj) 
		if obj.Type ~= "Port" then
			local objName = obj:GetAttri("Name")
			local objDesc = obj:GetAttri("Description")
			if FXRule.EvaluateString("Contains", objName, "Last Inspection Chamber") then
				lastChamberGrp:Add(obj);
			-- elseif FXRule.EvaluateString("Contains", objDesc, "Drain Line") then
			elseif FXRule.EvaluateString("Contains", objDesc, "Sewer Connection") or
				FXRule.EvaluateString("Contains", objDesc, "Drain Line")then
				drainLineGrp:Add(obj);
			elseif FXRule.EvaluateString("Contains", objDesc, "Sewer Line") then
				sewerLineGrp:Add(obj)
			elseif FXRule.EvaluateString("Contains", objDesc, "Y Junction") then
				yJunctionGrp:Add(obj);
			end
		end
	end)
	print("testing",#lastChamberGrp, #drainLineGrp, #sewerLineGrp, #yJunctionGrp)
	if #lastChamberGrp ~= 0 and #drainLineGrp ~= 0 and #sewerLineGrp ~= 0 and #yJunctionGrp ~= 0 then
		local sewerLineDiameter;
		local isPassed = false;
		sewerLineGrp:ForEach(function (sewer)
			sewerLineDiameter = FXUtility.Round(sewer:GetAuxAttri("Mechanical.Diameter"),2)
		end)
		yJunctionGrp:ForEach(function (junction)
			local diam1 = FXUtility.Round(junction:GetAuxAttri("Dimensions.Nominal Diameter 1"),2)
			local diam2 = FXUtility.Round(junction:GetAuxAttri("Dimensions.Nominal Diameter 2"),2)
			local diam3 = FXUtility.Round(junction:GetAuxAttri("Dimensions.Nominal Diameter 3"),2)
			print("testing",diam1,diam2,diam3)
			if diam1 == minDiameter and diam2 == minDiameter and diam3 == minDiameter then
				isPassed = true;
			end
		end)
		drainLineGrp:ForEach(function (drainLine)
			local drainLineDiameter = FXUtility.Round(drainLine:GetAuxAttri("Mechanical.Diameter"),2)
			local pipeName = drainLine:GetAttri("Name");
			local pipeDesc = drainLine:GetAttri("Description");
			if drainLineDiameter == minDiameter and sewerLineDiameter == minDiameter and isPassed then
				FXUtility.DisplaySolid_Info(drainLine,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. drainLineDiameter .. " mm");
			else
				FXUtility.DisplaySolid_Error(drainLine,pipeDesc .. " " ..  pipeName .. ": Diameter = " .. drainLineDiameter .. " mm");		
			end
		end)
	end
end