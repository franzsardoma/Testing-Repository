--SSW 4.2.1 (b) (ii)
--Implemented by Elcar Zarcilla
--January 16,2019
local grpManhole = FXGroup.new()
local grpDrainline = FXGroup.new()
local grpPublicSewer = FXGroup.new()
local grpTumblingBay = FXGroup.new()
local grpBackdrop = FXGroup.new()
local ARRManhole={}
local ARRDrainline={}
local ARRPublic={}
local ARRTumbling={}
local ARRBackdrop={}
local ARRVerticalDistance={}
local ARRGrpDrainline={}
local ARRArrow={}
local ARRLine={}
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_4_2_1_B_II_BACKDROP_OR_TUMBLING_BAY_CONNECTION");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	operator1 = (ConditionValues[4]) -- ">="
  	min1 = tonumber(ConditionValues[5])
  	operator2 = (ConditionValues[7]) -- "<="
  	max1 = tonumber(ConditionValues[8])
  	operator3 = (ConditionValues[12]) -- ">"
  	min2 = tonumber(ConditionValues[13])
  	operator4 = (ConditionValues[15]) -- "<="
  	max2 = tonumber(ConditionValues[16])
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpDrainline = grpDrainline + v;
			grpDrainline = grpDrainline:Unique();
		end
		if (k == 3) then
			grpPublicSewer = grpPublicSewer + v;
			grpPublicSewer = grpPublicSewer:Unique();
		end
		if (k == 4) then
			grpTumblingBay = grpTumblingBay + v;
			grpTumblingBay = grpTumblingBay:Unique();
		end
		if (k == 5) then
			grpBackdrop = grpBackdrop + v;
			grpBackdrop = grpBackdrop:Unique();
		end
		if (k == 6) then
			grpManhole = grpManhole + v;
			grpManhole = grpManhole:Unique();
		end
	end
end

function checkRule(Building)
	local check = true;
	if #grpDrainline == 0 then
		check = false
		FXUtility.DisplaySolid_Warning(Building,"Drain Line is not provided.")
	end
	if #grpPublicSewer == 0 then
		check = false
		FXUtility.DisplaySolid_Warning(Building,"Public Sewer is not provided.")
	end
	if #grpManhole == 0 then
		check = false
		FXUtility.DisplaySolid_Warning(Building,"Manhole is not provided.")
	end
	if check then
		grpManhole:ForEach(function ( Manhole )
			local ReducerGrp = FXGroup.new()
			local drainLine;
			local publicSewer;
			local manholeName = Manhole:GetAttri("Name")
			local publicLowpos=0;
			local drainlineLowpos=-0;
			local flag = false

			local inspectionChamberGrp = FXGroup.new()
			local DCEgrp = Building:GetDescendants("DistributionChamberElement")
			DCEgrp:ForEach(function(distChambEle)
				local objType = distChambEle:GetAttri("ObjectType");
				if FXUtility.HasPatterInString(objType,"Inspection Chamber") == true then
            		inspectionChamberGrp:Add(distChambEle)
          		end
			end)

			grpDrainline:ForEach(function ( sewer )
				local checkConnectedChamber = FXPUB.CheckConnectedChamberElement(Building,Manhole,sewer)
				if checkConnectedChamber == true then
					flag = true;
					inspectionChamberGrp:ForEach(function(inspChamber)
						if FXClashDetection.IsCollided(sewer, inspChamber) then
							drainLine = sewer;
							drainLineOBBLowPos = FXGeom.GetBoundingBox(sewer):LowPos().z
							drainlineLowpos = drainLineOBBLowPos;
						end
					end)
				end	
			end)

			if flag == false then
				FXUtility.DisplaySolid_Warning(Building,"Manhole not connected to drain line.")
				return;
			end	

			grpPublicSewer:ForEach(function ( sewer )
				if FXClashDetection.IsCollided(Manhole, sewer) then
					publicOBBLowPos = FXGeom.GetBoundingBox(sewer):LowPos().z
					local publicX = FXGeom.GetBoundingBox(sewer):LowPos().x
					local publicY = FXGeom.GetBoundingBox(sewer):LowPos().y
					local pnt1 = Point3D(publicX,publicY,publicOBBLowPos)
					local pnt2 = Point3D(publicX,publicY,publicOBBLowPos+100)
					local Line = Line3D(pnt1,pnt2)
					local node = FXUtility.CreateNodeFrom(Line);
					if FXClashDetection.IsCollided(Manhole,node) then
						publicLowpos = publicOBBLowPos;
						publicSewer = sewer;
					end
					FXClashDetection.DeleteNode(node)
				end
			end)
			local verticalDistance = FXUtility.Round(drainlineLowpos - publicLowpos,2)
			local verticalDistanceRounded = FXUtility.Round(verticalDistance)
			local pipeX = FXGeom.GetBoundingBox(drainLine):LowPos().x
			local pipeY = FXGeom.GetBoundingBox(drainLine):LowPos().y
			local publicX = FXGeom.GetBoundingBox(publicSewer):LowPos().x
			local publicY = FXGeom.GetBoundingBox(publicSewer):LowPos().y
			local pnt1 = Point3D(pipeX,pipeY,drainlineLowpos)
			local pnt2 = Point3D(pipeX,pipeY,publicLowpos)
			local pnt3 = Point3D(pnt2.x,publicY,pnt2.z)
			local Line = Line3D(pnt2,pnt3)
			local arrow = DoubleArrow(pnt1,pnt2)

			if FXRule.EvaluateNumber(operator1,verticalDistanceRounded,min1) and FXRule.EvaluateNumber(operator2,verticalDistanceRounded,max1) then
				if #grpTumblingBay ~= 0  then
					grpTumblingBay:ForEach(function ( tumblingBay )
						if FXPUB.CheckConnectedChamberElement(Building,Manhole,tumblingBay) then
							FXUtility.DisplaySolid_Info(drainLine,"Vertical Distance: "..verticalDistanceRounded.." mm; Tumbling bay connection is provided.");
							CheckReport.AddRelatedObj( Manhole, Manhole:GetAttri("Name"))

							grpPublicSewer:ForEach(function ( sewer )
							CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
							end)

							grpDrainline:ForEach(function ( sewer )
								CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
							end)

							CheckReport.AddRelatedObj( tumblingBay, tumblingBay:GetAttri("Name"))
							CheckReport.AddRelatedGeometry_Info(Line)
							CheckReport.AddRelatedGeometry_Info(arrow)
						end
					end)
				else
					FXUtility.DisplaySolid_Error(drainLine,"Vertical Distance: "..verticalDistanceRounded.." mm; Tumbling bay connection is not provided.");
					CheckReport.AddRelatedObj( Manhole, Manhole:GetAttri("Name"))

					grpDrainline:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
					end)

					grpPublicSewer:ForEach(function ( sewer )
						CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
					end)
					CheckReport.AddRelatedGeometry_Error(arrow)
					CheckReport.AddRelatedGeometry_Error(Line)
				end
			elseif FXRule.EvaluateNumber(operator3,verticalDistanceRounded,min2) and FXRule.EvaluateNumber(operator4,verticalDistanceRounded,max2) then
				if #grpBackdrop ~= 0  then
					grpBackdrop:ForEach(function ( backdrop )
						if FXPUB.CheckConnectedChamberElement(Building,Manhole,backdrop) then
							FXUtility.DisplaySolid_Info(drainLine,"Vertical Distance: "..verticalDistanceRounded.." mm; Tumbling bay connection is provided.");
							CheckReport.AddRelatedObj( Manhole, Manhole:GetAttri("Name"))

							grpPublicSewer:ForEach(function ( sewer )
							CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
							end)

							grpDrainline:ForEach(function ( sewer )
								CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
							end)

							CheckReport.AddRelatedObj( backdrop, backdrop:GetAttri("Name"))
							CheckReport.AddRelatedGeometry_Info(Line)
							CheckReport.AddRelatedGeometry_Info(arrow)
						end
					end)
				else
					FXUtility.DisplaySolid_Error(drainLine,"Vertical Distance: "..verticalDistanceRounded.." mm; Backdrop connection is not provided.");

					CheckReport.AddRelatedObj( Manhole, Manhole:GetAttri("Name"))

					grpDrainline:ForEach(function ( sewer )
					CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
					end)

					grpPublicSewer:ForEach(function ( sewer )
						CheckReport.AddRelatedObj( sewer, sewer:GetAttri("Name"))
					end)

					CheckReport.AddRelatedGeometry_Error(arrow)
					CheckReport.AddRelatedGeometry_Error(Line)
				end
			end
		end)
	end
end