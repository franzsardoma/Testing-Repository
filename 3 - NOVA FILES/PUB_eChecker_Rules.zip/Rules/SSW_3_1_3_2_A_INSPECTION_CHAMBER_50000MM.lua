local SystemTypes;
local grpFlowSegment = FXGroup:new();
local grpFlowFitting = FXGroup:new();
local InspectionChamberGrp = FXGroup:new()
local maxDistance;
local isConnectedToChamber = false;
local isTwoInspectionChamber = false;
local condition4;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_2_A_INSPECTION_CHAMBER_50000MM")

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	condition4 = FXRule.ParseValues(parsedXml, "Condition4");
	
	
	maxDistance = ConditionValues[3];
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			InspectionChamberGrp = InspectionChamberGrp + v;
			InspectionChamberGrp = InspectionChamberGrp:Unique()
		end
	end
	for k,v in pairs(GrpObjsSystem) do
		
		if (k == 3) then
			grpFlowSegment = grpFlowSegment + v;
			grpFlowSegment = grpFlowSegment:Unique()
		end
		if (k == 4) then
			grpFlowFitting = grpFlowFitting + v;
			grpFlowFitting = grpFlowFitting:Unique()

		end
	end
end


function checkRule(Building)
	if #InspectionChamberGrp ~= 0 then
		if #grpFlowSegment ~= 0 then
			local chamber1;
			local finalchamber2;
			local chamber1Name;
			local chamber2Name;
			local checkedChambers = FXGroup.new()
			local InspectionChamberGrpprj = FXMeasure.GetProjection(InspectionChamberGrp, 0)
			local isCompliant = true;
			local count = 0;
			local ConnectedInspectionChamber = FXGroup:new()
			
			if #InspectionChamberGrp > 1 then
				InspectionChamberGrp:ForEach(function ( chamber1 )
					local arrowGeom;
					local chamber1ID = chamber1.Id
					checkedChambers:Add(chamber1)
						
					local isTwoInspectionChamberConnected = false;
					InspectionChamberGrp = InspectionChamberGrp  - checkedChambers
					InspectionChamberGrp:ForEach(function ( chamber2 )
						local chamber2ID = chamber2.Id

						if chamber2ID ~= chamber1ID then

							local chamber1ConnectedObjs = FXGroup.new();
							local chamber2ConnectedObjs = FXGroup.new();
							local connectingObjects = grpFlowSegment+grpFlowFitting
							connectingObjects:ForEach(function ( connObj )		
								if FXClashDetection.IsCollided(connObj, chamber1) and FXClashDetection.IsCollided(connObj, chamber2) then
									isTwoInspectionChamberConnected = true
									finalchamber2 = chamber2;
									isConnectedToChamber = true
								elseif FXClashDetection.IsCollided(connObj, chamber1) then
									chamber1ConnectedObjs:Add(connObj)
								elseif FXClashDetection.IsCollided(connObj, chamber2) then
									chamber2ConnectedObjs:Add(connObj)
								end
							end)
							if isTwoInspectionChamber == false then
								chamber1ConnectedObjs:ForEach(function ( chamber1Obj )
									chamber2ConnectedObjs:ForEach(function ( chamber2Obj )
										if FXPUB.IsObjsConnected (chamber1Obj, chamber2Obj) then
											isTwoInspectionChamberConnected = true
											chamber2 = chamber2;
											isConnectedToChamber = true
										end
									end)
								end)
							end
						end
					end)

					

					if isTwoInspectionChamberConnected then
	
						local chamber1Name = chamber1:GetAttri("Name");
						local chamber1OBB = FXGeom. GetBoundingOBB(chamber1)
						local centerPnt1 = chamber1OBB:GetPos();
						local maxPnt1 = chamber1OBB:MaxPnt();

						local chamber2Name = finalchamber2:GetAttri("Name");
						local chamber2OBB = FXGeom. GetBoundingOBB(finalchamber2)
						local centerPnt2 = chamber2OBB:GetPos();
						local maxPnt2 = chamber2OBB:MaxPnt();


						local distLine = Line3D(Point3D(centerPnt1.x,centerPnt1.y,maxPnt1.z), Point3D(centerPnt2.x,centerPnt2.y,maxPnt2.z))

						local chamberDistance = FXUtility.Round(distLine:Length(), 2)


						if chamberDistance > tonumber(maxDistance) then
							isCompliant = false;
						end
						arrowGeom = DoubleArrow(distLine:GetStartPoint(), distLine:GetEndPoint());

						CheckResult(Building, isCompliant, chamber1, finalchamber2, chamber1Name, chamber2Name, chamberDistance, arrowGeom);
						
					end
				end)
			else
				FXUtility.DisplaySolid_Warning(Building, "Only one Inspection Chamber is provided.")
				return
			end
		else
			isConnectedToChamber = false
		end

		if isConnectedToChamber == false then
			FXUtility.DisplaySolid_Warning(Building, MSG_NO_CONN_CHAMBER)
		end
		
	else
		FXUtility.DisplaySolid_Warning(Building, MSG_NO_CHAMBER)
	end

end


function CheckResult(Building, isCompliant, chamber1, chamber2, chamber1Name, chamber2Name, chamberDistance, arrowGeom)
	
	if isCompliant then
		FXUtility.DisplaySolid_Info(Building, chamber1Name..": Distance = "..chamberDistance.."mm to "..chamber2Name);
		CheckReport.AddRelatedObj( chamber1, chamber1Name )
		CheckReport.AddRelatedObj( chamber2, chamber2Name )
		CheckReport.AddRelatedGeometry_Solid(arrowGeom, "Arrow3D")
	else
		FXUtility.DisplaySolid_Error(Building, chamber1Name..": Distance = "..chamberDistance.."mm to "..chamber2Name);
		CheckReport.AddRelatedObj( chamber1, chamber1Name )
		CheckReport.AddRelatedObj( chamber2, chamber2Name )
		CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
	end
	
end

