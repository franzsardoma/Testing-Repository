-- modified by: Lawrence Roy Quiling 1/4/2019

local grpTrenchs = FXGroup:new();
local grpSewers = FXGroup:new()
local maxDepthRange = 0;
local minDepthRange = 0;
local minTrenchWidth = 0;
local Condition2Operator
local exceDepthRange = 0
local TrenchValues = {}
local SewerValues = {}

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_2_C_III_MINIMUM_TRENCH_WIDTH")
	
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpTrenchs = grpTrenchs + v;
			grpTrenchs = grpTrenchs:Unique();
		end
	end

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 3) then
				grpSewers = grpSewers + v;
				grpSewers = grpSewers:Unique();
			end
		end
	end

	for k,v in pairs(ConditionValues1) do
		if (k == 2) then
			minDepthRange = tonumber(v);
		end
		if (k == 4) then
			maxDepthRange = tonumber(v);
		end
		if (k == 8) then
			minTrenchWidth = tonumber(v);
		end
	end
	for k,v in pairs(ConditionValues2) do
		if (k == 2) then
			Condition2Operator = v;
		end
		if (k == 3) then
			exceDepthRange = tonumber(v);
		end
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(TrenchValues, v1["value"])
			end
			if(k == 2) then
				table.insert(SewerValues, v1["value"])
			end
		end
	end
end

function checkRule( Building )
	local flag = true;
	if #grpTrenchs == 0 then
		CheckReport.Warning(Building, TrenchValues[1].." is not provided.")
		flag = false;
	end
	if #grpSewers == 0 then
		CheckReport.Warning(Building, SewerValues[1].." is not provided.")
		flag = false;
	end
	if flag == false then
		return;
	end
	
	local grpSlabs = Building:GetDescendants("Slab");

	grpTrenchs:ForEach(function ( TrenchEle )
		local TrenchWidth, TrenchWidthArrow = getWidthTrench( TrenchEle )
		local grpPipes = getPipes( TrenchEle )
		local IsErrorNotFound = true
		local ARRCTrench = {}
		local ARRCPipe = {}
		local ARRCArrow = {}
		local ARRCTrenchWidth = {}
		local ARRCPipeDepth = {}
		local ARRCPipeDepthArrow = {}
		local ARRCPipeDepthLine = {}
		local ARRWTrench = {}
		local ARRWPipe = {}
		local ARRWMaxDepth = {}
		local ARRWPipeDepthArrow = {}
		local ARRWPipeDepthLine = {}
		local ARRWWidthArrow = {}
		-- print(TrenchWidth)
		grpPipes:ForEach(function ( Pipe )
			local PipeDepth ,PipeDepthArrow ,PipeDepthLine = getPipeDepth(Pipe, grpSlabs, TrenchEle);
			-- print(CheckCondition( PipeDepth , Condition2Operator, exceDepthRange ))
			if PipeDepth > minDepthRange and PipeDepth <= maxDepthRange then
				if TrenchWidth >= 750 then
					table.insert(ARRCTrench, TrenchEle)
					table.insert(ARRCPipe, Pipe)
					table.insert(ARRCArrow, TrenchWidthArrow)
					table.insert(ARRCTrenchWidth, TrenchWidth)
					table.insert(ARRCPipeDepth, PipeDepth)
					table.insert(ARRCPipeDepthArrow, PipeDepthArrow)
					table.insert(ARRCPipeDepthLine, PipeDepthLine)
				else
					IsErrorNotFound = false
					FXUtility.DisplaySolid_Error(TrenchEle, TrenchEle:GetAttri("ObjectType").." width: "..TrenchWidth.." mm; "..Pipe:GetAttri("ObjectType").." depth: "..PipeDepth.." mm",TrenchWidthArrow)
					CheckReport.AddRelatedObj(TrenchEle, TrenchEle:GetAttri("ObjectType"))
					CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("ObjectType"))
					CheckReport.AddRelatedGeometry_Info(PipeDepthArrow)
					CheckReport.AddRelatedGeometry_Info(PipeDepthLine)
				end
			elseif FXRule.EvaluateNumber(Condition2Operator, PipeDepth, exceDepthRange) then
				table.insert(ARRWTrench, TrenchEle)
				table.insert(ARRWPipe, Pipe)
				table.insert(ARRWMaxDepth, maxDepthRange)
				table.insert(ARRWPipeDepthArrow, PipeDepthArrow)
				table.insert(ARRWPipeDepthLine, PipeDepthLine)
				table.insert(ARRWWidthArrow, TrenchWidthArrow)
			end

			if IsErrorNotFound then
				for k,TrenchEle in pairs(ARRCTrench) do
					FXUtility.DisplaySolid_Info(TrenchEle, TrenchEle:GetAttri("ObjectType").." width: "..ARRCTrenchWidth[k].." mm; "..ARRCPipe[k]:GetAttri("ObjectType").." depth: "..ARRCPipeDepth[k].." mm",ARRCArrow[k]);
					CheckReport.AddRelatedObj(TrenchEle, TrenchEle:GetAttri("ObjectType"))
					CheckReport.AddRelatedObj(ARRCPipe[k], ARRCPipe[k]:GetAttri("ObjectType"))
					CheckReport.AddRelatedGeometry_Info(ARRCPipeDepthArrow[k])
					CheckReport.AddRelatedGeometry_Info(ARRCPipeDepthLine[k])
				end
				for k,TrenchEle in pairs(ARRWTrench) do
					FXUtility.DisplaySolid_Warning(TrenchEle, ARRWPipe[k]:GetAttri("ObjectType").." depth is greater than"..ARRWMaxDepth[k].." mm; "..TrenchEle:GetAttri("ObjectType").." width shall be advised by PUB",ARRWPipeDepthArrow[k])
					CheckReport.AddRelatedObj(TrenchEle, TrenchEle:GetAttri("ObjectType"))
					CheckReport.AddRelatedObj(ARRWPipe[k], ARRWPipe[k]:GetAttri("ObjectType"))
					CheckReport.AddRelatedGeometryWithColor_Solid(ARRWPipeDepthLine[k], "", "1,1,0,1")
					CheckReport.AddRelatedGeometryWithColor_Solid(ARRWWidthArrow[k], "", "1,1,0,1")
				end
			end
		end)
	end)
end

function getWidthTrench( Obj )
	local width = 0;
	local pnt1 = FXMeasure.GetProjectionCenterLine(Obj):GetStartPoint();
	local pnt2 = FXMeasure.GetProjectionCenterLine(Obj):GetEndPoint();
	local point1 = Point3D(pnt1.x, pnt1.y , FXGeom.GetBoundingBox(Obj):MidPos().z );
	local point2 = Point3D(pnt2.x, pnt2.y , FXGeom.GetBoundingBox(Obj):MidPos().z );
	local line = Line3D(point1, point2)
	local extended
	while true do 			
		width = width + 1 ;
		extended = FXMeasure.CreateFaceFromEdge(line, width);
		local extendedNode = FXUtility.CreateNodeFrom(extended);

		if FXClashDetection.IsCollided ( extendedNode , Obj ) then
			FXClashDetection.DeleteNode ( extendedNode );
			break				
		end
		FXClashDetection.DeleteNode ( extendedNode ); 
	end
	local closetEdge = FXMeasure.GetOuterEdge(extended)
	local line = GetShortestLine( closetEdge )
	local arrow = DoubleArrow(line:GetStartPoint(),line:GetEndPoint())
	-- FXUtility.DisplaySolid_Error(Obj, "das",arrow)
	return width*2, arrow;
end

function getPipeDepth( Pipe, grpSlabs, Trench)
	local innnerPnt = FXGeom.GetBoundingBox(Pipe)
	local HighTrenchPnt = FXGeom.GetBoundingBox(Trench)
	local line = Line3D(Point3D(HighTrenchPnt:HighPos().x ,innnerPnt:MidPos().y, innnerPnt:LowPos().z), Point3D(HighTrenchPnt:HighPos().x ,HighTrenchPnt:HighPos().y, innnerPnt:LowPos().z))
	if HighTrenchPnt:x_range() < HighTrenchPnt:y_range() then
		line = Line3D(Point3D(HighTrenchPnt:MidPos().x ,innnerPnt:HighPos().y, innnerPnt:LowPos().z), Point3D(HighTrenchPnt:HighPos().x ,HighTrenchPnt:HighPos().y, innnerPnt:LowPos().z))
	end
	local arrow = DoubleArrow(HighTrenchPnt:HighPos(), Point3D(HighTrenchPnt:HighPos().x ,HighTrenchPnt:HighPos().y, innnerPnt:LowPos().z))
	local depth = HighTrenchPnt:HighPos().z - innnerPnt:LowPos().z
	-- print(depth)
	return FXUtility.Round(depth), arrow, line;
end

function getPipes( Trench )
	local GrpPipes = FXGroup:new()
	local TrenchBox = FXGeom.GetBoundingBox(Trench)
	local node = FXUtility.CreateNodeFrom(TrenchBox);

	grpSewers:ForEach(function ( SewerEle )
		if (FXClashDetection.IsCollided(SewerEle, node)) then
			GrpPipes:Add(SewerEle)
		end
	end)
	FXClashDetection.DeleteNode ( node );
	return GrpPipes;
end

function GetShortestLine( route )

	local PolyLinePointNumber = route:GetPointNumber()
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = route:GetPoint(i)
		local Point2 = route:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end