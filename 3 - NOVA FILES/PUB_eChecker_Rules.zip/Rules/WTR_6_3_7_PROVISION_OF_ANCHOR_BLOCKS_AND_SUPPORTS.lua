local grpWaterMain = FXGroup.new();		-- (FlowSegment) --
local grpFlowFitting = FXGroup.new();	-- (FlowFitting) --
local grpAnchorBlock = FXGroup.new();	-- (BuildingElementProxy) --


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_3_7_PROVISION_OF_ANCHOR_BLOCKS_AND_SUPPORTS")
	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local GrpObjs2 = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs1) do
		if (k == 2) then
			grpWaterMain = grpWaterMain + v;
			grpWaterMain = grpWaterMain:Unique();
		end
		if (k == 3) then
			grpFlowFitting = grpFlowFitting + v;
			grpFlowFitting = grpFlowFitting:Unique();
		end
	end
	for k,v in pairs(GrpObjs2) do
		if (k == 4) then
			grpAnchorBlock = grpAnchorBlock + v;
			grpAnchorBlock = grpAnchorBlock:Unique();
		end
	end
end

function CheckRule( Building )
	if(#grpWaterMain ~= 0 or #grpAnchorBlock ~= 0)then
		grpFlowFitting:ForEach(function ( FITTING )
			local ConnectedElement = FITTING:GetConnectedElement();
			local grpConnectedWaterMain = FXGroup.new();
			local Flag = false;
			local flagBlock = false;

			ConnectedElement:ForEach(function ( ELEMENT )
				if(FXUtility.HasPatterInString(ELEMENT:GetAuxAttri("Entity.ObjectType"), "Water Main"))then
					grpConnectedWaterMain:Add(ELEMENT);
					Flag = true;
				end
			end)

			if(Flag == true)then
				grpAnchorBlock:ForEach(function ( BLOCK )
					if(FXClashDetection.IsCollided(FITTING , BLOCK))then
						flagBlock = true
						if(FXUtility.HasPatterInString(FITTING:GetAttri("Name"), "Tee"))then
							FXUtility.DisplaySolid_Info(FITTING , "Anchor Block provided at Branch in Water Main");
							CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"));

						elseif(FXUtility.HasPatterInString(FITTING:GetAttri("Name") , "Cap"))then
							FXUtility.DisplaySolid_Info(FITTING , "Anchor Block provided at Dead End in Water Main");
							CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"));

						elseif(FXUtility.HasPatterInString(FITTING:GetAttri("Name") , "Elbow"))then
							local flagSlope = false;
							grpConnectedWaterMain:ForEach(function ( slope )
								local pipeSlope = slope:GetAuxAttri("Constraints.Slope")
								if(tonumber(pipeSlope) ~= 0)then
									flagSlope = true
								end
							end)
							if(flagSlope == false)then
								FXUtility.DisplaySolid_Info(FITTING , "Anchor Block provided at Bend in Water Main");
								CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"))
							else
								FXUtility.DisplaySolid_Info(FITTING , "Anchor Block provided at Change in Gradient in Water Main");
								CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"))
							end
						end
					end
				end)

				if(flagBlock == false)then
					if(FXUtility.HasPatterInString(FITTING:GetAttri("Name") , "Tee"))then
						FXUtility.DisplaySolid_Error(FITTING , "Water Main has no Anchor Block at branch.");
						CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"));

					elseif(FXUtility.HasPatterInString(FITTING:GetAttri("Name") , "Cap"))then
						FXUtility.DisplaySolid_Error(FITTING , "Water Main has no Anchor Block at dead end.");
						CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"));

					elseif(FXUtility.HasPatterInString(FITTING:GetAttri("Name") , "Elbow"))then
						local flagSlope = false;
						grpConnectedWaterMain:ForEach(function ( slope )
							local pipeSlope = slope:GetAuxAttri("Constraints.Slope")
							if(tonumber(pipeSlope) ~= 0)then
								flagSlope = true
							end
						end)
						if(flagSlope == false)then	
							FXUtility.DisplaySolid_Error(FITTING , "Water Main has no Anchor Block at bend.");
							CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"));
						else
							FXUtility.DisplaySolid_Error(FITTING , "Water Main has no Anchor Block at change in gradient");
							CheckReport.AddRelatedObj(FITTING , FITTING:GetAttri("Name"));
						end
					end
				end
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building , "Anchor Block is not provided.");
		FXUtility.DisplaySolid_Warning(Building , "Water Main is not provided.");
	end
end