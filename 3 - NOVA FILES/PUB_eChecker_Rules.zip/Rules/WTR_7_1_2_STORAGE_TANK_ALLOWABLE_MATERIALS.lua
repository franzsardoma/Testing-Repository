local WaterTankGrp = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function Parser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_2_STORAGE_TANK_ALLOWABLE_MATERIALS");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	-- -- IsConnected = ConditionValues[1];
	-- -- minDiameter = tonumber(ConditionValues[2])

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- print(#GrpObjs)
	if(GrpObjs ~= nil)then		
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				WaterTankGrp =   WaterTankGrp + v;
				WaterTankGrp = WaterTankGrp:Unique();
			end		
		end
	end	
end

function CheckRule( Building )
	local Material;
	local Flag;
	local Tank;
	--------------------------------------------------------------------------
	if(#WaterTankGrp > 0)then
		-----------------------------------------------------------------------
		WaterTankGrp:ForEach(function(Element)
			Material = Element:GetAuxAttri("Materials and Finishes.Material");
			Tank = Element;
		end)
		-----------------------------------------------------------------------
		if(Material ~= nil)then
			if(FXUtility.HasPatterInString(Material,"Reinforced Concrete"))then
				Flag = true;
			elseif(FXUtility.HasPatterInString(Material,"Fiber Glass Reinforced Polyester"))then
				Flag = true;
			elseif(FXUtility.HasPatterInString(Material,"Glass fiber Reinforced Polyester"))then
				Flag = true;
			elseif(FXUtility.HasPatterInString(Material,"Stainless Steel Grade 3.16") or FXUtility.HasPatterInString(Material,"Stainless Steel Grade 316"))then
				Flag = true;
			else
				Flag = false;
			end
		end
		-----------------------------------------------------------------------
		local TankName = Tank:GetAuxAttri("Entity.ObjectType");
		if(Flag)then 
			FXUtility.DisplaySolid_Info(Tank,TankName..": "..Material);
		else
			FXUtility.DisplaySolid_Error(Tank,TankName..": "..Material);
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Water Storage Tank is not provided.");
	end
	---------------------------------------------------------------------------
end