local SpaceName = {};
local minDist = 0--300;
local grpFlowSegment = FXGroup:new();
local grpSpaces = FXGroup:new();
local arrProj = {};
local isNoCommonPipe = false
local isErrorFound = false
local x1 = 0
local x2 = 0
local comSpaceArr = {}
local com2SpaceArr = {}
local com2PipeArr = {}
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("BuildingStorey");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckResult");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_G_COMMON_AREAS_AND_TOILETS")
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);	
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 2 ) then
			grpFlowSegment = grpFlowSegment + v
			grpFlowSegment = grpFlowSegment:Unique()
		end
	end

	for k,v in pairs(GrpBuildingObjs) do -- Checking in Building
		if ( k == 3 ) then
			grpSpaces = grpSpaces + v
		end
	end

	-- grpSpaces :ForEach (function ( spaces )
	-- 	print (spaces:GetAttri("LongName") )
	-- end)
end

function getStoreyProjections(Building)
	-- print ( #grpFlowSegment .. " - " ..#grpSpaces)
	arrProj = {};
	grpSpaces:ForEach(function ( spaces )
		table.insert(SpaceName, spaces:GetAttri("LongName"))
	end)

	local grpStorey = Building:GetChildren("BuildingStorey");
	local countStorey = 0;
	grpStorey:ForEach(function (Storey)
	
		if( FXUtility.IsFirstStorey(Storey) or countStorey >= 1 ) then
			countStorey = countStorey + 1;
		end
	
		local grpSlabs = Storey:GetDescendants("Slab");
		local elev = Storey:Elevation();
		if( #grpSlabs ~= 0 ) then
			local SlabsProj =  FXMeasure.GetProjection(grpSlabs, elev);
			arrProj[elev] = SlabsProj; 
		end
	end)
	
	if( countStorey > 1 ) then
		return true;
	else
		return false;
	end
end


function CheckLevel( objEle1, objEle2 ) 
	local objEle1Lvl = string.lower(objEle1:GetParent():GetAttri("Name"));
	local objEle2Lvl = string.lower(objEle2:GetParent():GetAttri("Name"));
	local isSameLvl = FXRule.EvaluateString("Contains", objEle2Lvl, objEle1Lvl);
	
	return isSameLvl;
end

function CheckObj( objEle1, objEle2 )

	local isSameLvl = CheckLevel( objEle1, objEle2 );
	
	if( isSameLvl ) then
		return true;
	end
	
	local res = false;
	local cnt = 0;
	local obj =  FXGeom.GetBoundingOBB(objEle1);
	local objElev = obj:MinPnt().z;
			
	for k,v in pairs(arrProj) do
		if( objElev < k ) then
			local obb =  FXGeom.GetBoundingOBB(objEle2);
			local zValue = obb:MinPnt().z;
			if( zValue < k ) then
				return true;
			else
				local pipeProj = FXMeasure.GetObjProjection(objEle2, 0.0);
				PrjFinal = FXMeasure.SubtractProjection(pipeProj, v);
				if( PrjFinal ~= nil ) then
					return true;
				else
					return false;
				end
			end
		end
	end
	
	return res;
end

function checkRule(Building) -- Building Storey
	local isMultiStorey = getStoreyProjections(Building);
	
	if #grpFlowSegment == 0 then
		isNoCommonPipe = true 
		return;
	end

	local grpSpaces = Building:GetDescendants("Space");
	local strName = "LongName";
	grpSpaces:ForEach(function (Space)		
		grpFlowSegment:ForEach(function (FlowSegment)
			local isCheckObj = CheckObj( Space, FlowSegment );
			if isCheckObj and Space ~= nil and FlowSegment ~= nil then
				compareObjs2(Space, FlowSegment, strName);				
			end
		end)
	end)
end

function CheckResult(Building)
	if isNoCommonPipe then
		FXUtility.DisplaySolid_Warning(Building, "Common Pipe is not provided.");
	end
	-- print ( #comSpaceArr)
	if(isErrorFound == false)then
		local y1 = 1 
		local y2 = 1

		while y1 ~= x1 + 1 do 
			FXUtility.DisplaySolid_Info( comSpaceArr[y1] , "Common Pipe inside ".. comSpaceArr[y1] :GetAttri("LongName"));
			y1 = y1 + 1
		end	

		while y2 ~= x2 + 1 do
			FXUtility.DisplaySolid_Info( com2SpaceArr[y2] , com2SpaceArr[y2]:GetAttri("LongName").."; ".. com2PipeArr[y2]:GetAttri("ObjectType"));
			CheckReport.AddRelatedObj( com2PipeArr[y2] , com2PipeArr[y2]:GetAttri("ObjectType"));
			y2 = y2 + 1
		end
	end
end

function compareObjs2(Space, FlowSegment, strName)		
	local obb1 =  FXGeom.GetBoundingOBB(Space);
	local zValue1 = obb1:MinPnt().z;
	local obb2 =  FXGeom.GetBoundingOBB(FlowSegment);
	local zValue2 = obb2:MinPnt().z;
	-- print ( zValue1.." - "..zValue2 .." : "..Space:GetParent():GetAttri("Name"))

	if zValue1 > zValue2 then
		-- print ("return")
		return true;
	end
	-- print ("NAKA LUSOT")
	local tempName = Space:GetAttri(strName);
	local bRet = FXUtility.IsBelongToTableSpace(Space,SpaceName);

	local isOverlap = FXRelation.IsOverlap(Space, FlowSegment);
	if isOverlap == -1 then
		x2 = x2 + 1
		com2SpaceArr[x2] = Space
		com2PipeArr[x2] = FlowSegment
	else
		local nodeContainer	= FXUtility.CreateNodeFrom(obb1);
		local SpaceProj =  FXMeasure.GetObjProjection(nodeContainer, 0.0);
		local FlowSegmentProj =  FXMeasure.GetObjProjection(FlowSegment, 0.0);
		
		if( SpaceProj ~= nil and FlowSegmentProj ~=  nil ) then
			SpaceProj = FXMeasure.MoveProjection(SpaceProj,0);
			FlowSegmentProj = FXMeasure.MoveProjection(FlowSegmentProj,0)
			local node1		= FXUtility.CreateNodeFrom(SpaceProj);
			local node2		= FXUtility.CreateNodeFrom(FlowSegmentProj);

			local distance =  FXRelation.Distance(node1, node2);				
			if distance:Length() <= minDist then
				
				if (bRet == false) then 
					isErrorFound = true
					FXUtility.DisplaySolid_Error(Space, Space:GetAttri(strName).."; "..FlowSegment:GetAttri("ObjectType"));
					CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("ObjectType"));
				elseif bRet then
					x1 = x1 + 1					
					comSpaceArr[x1] = Space
				end
			end			
			FXClashDetection.DeleteNode(node1);
			FXClashDetection.DeleteNode(node2);			
		end
		FXClashDetection.DeleteNode(nodeContainer);
	end	
end

