--[[-----------------------------------------------------

Author: Monalyn L. Rueda

Rule ID: SSW 3.2.3.1 (h)
Rule Name: Minimum Transition Length

All copyrights to novasolutions 
--]]-----------------------------------------------------
local DischargePipeGrp = FXGroup:new()
local VentPipeGrp = FXGroup:new()
local CrossVentPipe = FXGroup:new()



local VentPipesTemp = FXGroup:new()
local SanitaryPipesTemp = FXGroup:new()



local count = 0



function main()

	CheckEngine.SetCheckType("System")
	CheckEngine.BindCheckFunc("getSystemPipes")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
    .BindCheckFunc("GetRequiredPipes")
    .RunCheckPipeline()
    
end

function XMLParser(Site)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_3_1_H_CROSS_VENT")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Site, systemTypes)

	for k,v in pairs(xmlObjs) do

		if (k == 2) then
			CrossVentPipe = CrossVentPipe + v;
			CrossVentPipe = CrossVentPipe:Unique();			    
		end

		-- if (k == 3) then
		-- 	CrossVentFitting = CrossVentFitting + v;
		-- 	CrossVentFitting = CrossVentFitting:Unique();			    
		-- end

		if (k == 4) then
			DischargePipeGrp = DischargePipeGrp + v;
			DischargePipeGrp = DischargePipeGrp:Unique();			    
		end

		if (k == 5) then
			VentPipeGrp = VentPipeGrp + v;
			VentPipeGrp = VentPipeGrp:Unique();			    
		end

	end

end

function getSystemPipes(System)

	if (FXUtility.HasPatterInString(System:GetAttri("Name"),"Vent")) then
		VentPipesTemp = VentPipesTemp + System:GetDescendants("FlowSegment");

	elseif (FXUtility.HasPatterInString(System:GetAttri("Name"),"Sanitary")) then
		SanitaryPipesTemp = SanitaryPipesTemp + System:GetDescendants("FlowSegment");
	end

end

function GetRequiredPipes(building)
	local VentPipes = FXGroup:new()
	local SanitaryPipes = FXGroup:new()
	local SanitaryFitting = FXGroup:new()
	local CrossVent = FXGroup:new()

	if #CrossVentPipe == 0 then
		CheckReport.Warning(building,"Cross Vent is not provided.")
		return;
	end

	if #DischargePipeGrp == 0 then
		CheckReport.Warning(building,"Discharge stack pipes is not provided.")
		return;
	end

	if #VentPipeGrp == 0 then
		CheckReport.Warning(building,"Ventilating stack pipes is not provided.")
		return;
	end

	if #VentPipesTemp ~= 0 and #SanitaryPipesTemp ~= 0 then

			VentPipesTemp:ForEach(function(pipes)
				local pipeDiameter = FXPUB.GetDiameter(pipes);

				if pipeDiameter >= 75 then
					VentPipes:Add(pipes)
				end	
			end)

			SanitaryPipesTemp = SanitaryPipesTemp - VentPipesTemp

			SanitaryPipesTemp:ForEach(function(pipes)
				local pipeDiameter = FXPUB.GetDiameter(pipes);

				if pipeDiameter >= 75 then 
					SanitaryPipes:Add(pipes)
				end
			end)

			if (#SanitaryPipes ~= 0) then

				SanitaryPipes:ForEach(function(pipes)
					local ConnectedFitting = pipes:GetConnectedFitting()
					ConnectedFitting:ForEach(function(fit)
						SanitaryFitting:Add(fit)
					end)
				end)

				CrossVentPipe:ForEach(function(pipes)

					local ConnectedFitting = pipes:GetConnectedFitting()

					ConnectedFitting:ForEach(function(connfit)

						SanitaryFitting:ForEach(function(fit)

							if (FXUtility.HasPatterInString(connfit.Id, fit.Id)) then	
								CrossVent:Add(pipes)
							end

						end)
					end)

				end)

			end

			if #CrossVent ~= 0 then
				local CheckProvisionFunc = CheckProvision(building, CrossVent)
			else
				FXUtility.DisplaySolid_Warning(building, "Cross Vent is not provided.");
			end
	end

end

function CheckProvision(building, CrossVent)

local BuildingStorey = building:GetDescendants('BuildingStorey')
local crossventTemp = FXGroup:new()
local storeyGrp = FXGroup:new()

	BuildingStorey:ForEach(function(storey)
		count = count + 1
		if (count%10 == 0) then

			storeyGrp:Add(storey)
			local FlowSegments = storey:GetDescendants('FlowSegment')

			FlowSegments:ForEach(function(flowpipes)

				CrossVent:ForEach(function(pipes)

					if (FXUtility.HasPatterInString(flowpipes.Id, pipes.Id)) then
						crossventTemp:Add(pipes)
					end
				end)
			end)
		end
	end)

	if #storeyGrp ~= 0 then

		storeyGrp:ForEach(function(storey)
			local FlowSegments = storey:GetDescendants('FlowSegment')
			local DischargePerStorey = FXGroup:new()
			local VentPerStorey = FXGroup:new()

			local crossvent
			print(storey:GetAttri('Name'))

			FlowSegments:ForEach(function(flowpipes)
				local pipeDiameter = FXPUB.GetDiameter(flowpipes);

				if pipeDiameter >= 75 then 
					
					CrossVent:ForEach(function(pipes)

						if (FXUtility.HasPatterInString(flowpipes.Id, pipes.Id)) then
							crossvent = pipes
						end
					end)

					DischargePipeGrp:ForEach(function(discharge)

						if (FXUtility.HasPatterInString(flowpipes.Id, discharge.Id)) then
							DischargePerStorey:Add(discharge)
						end

					end)

					VentPipeGrp:ForEach(function(vent)

						if (FXUtility.HasPatterInString(flowpipes.Id, vent.Id)) then
							VentPerStorey:Add(flowpipes)
						end
					end)
				end
			end)

				if #crossventTemp == #storeyGrp then
					local Compliant = DisplayCompliantMessages(crossvent, storey)
				else
					local NonCompliant = DisplayNonCompliantMessages(crossvent, DischargePerStorey, VentPerStorey, storey)
				end
		end)
	end
end

function DisplayCompliantMessages(crossvent, storey)

	local crossventfitting = crossvent:GetConnectedFitting()

	FXUtility.DisplaySolid_Info(crossvent, " Cross vent pipe is provided between discharge pipe and ventilating pipe at every 10 storey.");
	crossventfitting:ForEach(function(fit)
		CheckReport.AddRelatedObj(fit, " Connected Flowfit : " .. fit:GetAttri("Name"));
	end)
end

function DisplayNonCompliantMessages(crossvent, dischargepipes, ventpipes, storey)

	if crossvent ~= nil then

		local crossventfitting = crossvent:GetConnectedFitting()

		FXUtility.DisplaySolid_Error(crossvent, " Cross vent pipe is provided between discharge pipe and ventilating pipe at more than 10 storey.");

		crossventfitting:ForEach(function(fit)
			CheckReport.AddRelatedObj(fit, " Connected Flowfit : " .. fit:GetAttri("Name"));
		end)

		local AddRelatedObjsFunc = AddRelatedObjs(dischargepipes, ventpipes)

	else
		FXUtility.DisplaySolid_Error(storey, "Cross vent pipe not provided between discharge pipe and ventilating pipe");
		local AddRelatedObjsFunc = AddRelatedObjs(dischargepipes, ventpipes)
	end

end

function AddRelatedObjs(dischargepipes, ventpipes)
	dischargepipes:ForEach(function(pipes)
		CheckReport.AddRelatedObj(pipes, " Discharge Pipe : " .. pipes:GetAttri("Name"));
	end)
	ventpipes:ForEach(function(pipes)

		CheckReport.AddRelatedObj(pipes, " Ventilating Pipe : " .. pipes:GetAttri("Name"));
	end)
end