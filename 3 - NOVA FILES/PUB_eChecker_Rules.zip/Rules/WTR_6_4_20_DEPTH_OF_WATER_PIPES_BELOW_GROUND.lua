local grpPipe = FXGroup.new()
local grpObj = FXGroup.new()
local operator;
local maximumDis;
local isErrorFound = false
local x = 0
local comArr = {}
local comDepthArr = {}
local comArrowArr = {}

function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_6_4_20_DEPTH_OF_WATER_PIPES_BELOW_GROUND")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1"); -- parse the condition values

	operator = ConditionValues[2]
	maximumDis = tonumber(ConditionValues[3])
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	-- local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpPipe = grpPipe + v
			grpPipe = grpPipe:Unique()			
		end			
	end
	local xmlObj = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObj) do -- get the model objects
		if k == 3 then
			grpObj = grpObj + v
			grpObj = grpObj:Unique()			
		end			
	end
end

function checkRule(Building)
	
	local level1
	local node
	local site = Building:GetParent()
	grpstorey = Building:GetDescendants("BuildingStorey")
	-- grpSlab = Building:GetDescendants("Slab")
	-- grpPipe = Building:GetDescendants("FlowSegment")
	local grpPipeBelow = FXGroup.new()

	grpstorey:ForEach(function ( storey )
		local name = storey:GetAttri("Name")
		if FXUtility.HasPatterInString(name,"Level") and FXUtility.HasPatterInString(name,"1") then
			level1 = storey
		end
	end)

	grpPipe:ForEach(function ( pipe )
		local pipeBox = FXGeom. GetBoundingBox(pipe)
		local pipePoint = pipeBox:LowPos()
		if pipePoint.z < level1:Elevation() then
			grpPipeBelow:Add(pipe)
		end
	end)
	if #grpPipe ~= 0 then
		grpPipe:ForEach(function (pipe)
			local grpCol = FXGroup.new()
			local pipeBox = FXGeom. GetBoundingBox(pipe)
			local pipePoint = pipeBox:LowPos()
			local prjpipe = FXMeasure.GetObjProjection(pipe, pipePoint.z);	
			local edge = FXMeasure.GetOuterEdge(prjpipe)
			local noOfPnt1 = edge:GetPointNumber();
			local PlyLine = PolyLine3D(TRUE);

			for i = 1, noOfPnt1 -1, 1 do
				local pnt1 = edge:GetPoint(i);
				PlyLine:AddPoint(pnt1);
			end

			PlyLine:ClosePolyline();
			local face = PlyLine:Face3D()
			local extrudeFace = face:ExtrudedFace(Vector(0,0,5000))
			node = FXUtility.CreateNodeFrom(extrudeFace)
			grpObj:ForEach(function (slab )
				if FXClashDetection.IsCollided(node, slab) then
					grpCol:Add(slab)
				end
			end)

			if FXClashDetection.IsCollided(node, site) then
				grpCol:Add(site)
			end

			-- print(#grpCol)
			if grpCol == 0  then
				return;
			end
			local lowestEle = GetLowestElement(grpCol)
			local objBox = FXGeom. GetBoundingBox(lowestEle)
			local objPoint = objBox:HighPos()
			local doubleArrow = DoubleArrow(Point3D(pipePoint.x,pipePoint.y,objPoint.z),pipePoint)
			local dist = objPoint.z - pipePoint.z
			dist = FXUtility.Round(dist,0)
			if FXRule.EvaluateNumber(operator, dist, maximumDis) then
				x = x + 1
				-- FXUtility.DisplaySolid_Info(pipe,pipe:GetAttri("Name")..": Depth = ".. dist.." mm",doubleArrow)
				comArr[x] = pipe
				comDepthArr[x] = dist
				comArrowArr[x] = doubleArrow
			else
				isErrorFound = true
				FXUtility.DisplaySolid_Error(pipe,pipe:GetAuxAttri("Entity.ObjectType")..": Depth = ".. dist.." mm",doubleArrow)
			end
		end)

		if isErrorFound ~= true then	
			local y = 1
			while y ~= x + 1 do
				FXUtility.DisplaySolid_Info(comArr[y],comArr[y]:GetAuxAttri("Entity.ObjectType")..": Depth = ".. comDepthArr[y].." mm",comArrowArr[y])
				y = y + 1
			end
		end 
	else
		FXUtility.DisplaySolid_Warning(Building,"Water pipe is not provided.")
	end

end

function GetLowestElement(grp)
	local lowest
	grp:ForEach(function (ele)
		if lowest == nil then
			lowest = ele
		else
			local lowBox = FXGeom.GetBoundingOBB(lowest)
			local eleBox = FXGeom.GetBoundingOBB(ele)
			local lowpoint = lowBox:GetPos()
			local elepoint = eleBox:GetPos()
			if elepoint.z < lowpoint.z then
				lowest = ele
			end
		end
	end)
	return lowest
end