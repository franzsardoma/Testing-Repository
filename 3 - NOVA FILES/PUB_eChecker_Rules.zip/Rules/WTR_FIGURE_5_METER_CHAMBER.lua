local WaterMeterGroup = FXGroup.new();
local FlowSegmentGroup1 = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "WTR_FIGURE_5_WATER_METER_SPACING_FOR_VARIOUS_SIZES");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	--minHeight = ConditionValues[2];
	-- minDiameter = tonumber(ConditionValues[2])

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)		
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			WaterMeterGroup = WaterMeterGroup + v;
			WaterMeterGroup = WaterMeterGroup:Unique();
		end	
		-- if (k == 6) then	
		-- 	FlowSegmentGroup1 = FlowSegmentGroup1 + v;
		-- end		
	end	
end


function GetLength(Object)
	local ObjectBox = FXGeom.GetBoundingBox(Object);
	local x = FXUtility.Round(ObjectBox:x_range());
	local y = FXUtility.Round(ObjectBox:y_range());
	local z = FXUtility.Round(ObjectBox:z_range());
	local arr = {x,y,z};
	local temp;
	------------------------------------------------
	for i = 1, #arr, 1 do
		if(temp == nil)then 
			temp = arr[i];
		else
			if(temp < arr[i])then 
				temp = arr[i];
			end
		end
	end
	------------------------------------------------
	-- print(temp.."LENGTH "..Object.Id)
	-- FXUtility.DisplaySolid_Error(Object, Object:GetAttri("Name"));
	return temp;
end


function checkRule(Building)
	if(#WaterMeterGroup ~= 0)then
		WaterMeterGroup:ForEach(function(WaterMeter) 
			local ConnectedPipe = WaterMeter:GetConnectedSegment();
			local PipeLengthA = 0;
			local PipeLengthC = 0;
			local PipeObjectA;
			local PipeObjectC;
			if(#ConnectedPipe <= 2)then 
				local tempLength;
				local tempObject;
				ConnectedPipe:ForEach(function(Pipe)
					-- FXUtility.DisplaySolid_Error(Pipe, Pipe:GetAttri("Name"));
					local Length = GetLength(Pipe);
					if(tempLength == nil and tempObject == nil)then 
						tempLength = Length;
						tempObject = Pipe;
					else
						if(tempLength > Length)then
							PipeLengthA = tempLength;
							PipeObjectA = tempObject;
							--=======================
							PipeLengthC = Length;
							PipeObjectC = Pipe;
						else 
							PipeLengthA = Length;
							PipeObjectA = Pipe;
							--=======================
							PipeLengthC = tempLength;
							PipeObjectC = tempObject;
						end
					end
				end)
			end
			print("-----------")
			local MeterDiameter = WaterMeter:GetAuxAttri("Dimensions.Maximum Size")
			local MeterLength  = GetLength(WaterMeter);
			local A;
			local B;
			local C;
			A,B,C = CheckMeterSpacing(tonumber(MeterDiameter));
			
			-- print(D.."=D")
			print(PipeLengthA.."-A-"..A)
			if(PipeLengthA >= A)then 
				print(PipeLengthC.."-C")
				if(PipeLengthC >= C)then
					print(MeterLength.."-Meter")
					if(MeterLength == B)then 
						CompliantMsg(WaterMeter,MeterLength,PipeObjectA,PipeObjectC);
					else
						NonCompliantMsg(WaterMeter,MeterLength,PipeObjectA,PipeObjectC);
					end
				else
					NonCompliantMsg(WaterMeter,MeterLength,PipeObjectA,PipeObjectC);
				end
			else
				NonCompliantMsg(WaterMeter,MeterLength,PipeObjectA,PipeObjectC);
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building,"No Water Meter found.");
	end
end



function CheckMeterSpacing(Diameter)
	if(Diameter <= 25)then 
		local A = 75;
		local B = 225;
		local C = 50;
		local D = 350;
		return A,B,C;
	elseif(Diameter > 25 and Diameter <= 50)then
		local A = 150;
		local B = 300;
		local C = 100;
		local D = 560;
		return A,B,C;
	elseif(Diameter > 50 and Diameter <= 100)then
		local A = 300;
		local B = 360;
		local C = 200;
		local D = 870;
		return A,B,C;
	elseif(Diameter > 100 and Diameter <= 150)then
		local A = 500;
		local B = 500;
		local C = 300;
		local D = 1310;
		return A,B,C;
	else
		FXUtility.DisplaySolid_Warning(Building,"Invalid Diameter of Water Meter");
	end
end

function GetDoubleArrow(Object,ObjectA,ObjectC)
	--WATER METER
	-- local ObjectGroup = FXGroup.new();
	-- ObjectGroup:Add(Object);
	-- ObjectGroup:Add(ObjectA);
	-- ObjectGroup:Add(ObjectC);

	-- local HighPosZ;
	-- local MidZ;

	local ObjectOBB = FXGeom.GetBoundingOBB(Object);
	local ObjectBox = FXGeom.GetBoundingBox(Object);
	---------------------PIPE A-----------------------
	local ObjectAOBB = FXGeom.GetBoundingOBB(ObjectA);
	local ObjectABox = FXGeom.GetBoundingBox(ObjectA);
	---------------------PIPE C-----------------------
	local ObjectCOBB = FXGeom.GetBoundingOBB(ObjectC);
	local ObjectCBox = FXGeom.GetBoundingBox(ObjectC);


	local CenterY = (ObjectOBB:MaxPnt().y + ObjectOBB:MinPnt().y)/2;
	local MinY = ObjectOBB:MinPnt().y;
	local MaxY = ObjectOBB:MaxPnt().y;
	local HighPosZ = ObjectBox:HighPos().z;
	local MidZ = (HighPosZ + ObjectBox:LowPos().z)/2;
	local MeterZ = HighPosZ + 25;

	local Point1 = Point3D(ObjectOBB:MinPnt().x,CenterY,MeterZ);
	local Point2 = Point3D(ObjectOBB:MaxPnt().x,CenterY,MeterZ);
	local Line = Line3D(Point1,Point2);
	-------------------------POINTS------------------------------------------------
	local LinePoint1 = Point3D(ObjectOBB:MinPnt().x,CenterY,ObjectAOBB:MinPnt().z);
	local LinePoint2 = Point3D(ObjectOBB:MinPnt().x,CenterY,MeterZ);
	local LinePoint3 = Point3D(ObjectOBB:MaxPnt().x,CenterY,ObjectAOBB:MinPnt().z);
	local LinePoint4 = Point3D(ObjectOBB:MaxPnt().x,CenterY,MeterZ);
	-------------------------POLYLINE----------------------------------------------
	local PlyLineB = PolyLine3D(TRUE);
	PlyLineB:AddPoint(LinePoint1);
	PlyLineB:AddPoint(LinePoint2);
	PlyLineB:AddPoint(LinePoint4);
	PlyLineB:AddPoint(LinePoint3);

	local DoubleArrow = DoubleArrow(Line:GetStartPoint(),Line:GetEndPoint());

	--PIPE A
	local CenterYA = (ObjectAOBB:MaxPnt().y + ObjectAOBB:MinPnt().y)/2;
	-- local HighPosA = ObjectABox.HighPos().z;

	local Point1A = Point3D(ObjectAOBB:MinPnt().x,CenterYA,MeterZ);
	local Point2A = Point3D(ObjectAOBB:MaxPnt().x,CenterYA,MeterZ);
	local LineA = Line3D(Point1A,Point2A);
	-------------------------POINTS------------------------------------------------
	local LinePoint1A = Point3D(ObjectAOBB:MinPnt().x,CenterYA,ObjectAOBB:MinPnt().z);
	local LinePoint2A = Point3D(ObjectAOBB:MinPnt().x,CenterYA,MeterZ);
	local LinePoint3A = Point3D(ObjectAOBB:MaxPnt().x,CenterYA,ObjectAOBB:MinPnt().z);
	local LinePoint4A = Point3D(ObjectAOBB:MaxPnt().x,CenterYA,MeterZ);
	-------------------------POLYLINE----------------------------------------------
	local PlyLineA  = PolyLine3D(TRUE);
	PlyLineA:AddPoint(LinePoint1A);
	PlyLineA:AddPoint(LinePoint2A);
	PlyLineA:AddPoint(LinePoint4A);
	PlyLineA:AddPoint(LinePoint3A);
	
	local DoubleArrowA = DoubleArrow(LineA:GetStartPoint(),LineA:GetEndPoint());

	--PIPE C
	
	local CenterYC = (ObjectCOBB:MaxPnt().y + ObjectCOBB:MinPnt().y)/2;
	local Point1C = Point3D(ObjectCOBB:MinPnt().x,CenterYC,MeterZ);
	local Point2C = Point3D(ObjectCOBB:MaxPnt().x,CenterYC,MeterZ);
	local LineC = Line3D(Point1C,Point2C);
	local DoubleArrowC = DoubleArrow(LineC:GetStartPoint(),LineC:GetEndPoint());
	-------------------------POINTS------------------------------------------------
	local LinePoint1C = Point3D(ObjectCOBB:MinPnt().x,CenterYC,ObjectCOBB:MaxPnt().z);
	local LinePoint2C = Point3D(ObjectCOBB:MinPnt().x,CenterYC,MeterZ);
	local LinePoint3C = Point3D(ObjectCOBB:MaxPnt().x,CenterYC,ObjectCOBB:MaxPnt().z);
	local LinePoint4C = Point3D(ObjectCOBB:MaxPnt().x,CenterYC,MeterZ);
	-------------------------POLYLINE----------------------------------------------
	local PlyLineC = PolyLine3D(TRUE);
	PlyLineC:AddPoint(LinePoint1C);
	PlyLineC:AddPoint(LinePoint2C);
	PlyLineC:AddPoint(LinePoint4C);
	PlyLineC:AddPoint(LinePoint3C);


	--LENGTH D
	local Elevation = MeterZ + 100;

	local AMxX = ObjectAOBB:MaxPnt().x;
	local AMnX = ObjectAOBB:MinPnt().x;
	local Ac = CenterYA;
	
	local CMxX = ObjectCOBB:MaxPnt().x;
	local CMnX = ObjectCOBB:MinPnt().x;
	local Cc = CenterYC;


	local Point10a = Point3D(AMxX,Ac,Elevation); --Maximum Y, Center Y
	local Point20a = Point3D(CMnX,Cc,Elevation); -- Manimum C, Center Y
	local aLine = Line3D(Point10a,Point20a);
	local aLength = aLine:Length();

	local Point10b = Point3D(AMxX,CenterYA,Elevation);
	local Point20b = Point3D(CMxX,CenterYC,Elevation);
	local bLine = Line3D(Point10b,Point20b);
	local bLength = bLine:Length();

	local Point10c = Point3D(AMnX,CenterYA,Elevation);
	local Point20c = Point3D(CMxX,CenterYC,Elevation);
	local cLine = Line3D(Point10c,Point20c);
	local cLength = cLine:Length();

	local Point10d = Point3D(AMnX,CenterYA,Elevation);
	local Point20d = Point3D(CMnX,CenterYC,Elevation);
	local dLine = Line3D(Point10d,Point20d);
	local dLength = dLine:Length();


	local LineD = GetHighestLength(aLength,bLength,cLength,dLength,aLine,bLine,cLine,dLine);
	-------------------------POINTS------------------------------------------------
	local LinePoint1D = Point3D(LineD:GetStartPoint().x,LineD:GetStartPoint().y,MidZ);
	local LinePoint2D = Point3D(LineD:GetStartPoint().x,LineD:GetStartPoint().y,Elevation);
	local LinePoint3D = Point3D(LineD:GetEndPoint().x,LineD:GetStartPoint().y,MidZ);
	local LinePoint4D = Point3D(LineD:GetEndPoint().x,LineD:GetStartPoint().y,Elevation);
	-------------------------POLYLINE----------------------------------------------
	local PlyLineD = PolyLine3D(TRUE);
	PlyLineD:AddPoint(LinePoint1D);
	PlyLineD:AddPoint(LinePoint2D);
	PlyLineD:AddPoint(LinePoint4D);
	PlyLineD:AddPoint(LinePoint3D);

	-- print(Result)
	local DoubleArrowD = DoubleArrow(LineD:GetStartPoint(),LineD:GetEndPoint());
	-----------------------------------------------------------------------------
	local Total = LineD:GetStartPoint():Distance_Pnt(LineD:GetEndPoint()); 
	local C_LENGTH = LineC:GetStartPoint():Distance_Pnt(LineC:GetEndPoint());
	local A_LENGTH = LineA:GetStartPoint():Distance_Pnt(LineA:GetEndPoint());
	-----------------------------------------------------------------------------
	Total = FXUtility.Round(Total);
	C_LENGTH = FXUtility.Round(C_LENGTH);
	A_LENGTH = FXUtility.Round(A_LENGTH);	
	-----------------------------------------------------------------------------	
	return DoubleArrow,DoubleArrowA,DoubleArrowC,DoubleArrowD,PlyLineA,PlyLineB,PlyLineC,PlyLineD,Total,A_LENGTH,C_LENGTH;
end

function CompliantMsg(Meter,MeterLength,PipeA,PipeC)
	local ArrowMeter, ArrowA, ArrowC, ArrowD, PolyLineA, PolyLineB, PolyLineC, PolyLineD, Total, A_LENGTH, C_LENGTH = GetDoubleArrow(Meter,PipeA,PipeC);
	local Msg = ResultMsg(A_LENGTH,MeterLength,C_LENGTH,Total);

	FXUtility.DisplaySolid_Info(Meter,Msg);
	CheckReport.AddRelatedObj(PipeA,PipeA:GetAttri("Name"));
	CheckReport.AddRelatedObj(Meter,Meter:GetAttri("Name"));
	CheckReport.AddRelatedObj(PipeC,PipeC:GetAttri("Name"));
	
	-- CheckReport.AddRelatedGeometry_Solid(ArrowA,"A: "..LengthA.."mm ; "..Meter:GetAttri("Name"));

	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Solid(ArrowA);
	CheckReport.AddRelatedGeometry_Solid(PolyLineA);
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Solid(ArrowMeter);
	CheckReport.AddRelatedGeometry_Solid(PolyLineB);
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Solid(ArrowC);
	CheckReport.AddRelatedGeometry_Solid(PolyLineC);
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Solid(ArrowD);
	CheckReport.AddRelatedGeometry_Solid(PolyLineD);
	-------------------------------------------------

end

function NonCompliantMsg(Meter,MeterLength,PipeA,PipeC)
	local ArrowMeter, ArrowA, ArrowC, ArrowD, PolyLineA, PolyLineB, PolyLineC, PolyLineD, Total, A_LENGTH, C_LENGTH = GetDoubleArrow(Meter,PipeA,PipeC);
	local Msg = ResultMsg(A_LENGTH,MeterLength,C_LENGTH,Total);

	FXUtility.DisplaySolid_Error(Meter,Msg);
	CheckReport.AddRelatedObj(PipeA,PipeA:GetAttri("Name"));
	CheckReport.AddRelatedObj(Meter,Meter:GetAttri("Name"));
	CheckReport.AddRelatedObj(PipeC,PipeC:GetAttri("Name"));
	
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Error(ArrowA);
	CheckReport.AddRelatedGeometry_Error(PolyLineA);
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Error(ArrowMeter);
	CheckReport.AddRelatedGeometry_Error(PolyLineB);
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Error(ArrowC);
	CheckReport.AddRelatedGeometry_Error(PolyLineC);
	-------------------------------------------------
	CheckReport.AddRelatedGeometry_Error(ArrowD);
	CheckReport.AddRelatedGeometry_Error(PolyLineD);
	-------------------------------------------------
end

function ResultMsg(A_LENGTH,MeterLength,C_LENGTH,Total)
	local MsgA = "Distance \"A\": "..math.floor(A_LENGTH).."mm; ";
	local MsgB = "\"B\": "..math.floor(MeterLength).."mm; ";
	local MsgC = "\"C\": "..math.floor(C_LENGTH).."mm ; ";
	local MsgD = "Total Distance \"D\": "..math.floor(Total).."mm";
	local Msg = MsgA..MsgB..MsgC..MsgD;
	return Msg;
end

function GetHighestLength(a,b,c,d,al,bl,cl,dl)
	local arr = {a,b,c,d};
	local temp = 0;
	local index;
	for i = 1, #arr ,1 do 
		-- print(arr[i])
		if(temp == 0)then 
			temp = arr[i];
			index = i;
		else
			if(arr[i] > temp)then
				temp = arr[i];
				index = i;
			end
		end
	end
	temp = TableCheck(index,al,bl,cl,dl);
	return temp;
end


function TableCheck(Value,al,bl,cl,dl) 
	if(Value == 1)then 
		return al;
	elseif(Value == 2)then
		return bl;
	elseif(Value == 3)then	
		return cl;
	else
		return dl;
	end
end



