local spaceGrp = FXGroup:new();
local waterTankGrp = FXGroup:new();
local tankCover = FXGroup:new();
local doorGrp = FXGroup:new();
local isCompliant = true;
local con1; --con is Condition.
local con2;
local con3;
local hasCover = FXGroup:new();
local noCover = FXGroup:new();
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("Building");
	-- CheckEngine.BindCheckFunc("CheckRuleWarning");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_19_B_LOCKS_FOR_WATER_TANK")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition2");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition3");
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition4");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	con1 = ConditionValues1[2];
	con2 = ConditionValues1[2];
	con3 = ConditionValues1[2];

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			spaceGrp = spaceGrp + v
			spaceGrp = spaceGrp:Unique()
		end
		if (k == 4) then
			tankCover = tankCover + v
			tankCover = tankCover:Unique()
		end
		if (k == 5) then
			doorGrp = doorGrp + v
			doorGrp = doorGrp:Unique()
		end
	end
	if GrpObjSystem ~= nil then
		for k,v in pairs(GrpObjSystem) do
			if (k == 3) then
				waterTankGrp = waterTankGrp + v
				waterTankGrp = waterTankGrp:Unique()
			end
		end
	end
end
function CheckRuleWarning(Building)
	if waterTankGrp == nil or #waterTankGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Water Tank is not provided.");
	end
end
function CheckRule(Building)
	if #spaceGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Tank/Pump Room is not provided.");
	else
		if #waterTankGrp == 0 then
			FXUtility.DisplaySolid_Warning(Building,"Water Tank is not provided.");
		else
			local flag = false;
			local i = 0;
			local arrObj1 = {};
			local arrObj2 = {};
			local arrObj3 = {};
			local arrObj4 = {};
			spaceGrp:ForEach(function(space)
				local box = FXGeom.GetBoundingBox(space);
				local zVal = box:HighPos().z;
				local spaceProj = FXMeasure.GetObjProjection(space,zVal);

				local obb = FXGeom.GetBoundingOBB(space);
				local node = FXUtility.CreateNodeFrom(obb);

				waterTankGrp:ForEach(function(tank)
					if FXClashDetection.IsCollided(tank,node) then
						local tankProj = FXMeasure.GetObjProjection(tank,space:GetParent("BuildingStorey"):Elevation())
						local tempProj = FXMeasure.IntersectTwoProjection(tankProj, spaceProj, space:GetParent("BuildingStorey"):Elevation());
						local area1 = FXUtility.Round(FXMeasure.GetProjectionArea(tankProj)/1000000, 2);
						local area2 = FXUtility.Round(FXMeasure.GetProjectionArea(tempProj)/1000000, 2);
						print(area1.."=="..area2)
						if area2 ~= nil and area1 == area2 then
							if #tankCover == 0 then
								flag = true;
							else
								tankCover:ForEach(function(cover)
									if FXClashDetection.IsCollided(tank,cover) then
										hasCover:Add(tank)
										i = i + 1;
										if con1 == "true" then
											local lock = cover:GetAuxAttri("Mechanical.Padlock")
											if lock == "true" then
												-- arrObj1[i] = tank;
												-- arrObj2[i] = cover;
												FXUtility.DisplaySolid_Info(cover,tank:GetAttri("ObjectType")..": "..cover:GetAttri("ObjectType")..": Non-duplicable key lock is provided.")
												CheckReport.AddRelatedObj(tank,tank:GetAttri("ObjectType"))
											else
												FXUtility.DisplaySolid_Error(cover,tank:GetAttri("ObjectType")..": "..cover:GetAttri("ObjectType")..": Non-duplicable key lock is not provided.")
												CheckReport.AddRelatedObj(tank,tank:GetAttri("ObjectType"))
												isCompliant = false;
											end
										else
											-- arrObj1[i] = tank;
											-- arrObj2[i] = cover;
											FXUtility.DisplaySolid_Info(cover,tank:GetAttri("ObjectType")..": "..cover:GetAttri("ObjectType")..": Non-duplicable key lock is provided.")
											CheckReport.AddRelatedObj(tank,tank:GetAttri("ObjectType"))
										end
										local conDoors = space:GetConnectedDoor();
										if con2 == "true" and con3 == "true" then
											if conDoors ~= nil or #conDoors ~= 0 then
												conDoors:ForEach(function(door)
													local hardwarelock = door:GetAuxAttri("Mechanical.Hardware Lock")
													local duplicate = door:GetAuxAttri("Mechanical.Non-Duplicable Lock")

													if hardwarelock == "true" and duplicate == "true" then
														-- arrObj3[i] = space;
														-- arrObj4[i] = door;
														FXUtility.DisplaySolid_Info(door,space:GetAttri("LongName")..": "..door:GetAttri("ObjectType")..": Non-duplicable key lock is provided.")
														CheckReport.AddRelatedObj(space,space:GetAttri("LongName"))
													else
														FXUtility.DisplaySolid_Error(door,space:GetAttri("LongName")..": "..door:GetAttri("ObjectType")..": Non-duplicable key lock is not provided.")
														CheckReport.AddRelatedObj(space,space:GetAttri("LongName"))
														isCompliant = false;
													end
												end)
											else
												FXUtility.DisplaySolid_Warning(space,"Door is not provided.");
												isCompliant = false;
											end
										else
											if conDoors ~= nil or #conDoors ~= 0 then
												conDoors:ForEach(function(door)
													-- arrObj3[i] = space;
													-- arrObj4[i] = door;
													FXUtility.DisplaySolid_Info(door,space:GetAttri("LongName")..": "..door:GetAttri("ObjectType")..": Non-duplicable key lock is provided.")
													CheckReport.AddRelatedObj(space,space:GetAttri("LongName"))
												end)
											else
												FXUtility.DisplaySolid_Warning(space,"Door is not provided.");
												isCompliant = false;
											end
										end
									else
										noCover:Add(tank)
									end
								end)
							end
						end
						if area2 ~= nil and area1 ~= area2 then
							FXUtility.DisplaySolid_Error(tank,"Water Tank is partially covered.");
							isCompliant = false;
						end
					end
				end)
			end)
			if flag then
				FXUtility.DisplaySolid_Warning(Building,"Water Tank Cover is not provided.");
				isCompliant = false;
			end
			hasCover:Unique();
			noCover:Unique();
			noCover = noCover - hasCover;

			if #noCover > 0 then
				noCover:ForEach(function(obj)
					FXUtility.DisplaySolid_Warning(obj,"Water Tank Cover is not provided.");
					isCompliant = false;
				end)
			end
			-- if isCompliant then
			-- 	if #arrObj3 ~= 0 then
			-- 		for k,space in pairs(arrObj3) do
			-- 			FXUtility.DisplaySolid_Info(space,arrObj4[k]:GetAttri("ObjectType").." Lock is provided.")
			-- 			CheckReport.AddRelatedObj(arrObj4[k],arrObj4[k]:GetAttri("ObjectType"))
			-- 		end
			-- 	end
			-- 	if #arrObj1 ~= 0 then
			-- 		for k,tank in pairs(arrObj1) do
			-- 			FXUtility.DisplaySolid_Info(tank,arrObj2[k]:GetAttri("ObjectType").." Padlock is provided.")
			-- 			CheckReport.AddRelatedObj(arrObj2[k],arrObj2[k]:GetAttri("ObjectType"))
			-- 		end
			-- 	end
			-- end
		end
	end
end