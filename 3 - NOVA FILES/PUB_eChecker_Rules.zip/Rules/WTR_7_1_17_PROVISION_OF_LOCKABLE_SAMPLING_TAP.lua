local Tank = FXGroup:new()
local WashoutPipe = FXGroup:new()
local IsolatingValve = FXGroup:new()
local LockableTap = FXGroup:new()
local SamplingPipe = FXGroup:new()
local tankFlag = true
local flag = true
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_17_PROVISION_OF_LOCKABLE_SAMPLING_TAP")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
-- print(GrpObjsSystem);
	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				Tank = Tank + v;
				Tank = Tank:Unique();
			end
			if (k == 3) then
				WashoutPipe = WashoutPipe + v;
				WashoutPipe = WashoutPipe:Unique();
			end
			if (k == 4) then
				IsolatingValve = IsolatingValve + v;
				IsolatingValve = IsolatingValve:Unique();
			end
			if (k == 5) then
				LockableTap = LockableTap + v;
				LockableTap = LockableTap:Unique();
			end
			
		end
	end
	

end

function checkRule(Building)
	local tank2 = {}
	local wash2 = {}
	local isolatingValve2 = {}
	local lockableTap2 = {}
	if #Tank ~= 0 then
		Tank:ForEach(function( tank )
			if #WashoutPipe ~= 0 then
				WashoutPipe:ForEach(function( wash )
					if FXPUB.ObjToObjIsConnected(tank,wash,10)then
						if #IsolatingValve ~= 0 then
							IsolatingValve:ForEach(function( isolatingValve )
								if FXPUB.ObjToObjIsConnected(wash,isolatingValve,10)then
									if #LockableTap ~= 0 then
										LockableTap:ForEach(function( lockableTap )
											if FXPUB.ObjToObjIsConnected(isolatingValve,lockableTap,10)then
												table.insert(tank2,tank)
												table.insert(wash2,wash)
												table.insert(isolatingValve2,isolatingValve)
												table.insert(lockableTap2,lockableTap)

											end
										end)
									else
										flag = false
										FXUtility.DisplaySolid_Error(tank, "Lockable Sampling Tap is not provided." )
									end
								end
							end)
						else
							flag = false
							FXUtility.DisplaySolid_Error(tank, "Isolating Valve is not provided." )
						end
						return false;
					end
				end)
			else
				flag = false
				FXUtility.DisplaySolid_Error(tank, "Wash Out Pipe is not provided." )
			end
		end)
	else
		flag = false
		FXUtility.DisplaySolid_Warning(Building,"Tank is not provided.")
	end
	if flag then
		for i = 1, #tank2 do
			
				FXUtility.DisplaySolid_Info(tank2[i], "Lockable Sampling Tap is provided." )
				-- CheckReport.AddRelatedObj(wash2[i], wash2[i]:GetAttri("ObjectType"))
				-- CheckReport.AddRelatedObj(isolatingValve2[i], isolatingValve2[i]:GetAttri("ObjectType"))
				CheckReport.AddRelatedObj(lockableTap2[i], lockableTap2[i]:GetAttri("ObjectType"))
			end
	end
end