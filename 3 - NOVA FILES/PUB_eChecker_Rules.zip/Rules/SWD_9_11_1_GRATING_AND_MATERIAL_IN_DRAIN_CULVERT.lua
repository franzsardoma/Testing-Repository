-- Author:Mohammad Derick Pauig


local grpSlabDrive = FXGroup.new()
local grpSlabWalk = FXGroup.new()
local grpDrain = FXGroup.new()
local grpCulvert = FXGroup.new()
local grpGratingVeh = FXGroup.new()
local grpGratingPed = FXGroup.new()


function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_9_11_1_GRATING_AND_MATERIAL_IN_DRAIN_CULVERT")

	--local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1"); -- parse the condition values
	-- local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition2");
	-- local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition3");
	-- maxWidth = tonumber(ConditionValues[3])
	-- material1 = ConditionValues1[1]
	-- material2 = ConditionValues2[1]
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	--local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpGratingVeh = grpGratingVeh + v
			grpGratingVeh = grpGratingVeh:Unique()		
		end
		if k == 3 then
			grpGratingPed = grpGratingPed + v
			grpGratingPed = grpGratingPed:Unique()			
		end	
		if k == 4 then
			grpSlabDrive = grpSlabDrive + v
			grpSlabDrive = grpSlabDrive:Unique()			
		end
		if k == 5 then
			grpSlabWalk = grpSlabWalk + v
			grpSlabWalk = grpSlabWalk:Unique()			
		end		
		if k == 6 then
			grpCulvert = grpCulvert + v
			grpCulvert = grpCulvert:Unique()				
		end	
	end
end

function checkRule(Building)
	local slab = {}
	local Drain = {}
	local grating = {}
	local iscompliant = true
	local x = 0
	local isnotcol = false
	print(#grpSlabDrive.."dri")
	print(#grpSlabWalk.."walk")
	print(#grpDrain.."dra")
	print(#grpGratingVeh.."veh")
	print(#grpGratingPed.."ped")
	print(#grpCulvert.."cul")


	if #grpSlabWalk ~= 0 or #grpSlabDrive ~= 0 then
		if #grpCulvert ~= 0 then
			if #grpGratingVeh ~= 0 or #grpGratingPed ~= 0 then
				grpSlabDrive:ForEach(function ( drive )
					local elevation = drive:GetParent():Elevation()
					local slabface = FXMeasure.GetObjProjection(drive,elevation)
					local nFace  = slabface:GetFaceNumber();
					local iscovered
					for i = 0, nFace -1, 1  do
						local nFaceNumber = slabface:GetFace(i):GetVoidFaceNumber(); 
						if(nFaceNumber > 0) then 
							for j = 0, nFaceNumber -1, 1 do 
								
								local inner = slabface:GetFace(i):GetVoidFace(j):Face3D();
								local inner = inner:Move(Vector(0,0,500))
								local inner = inner:ExtrudedFace(Vector(0,0,-2500))
								local node  = FXUtility.CreateNodeFrom(inner)
								local drac
								
								grpCulvert:ForEach(function ( dracul )
									if FXClashDetection.IsCollided(node, dracul) then
										drac = dracul
									end
								end)

								grpGratingVeh:ForEach(function ( veh )
									if FXClashDetection.IsCollided(node, veh) then
										iscovered = true
										x = x + 1
										slab[x] = drive
										grating[x] = veh
										Drain[x] = drac
									else
										if iscovered ~= true then
											iscovered = false
										end
									end
								end)

								grpGratingPed:ForEach(function ( gra )
									if FXClashDetection.IsCollided(node, gra) then
										iscovered = true
										iscompliant = false
					 					FXUtility.DisplaySolid_Error(drive,drive:GetAttri("Name") .. " : " ..material(gra))
					 					CheckReport.AddRelatedObj( drive, drive:GetAttri("Name"));
					 					CheckReport.AddRelatedObj( gra, gra:GetAttri("Name"));
					 					CheckReport.AddRelatedObj( drac, drac:GetAttri("Name"));
					 				else
					 					if iscovered ~= true then
											iscovered = false
										end
					 				end
								end)

								if iscovered == false then
									FXUtility.DisplaySolid_Error(drive,drive:GetAttri("Name") .. " : Grating is not provided.")
									CheckReport.AddRelatedObj( drive, drive:GetAttri("Name"));
					 				CheckReport.AddRelatedObj( drac, drac:GetAttri("Name"));
								end
							end 
						end
					end
				end)
				grpSlabWalk:ForEach(function ( walk )
					local elevation = walk:GetParent():Elevation()
					local slabface = FXMeasure.GetObjProjection(walk,elevation)
					local nFace  = slabface:GetFaceNumber();
					local iscovered
					for i = 0, nFace -1, 1  do
						local nFaceNumber = slabface:GetFace(i):GetVoidFaceNumber(); 
						if(nFaceNumber > 0) then 
							for j = 0, nFaceNumber -1, 1 do 
								
								local inner = slabface:GetFace(i):GetVoidFace(j):Face3D();
								local inner = inner:Move(Vector(0,0,500))
								local inner = inner:ExtrudedFace(Vector(0,0,-2500))
								local node  = FXUtility.CreateNodeFrom(inner)
								local drac
								print("haha")
								grpCulvert:ForEach(function ( dracul )
									if FXClashDetection.IsCollided(node, dracul) then
										drac = dracul
									end
								end)

								grpGratingVeh:ForEach(function ( veh )
									if FXClashDetection.IsCollided(node, veh) then
										iscovered = true
										iscompliant = false
										FXUtility.DisplaySolid_Error(walk,walk:GetAttri("Name") .. " : " ..material(veh))
										CheckReport.AddRelatedObj( walk, walk:GetAttri("Name"));
										CheckReport.AddRelatedObj( veh, veh:GetAttri("Name"));
										CheckReport.AddRelatedObj( drac, drac:GetAttri("Name"));
									else
										if iscovered ~= true then
											iscovered = false
										end
									end
								end)

								grpGratingPed:ForEach(function ( gra )
									if FXClashDetection.IsCollided(node, gra) then
										iscovered = true
										x = x + 1
										slab[x] = walk
										grating[x] = gra
										Drain[x] = drac
									else
										if iscovered ~= true then
											iscovered = false
										end
									end
								end)

								if iscovered == false then
									FXUtility.DisplaySolid_Error(walk,walk:GetAttri("Name") .. " : Grating is not provided.")
									CheckReport.AddRelatedObj( walk, walk:GetAttri("Name"));
					 				CheckReport.AddRelatedObj( drac, drac:GetAttri("Name"));
								end

							end 
						end
					end
				end)
			elseif #grpGratingVeh == 0 and #grpGratingPed == 0 then
				iscompliant = false
				FXUtility.DisplaySolid_Warning(Building,"No Grating provided.")
			end
		else
			iscompliant = false
			FXUtility.DisplaySolid_Warning(Building,"No Drain/Culvert provided.")
		end
	elseif #grpSlabWalk == 0 and #grpSlabDrive == 0 then
		iscompliant = false
		FXUtility.DisplaySolid_Warning(Building,"No Driveway/Sidewalk provided.")
	end
	-- if isnotcol == true then
	-- 	iscompliant = false
	-- 	FXUtility.DisplaySolid_Warning(Building,"No Grating provided.")
	-- end

	if iscompliant == true then
		for i,Ele in pairs(slab) do
			FXUtility.DisplaySolid_Info(Ele,Ele:GetAttri("Name") .. ": " ..material(grating[i]))
			CheckReport.AddRelatedObj( Ele, Ele:GetAttri("Name"));
			CheckReport.AddRelatedObj( grating[i], grating[i]:GetAttri("Name"));
			CheckReport.AddRelatedObj( Drain[i], Drain[i]:GetAttri("Name"));
		end
	end
end





function Type( obj )
	local type = obj:GetAttri("ObjectType")
	return type
end
function material( obj )
	local type = obj:GetAuxAttri("Materials and Finishes.Material")
	return type
end

-- function getWidthLine( obj )
-- 	local stoOBB = FXGeom.GetBoundingOBB(obj);
-- 	local objbox = FXGeom. GetBoundingBox(obj);
-- 	local cntrOBB = stoOBB:GetPos();
-- 	local line
-- 	local i = 1
-- 	local inc = 1
-- 	while (i > 0)do
-- 		if objbox:y_range() > objbox:x_range() then
-- 			line = Line3D(Point3D(cntrOBB.x + inc,cntrOBB.y,cntrOBB.z),Point3D(cntrOBB.x - inc,cntrOBB.y,cntrOBB.z))
-- 			extndNode = FXUtility.CreateNodeFrom(line);
-- 			if(FXClashDetection.IsCollided(extndNode , obj))then
-- 				i = i - 1;
-- 				FXClashDetection.DeleteNode(extndNode);
-- 			end
-- 			FXClashDetection.DeleteNode (extndNode);
--  		else
-- 			line = Line3D(Point3D(cntrOBB.x,cntrOBB.y + inc,cntrOBB.z),Point3D(cntrOBB.x,cntrOBB.y - inc,cntrOBB.z))
-- 			extndNode = FXUtility.CreateNodeFrom(line);
-- 			if(FXClashDetection.IsCollided(extndNode , obj))then
-- 				i = i - 1;
-- 				FXClashDetection.DeleteNode(extndNode);
-- 			end
-- 			FXClashDetection.DeleteNode (extndNode);
-- 		end
-- 		inc = inc + 1
-- 	end
-- 	return line
-- end



