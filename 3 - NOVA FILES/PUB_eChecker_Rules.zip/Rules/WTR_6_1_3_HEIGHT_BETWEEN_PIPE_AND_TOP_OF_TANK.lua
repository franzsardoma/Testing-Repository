-- local ServicePipeGrp = FXGroup.new();
local TankGrp = FXGroup.new();
-- local WindowGrp = FXGroup.new();
local ConditionType;
local ConditionValue;
local ConditionUnit;
local Limit;

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end


function Parser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "WTR_6_1_3_HEIGHT_BETWEEN_PIPE_AND_TOP_OF_TANK");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	ConditionType = tostring(ConditionValues[2]);
	ConditionType = ConditionType:gsub("%s+", "");

	ConditionValue = tonumber(ConditionValues[3]);
	ConditionUnit = tostring(ConditionValues[4]);
	

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- -- print(#GrpObjs)
	if(GrpObjs ~= nil)then		
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				-- ServicePipeGrp =   ServicePipeGrp + v;
				-- ServicePipeGrp = ServicePipeGrp:Unique();
			end	
			if (k == 2) then	
				TankGrp = TankGrp + v;
				TankGrp = TankGrp:Unique();
			end			
		end
	end	
end

function CheckRule(Building)
	print(ConditionType)
		print(ConditionValue)
	print(#TankGrp)
	-- local TankGrp = Building:GetDescendants("FlowStorageDevice");
	local ServicePipeGrp = Building:GetDescendants("FlowSegment");
	local isAllCompliant = true;

	local PipeCompliant = {};
	local PipeDACompliant = {};
	local TankCompliant = {};
	local TankDACompliant = {};
	local DistanceCompliant = {};
	local DiameterCompliant = {};

	if(#TankGrp ~= 0)then 
		TankGrp:ForEach(function(Tank)
			Limit = 10;
			local FilteredPipe = FilterPipe(ServicePipeGrp,Tank);
			
			FilteredPipe:ForEach(function(Pipe)
				local IsOverlap = FXRelation.IsOverlap(Tank, Pipe);
				if(IsOverlap == 1)then 	
					local GrpElements = Pipe:GetConnectedElement();
					local ConnectedElement;
					GrpElements:ForEach(function(Element)
						ConnectedElement = Element;
					end)
					
					local CollidedObject = GetConnectedElementCollidedOnTank(ConnectedElement,Pipe,Tank);
					
					if(CollidedObject ~= nil)then 

						local BoxPipe = FXGeom.GetBoundingBox(Pipe);
						local BoxTank = FXGeom.GetBoundingBox(Tank);
						local PipePoint = Point3D(BoxPipe:LowPos().x, BoxPipe:MidPos().y, BoxPipe:LowPos().z);
						local TopPipePoint = Point3D(BoxPipe:LowPos().x, BoxPipe:MidPos().y, BoxPipe:HighPos().z);
						local PipeDoubleArrow = DoubleArrow(PipePoint,TopPipePoint);

						local TankPoint = Point3D(BoxPipe:LowPos().x, BoxPipe:MidPos().y, BoxTank:HighPos().z);

						local Line = Line3D(PipePoint,TankPoint);
						local Distance = Line:Length();
						local DoubleArrow = DoubleArrow(PipePoint,TankPoint);

						local Diameter = FXUtility.Round(FXPUB.GetDiameter(Pipe),0);
						local TwiceDiameter = Diameter * 2;

						local Condition1 = FXRule.EvaluateNumber(ConditionType,Distance,TwiceDiameter);
						local Condition2 = FXRule.EvaluateNumber(ConditionType,Distance,ConditionValue);
						
						if(Condition1 and Condition2)then
							table.insert(PipeCompliant,Pipe);
							table.insert(PipeDACompliant,PipeDoubleArrow);

							table.insert(TankCompliant,Tank);
							table.insert(TankDACompliant,DoubleArrow);

							table.insert(DiameterCompliant,math.floor(Diameter));
							table.insert(DistanceCompliant,math.floor(Distance));
						else
							isAllCompliant = false;
							if(Condition1)then 
								FXUtility.DisplaySolid_Error(Pipe,"Diameter = "..Diameter.." mm.");
								FXUtility.DisplaySolid_Error(Pipe,"Distance = "..Distance.." mm from "..Tank:GetAuxAttri("Entity.ObjectType")..
									"; is less than minimum height of 150mm.");
							else
								FXUtility.DisplaySolid_Error(Pipe,"Diameter = "..Diameter.." mm.");
								FXUtility.DisplaySolid_Error(Pipe,"Distance = "..Distance.." mm from "..Tank:GetAuxAttri("Entity.ObjectType")..
									"; is smaller than twice the diameter of "..Pipe:GetAuxAttri("Entity.ObjectType")..".");
							end
							CheckReport.AddRelatedGeometry_Error(PipeDoubleArrow);
							CheckReport.AddRelatedGeometry_Error(DoubleArrow);
						end
					end
				end		
			end)
		end)

		if(isAllCompliant)then 
			for i=1, #PipeCompliant do
				if(DistanceCompliant[i] > (DiameterCompliant[i]*2))then 
					FXUtility.DisplaySolid_Info(PipeCompliant[i],"Diameter = "..DiameterCompliant[i].." mm.");
					FXUtility.DisplaySolid_Info(PipeCompliant[i],"Distance = "..DistanceCompliant[i].." mm from "..TankCompliant[i]:GetAuxAttri("Entity.ObjectType")..
						"; is greater than minimum height of 150mm.");
				else
					FXUtility.DisplaySolid_Info(PipeCompliant[i],"Diameter = "..DiameterCompliant[i].." mm.");
					FXUtility.DisplaySolid_Info(PipeCompliant[i],"Distance = "..DistanceCompliant[i].." mm from "..TankCompliant[i]:GetAuxAttri("Entity.ObjectType")..
						"; is equal to twice the diameter of "..PipeCompliant[i]:GetAuxAttri("Entity.ObjectType")..".");
				end
				CheckReport.AddRelatedGeometry_Info(PipeDACompliant[i]);
				CheckReport.AddRelatedGeometry_Info(TankDACompliant[i]);
			end
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Tank is not provided.");
	end
end


function GetConnectedElementCollidedOnTank( ConnectedObj, PreviousObj , Tank)
	if(PreviousObj == nil) then
		return;
	end

	if(Limit < 1)then 
		return;
	end

	Limit = Limit - 1;
	local Collided;
	local grpConnObjs = ConnectedObj:GetConnectedElement();
	grpConnObjs:Sub(PreviousObj);
	grpConnObjs:ForEach(function ( ConnectedElement )
		
		if(FXClashDetection.IsCollided(ConnectedElement,Tank))then
			Collided = ConnectedElement;
		else
			if((FXMeasure.Distance(ConnectedElement,Tank):Length()) <= 3)then 
				Collided = ConnectedElement;
			else
				GetConnectedElementCollidedOnTank( ConnectedElement, ConnectedObj, Tank);
			end
		end
	end)

	if(Collided ~= nil)then 
		return Collided;
	end
end


function FilterPipe(PipeGroup,Tank)
	local Group = FXGroup.new();
	local BuildingStorey = FXUtility.GetStorey(Tank);
	local TankSystemType = Tank:GetAuxAttri("Mechanical.System Type");
	PipeGroup:ForEach(function(Element)
		if(FXUtility.GetStorey(Element):GetAttri("Name") == BuildingStorey:GetAttri("Name"))then
			local ElementSystem =  Element:GetAuxAttri("Mechanical.System Type");
			if(ElementSystem ~= nil)then 
				if(FXUtility.HasPatterInString(TankSystemType,ElementSystem))then 
					Group:Add(Element);
				end
			end
		end
	end)

	return Group;
end

