
--[[ 
	Implemented by: Lemuel B. Echague
	NovaSolutions(Philippines), Inc.
	January 22, 2019
  ]]--



local pipePropTbl = {};
local pipeValTbl = {};


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end


function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_5_3_2_B_II_CUT_OFF_DRAINS_FOR_RETAINING_WALLS")
	-- systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	local bldgGrpObjs = FXRule.filterObjects(parsedXml, Building);
	local tblValues = FXRule.filterTableValues(parsedXml, Building)


	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				wallType = v1["type"];
				wallProp = v1["property"];
				wallValue = v1["value"];
			end	
			if (k == 2) then
				pipeTopProp = v1["property"];
				pipeTopValue = v1["value"];
			end	
			if (k == 3) then
				pipeBotProp = v1["property"];
				pipeBotValue = v1["value"];
			end	

		end
	end

end

function checkRule(Building)


	local retWall = FXGroup:new();
	local compliantWall = FXGroup:new();
	local compliantPipe = FXGroup:new();
	local collidedPipes = FXGroup:new();
	local storey = Building:GetChildren("BuildingStorey")
	local segmentGrp = Building:GetDescendants("FlowSegment");

	storey:ForEach(function(level)
		local wallGrp = level:GetDescendants("Wall");
		wallGrp:ForEach(function(wall)
			if (FXUtility.HasPatterInString(wall:GetAttri(wallProp), wallValue)) then	
				retWall:Add(wall)
				segmentGrp:ForEach(function(segments)
					if FXClashDetection.IsCollided(wall, segments) then	
						collidedPipes:Add(segments) 	
					end
				end)
			end		
		end)
	end)

	if (#retWall == 0) then
		FXUtility.DisplaySolid_Warning(Building, "Retaining Wall is not provided");
	end

	retWall:ForEach(function(wall)
		local topCheck = false
		local botCheck = false
		if #collidedPipes ~= 0 then
			collidedPipes:ForEach(function(drain)
				if #collidedPipes == 2 then		
					if (FXUtility.HasPatterInString(drain:GetAttri(pipeTopProp), pipeTopValue)) then	
						local topDrain = (drain:GetParent()):GetAttri("Name");
						if FXUtility.HasPatterInString(topDrain, "UPPER GROUND") then	
							FXUtility.DisplaySolid_Info(drain, drain:GetAttri("ObjectType") .. " provided.");
						end
					end
					if (FXUtility.HasPatterInString(drain:GetAttri(pipeBotProp), pipeBotValue)) then
						local botDrain = (drain:GetParent()):GetAttri("Name");
						if FXUtility.HasPatterInString(botDrain, "LOWER GROUND") then	
							FXUtility.DisplaySolid_Info(drain, drain:GetAttri("ObjectType") .. " provided.");
						end
					end				
				elseif #collidedPipes == 1 then
					isCompliant = false	
					if not(FXUtility.HasPatterInString(drain:GetAttri(pipeTopProp), pipeTopValue)) then
						FXUtility.DisplaySolid_Error(wall, pipeTopValue .. " is not provided.");
					else
						FXUtility.DisplaySolid_Error(wall, pipeBotValue .. " is not provided.");
					end
				end
			end)
		else 
			FXUtility.DisplaySolid_Error(wall, "Top Cut-off Drains is not provided.");
			FXUtility.DisplaySolid_Error(wall, "Bottom Cut-off Drains is not provided.");
		end		
	end)
end