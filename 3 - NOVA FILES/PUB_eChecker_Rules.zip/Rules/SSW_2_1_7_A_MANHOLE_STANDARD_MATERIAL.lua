local grpManholes = FXGroup:new();
local materialName = {"Precast concrete", "Concrete, precast", "Pre-cast concrete", "Pre cast concrete"};

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_7_A_MANHOLE_STANDARD_MATERIAL")
	
	--local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpManholes = grpManholes + v;
			grpManholes = grpManholes:Unique();
		end
	end
end

function checkRule( Building )

	if #grpManholes == 0 then
		CheckReport.Warning(Building,"Manhole is not provided.")
		return;
	end

	grpManholes:ForEach(function ( ManholeEle )
		local isCircular = false;
		local isPreCastConcrete = false;
		local isCompliant = false;
		local Name  = ManholeEle:GetAttri("Name")

		if (FXMeasure.GetCircularFacesInDirection(ManholeEle, 0)) then
			isCircular = true;
		end

		if (FXUtility.IsBelongToTableAttribute(ManholeEle, materialName, "Material.Layer.1.material")) then
			isPreCastConcrete = true;
		end

		if (isCircular and isPreCastConcrete) then
			isCompliant = true;
		end

		checkResult(ManholeEle, isCompliant, isCircular, isPreCastConcrete, Name)
	end)
end

function checkResult( ManholeEle, isCompliant, isCircular, isPreCastConcrete, Name )
	if isCompliant then
		FXUtility.DisplaySolid_Info(ManholeEle, Name.." is Circular and Pre-cast Concrete material");
	else
		if isCircular then
			FXUtility.DisplaySolid_Error(ManholeEle, Name.." is not Pre-cast concrete");
		elseif isPreCastConcrete then
			FXUtility.DisplaySolid_Error(ManholeEle, Name.." is not Circular");
		else
			FXUtility.DisplaySolid_Error(ManholeEle, Name.." is not Circular and Pre-cast concrete");
		end
	end
end