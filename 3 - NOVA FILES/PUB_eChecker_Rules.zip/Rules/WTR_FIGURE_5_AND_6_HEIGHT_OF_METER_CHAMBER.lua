-- --[[
-- 	Title: WTR_FIGURE_5_AND_6_HEIGHT_OF_METER_CHAMBER
-- 	Developed by:
-- 	Modified by: Wilcelle Tapagñan(Started:1/3/2019;Ended:)
-- ]]--

local WaterMeter = FXGroup.new();
local Valves = FXGroup.new();
local ValvesInMeterChamber = FXGroup.new();
local WaterMeterCheck = false;
local MeterChamberSpace = FXGroup.new();
local MeterChamber = FXGroup.new();
local MeterObject;
local operator;
local maxHeight;
local ConnectedWallsGroup;
-- local wah = FXGroup.new()
-- local systemTypes

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("System");
	CheckEngine.BindCheckFunc("GetSystem");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "WTR_FIGURE_5_AND_6_HEIGHT_OF_METER_CHAMBER");
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
 --   	local GrpObjs2 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);

	operator = ConditionValues[2];
	maxHeight = tonumber(ConditionValues[3]);

	if ( GrpObjs ~= 0 ) then	
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				MeterChamber =  MeterChamber + v;
				MeterChamber = MeterChamber:Unique();
			end
		end	
	end
	-- if ( GrpObjs2 ~= 0 ) then	
	-- 	for k,v in pairs(GrpObjs) do
	-- 		if (k == 3) then
	-- 			wah =  wah + v
	-- 			wah = wah:Unique();
	-- 		end
	-- 	end	
	-- end
end

function CheckRule(Building)

	local WaterMeterObject = true;
	local metchamArr = {};
	local conWall = {};
	local metchamTbl;
	local conTbl = FXGroup.new();
	local arrowGeom;
	local polyline;
	local SpaceHeight;
	local valveChamber = FXGroup.new()

	if CheckWarning(Building) then
		
		local grpSpace = Building:GetDescendants("Space");

		grpSpace:ForEach(function( spaceEle )
			if ( FXUtility.HasPatterInString(spaceEle:GetAuxAttri("Entity.LongName"),"Valve Chamber") == true ) then
				valveChamber:Add(spaceEle)
			end
		end)

		if CheckWarningChamber2(valveChamber,Building) then

			MeterChamber:ForEach(function(MeterElement)

				WaterMeter:ForEach(function(WaterMeterObject)
					if ( FXClashDetection.IsCollided(MeterElement,WaterMeterObject) ) == true then
						WaterMeterCheck = true;
						MeterChamberSpace:Add(MeterElement);
						MeterObject = WaterMeterObject;
					end
				end)

				Valves:ForEach(function(ValvesObject)
					if ( FXClashDetection.IsCollided(MeterElement,ValvesObject) ) == true then
						ValvesInMeterChamber:Add(ValvesObject);
					end
				end)
			end)

			MeterChamberSpace:ForEach(function( metchamspaEle )
				if CheckWarningValve(ValvesInMeterChamber,Building,metchamspaEle) then
					if WaterMeterCheck then

						local ConnectedWallsGroup = metchamspaEle:GetConnectedWall();		
						local SpaceOBB = FXGeom.GetBoundingOBB(metchamspaEle);
						local SpaceBox = FXGeom.GetBoundingBox(metchamspaEle);
						SpaceHeight = SpaceOBB:MaxPnt().z;
						local Point1 = Point3D(SpaceOBB:MaxPnt().x,SpaceOBB:MaxPnt().y,SpaceBox:HighPos().z);
						local Point2 = Point3D(SpaceOBB:MaxPnt().x,SpaceOBB:MaxPnt().y,SpaceBox:LowPos().z);;

						-- SpaceHeight

						local Line = Line3D(Point1,Point2);
						local Pnt1, Pnt2;
						local Spaceyrange = SpaceBox:y_range();
						local Spacexrange = SpaceBox:x_range();

						if(Spaceyrange > Spacexrange)then
							if(Line:GetStartPoint().y > 0)then
								Pnt1 = Point3D(Line:GetStartPoint().x,SpaceBox:HighPos().y+200,Line:GetStartPoint().z);
								Pnt2 = Point3D(Line:GetEndPoint().x,SpaceBox:HighPos().y+200,Line:GetEndPoint().z);
							else
								Pnt1 = Point3D(Line:GetStartPoint().x,SpaceBox:LowPos().y-200,Line:GetStartPoint().z);
								Pnt2 = Point3D(Line:GetEndPoint().x,SpaceBox:LowPos().y-200,Line:GetEndPoint().z);
							end
						else
							if(Line:GetStartPoint().x > 0)then
								Pnt1 = Point3D(SpaceBox:HighPos().x+200,Line:GetStartPoint().y,Line:GetStartPoint().z);
								Pnt2 = Point3D(SpaceBox:HighPos().x+200,Line:GetEndPoint().y,Line:GetEndPoint().z);
							else
								Pnt1 = Point3D(SpaceBox:LowPos().x-200,Line:GetStartPoint().y,Line:GetStartPoint().z);
								Pnt2 = Point3D(SpaceBox:LowPos().x-200,Line:GetEndPoint().y,Line:GetEndPoint().z);
							end
						end

						arrowGeom = DoubleArrow(Pnt1, Pnt2);
						polyline = PolyLine3D(TRUE);
						polyline:AddPoint(Line:GetStartPoint());
						polyline:AddPoint(Pnt1);

						if ( FXRule.EvaluateNumber(operator, SpaceHeight, maxHeight) ) == true then

							isCompliant = true;
							metchamTbl = metchamspaEle;				 
						else

							isCompliant = false;
							DisplayErrorResult(isCompliant,metchamspaEle,SpaceHeight,arrowGeom,polyline,MeterObject,ConnectedWallsGroup);
						end

						ConnectedWallsGroup:ForEach(function(WallObject)
							conTbl:Add(WallObject);
						end)
					else
						FXUtility.DisplaySolid_Error(Building,"Water Meter is not provided.");	
					end
				end
			end)

			if isCompliant then

				table.insert(metchamArr,metchamTbl);
				table.insert(conWall,conTbl);
			end
			
			if isCompliant then

				for k=1, #metchamArr do

					FXUtility.DisplaySolid_Info(metchamArr[k],SpaceHeight.."mm",arrowGeom);
					CheckReport.AddRelatedGeometry_Solid(polyline);
					
					conWall[k]:ForEach(function(conEle)
						CheckReport.AddRelatedObj(conEle,conEle:GetAttri("Name"));	
					end)
					CheckReport.AddRelatedObj(MeterObject,MeterObject:GetAttri("Name"));
				end
			end
		end
	end
end

function CheckWarning(Building)
	local Warning = true;

	if (#MeterChamber == 0) then

		FXUtility.DisplaySolid_Warning(Building, "Meter Chamber is not provided");
		Warning = false;
	end

	return Warning;
end

function CheckWarningValve(ValvesInMeterChamber,Building,metchamspaEle)
	local Warning = true;

	if (#ValvesInMeterChamber > 0) then
		
		FXUtility.DisplaySolid_Warning(metchamspaEle,"There are valves inside Meter Chamber.");
		
		ValvesInMeterChamber:ForEach(function(ValvePresent) 
			CheckReport.AddRelatedObj(ValvePresent,ValvePresent:GetAttri("Name"));
		end)	
		Warning = false;
	end

	return Warning;
end

function CheckWarningChamber2(valveChamber,Building)
	local Warning = true;

	if (#valveChamber == 0) then
		
		FXUtility.DisplaySolid_Warning(Building,"Separated underground Valve Chamber is not provided.");			
		Warning = false;
	end

	return Warning;
end

function DisplayErrorResult(isCompliant,metchamspaEle,SpaceHeight,arrowGeom,polyline,MeterObject,ConnectedWallsGroup)

	if isCompliant == false then
		FXUtility.DisplaySolid_Error(metchamspaEle,SpaceHeight.."mm",arrowGeom);
		CheckReport.AddRelatedGeometry_Error(polyline);
	end

	ConnectedWallsGroup:ForEach(function(WallObject)
		CheckReport.AddRelatedObj(WallObject,WallObject:GetAttri("Name"));	
	end)
	CheckReport.AddRelatedObj(MeterObject,MeterObject:GetAttri("Name"));
end

function GetSystem(System)
	local FlowControllerGroup = System:GetDescendants("FlowController");
	FlowControllerGroup:ForEach(function(FlowControllerElement);
		if(FXUtility.HasPatterInString(FlowControllerElement:GetAttri("Name"),"Water Meter") == true or FXUtility.HasPatterInString(FlowControllerElement:GetAttri("Name"),"Water_Meter") == true)then 
			WaterMeter:Add(FlowControllerElement);
		else 
			Valves:Add(FlowControllerElement);
		end
	end)
end

