local GrpDrain = FXGroup.new();
local GrpSlope = FXGroup.new();
local GrpSpace = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_4_2_4_PROVISION_OF_DRAINAGE_SYSTEM")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			GrpDrain = GrpDrain + v;
			GrpDrain = GrpDrain:Unique();
		end
		if (k == 3) then
			GrpSlope = GrpSlope + v;
			GrpSlope = GrpSlope:Unique();
		end

		if (k == 4) then
			GrpSpace = GrpSpace + v;
			GrpSpace = GrpSpace:Unique();
		end
	end
end

function CheckRule( Building )
	-- print(#GrpDrain.." Drain ")
	-- print(#GrpSlope.." Slope ")
	-- print(#GrpSpace.." Space ")
	local Property_A, Elevation_A, Elevation_B, HighestElevation, H_Space, L_Space, LongLineNode1;
	local DRAIN = {};
	local flag = true;

	if(#GrpSlope ~= 0)then
		GrpSpace:ForEach(function ( Property_B )
			if(Property_A == nil)then
				Property_A = Property_B
			else
				if(Property_A.Id ~= Property_B.Id)then
					Elevation_A = FXGeom.GetBoundingBox(Property_A):LowPos().z
					Elevation_B = FXGeom.GetBoundingBox(Property_B):LowPos().z

					if(Elevation_A ~= Elevation_B)then
						if(Elevation_A > Elevation_B)then
							if(HighestElevation == nil or Elevation_A > HighestElevation)then
								HighestElevation = Elevation_A;
								H_Space = Property_A;
								L_Space = Property_B;
							end
						else
							if(HighestElevation == nil or Elevation_B > HighestElevation)then
								HighestElevation = Elevation_B;
								H_Space = Property_B;
								L_Space = Property_A;
							end
						end
					end
				end
			end		
		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Slope is not provided.")
	end

	if(#GrpDrain ~= 0)then
		GrpDrain:ForEach(function ( drain )
			local box = FXGeom.GetBoundingBox(drain):HighPos().z
			local lim = Elevation_B - box;
			local prj = FXMeasure.GetObjProjection(drain, box);
			local otr = FXMeasure.GetOuterEdge(prj);
			local fac = otr:Face3D();
			local ext = fac:ExtrudedFace(Vector(0, 0, lim));
			local nod = FXUtility.CreateNodeFrom(ext);

			local ShortLine = GetShortLine(otr);
			local XtndLine2 = FXGFA.ShrinkageLine(ShortLine,-3000);
			local Pataba = FXMeasure.CreateFaceFromEdge(XtndLine2, 1);
			local ShortLineNode2 = FXUtility.CreateNodeFrom(Pataba);
			
			if(FXClashDetection.IsCollided(H_Space, nod))then
				GrpSlope:ForEach(function ( SlopeSlab )
					if(FXClashDetection.IsCollided(ShortLineNode2, SlopeSlab))then
						table.insert(DRAIN, drain);
						flag = true;
					end
				end)
			end
		end)
	else
		flag = false;
		FXUtility.DisplaySolid_Error(H_Space, "Drainage system is not provided along boundary of Property B");
	end

	if(flag)then
		for i = 1, #DRAIN do
			FXUtility.DisplaySolid_Info(DRAIN[i], "Drainage system is provided along boundary of Property B.")
		end
	end
	-- if(flag)then
	-- 	GrpDrain:ForEach(function ( d )
	-- 		FXUtility.DisplaySolid_Info(d, "Drainage system is provided along boundary of Property B.")
	-- 	end)
	-- end
	
end
-- to Get the smalles line of Drain projection --
function GetShortLine( route )
	local PolyLinePointNumber = route:GetPointNumber();
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = route:GetPoint(i)
		local Point2 = route:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end