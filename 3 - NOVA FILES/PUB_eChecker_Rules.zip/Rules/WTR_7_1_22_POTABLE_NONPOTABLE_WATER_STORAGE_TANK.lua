-- Parse --
local GrpOutletPipe = FXGroup.new();
local GrpTank1 = FXGroup.new(); -- FlowStorageDevice --
local GrpWall = FXGroup.new();
local GrpTank2 = FXGroup.new(); -- Space --

-- Local --
local GrpPipe_P = FXGroup.new(); -- Potable Pipe --
local GrpPipe_N = FXGroup.new(); -- Non-Potable Pipe --
local GrpSpace_P = FXGroup.new(); -- Potable Space --
local GrpSpace_N = FXGroup.new(); -- Non-Potable Space --
local GrpWall_P = FXGroup.new(); -- Potable Wall --
local GrpWall_N = FXGroup.new(); -- Non-Potable Wall --

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("System");
	CheckEngine.BindCheckFunc("CheckSystem");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser( Building )
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_22_POTABLE_NONPOTABLE_WATER_STORAGE_TANK")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			GrpOutletPipe = GrpOutletPipe + v;
			GrpOutletPipe = GrpOutletPipe:Unique();
		end
		if (k == 3) then
			GrpTank1 = GrpTank1 + v;
			GrpTank1 = GrpTank1:Unique();
		end
		if (k == 4) then
			GrpWall = GrpWall + v;
			GrpWall = GrpWall:Unique();
		end
		if (k == 5) then
			GrpTank2 = GrpTank2 + v;
			GrpTank2 = GrpTank2:Unique();
		end
	end
end

function CheckSystem( System )
	local flowSegment = System:GetDescendants("FlowSegment")
	local Potable = {"Domestic Cold Water","Domestic Hot Water"}
	local NonPotable = {"Other", "Sanitary", "Sewerage", "Hydronic", "Fire Protection"}
	
	flowSegment:ForEach(function ( pipe )
		if(SystemType(pipe, Potable))then
			GrpPipe_P:Add(pipe)

		elseif(SystemType(pipe, NonPotable))then
			GrpPipe_N:Add(pipe)
		end
	end)
end

function CheckRule( Building )
	local GrpPartition = FXGroup.new();
	local COMPLIANT = true;
	local SameWall, Space_P, Space_N, Space_Tank

	if(#GrpTank1 ~= 0 or #GrpTank2 ~= 0)then
		--( Check the Space if connected to Potable or Non-Potable Pipe)--
		GrpTank2:ForEach(function ( space )
			local BottomFace = FXMeasure.GetBottomFace(space);
			local Box = FXGeom.GetBoundingBox(space);
			local ExtrudeFace = BottomFace:ExtrudedFace(Vector(0,0,Box:HighPos().z - Box:LowPos().z));
			local Node = FXUtility.CreateNodeFrom(ExtrudeFace);
			Space_Tank = space;

			GrpPipe_P:ForEach(function ( P_Pipe )
				if (FXClashDetection.IsCollided(Node, P_Pipe)) then
					GrpSpace_P:Add(space)
				end
			end)
			GrpPipe_N:ForEach(function ( N_Pipe )
				if (FXClashDetection.IsCollided(Node, N_Pipe)) then
					GrpSpace_N:Add(space)
				end
			end)
		end)
		--( Space Connected to Wall )--
		if(#GrpSpace_P ~= 0 and GrpSpace_N ~= 0)then
			GrpSpace_P:ForEach(function ( SpaceTank )
				GrpWall_P = SpaceTank:GetConnectedWall();
				Space_P = SpaceTank;
			end)
			GrpSpace_N:ForEach(function ( SpaceTank )
				GrpWall_N = SpaceTank:GetConnectedWall();
				Space_N = SpaceTank;
			end)
		end

		GrpWall_P:ForEach(function ( Wall_P )
			GrpWall_N:ForEach(function ( Wall_N )
				COMPLIANT = true;
				if(Wall_P.Id == Wall_N.Id)then
					GrpPartition:Add(Wall_N);
					SameWall = Wall_N;
				end
			end)
		end)

		if(#GrpPartition ~= 0)then
			GrpTank2:ForEach(function ( space )
				FXUtility.DisplaySolid_Error(space, "Common wall(s) is provided between potable and non-potable storage tanks.");
				CheckReport.AddRelatedObj(SameWall, SameWall:GetAttri("Name"));
			end)
		elseif(COMPLIANT)then
			GrpTank2:ForEach(function ( space )
				FXUtility.DisplaySolid_Info(space, "Common wall(s) is not provided between potable and non-potable storage tanks.");
			end)
		end

		-- Checking for Tank Object --
		GrpTank1:ForEach(function ( TANK )
			local Array_Point = {}
			local box = FXGeom.GetBoundingBox(TANK);
			local tankMidPoint = box:MidPos();
			local tankXMax = box:HighPos().x;
			local tankYMax = box:HighPos().y;
			local tankXMin = box:LowPos().x;
			local tankYMin = box:LowPos().y;
			local tankMidPoint1 = Point3D(tankXMax - 300, tankYMax - 300, tankMidPoint.z);
			local tankMidPoint2 = Point3D(tankXMin + 300, tankYMax - 300, tankMidPoint.z);
			local tankMidPoint3 = Point3D(tankXMin + 300, tankYMin + 300, tankMidPoint.z);
			local tankMidPoint4 = Point3D(tankXMax - 300, tankYMin + 300, tankMidPoint.z);
			local pnt;

			table.insert(Array_Point, tankMidPoint1)
			table.insert(Array_Point, tankMidPoint2)
			table.insert(Array_Point, tankMidPoint3)
			table.insert(Array_Point, tankMidPoint4)

			for k,point in pairs(Array_Point) do
				local node1 = FXUtility.CreateNodeFrom(point);
				if (FXClashDetection.IsCollided(TANK, node1) == false) then
					pnt = point
					FXClashDetection.DeleteNode ( node1 );
					break;
				end
				FXClashDetection.DeleteNode ( node1 );
			end

			if pnt ~= nil then
				local line
				local pnt2 = pnt
				local limit = box:HighPos().z - box:LowPos().z;
				local ctr = 0;
				local ctr2 = 0;
				while ctr ~= limit do 			
					pnt2 = pnt2:Add_Vec(Vector(0,0,-100))
					line = Line3D(pnt, pnt2)
					local extendedNode = FXUtility.CreateNodeFrom(line);

					if FXClashDetection.IsCollided ( TANK , extendedNode ) then
						FXClashDetection.DeleteNode ( extendedNode );
						pnt2 = pnt2:Add_Vec(Vector(0,0,100))
						break;				
					end
					ctr = ctr + 1;
					FXClashDetection.DeleteNode ( extendedNode ); 
				end
				
				local pnt3 = pnt

				while ctr2 ~= limit do 			
					pnt3 = pnt3:Add_Vec(Vector(0,0,100))
					line = Line3D(pnt, pnt3)
					local extendedNode = FXUtility.CreateNodeFrom(line);

					if FXClashDetection.IsCollided ( TANK , extendedNode ) then
						FXClashDetection.DeleteNode ( extendedNode );
						pnt3 = pnt3:Add_Vec(Vector(0,0,-100))
						break;				
					end
					ctr2 = ctr2 + 1;
					FXClashDetection.DeleteNode ( extendedNode ); 
				end

				local Ztopvalue = pnt3.z - pnt2.z

				tankMidPoint1 = Point3D( tankMidPoint1.x, tankMidPoint1.y, pnt2.z)
				tankMidPoint2 = Point3D( tankMidPoint2.x, tankMidPoint2.y, pnt2.z)
				tankMidPoint3 = Point3D( tankMidPoint3.x, tankMidPoint3.y, pnt2.z)
				tankMidPoint4 = Point3D( tankMidPoint4.x, tankMidPoint4.y, pnt2.z)

				local PlyLine  = PolyLine3D(TRUE);

				PlyLine:AddPoint(tankMidPoint1);
				PlyLine:AddPoint(tankMidPoint2);
				PlyLine:AddPoint(tankMidPoint3);
				PlyLine:AddPoint(tankMidPoint4);
				PlyLine:ClosePolyline();

				local faceA = PlyLine:Face3D();
				local extrude = faceA:ExtrudedFace(Vector(0, 0, Ztopvalue));
				local extrudeNode = FXUtility.CreateNodeFrom(extrude);
				local IfCompliant2 = true;

				if(FXClashDetection.IsCollided(TANK, extrudeNode))then
					IfCompliant2 = false;
					FXUtility.DisplaySolid_Error(TANK, "Common wall(s) is provided between potable and non-potable storage tanks.")
				end

				if(IfCompliant2)then
					FXUtility.DisplaySolid_Info(TANK, "Common wall(s) is not provided between potable and non-potable storage tanks.")
				end
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Tank Room is not provided.")
	end

end

function SystemType(Element, Table)
	local  flag = false;
	local  material = Element:GetAuxAttri("Mechanical.System Name")
	if material ~= nil then
		for i=1,#Table do
			if(FXUtility.HasPatterInString(material, Table[i])) then 
				flag = true
				break
			end 
		end
	end
	return flag
end