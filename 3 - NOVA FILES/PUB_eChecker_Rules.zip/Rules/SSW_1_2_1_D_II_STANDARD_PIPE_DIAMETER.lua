local grpManholeAndInspectionChamber		= FXGroup.new();
local grpPublicSewer 		    			= FXGroup.new();
local grpMinorSewer							= FXGroup.new();
local grpConnectingSewer					= FXGroup.new();
local grpManhole    	   	   			    = FXGroup.new();
local grpRaisedAndYJunction					= FXGroup.new();
local fittingTypes = {}

local isErrorFound = false
local x = 0 
local comPublicArr = {}
local comPublicDiamArr = {}
local comConnectingArr = {}
local comConnectingDiamArr = {}
local x1 = 0
local comMinorArr = {}
local comMinorDiamArr = {}
local x2 = 0
local x3 = 0 	

function main()
	CheckEngine.SetCheckType    ("Building")
	CheckEngine.BindCheckFunc   ("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc   ("YandRaisedJunction");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("manhole");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType	("Building");
	CheckEngine.BindCheckFunc	("DisplayWarning");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	--minWidth
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_1_D_II_STANDARD_PIPE_DIAMETER")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml,Building)
	
	ifOperator1 = ConditionValues1[3]
	isLessThan = tonumber(ConditionValues1[4])
	thenIsEqualTo = ConditionValues1[7]

	ifOperator2 = ConditionValues1[10]
	isGreaterAndEqualTo = tonumber(ConditionValues1[11])
	thenIsEqualTo2 = ConditionValues1[14]
	thenIsEqualToThis = tonumber(ConditionValues1[15])


	conSewerParam = ConditionValues2[3]
	conSewerVal = tonumber(ConditionValues2[4])


	minorSewerParam = ConditionValues3[3]
	minorSewerVal = tonumber(ConditionValues3[4])

	for k,v in pairs(tblValues) do    
		for k1,v1 in pairs(v) do
			table.insert( fittingTypes , v1["value"] )
		end
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 2 ) then
			grpRaisedAndYJunction = grpRaisedAndYJunction + v
			grpRaisedAndYJunction = grpRaisedAndYJunction:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 3 ) then
			grpManhole = grpManhole + v
			grpManhole = grpManhole:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 4 ) then
			grpPublicSewer = grpPublicSewer + v
			grpPublicSewer = grpPublicSewer:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 5 ) then
			grpConnectingSewer = grpConnectingSewer + v
			grpConnectingSewer = grpConnectingSewer:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 6 ) then
			grpMinorSewer = grpMinorSewer + v
			grpMinorSewer = grpMinorSewer:Unique()
		end
	end

	for k,v in pairs(GrpObjs) do -- Checking in System
		if ( k == 7 ) then
			grpManholeAndInspectionChamber = grpManholeAndInspectionChamber + v
			grpManholeAndInspectionChamber = grpManholeAndInspectionChamber:Unique()
		end
	end
end


function YandRaisedJunction( Building )

	print (#grpRaisedAndYJunction .." - "..#grpManhole.." - "..#grpPublicSewer.." - "..#grpConnectingSewer.." - "..#grpMinorSewer.." - "..#grpManholeAndInspectionChamber.." - "..#grpManholeAndInspectionChamber)

	if #grpRaisedAndYJunction == 0 then
		return
	end

	if #grpManholeAndInspectionChamber == 0 then
		return
	end

	if #grpConnectingSewer 			   == 0 then
		return
	end

	if #grpMinorSewer 				   == 0 then 
		return
	end

	if #grpPublicSewer				   == 0 then
		return
	end	

	local grpLastInspectionChamberOrManhole = FXGroup.new();
	grpManholeAndInspectionChamber:ForEach(function ( chamberObj )

		grpMinorSewer:ForEach (function ( minorSewerObj )

			grpConnectingSewer:ForEach (function ( connectingSewerObj )
				if CheckConnectedChamberElement( chamberObj:GetParent() , chamberObj , minorSewerObj ) and 
				   CheckConnectedChamberElement( chamberObj:GetParent() , chamberObj , connectingSewerObj ) then -- This is the Last InspectionChamber

				   	grpLastInspectionChamberOrManhole:Add ( chamberObj )
				end	
			end)				
		end)
	end)


	grpLastInspectionChamberOrManhole:ForEach (function ( chamberObj )
		local publicSewerDiameter
		local pubSewerObj
		grpConnectingSewer:ForEach (function ( connectingSewerObj )
			local isConnectedToYJunction 	  = false
			local isConnectedToRaisedJunction = false
			local connectingSewerDiameter
			
			if CheckConnectedChamberElement( Building , chamberObj , connectingSewerObj ) then 
				
				grpRaisedAndYJunction:ForEach (function ( raisedAndYobj )

					local lastObj,count = FXPUB.GetConnectedObj( connectingSewerObj , "FlowFitting" , "GlobalId" , raisedAndYobj:GetAttri("GlobalId") , 13 )

					if lastObj ~= nil then					
						grpPublicSewer:ForEach(function ( publicSewerObj )
							
							if FXClashDetection.IsCollided( lastObj , publicSewerObj ) then	 -----------------------------------
								local raisedOrYAttri = lastObj:GetAuxAttri("Entity.ObjectType")
								
								if FXUtility.HasPatterInString( raisedOrYAttri ,fittingTypes[2]) then

									isConnectedToYJunction = true
									pubSewerObj = publicSewerObj
			   						connectingSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( connectingSewerObj ) ,0) 
			   						publicSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( publicSewerObj ) ,0) 
		
			   					elseif FXUtility.HasPatterInString( raisedOrYAttri ,fittingTypes[1]) then
			   						isConnectedToRaisedJunction = true
			   						pubSewerObj = publicSewerObj
			   						-- print ("i did it")
			   						connectingSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( connectingSewerObj ) ,0) 
			   						publicSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( publicSewerObj ) ,0) 
			   					else
			   						FXUtility.DisplaySolid_Warning ( Building ,"Connecting Sewer is not connected to junction connections.")
			   					end
							end
						end)
					end
			   	end)

				local ifPublicSewerIsLessThan200 = FXRule.EvaluateNumber( ifOperator1 , publicSewerDiameter , isLessThan  )
				local isConnectingSewerEqualToPublicSewerDiameter = FXRule.EvaluateNumber( thenIsEqualTo , connectingSewerDiameter , publicSewerDiameter )
				
				local isPublicSewerIsGreaterThan200 = FXRule.EvaluateNumber( ifOperator2  , publicSewerDiameter , isGreaterAndEqualTo )
				local thenConnectingSewerEqual200 = FXRule.EvaluateNumber( thenIsEqualTo2   , connectingSewerDiameter , thenIsEqualToThis )

				if isConnectedToYJunction then					
					if ifPublicSewerIsLessThan200 and isConnectingSewerEqualToPublicSewerDiameter then
						x = x + 1
						comConnectingArr[x] = connectingSewerObj
						comConnectingDiamArr[x] = connectingSewerDiameter
						comPublicArr[x] = pubSewerObj
						comPublicDiamArr[x] = publicSewerDiameter
					elseif isPublicSewerIsGreaterThan200 and thenConnectingSewerEqual200 then
						x = x + 1
						comConnectingArr[x] = connectingSewerObj
						comConnectingDiamArr[x] = connectingSewerDiameter
						comPublicArr[x] = pubSewerObj
						comPublicDiamArr[x] = publicSewerDiameter
					elseif isPublicSewerIsGreaterThan200 and thenConnectingSewerEqual200 == false then
						FXUtility.DisplaySolid_Error ( connectingSewerObj , connectingSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..connectingSewerDiameter.." mm is greater than "..thenIsEqualToThis.." mm")
						CheckReport.AddRelatedObj( connectingSewerObj, connectingSewerObj:GetAuxAttri("Entity.ObjectType"))
						isErrorFound = true
					else
						FXUtility.DisplaySolid_Error ( connectingSewerObj ,pubSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..publicSewerDiameter.." mm;"..connectingSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..connectingSewerDiameter.." mm")
						CheckReport.AddRelatedObj( connectingSewerObj, connectingSewerObj:GetAuxAttri("Entity.ObjectType"))
						isErrorFound = true
					end		
				
				elseif isConnectedToRaisedJunction then
					
					if ifPublicSewerIsLessThan200 and isConnectingSewerEqualToPublicSewerDiameter then
						x = x + 1
						comConnectingArr[x] = connectingSewerObj
						comConnectingDiamArr[x] = connectingSewerDiameter
						comPublicArr[x] = pubSewerObj
						comPublicDiamArr[x] = publicSewerDiameter
					elseif isPublicSewerIsGreaterThan200 and thenConnectingSewerEqual200 then
						x = x + 1
						comConnectingArr[x] = connectingSewerObj
						comConnectingDiamArr[x] = connectingSewerDiameter
						comPublicArr[x] = pubSewerObj
						comPublicDiamArr[x] = publicSewerDiameter
					elseif isPublicSewerIsGreaterThan200 and thenConnectingSewerEqual200 == false then
						FXUtility.DisplaySolid_Error ( connectingSewerObj , connectingSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..connectingSewerDiameter.." mm is greater than "..thenIsEqualToThis.." mm")
						CheckReport.AddRelatedObj( connectingSewerObj, connectingSewerObj:GetAuxAttri("Entity.ObjectType"))
						isErrorFound = true
					else
						FXUtility.DisplaySolid_Error ( connectingSewerObj ,pubSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..publicSewerDiameter.." mm;"..connectingSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..connectingSewerDiameter.." mm")
						CheckReport.AddRelatedObj( connectingSewerObj, connectingSewerObj:GetAuxAttri("Entity.ObjectType"))
						isErrorFound = true
					end		
				end	
			end	
		end)
	
		grpMinorSewer:ForEach (function ( minorSewerObj )

			if CheckConnectedChamberElement( Building , chamberObj , minorSewerObj ) then
				local minorSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( minorSewerObj ) ,0) 
				local isMinorDiamGreaterThan200 = FXRule.EvaluateNumber( minorSewerParam  , minorSewerDiameter , minorSewerVal )

				if isMinorDiamGreaterThan200 then
					x1 = x1 + 1
					comMinorArr[x1] = minorSewerObj
					comMinorDiamArr[x1] = minorSewerDiameter
				elseif isMinorDiamGreaterThan200 == false then
					FXUtility.DisplaySolid_Error ( minorSewerObj ,minorSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..minorSewerDiameter.." mm is less than "..minorSewerVal.."mm")
					CheckReport.AddRelatedObj(minorSewerObj, minorSewerObj:GetAuxAttri("Entity.ObjectType"))
					isErrorFound = true
				end
			end
		end)
	end)
end


function manhole( Building )
	if #grpManhole 				       == 0 then
		return
	end

	if #grpManholeAndInspectionChamber == 0 then
		return
	end

	if #grpConnectingSewer 			   == 0 then
		return
	end

	if #grpMinorSewer 				   == 0 then 
		return
	end

	if #grpPublicSewer 				   == 0 then
		return
	end

	local grpLastInspectionChamberOrManhole = FXGroup.new();
	grpManholeAndInspectionChamber:ForEach(function ( chamberObj )

		grpMinorSewer:ForEach (function ( minorSewerObj )

			grpConnectingSewer:ForEach (function ( connectingSewerObj )
				if CheckConnectedChamberElement( Building , chamberObj , minorSewerObj ) and 
				   CheckConnectedChamberElement( Building , chamberObj , connectingSewerObj ) then 
				   	grpLastInspectionChamberOrManhole:Add ( chamberObj )
				end	
			end)				
		end)
	end)

	grpLastInspectionChamberOrManhole:ForEach (function ( chamberObj )
		local publicSewerDiameter
		local pubSewerObj 

		grpConnectingSewer:ForEach (function ( connectingSewerObj )
			-- local connectingSewerDiameter = tonumber(connectingSewerObj:GetAuxAttri("Mechanical.Diameter") ) 	
			local connectingSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( connectingSewerObj ) ,0) 
			local isConnectedToManhole

			if 	CheckConnectedChamberElement( Building , chamberObj , connectingSewerObj ) then
				grpManhole:ForEach(function ( manholeObj )
					
					if CheckConnectedChamberElement( Building , manholeObj , connectingSewerObj ) then
						grpPublicSewer:ForEach(function ( publicSewerObj )

							if CheckConnectedChamberElement( Building , manholeObj , publicSewerObj ) then
								isConnectedToManhole = true
								-- publicSewerDiameter = tonumber(publicSewerObj:GetAuxAttri("Mechanical.Diameter") ) 
								publicSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( publicSewerObj ) ,0) 
								pubSewerObj = publicSewerObj
							end
						end)
					else
						FXUtility.DisplaySolid_Warning ( Building ,"Connecting Sewer is not connected to junction connections.")
					end
				end)
			end

			connectingSewerDiameter = tonumber(FXUtility.Round( connectingSewerDiameter , 0  ))
			conSewerVal = tonumber(FXUtility.Round( conSewerVal , 0 ))

			if isConnectedToManhole then
				local isConnectingSewerGreaterThan200 = FXRule.EvaluateNumber( conSewerParam , connectingSewerDiameter , conSewerVal )
				print ( conSewerParam)
				print ( connectingSewerDiameter)
				print ( conSewerVal)
				if isConnectingSewerGreaterThan200 then
					x = x + 1
					comConnectingArr[x] = connectingSewerObj
					comConnectingDiamArr[x] = connectingSewerDiameter
					comPublicArr[x] = pubSewerObj
					comPublicDiamArr[x] = publicSewerDiameter
				elseif isConnectingSewerGreaterThan200 == false then
					FXUtility.DisplaySolid_Error ( connectingSewerObj ,pubSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..publicSewerDiameter.." mm;"..connectingSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..connectingSewerDiameter.." mm")
					CheckReport.AddRelatedObj( connectingSewerObj, connectingSewerObj:GetAuxAttri("Entity.ObjectType"))		
					isErrorFound = true			
				end
			end
		end)


		grpMinorSewer:ForEach (function ( minorSewerObj )
			if CheckConnectedChamberElement( Building , chamberObj , minorSewerObj ) then
				-- local minorSewerDiameter = tonumber(minorSewerObj:GetAuxAttri("Mechanical.Diameter") ) 
				local minorSewerDiameter = FXUtility.Round( FXPUB.GetDiameter ( minorSewerObj ) ,0)  

				local isMinorDiamGreaterThan200 = FXRule.EvaluateNumber( minorSewerParam  , minorSewerDiameter , minorSewerVal )

				if isMinorDiamGreaterThan200 then
					x1 = x1 + 1
					comMinorArr[x1] = minorSewerObj
					comMinorDiamArr[x1] = minorSewerDiameter

				elseif isMinorDiamGreaterThan200 == false then
					FXUtility.DisplaySolid_Error ( minorSewerObj ,minorSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..minorSewerDiameter.." mm is less than "..minorSewerVal.."mm")
					CheckReport.AddRelatedObj(minorSewerObj, minorSewerObj:GetAuxAttri("Entity.ObjectType"))
					isErrorFound = true
				end
			end
		end)
	end)
end


function DisplayWarning( Building )
	if #grpConnectingSewer			   == 0 then
		FXUtility.DisplaySolid_Warning ( Building ,"Connection sewer is not provided.")
	end

	if #grpPublicSewer 				   == 0 then
		FXUtility.DisplaySolid_Warning ( Building ,"Public sewer is not provided.")
	end

	if #grpManholeAndInspectionChamber == 0 then
		FXUtility.DisplaySolid_Warning ( Building ,"Last manhole/Last inspection chamber is not provided.")
	end

	if #grpRaisedAndYJunction == 0 and #grpManhole == 0 then
		FXUtility.DisplaySolid_Warning ( Building ,"Junction connection is not provided.")
	end

	if #grpMinorSewer				   == 0 then
		FXUtility.DisplaySolid_Warning ( Building ,"Minor sewer is not provided.")
	end

	if isErrorFound == false then
		local y = 1
		local y1 = 1
	

		while y ~= x + 1 do
			FXUtility.DisplaySolid_Info ( comConnectingArr[y] ,comPublicArr[y]:GetAuxAttri("Entity.ObjectType")..": Diameter = "..comPublicDiamArr[y].." mm;"..comPublicArr[y]:GetAuxAttri("Entity.ObjectType")..": Diameter = "..comConnectingDiamArr[y].." mm")
			CheckReport.AddRelatedObj( comConnectingArr[y], comConnectingArr[y]:GetAuxAttri("Entity.ObjectType"))
			y = y + 1
		end

		while y1 ~= x1 + 1 do
			FXUtility.DisplaySolid_Info ( comMinorArr[y1] , comMinorArr[y1]:GetAuxAttri("Entity.ObjectType")..": Diameter = "..comMinorDiamArr[y1].." mm")
			CheckReport.AddRelatedObj( comMinorArr[y1] , comMinorArr[y1]:GetAuxAttri("Entity.ObjectType"))
			y1 = y1 + 1
		end

		-- while y2 ~= x2 + 1 do
		-- 	FXUtility.DisplaySolid_Info ( connectingSewerObj ,pubSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..publicSewerDiameter.." mm;"..connectingSewerObj:GetAuxAttri("Entity.ObjectType")..": Diameter = "..connectingSewerDiameter.." mm")
		-- 	CheckReport.AddRelatedObj( connectingSewerObj, connectingSewerObj:GetAuxAttri("Entity.ObjectType"))
		-- end


	end
end


function CheckConnectedChamberElement(Container, chamber, pipe)
	local isConnectedToChamber = false;
	local chamberConnectedObjs = FXGroup.new()
	local flowFittingGrp = Container:GetDescendants("FlowFitting")
	local flowSegmentGrp = Container:GetDescendants("FlowSegment")
	if (FXClashDetection.IsCollided(pipe,chamber)) then
		isConnectedToChamber = true;
	else
		flowFittingGrp:ForEach(function ( fitting )
			if (FXClashDetection.IsCollided(fitting, chamber)) then
				chamberConnectedObjs:Add(fitting)
				if (FXClashDetection.IsCollided(fitting, pipe)) then
					isConnectedToChamber = true;
				end
			end
		end)
	end

	if isConnectedToChamber == false then
		flowSegmentGrp:ForEach(function ( segment )
			if (FXClashDetection.IsCollided(segment, chamber)) then
				chamberConnectedObjs:Add(segment)
			end
		end)

		chamberConnectedObjs:ForEach(function ( connectedObj )
			if (FXPUB.IsTwoObjsConnected(connectedObj, pipe , 13) ) then
				isConnectedToChamber = true;
				return false;
			end
		end)
	end

	return isConnectedToChamber;
end