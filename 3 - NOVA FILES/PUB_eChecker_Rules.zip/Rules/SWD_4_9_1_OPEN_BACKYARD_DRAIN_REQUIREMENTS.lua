local flowSegmentGrp = FXGroup:new();
local maintenanceSumpGrp = FXGroup:new();
local concreteHaunchGrp = FXGroup:new();
local minDiameter;
local systemTypes;
local conduitProp;
local conduitValue;
local sumpProp;
local sumpValue;
local haunchProp;
local haunchValue;





function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.Run()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_4_9_1_OPEN_BACKYARD_DRAIN_REQUIREMENTS")
     systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
    local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
    minDiameter = tonumber (ConditionValues[3]);
   local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
   local bldgGrpObjs = FXRule.filterObjects(parsedXml, Building);
   local tblValues = FXRule.filterTableValues(parsedXml, Building)

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			flowSegmentGrp = flowSegmentGrp + v;
			flowSegmentGrp = flowSegmentGrp:Unique();		
		end
		if (k == 4) then
			maintenanceSumpGrp = maintenanceSumpGrp + v;
			maintenanceSumpGrp = maintenanceSumpGrp:Unique();				
		end
	end
	for k,v in pairs(bldgGrpObjs) do
		if (k == 3) then
			concreteHaunchGrp = concreteHaunchGrp + v;
			concreteHaunchGrp = concreteHaunchGrp:Unique();		
		end
	end

	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				conduitProp = v1["property"];
				conduitValue = v1["value"];
			end
		end
	end
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 2) then
				haunchProp = v1["property"];
				haunchValue = v1["value"];
			end
		end
	end
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 3) then
				sumpProp = v1["property"];
				sumpValue = v1["value"];
			end
		end
	end
end

function checkRule(Building)
	
	-- Checking the parsed objects from Universal Template
	local check = checkParseObj(Building)
	if check then
		local noConnectedMaintenanceSumpGrp = FXGroup:new();
		local conduitDrainGrp = FXGroup:new();
		local noSlope = false
		local pipeGrp = FXGroup:new();
		local noSlopeGrp = FXGroup:new();
		local bldgElementGrp = Building:GetDescendants("BuildingElementProxy")
		local isSupported = false;
		local isCompliant = false
		local nonCompliant = false
		local isCompliant2 = true;
		local ARRConduit = {}
		local ARRConduitInvert = {}
		local ARRConduitInvertLine = {}
		local ARRConduitInvertPipe = {}
		local ARRConduitInvertLevel = {}
		local ARRConcreteHaunch = {}
		local ARRParallelDrain = {}
		local compliantConcreteHaunchGrp = FXGroup:new();
		local ParallelDrainGrp = FXGroup:new();
		local connectedMaintenanceSumpGrp = FXGroup:new();

		local ARRGRPChain = {}
		local i = 0
		-- Conduit Drain with diameter only
		flowSegmentGrp:ForEach(function(flowSegmentGrpEle)
			if (FXPUB.GetDiameter(flowSegmentGrpEle)) ~= nil then
				pipeGrp:Add(flowSegmentGrpEle)
				conduitDrainGrp:Add(flowSegmentGrpEle)
			end 
		end)
		-- Checking the provision of Concrete Haunch to the Conduit Drain
		pipeGrp:ForEach(function(conduitDrainGrpEle) -- checking if has non compliant pipes that has no support
			concreteHaunchGrp:ForEach(function(concreteHaunchGrpEle)
				if FXClashDetection.IsCollided(conduitDrainGrpEle, concreteHaunchGrpEle) then
					local conduitDrainGrpEleBoxZ = FXGeom.GetBoundingBox(conduitDrainGrpEle):LowPos().z
					local concreteHaunchGrpEleBoxZ = FXGeom.GetBoundingBox(concreteHaunchGrpEle):LowPos().z
					if concreteHaunchGrpEleBoxZ < conduitDrainGrpEleBoxZ then
						isSupported = true;
						i = i + 1
						ARRConcreteHaunch[i] = conduitDrainGrpEle

					end
				end
			end)
			if not isSupported then
				isCompliant2 = false
				FXUtility.DisplaySolid_Error(conduitDrainGrpEle, conduitValue .. " support not provided.")
				CheckReport.AddRelatedObj(conduitDrainGrpEle, conduitValue..":"..conduitDrainGrpEle:GetAttri("Tag"))
			end
		end)



		if isSupported then
			concreteHaunchGrp:ForEach(function(concreteHaunchGrpEle)
				local grpPipes = FXGroup.new();
				local allPipesHasSlope = true;
				conduitDrainGrp:ForEach(function ( pipeObj )
					if FXClashDetection.IsCollided(pipeObj, concreteHaunchGrpEle) then
						if FXMeasure.GetPipeSlope(pipeObj) == 0 or  FXMeasure.GetPipeSlope(pipeObj) == nil then
							noSlopeGrp:Add (pipeObj);
							allPipesHasSlope = false;
						else
							grpPipes:Add(pipeObj);
						end				
					end				
				end)

				local highestPipe;
				local lowestPipe;

				if allPipesHasSlope then
					pipeGrp:ForEach (function ( pipeObj )
						local highPos = FXGeom.GetBoundingBox( pipeObj ):HighPos().z;
						local lowPos = FXGeom.GetBoundingBox( pipeObj ):LowPos().z;

						if highestPipe == nil or highPos > FXGeom.GetBoundingBox( highestPipe ):HighPos().z then
							highestPipe = pipeObj;
						end

						if lowestPipe == nil or lowPos < FXGeom.GetBoundingBox( lowestPipe ):LowPos().z then
							lowestPipe = pipeObj;
						end
					end)

					local highestPipeCircleArr = FXMeasure.GetALLCircularFaces(highestPipe);
					local lowestPipeCircleArr = FXMeasure.GetALLCircularFaces(lowestPipe);


					local highPipeLine1 = FXMeasure.GetOuterDiameterLines(highestPipeCircleArr[1], 0)
					local highPipeLine2 = FXMeasure.GetOuterDiameterLines(highestPipeCircleArr[2], 0)
					local lowestPipeLine1 = FXMeasure.GetOuterDiameterLines(lowestPipeCircleArr[1], 0)
					local lowestPipeLine2 = FXMeasure.GetOuterDiameterLines(lowestPipeCircleArr[2], 0)

					local highestPnt1 = getLowestPnt(highPipeLine1);
					local highestPnt2 = getLowestPnt(highPipeLine2);
					local lowestPnt1  = getLowestPnt(lowestPipeLine1);
					local lowestPnt2  = getLowestPnt(lowestPipeLine2);

					local highestPnt;
					local lowestPnt;

					if highestPnt1.z > highestPnt2.z then
						highestPnt = highestPnt1
					else
						highestPnt = highestPnt2
					end

					if lowestPnt1.z < lowestPnt2.z then
						lowestPnt = lowestPnt1
					else
						lowestPnt = lowestPnt2
					end


					local newPnt = Point3D( highestPnt.x , highestPnt.y , lowestPnt.z);
					local arrow = DoubleArrow( highestPnt , newPnt );
					local invertLine = Line3D(newPnt, lowestPnt) 

					print ( Line3D (highestPnt , newPnt):Length() )

					local slope = FXMeasure.GetPipeSlope(lowestPipe);
					local deg2 = math.atan(slope)
					local hyp = Line3D (highestPnt , lowestPnt):Length() 
					local height = (hyp * math.sin (deg2))  
					print (height)
					-- FXUtility.DisplaySolid_Warning(Building, "1", arrow )
					-- FXUtility.DisplaySolid_Warning(Building, "1", invertLine)

					if hyp >= 150 then
						i = i + 1
						ARRConduitInvert[i] = FXUtility.Round(height, 2)
						ARRConduitInvertLevel[i] = arrow
						ARRConduitInvertPipe[i] = highestPipe
						ARRConduitInvertLine[i] = invertLine
					else 
						isCompliant2 = false
						FXUtility.DisplaySolid_Error(pipeObj, "Pipe 150 mm deep Invert drop not provided",arrow )
					end		
				else
					isCompliant2 = false
					noSlopeGrp:ForEach(function(pipeObj)
						FXUtility.DisplaySolid_Error(pipeObj, "Pipe 150 mm deep Invert drop not provided")
					end)
				end
			end)
		end

		-- 	-- Checking of Pipe Diameter
			local firstPipe;
			local secondPipe;		

		print(#conduitDrainGrp)
			conduitDrainGrp:ForEach(function(conduitDrainGrpEle)
				if firstPipe == nil then
					firstPipe = conduitDrainGrpEle
				else
					secondPipe = conduitDrainGrpEle
				end

				-- Checking the Diameter of two Conduit Drain
				local conduitDrainDiameter =  FXUtility.Round(FXPUB.GetDiameter(conduitDrainGrpEle));
				if conduitDrainDiameter >= minDiameter then
					i = i + 1
					ARRConduit[i] = conduitDrainGrpEle
				else
					isCompliant2 = false
					FXUtility.DisplaySolid_Error(conduitDrainGrpEle, conduitDrainDiameter .. " mm ; FlowSegment : " .. conduitValue)
					CheckReport.AddRelatedObj(conduitDrainGrpEle, conduitValue..":"..conduitDrainGrpEle:GetAttri("Tag"))
				end		
		
			end)
				-- Check if the Conduit Drain is straight	
				conduitDrainGrp:ForEach(function(conduitDrainGrpEle)
					local firstPipeDirection = FXMeasure.GetProjectionCenterLine(firstPipe)
					local secondPipeDirection = FXMeasure.GetProjectionCenterLine(secondPipe)
					if not IsParallel(firstPipeDirection, secondPipeDirection, 0.1) then			
						isCompliant2 = false	
						FXUtility.DisplaySolid_Error(conduitDrainGrpEle, conduitValue .. " has change in direction.")
						CheckReport.AddRelatedObj(conduitDrainGrpEle, conduitValue..":"..conduitDrainGrpEle:GetAttri("Tag"))			
					else
						i = i + 1
						ARRParallelDrain[i] = conduitDrainGrpEle
					end
				end)
	

		-- Checking for the provision of Maitenance Sump in every Conduit Drain
		maintenanceSumpGrp:ForEach(function(maintenanceSumpGrpEle)
			conduitDrainGrp:ForEach(function(conduitDrainGrpEle)
			local flag, Obj = isConnectedToMaintenanceSump(conduitDrainGrpEle)
			if flag then
				connectedMaintenanceSumpGrp:Add(maintenanceSumpGrpEle)
			else
				isCompliant2 = false
				noConnectedMaintenanceSumpGrp:Add(conduitDrainGrpEle)
			end
			end)
		end)
		-- Displaying No Provision of Maintenance Sump
		if #noConnectedMaintenanceSumpGrp ~= 0 then
			noConnectedMaintenanceSumpGrp:ForEach(function(conduitDrainGrpEle)
				FXUtility.DisplaySolid_Error(conduitDrainGrpEle, "No Maintenance Sump provided.")
				CheckReport.AddRelatedObj(conduitDrainGrpEle, conduitDrainGrpEle:GetAttri(conduitProp)..":"..conduitDrainGrpEle:GetAttri("Tag"))
			end)		
		end	
		-- -- Displaying compliant results only 
		if isCompliant2 then
			for i,conduitDrainGrpEle in pairs(ARRConduit) do
				local conduitDrainDiameter =  FXUtility.Round(FXPUB.GetDiameter(conduitDrainGrpEle));
				FXUtility.DisplaySolid_Info(conduitDrainGrpEle, conduitDrainDiameter .. " mm ; FlowSegment : ")
				CheckReport.AddRelatedObj(conduitDrainGrpEle, conduitValue..":"..conduitDrainGrpEle:GetAttri("Tag"))			
			end
			-- Displaying Provision of collided Concrete Haunch
			for i,concreteHaunchGrpEle in pairs(ARRConcreteHaunch) do
				FXUtility.DisplaySolid_Info(concreteHaunchGrpEle, haunchValue.. " support provided.")
				CheckReport.AddRelatedObj(concreteHaunchGrpEle, haunchValue..":"..concreteHaunchGrpEle:GetAttri("Tag"))
			end

			-- Displaying Provision of Connected Maintenance Sump
			connectedMaintenanceSumpGrp:ForEach(function(connectedMSele)
				FXUtility.DisplaySolid_Info(connectedMSele, connectedMSele:GetAttri(sumpProp) ..  " provided.")
				CheckReport.AddRelatedObj(connectedMSele, connectedMSele:GetAttri(sumpProp)..":"..connectedMSele:GetAttri("Tag"))
			end)	

			for i,conduitDrainGrpEle in pairs(ARRParallelDrain) do
				FXUtility.DisplaySolid_Info(conduitDrainGrpEle, conduitDrainGrpEle:GetAttri(conduitProp) .. " is straight.")
				CheckReport.AddRelatedObj(conduitDrainGrpEle, conduitDrainGrpEle:GetAttri(conduitProp)..":"..conduitDrainGrpEle:GetAttri("Tag"))	
			end

			for i,pipes in pairs(ARRConduitInvertPipe) do
				local conduit = pipes:GetAttri("ObjectType")

				FXUtility.DisplaySolid_Info(pipes, conduit .. ": " .. ARRConduitInvert[i]  .. " mm" .. " deep Invert drop provided.", ARRConduitInvertLevel[i] )
				-- CheckReport.AddRelatedGeometry_Solid(, "msg")
			end
		end


	end


end


function GetShortestLine( obj )
	local outerEdge = FXMeasure.GetOuterEdge(obj)
	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;
	local distLength;
	print (PolyLinePointNumber)
	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( distLength == nil or dist:Length() >= Line:Length() ) then
			dist = Line;
			distLength = Line:Length()
		end
	end
	return dist;
end

function checkParseObj(Building)
	if (#flowSegmentGrp == 0 or #flowSegmentGrp == nil ) then
		FXUtility.DisplaySolid_Warning(Building, "Conduit Drain pipe not provided.")
		return false;
	end

	if (#maintenanceSumpGrp == 0 or #maintenanceSumpGrp == nil) then
		FXUtility.DisplaySolid_Error(Building, "Maintenance Sump not provided.")
		return false;
	end
	if (#concreteHaunchGrp == 0 or #concreteHaunchGrp  == nil) then
		FXUtility.DisplaySolid_Error(Building, "Concrete Haunch not provided.")
		return false;
	end

	return true;
end


function isConnectedToMaintenanceSump ( Obj1 )
	local flag = false
	local Obj;
	grpConnObjs = Obj1:GetConnectedElement();
	grpConnObjs:ForEach(function ( ConnObj )
		if (FXUtility.HasPatterInString(ConnObj:GetAttri(sumpProp),sumpValue)) then
			Obj = ConnObj;
			flag = true;
		end
	end)	

	return flag, Obj;
end
function IsParallel(line1,line2)
	local Line1Vec = line1:GetVector();
	local Line2Vec = line2:GetVector();
	local Prallel = Line1Vec:IsParallel(Line2Vec);
	if Prallel == true then
		return true;
	else
		return false;
	end
end

function getLowestPnt( line )
	local pnt1 = line:GetStartPoint();
	local pnt2 = line:GetEndPoint();

	if pnt1.z > pnt2.z then
		return pnt2;
	else
		return pnt1;
	end
end