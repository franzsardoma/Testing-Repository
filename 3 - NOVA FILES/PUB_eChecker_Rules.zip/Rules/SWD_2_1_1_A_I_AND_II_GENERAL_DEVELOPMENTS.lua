	--[[
		Implemented by: Aldrin Lacorte
	]]--
local dischargeGrp = FXGroup.new()
local roadGrp = FXGroup.new()
local firstStSlabGrp = FXGroup.new()

local sitePropTbl = {}
local siteValTbl = {}
local levelObjType
local levelObjProp
local levelObjValue
local roadTypeTbl = {}
local roadPropTbl = {}
local roadValueTbl = {}
local minSouth
local minNorth
local minRoad

local RESULT = "Platform Level:%.2fm; %s; %s; Road Level:%.2fm "
local C_MRL = "Platform Level is above required SHD."
local NC_MRL = "Platform Level is below required SHD."
local C_NC_ROAD = "Platform Level is %.0fmm from Road."
local PL_NO_MATCH = "Project Location does not match."

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_2_1_1_A_I_AND_II_GENERAL_DEVELOPMENTS")
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building)
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1")
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2")
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3")
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	minSouth = ConditionValues[3]
	minNorth = ConditionValues2[3]
	minRoad = ConditionValues3[1]

	for k,v in pairs(GrpObjs) do 

		if (k == 4) then
			dischargeGrp = dischargeGrp + v
			dischargeGrp = dischargeGrp:Unique()
		end

		if (k == 5) then
			roadGrp = roadGrp + v
			roadGrp = roadGrp:Unique()
		end
	end
	print("roadGrp " .. #roadGrp)
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				levelObjType = v1["type"]
				levelObjProperty = v1["property"]
				levelObjValue = v1["value"]
			end	
			if (k == 2) then
				ObjProperty = v1["property"]
				ObjValue = v1["value"]
				table.insert(sitePropTbl, ObjProperty)
				table.insert(siteValTbl, ObjValue)
			end	
			-- if (k == 4) then
			-- 	ObjType = v1["type"]
			-- 	ObjProperty = v1["property"]
			-- 	ObjValue = v1["value"]
			-- 	table.insert(roadTypeTbl, ObjType)
			-- 	table.insert(roadPropTbl, ObjProperty)
			-- 	table.insert(roadValueTbl, ObjValue)
			-- end	
		end
	end
end

function checkRule(Building)

	local isPassed = true;

	local StoreyAr = {};
	local Requirement = {};
	local SlabAr = {};
	local RoadDiff = {};
	local k = 0;

	local bldgNamePara1 = siteValTbl[3]
	local bldgNamePara2 = siteValTbl[4]
	local bldgProjectAddressPara = {siteValTbl[2], siteValTbl[1]}
	local Site = Building:GetParent();
	-- local Project = Building:GetParent():GetParent();
	local bldgPDT = FXPUB.GetProjDevelopmentType(Site) --GetPDT(Site)
	if bldgPDT == nil then

		FXUtility.DisplaySolid_Warning(Site, "Project Development Type is not specified.");
		-- return;
		isPassed = false
	elseif not( (FXUtility.HasPatterInString(bldgPDT,bldgNamePara1)) or (FXUtility.HasPatterInString(bldgPDT,bldgNamePara2)) ) then 

		local msg = "Project Development Type does not match.";
		FXUtility.DisplaySolid_Warning(Site, msg);
		-- return;
		isPassed = false
	end

	local bldgPL = FXPUB.GetProjLocation(Site) --GetPL(Site) 
	if bldgPL == nil then
		FXUtility.DisplaySolid_Warning(Site, "Project Location is not specified.");
		isPassed = false
		-- return;
	end
	-- print("ProjDevelopmentType " .. bldgPDT .. " Project Location " .. bldgPL)
	local minMRL;
	if (FXUtility.HasPatterInString(bldgPL,bldgProjectAddressPara[1])) then
		minMRL = minSouth
	elseif (FXUtility.HasPatterInString(bldgPL,bldgProjectAddressPara[2])) then
		minMRL = minNorth
	else
		local msg = "Project Location does not match.";
		FXUtility.DisplaySolid_Warning(Site, msg);
		isPassed = false
		-- return;
	end

	-- //Getting the 1st storey and elevation (temp)
	local storeys = Building:GetChildren("BuildingStorey")
	storeys:ForEach(function(storey)
		if ( FXUtility.HasPatterInString(storey:GetAttri("Name"), levelObjValue)) then
			firstStSlabGrp = storey:GetDescendants(levelObjType)
			LevelElev = storey:Elevation()
		end
	end)
	--[[
		Grouping of Road based from Building Storey "Road" and Slab "Road"
		local road = Building:GetChildren(roadTypeTbl[2])
		local slab = Building:GetDescendants(roadTypeTbl[1])
		road:ForEach(function(storey)
			if ( FXUtility.HasPatterInString(storey:GetAttri(roadPropTbl[2]), roadValueTbl[2])) then
				slab:ForEach(function(slabs)
				if ( FXUtility.HasPatterInString(slabs:GetAttri(roadPropTbl[1]), roadValueTbl[1])) then
					roadGrp:Add(slabs)
				end
				end)
			end
		end)
	]]
	if #firstStSlabGrp == 0 then
		FXUtility.DisplaySolid_Warning(Site, "No First Storey found.");
		isPassed = false
	end
	if #roadGrp == 0 then
		FXUtility.DisplaySolid_Warning(Site, "No Road Storey found.");
		isPassed = false
	end
	if #dischargeGrp == 0 then
		FXUtility.DisplaySolid_Warning(Site, "No Vertical Grating found.");
		isPassed = false
	end

	if isPassed then
		local isCompliant = true

		local lowestSlabElev, lowestSlab;
		firstStSlabGrp:ForEach(function (slab)
			local slabElev = FXGeom.GetBoundingBox(slab):HighPos().z;
			if lowestSlabElev == nil then
				lowestSlabElev = slabElev
			elseif lowestSlabElev > slabElev then
				lowestSlabElev = slabElev
				lowestSlab = slab
			end
		end)
		print("Platform lvl " .. lowestSlabElev)
		-- FXPUB.DisplayTest(lowestSlab, "lowestSlab")

		local storeys = Building:GetChildren("BuildingStorey")
		storeys:ForEach(function (storey)
			if ( FXUtility.HasPatterInString(storey:GetAttri("Name"), levelObjValue) or 
				FXUtility.HasPatterInString(storey:GetAttri("Name"), "storey 01")) then
				-- // COMPARE TIME \\

				local platformLvl = lowestSlabElev

				-- MRL computation
				local SiteRefElev = Building:GetParent()
				local calculatedMRL = (minMRL - (SiteRefElev:GetAttri("RefElevation") + LevelElev)) + LevelElev

				local roadElev = FXPUB.GetRoadElevation(dischargeGrp, roadGrp)
				-- local roadElev = newDistance:GetEndPoint().z
				minRoad = minRoad + roadElev 

				RESULT = string.format(RESULT, 
					FXPUB.SetStandardMrl(platformLvl), bldgPL, bldgPDT, FXPUB.SetStandardMrl(roadElev))
				print(RESULT)
				
				local roadDiff = platformLvl - roadElev

				--[[ platform should be above the mrl or road
						local requirement, str, roadDiff;
						the platform should be above the mrl or road (whichever is the highest) 
						if calculatedMRL >= minRoad then
							requirement = calculatedMRL
						else
							requirement = minRoad 
							roadDiff = platformLvl - roadElev
						end

						if platformLvl >= requirement then
							print("COMPLIANT")

						else
							print("NON COMPLIANT")
							if roadDiff == nil then print("roadDiff is nil.") end
							DisplayResult(storey, requirement, lowestSlab, false, roadDiff)
						end
				]]--

				-- platform should be above the mrl and road 
				if platformLvl >= calculatedMRL and platformLvl >= minRoad then 
					-- check the highest between calculatedMRL and minRoad
					print("COMPLIANT")
					if calculatedMRL >= minRoad then --COMPLIANT MRL
						print("calculatedMRL " .. calculatedMRL)
						StoreyAr[k] = storey
						Requirement[k] = calculatedMRL
						SlabAr[k] 	= lowestSlab
					else --COMPLIANT ROAD
						print(minRoad .. "minRoad")
						StoreyAr[k] =storey
						Requirement[k] = minRoad
						SlabAr[k] = lowestSlab
						RoadDiff[k] = roadDiff	
					end
					k = k + 1;
				else
					isCompliant = false;
					if platformLvl < calculatedMRL then --NONCOMPLIANT MRL
						DisplayResult(storey, calculatedMRL, lowestSlab, false)
					elseif platformLvl < minRoad then --NONCOMPLIANT ROAD
						DisplayResult(storey, minRoad, lowestSlab, false, roadDiff)
					end
				end
				return false
			end
		end)
	
		if isCompliant then
			for j,storey in pairs(StoreyAr) do
				if RoadDiff[j] == nil then print("roadDiff is nil.") else print("roadDiff " .. RoadDiff[j]) end
				DisplayResult(storey, Requirement[j], SlabAr[j], true, RoadDiff[j])
			end
		end	
	else
		return;
	end
end

function DisplayResult(storey, mRL, lowestSlab, isPassed, roadDiff)

	local storeyOBB = FXGeom.GetBoundingBox(storey)
	local roadNode = FXUtility.CreateNodeFrom(storeyOBB);
	local prj = FXMeasure.GetObjProjection(roadNode, mRL)
	FXClashDetection.DeleteNode(roadNode);

	-- DisplayTest(storey, "mrlPrj", mrlPrj)

	if isPassed then
		FXUtility.DisplaySolid_Info(storey, RESULT);
		CheckReport.AddRelatedGeometry_SupportedInfo(prj)
		if roadDiff == nil then -- mrlDiff
			CheckReport.AddRelatedObj( lowestSlab, C_MRL );
		else -- roadDiff
			CheckReport.AddRelatedObj( lowestSlab, string.format(C_NC_ROAD, roadDiff));
		end
	else
		FXUtility.DisplaySolid_Error(storey, RESULT);
		if roadDiff == nil then -- mrlDiff
			CheckReport.AddRelatedObj( lowestSlab, NC_MRL );
			CheckReport.AddRelatedGeometry_SupportedInfo(prj)
		else -- roadDiff
			CheckReport.AddRelatedObj( lowestSlab, string.format(C_NC_ROAD, roadDiff));
			CheckReport.AddRelatedGeometry_SupportedInfo(prj)			
		end

		local prjNode = FXUtility.CreateNodeFrom(prj);
		local distance = FXMeasure.Distance(prjNode, lowestSlab)
		FXClashDetection.DeleteNode(prjNode);
		print("dist Prj to lowestSlab " .. distance:Length())
		if distance:Length() >= 5 then
	   		local arrow = DoubleArrow(distance:GetStartPoint(), distance:GetEndPoint());
			CheckReport.AddRelatedGeometry_Error(arrow, "")
		end
	end
end


--[[
	local storeyGrp = FXGroup.new();
	local firstStSlabGrp = FXGroup.new();
	local roadGrp = FXGroup.new();
	local dischargeGrp = FXGroup.new();
	local minRoad;
	local  south
	local  north
	local storeyVal
	local bldgNamePara = "General Development"
	local bldgProjectAddressPara = {"Southern", "Northern"}

	local RESULT = "Platform Level:%.2fm; %s; %s; Road Level:%.2fm "
	local C_MRL = "Platform Level is above required mRL."
	local NC_MRL = "Platform Level is below required mRL."
	local C_NC_ROAD = "Platform Level is %.0fmm from Road."
	local PL_NO_MATCH = "Project Location does not match.";

	local COMPLIANT = {mrl = "Platform Level is below required mRL.", road = "Platform Level is %.0fmm from Road."}
	local NONCOMPLIANT = {mrl="Platform Level is below required mRL.", road="Platform Level is %.0fmm from Road."}

	function main()
		CheckEngine.SetCheckType("Building")
		CheckEngine.BindCheckFunc("XMLParser")
		CheckEngine.RunCheckPipeline()
		
		CheckEngine.SetCheckType("Building");
		CheckEngine.BindCheckFunc("checkRule");
		CheckEngine.RunCheckPipeline();
	end

	function XMLParser(Building)

		local ok, path = pcall(FXPUB.GetFilePath())
		-- print("LUA " .. path())
		local parsedXml = FXPUB.ParseXml(path(), "SWD_2_1_1_A") -- (LUA path, HTML filename)
		-- local parsedXml = FXPUB.ParseXml(path(), "SWD_2_1_1_A_I_GENERAL_DEVELOPMENTS") -- (LUA path, HTML filename)
		-- local tblValues = FXRule.filterTableValues(parsedXml, Building)
		
		local GrpObjs = FXRule.filterObjects(parsedXml, Building); -- parse osbjects using the function in FXRule.lua
		local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");

		local ConditionValues1 = FXRule.ParseValues(parsedXml, "Condition1");
		local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition2");
		local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition3");


		-- for k,v in pairs(tblValues) do		
		-- 	for k1,v1 in pairs(v) do
		-- 		if (k == 1) then
		-- 			storeyVal = v1["value"]
		-- 		end
		-- 	end
		-- end

		for k,v in pairs(ConditionValues1) do 
			if (k == 3) then
				south = tonumber(v);
			end
		end
		for k,v in pairs(ConditionValues2) do 
			if (k == 3) then
				north = tonumber(v);
			end
		end
		for k,v in pairs(ConditionValues3) do 
			if (k == 3) then
				minRoad = tonumber(v); 
			end
		end

		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				storeyGrp = storeyGrp + v
				storeyGrp =  storeyGrp:Unique();
			end
			if (k == 4) then
				dischargeGrp = dischargeGrp + v
				dischargeGrp =  dischargeGrp:Unique();
			end
			if (k == 5) then
				roadGrp = roadGrp + v
			end
		end
		-- print("storeyGrp " .. #storeyGrp)
	end

	function checkRule(Building)
		local Site = Building:GetParent();
		-- local Project = Building:GetParent():GetParent();
		local bldgPDT = GetPDT(Site)
		if bldgPDT == nil then
			FXUtility.DisplaySolid_Warning(Site, "Project Development Type not specified.");
			return;
		elseif not(FXUtility.HasPatterInString(bldgPDT,bldgNamePara)) then  
			local msg = "Project Development Type does not match.";
			FXUtility.DisplaySolid_Warning(Site, msg);
			return;
		end

		local bldgPL = GetPL(Site)
		if bldgPL == nil then
			FXUtility.DisplaySolid_Warning(Site, "No Project Location not specified.");
			return;
		end
		local isPassed = true
		-- //TEMP
		local storeys = Building:GetChildren("BuildingStorey")
		local level1
		storeys:ForEach(function(storey)
			if FXUtility.HasPatterInString(storey:GetAttri("Name"), "level 01") then
				firstStSlabGrp = storey:GetDescendants("Slab")
				level1 = storey:Elevation()
			end
		end)
		-- //TEMP

		if #firstStSlabGrp == 0 then
			FXUtility.DisplaySolid_Warning(Site, "No First Storey found.");
			isPassed = false
		end
		if #roadGrp == 0 then
			FXUtility.DisplaySolid_Warning(Site, "No Road Storey found.");
			isPassed = false
		end
		if #dischargeGrp == 0 then
			FXUtility.DisplaySolid_Warning(Site, "No Vertical Grating found.");
			isPassed = false
		end

		if isPassed then

		-- Get MRL
		
		local SiteRefElev = Building:GetParent()
		local southMRL = (south - (SiteRefElev:GetAttri("RefElevation") + level1)) + level1
		local northMRL = (north - (SiteRefElev:GetAttri("RefElevation") + level1)) + level1
		

			local lowestSlabElev, lowestSlab;
			firstStSlabGrp:ForEach(function (slab)
				local slabElevTemp = FXGeom.GetBoundingBox(slab):HighPos().z;
				if lowestSlabElev == nil then
					lowestSlabElev = slabElevTemp
					lowestSlab = slab
				elseif lowestSlabElev > slabElevTemp then
					lowestSlabElev = slabElevTemp
					lowestSlab = slab
				end
			end)
			-- FXPUB.DisplayTest(lowestSlab, "lowestSlab")

			-- Thoughts for future: what if in the model, many roads and discharge point
			local storeys = Building:GetChildren("BuildingStorey")
			storeys:ForEach(function (storey)
				if FXUtility.HasPatterInString(storey:GetAttri("Name"), "level 01") then -- ?
					print("roadGrp " .. #roadGrp)
					dischargeGrp:ForEach(function (discharge)
						local road, disLen
						roadGrp:ForEach(function (roadd)
							local tempDist = FXMeasure.Distance(discharge, roadd)
							if road == nil then
								road = roadd
								disLen = tempDist:Length()
							elseif  disLen > tempDist:Length() then
								road = roadd
								disLen = tempDist
							else
								print("line 166")
							end
						end)

						local roadFace = FXMeasure.GetTopFace(road)
						local dischargeOBB = FXGeom.GetBoundingOBB(discharge)
						local dischargeCenter = dischargeOBB:GetPos() 
						local dischargeBox = FXGeom.GetBoundingBox(discharge)
						local dischargeMax = dischargeBox:HighPos() 
						local dischargeMin = dischargeBox:LowPos()
						-- 1) Getting discharge center line and road projection
						local dischargeCenterLine = Line3D(Point3D(dischargeCenter.x, dischargeCenter.y, dischargeMax.z), 
							Point3D(dischargeCenter.x,  dischargeCenter.y, dischargeMin.z)) 
						local roadPrj = FXMeasure.GetObjProjection(road, dischargeMax.z)
						-- FXPUB.DisplayTest(discharge, "dischargeCenterLine", dischargeCenterLine)
						-- FXPUB.DisplayTest(road, "roadPrj", roadPrj)
						-- 2) Getting the lateral dist of discharge centerline and road projection
						local roadNode = FXUtility.CreateNodeFrom(roadPrj);
						local dischargeNode = FXUtility.CreateNodeFrom(dischargeCenterLine);
						local lateralDistance = FXMeasure.Distance(dischargeNode, roadNode) -- endpnt is in road
						FXClashDetection.DeleteNode(roadNode);FXClashDetection.DeleteNode(dischargeNode);
						-- FXPUB.DisplayTest(discharge, "lateralDistance " .. lateralDistance:Length(), lateralDistance)
						
						-- if lateralDistance:length is 0, it means the discharge is under the road 
						-- therefore i will use the dischargeCenterLine.
						if lateralDistance:Length() == 0 then
							lateralDistance = dischargeCenterLine;
						end
						--3) Getting aboveDistance of lateralDistance to top road
						local roadFaceNode = FXUtility.CreateNodeFrom(roadFace);
						local lateralNode = FXUtility.CreateNodeFrom(lateralDistance);
						local distance1 = FXMeasure.Distance(lateralNode, roadFaceNode) -- Endpnt is in road
						-- FXPUB.DisplayTest(road,"distance1 " .. distance1:Length() , distance1)
						FXClashDetection.DeleteNode(roadFaceNode);
						FXClashDetection.DeleteNode(lateralNode);
						-- /// Get Vertical Line \\\
						-- This will make the distance1(shortest distance) to vertical distance 
						-------------------------------------------------------------------------------------------
						local newDistance = Line3D(distance1:GetStartPoint(), 
							Point3D(distance1:GetStartPoint().x, distance1:GetStartPoint().y, distance1:GetEndPoint().z)) 
						-- FXPUB.DisplayTest(discharge,"newDistance " .. newDistance:Length() , newDistance)
						if newDistance:Length() > 0 then
							local roadFaceNode = FXUtility.CreateNodeFrom(roadFace);
							local i = 1;
							while(i>0) do
								local nDNode = FXUtility.CreateNodeFrom(newDistance);
								if FXClashDetection.IsCollided(nDNode,roadFaceNode) then
									print("GetVerticalDist COLLIDED:" .. i)
									break;
								-- loop will also break if it reach the road highest pnt z and still not collides
								elseif newDistance:GetEndPoint().z == FXGeom.GetBoundingOBB(road):MaxPnt().z then 
									print("GetVerticalDist LIMIT " .. i)
									break;
								else
									print("GetVerticalDist Not COLLIDED:" .. i)
									newDistance = Line3D(newDistance:GetStartPoint(), 
										Point3D(newDistance:GetEndPoint().x, newDistance:GetEndPoint().y, newDistance:GetEndPoint().z + i)); -- Endpnt is still in road
									i = i + 1;
									-- FXPUB.DisplayTest(discharge, "newDistance " .. newDistance:Length(), newDistance)
								end
								FXClashDetection.DeleteNode(nDNode);
							end
							FXClashDetection.DeleteNode(roadFaceNode);
							-- FXPUB.DisplayTest(road, "newDistance " .. newDistance:Length(), newDistance)
							-------------------------------------------------------------------------------------------
							local roadElev = newDistance:GetEndPoint().z
							minRoad = minRoad + roadElev 
							-- print(string.format("roadElev %.1f lvldiff %.2f", roadElev, lvldiff))
							-- // COMPARE TIME \\
							local platformLvl = lowestSlabElev
							RESULT = string.format(RESULT, 
								platformLvl/1000, bldgPL, bldgPDT, roadElev/1000)
							print(RESULT)
							local minMRL;
							if (FXUtility.HasPatterInString(bldgPL,bldgProjectAddressPara[1])) then
								minMRL = southMRL
							elseif (FXUtility.HasPatterInString(bldgPL,bldgProjectAddressPara[2])) then
								minMRL = northMRL
							else
								local msg = "Project Location does not match.";
								FXUtility.DisplaySolid_Warning(Site, msg);
								return;
							end
							-- print("Project Location " .. bldgPL)
							local roadDiff = platformLvl - roadElev
							if platformLvl >= minMRL and platformLvl >= minRoad then
								-- check the highest
								print("COMPLIANT")
								if minMRL >= minRoad then --COMPLIANT MRL
									print("minMRL " .. minMRL)
									DisplayResult(storey, minMRL, lowestSlab, true)
								else --COMPLIANT ROAD
									print("roadDiff " .. roadDiff .. "minRoad " .. minRoad)
									DisplayResult(storey, minRoad, lowestSlab, true, roadDiff)
								end
							else
								if platformLvl < minMRL then --NONCOMPLIANT MRL
									DisplayResult(storey, minMRL, lowestSlab, false)
								elseif platformLvl < minRoad then --NONCOMPLIANT ROAD
									DisplayResult(storey, minRoad, lowestSlab, false, roadDiff)
								end
							end
						else
							print("line 269: newDistance length is 0. ")
						end
					end)
					return false
				end
			end)
		else
			return;
		end
	end

	function GetPDT(Site)
		local revitPDT = Site:GetAuxAttri("Other.Project Development Type");
		local archiPDT = Site:GetAuxAttri("Location Data.Project Development Type");

		if revitPDT ~= nil then
			return revitPDT
		elseif archiPDT ~= nil then
			return archiPDT
		end
	end
	function GetPL(Site)
		local revitPL = Site:GetAuxAttri("Other.Project Location");
		local archiPL = Site:GetAuxAttri("Location Data.Project Location");

		if revitPL ~= nil then
			return revitPL
		elseif archiPL ~= nil then
			return archiPL
		end
	end

	function DisplayResult(storey, mRL, lowestSlab, isPassed, roadDiff)

		local storeyOBB = FXGeom.GetBoundingBox(storey)
		local roadNode = FXUtility.CreateNodeFrom(storeyOBB);
		local prj = FXMeasure.GetObjProjection(roadNode, mRL)
		FXClashDetection.DeleteNode(roadNode);
		-- local mrlPrj = GetExpandedProjection(prj,mRL, 2000)

		if isPassed then
			-- FXUtility.DisplaySolid_Info(storey, string.format(RESULT, roadDiff), mrlPrj);
			FXUtility.DisplaySolid_Info(storey, RESULT);
			CheckReport.AddRelatedGeometry_SupportedInfo(prj)
			if roadDiff == nil then -- mrlDiff
				CheckReport.AddRelatedObj( lowestSlab, C_MRL );
			else -- roadDiff
				CheckReport.AddRelatedObj( lowestSlab, string.format(C_NC_ROAD, roadDiff));
			end
		else
			FXUtility.DisplaySolid_Error(storey, RESULT);
			CheckReport.AddRelatedGeometry_SupportedInfo(prj)
			if roadDiff == nil then -- mrlDiff
				CheckReport.AddRelatedObj( lowestSlab, NC_MRL );
			else -- roadDiff
				CheckReport.AddRelatedObj( lowestSlab, string.format(C_NC_ROAD, roadDiff));
			end
			local prjNode = FXUtility.CreateNodeFrom(prj);
			
			-- Double arrow from mrl to lowest slab
			local distance = FXMeasure.Distance(prjNode, lowestSlab)
			FXClashDetection.DeleteNode(prjNode);
			print("DisplayResult mrlPrj to lowestSlab distance " .. FXUtility.Round(distance:Length()))
			if distance:Length() >= 5 then
		   		local arrow = DoubleArrow(distance:GetStartPoint(), distance:GetEndPoint());
				CheckReport.AddRelatedGeometry_Error(arrow, "")
			end
		end	
	end
]]