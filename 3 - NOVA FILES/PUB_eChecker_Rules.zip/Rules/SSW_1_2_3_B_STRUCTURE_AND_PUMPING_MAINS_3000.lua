-- Modified By: Lawrence Roy Quiling 1/9/2019

local grpPipeSegment 	= FXGroup:new();
local minDiameter 	--= 1501;
local minimumdist 	--= 3000 
local grpPipes 		= FXGroup:new();
local grpBldgObj 	= FXGroup:new();

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local Project = Building:GetParent():GetParent()
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_3_B_STRUCTURE_AND_PUMPING_MAINS_3000")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	minDiameter = tonumber(ConditionValues[3])
	minimumdist = tonumber(ConditionValues[6])

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpPipeSegment = grpPipeSegment + v;
				grpPipeSegment = grpPipeSegment:Unique();
			end
		end
	end

	if GrpObjs ~= nil then
		grpBldgObj = FXPUB.GetElementtype2InAdvisoryNote( Project, tblValues, GrpObjs )
	end
end

function checkRule(Building)
	local isWarning = false
	if #grpBldgObj == 0 then
		FXUtility.DisplaySolid_Warning(Building, NO_BLDG);
		isWarning = true;
	end
	if #grpPipeSegment == 0 then
		FXUtility.DisplaySolid_Warning(Building,MSG_NO_PUMP_MAINS);
		isWarning = true;
	end

	if isWarning then
		return
	else
		local bldgMaxPnt = FXPUB.GetHighestElevation(Building)
		FXPUB.AdvNoteNoDepth_CheckRule(bldgMaxPnt, grpBldgObj, grpPipeSegment, minDiameter, maxDiameter, minimumdist)
	end
end