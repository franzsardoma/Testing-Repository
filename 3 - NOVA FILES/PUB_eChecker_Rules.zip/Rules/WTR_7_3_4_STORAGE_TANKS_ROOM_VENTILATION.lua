local TankRoomGrp = FXGroup.new();
local WindowGrp = FXGroup.new();
local TankGrp = FXGroup.new();
local COMPLIANT = true;

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function Parser( Building )
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_3_4_STORAGE_TANKS_ROOM_VENTILATION");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	if(GrpObjs ~= nil)then		
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				TankRoomGrp = TankRoomGrp + v;
				TankRoomGrp = TankRoomGrp:Unique();
			end		
			if (k == 3) then
				TankGrp = TankGrp + v;
				TankGrp = TankGrp:Unique();
			end
		end
	end		
end

function CheckRule( Building )
	local SPACE = {};
	local WINDOW = {};

	if(#TankRoomGrp ~= 0)then
		TankRoomGrp:ForEach(function ( TANK_ROOM )
			local SpaceElements = TANK_ROOM:GetInSpaceElement();
			local IsTankExist = false;
			SpaceElements:ForEach(function(Element)
				if(Element.Type == "FlowStorageDevice")then
					TankGrp:ForEach(function(Tank)
						if(Tank.Id == Element.Id)then 
							IsTankExist = true;
						end
					end)
				end
			end)

			if(IsTankExist)then
				local Opening_Element = TANK_ROOM:GetConnectedOpeningElements();
				Opening_Element:ForEach(function ( ELEMENT1 )
					local GROUP = ELEMENT1:GetChildren();
					GROUP:ForEach(function ( ELEMENT2 )
						if(ELEMENT2.Type == "Window")then
							WindowGrp:Add(ELEMENT1);
							table.insert(SPACE,TANK_ROOM);
							table.insert(WINDOW,ELEMENT1);
						end
					end)
				end)
			else
				FXUtility.DisplaySolid_Warning(Building, "Tank is not provided.");
				return
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Tank Room is not provided.");
	end

	if(#WindowGrp ~= 0)then
		COMPLIANT = true;
	else
		COMPLIANT = false;
		TankRoomGrp:ForEach(function ( SPACE )
			FXUtility.DisplaySolid_Error(SPACE, "Window is not provided.");
		end)
	end

	if(COMPLIANT)then --( Compliant Result )--
		for i = 1, #SPACE do
			FXUtility.DisplaySolid_Info(SPACE[i], "Window is provided.")
			CheckReport.AddRelatedObj(WINDOW[i], WINDOW[i]:GetAttri("Name"))
		end
	end
end