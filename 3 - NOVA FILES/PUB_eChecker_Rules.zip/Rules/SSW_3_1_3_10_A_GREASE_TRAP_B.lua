local grpFlowTerminal = FXGroup:new();
local grpSpace = FXGroup:new();
local element1Name;
local element2NameArr = {};
local isErrorNotFound = true

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_10_A_GREASE_TRAP_B")
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpFlowTerminal = grpFlowTerminal + v;
				grpFlowTerminal = grpFlowTerminal:Unique();
			end
		end
	end

	for k,v in pairs(GrpObjsBuilding) do
		if (k == 3) then
			grpSpace = grpSpace + v;
			grpSpace = grpSpace:Unique();
		end
	end

	local Values1 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
		end
	end

	element1Name = Values1[1]
	for k,v in pairs(Values1) do
		if k ~= 1 then
			element1Name = element1Name.." or "..v
		end
	end

	local grpFlowTerminalParse = Building:GetDescendants("FlowTerminal")
	grpFlowTerminalParse:ForEach(function ( FlowTerminal )
		if (FXUtility.HasPatterInString(FlowTerminal:GetAttri("ObjectType"),"Grease Trap")) then
			grpFlowTerminal:Add(FlowTerminal)
			grpFlowTerminal = grpFlowTerminal:Unique();
		end
	end)
end

function checkRule(Building)
	
	if(#grpFlowTerminal == 0) then
		FXUtility.DisplaySolid_Warning(Building, "No Grease Trap to check.");
		return;
	end
	local ARRCObj1 = {}

	grpFlowTerminal:ForEach(function (obj1)

		local msgComp = true;
		local wasteProj =  FXMeasure.GetObjProjection(obj1, 0);

		grpSpace:ForEach(function (obj)

			local parentObj = obj:GetParent();
			if FXUtility.IsFirstStorey(parentObj) then
				local spaceProj =  FXMeasure.GetObjProjection(obj, 0);
				local tempprjCoverdGrp = FXMeasure.IntersectTwoProjection(spaceProj,wasteProj, 0);
				local area = FXUtility.Round(FXMeasure.GetProjectionArea(tempprjCoverdGrp)/1000000, 2);
				if( area ~= 0 ) then
					msgComp = false;
				end
			end
		end)
		if( msgComp ) then
			if not CheckIfNearSpace(parentObj, grpSpace, grpFlowTerminal ) then
				-- local isCircular = FXMeasure.GetCircularFacesInDirection(obj1, 0);
				local closetEdge = FXMeasure.GetOuterEdge(FXMeasure.GetTopFace(obj1))
				local PolyLinePointNumber = closetEdge:GetPointNumber()
				-- print(PolyLinePointNumber)
				if( PolyLinePointNumber > 5 ) then
					table.insert(ARRCObj1, obj1)
					-- FXUtility.DisplaySolid_Info(obj1, element1Name.." is provided outside food shop area.", topFace);
				else
					FXUtility.DisplaySolid_Error(obj1, "Non-compliant Grease Trap found.");
					isErrorNotFound = false
				end
			end
		else
			FXUtility.DisplaySolid_Error(obj1, obj1:GetAttri("ObjectType").." is within food shop area.");
			isErrorNotFound = false
		end
	end)

	if isErrorNotFound then
		for k,obj1 in pairs(ARRCObj1) do
			FXUtility.DisplaySolid_Info(obj1, element1Name.." is provided outside food shop area.");
		end
	end

end

function CheckIfNearSpace(BuildingStorey, grpSpace, grpGrease)
	
	local isNearSpace = false;
	grpSpace:ForEach(function(obj)
		
		local parentObj = obj:GetParent();
		if FXUtility.IsFirstStorey(parentObj) then
	
			local spaceObb = FXGeom.GetBoundingOBB(obj);
			local spaceHt = spaceObb:MaxPnt().z - spaceObb:MinPnt().z;
			local grpWalls = obj:GetConnectedWall();
			local grpColumns = obj:GetConnectedColumns();
			
			local grpWalls = grpWalls:Filter(function(obj1)
				local obb = FXGeom.GetBoundingOBB(obj1);
				local ht = obb:MaxPnt().z - obb:MinPnt().z;
				if( spaceHt <= 2100 ) then
					return true;
				end
			end)
			
			local allBarriers = grpWalls + grpColumns;
			allBarriers = allBarriers:Unique();
			local openings = obj:GetConnectedOpeningElements();
			
			local openingProj = FXMeasure.GetProjection(openings, 0);
			local barrierProj = FXMeasure.GetProjection(allBarriers, 0);
			
			prjSlab = FXMeasure.SubtractProjection(barrierProj, openingProj, 0);

			local faces = FXMeasure.GetBottomFace(obj);
			local solidObj = FXMeasure.CreateShellsolid(faces);
			local solidObj =  FXMeasure.ShrinkFace(solidObj, 4);
			local PolyLine = FXMeasure.GetOuterEdge(solidObj);
			
			local node = FXUtility.CreateNodeFrom(prjSlab);
			
			local polyline = faces:GetMainFace();
			local noOfPnt = polyline:GetPointNumber(); 
			
			local grpNearGrease = FXGroup:new();
			
			for i = 1, noOfPnt -1, 1  do
				local pnt1 = polyline:GetPoint(i-1);
				local pnt2 = polyline:GetPoint(i);
				local edgeLine = Line3D(pnt1,pnt2);
				
				local line = FXGFA.ShrinkageLine(edgeLine,100);
				local nodeTemp = FXUtility.CreateNodeFrom(line);
				
				local distance = FXMeasure.Distance(node, nodeTemp);
				
				if( distance:Length() > 0 ) then
					grpGrease:ForEach(function(objGrease)
						local extendedFace = FXMeasure.CreateFaceFromEdge(edgeLine,3000);
						local nodeTemp1 = FXUtility.CreateNodeFrom(extendedFace);
						local dist = FXMeasure.Distance(nodeTemp1, objGrease);
						if( dist:Length() < 200 ) then
							--FXUtility.DisplaySolid_Error(obj, obj:GetAttri("LongName").." and "..objGrease:GetAttri("Name").." are not separated by walls.", extendedFace);
							grpNearGrease:Add(objGrease);
						end
						FXClashDetection.DeleteNode(nodeTemp1);
					end)
				end
				
				FXClashDetection.DeleteNode(nodeTemp);
			end
			
			if( #grpNearGrease ~= 0 ) then
				isNearSpace = true;
				grpGrease:ForEach(function(objGrease)
					isErrorNotFound = false
					FXUtility.DisplaySolid_Error(obj, obj:GetAttri("ObjectType").." and "..objGrease:GetAttri("ObjectType").." are not separated by walls.");
					CheckReport.AddRelatedObj(objGrease, objGrease:GetAttri("ObjectType"))
				end)
			end
			
			FXClashDetection.DeleteNode(node);
		end
	end)
	
	return isNearSpace;
end