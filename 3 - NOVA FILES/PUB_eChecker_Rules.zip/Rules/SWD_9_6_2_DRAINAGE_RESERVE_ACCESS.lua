local DrainageReserveGrp = FXGroup.new()
local AccessRoadGrp = FXGroup.new()
local BuildingElementProxyGrp = FXGroup.new()
local bollardGrp=FXGroup.new()
local chainGrp=FXGroup.new()

local ArrProp= {};
local ArrVal= {};
local i = 0;

function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SWD_9_6_2_DRAINAGE_RESERVE_ACCESS");
  local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
  local tblValues = FXRule.filterTableValues(parsedXml, Building)
  -- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  -- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2) then
      DrainageReserveGrp = DrainageReserveGrp + v;
      DrainageReserveGrp = DrainageReserveGrp:Unique();
    end
    if (k == 3) then
      AccessRoadGrp = AccessRoadGrp + v;
      AccessRoadGrp = AccessRoadGrp:Unique();
    end
    if (k == 4) then
      BuildingElementProxyGrp = BuildingElementProxyGrp + v;
      BuildingElementProxyGrp = BuildingElementProxyGrp:Unique();
    end

  end

  for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 3) then
				property = v1["property"];	
				value = v1["value"];	
				i = i + 1
				ArrProp[i] = property
				ArrVal[i] = value		
			end
		end	
		for k1,v1 in pairs(v) do
			if (k == 1) then
				space1Prop = v1["property"];
				space1Value = v1["value"];
			end
		end
		for k1,v1 in pairs(v) do
			if (k == 2) then
				space2Prop = v1["property"];
				space2Value = v1["value"];
			end
		end
	end

end

function checkRule(Building)

local value1;
local value2;
local prop1;
local prop2;

for i,prop in pairs(ArrProp) do
	value1 =  ArrVal[1]
	prop1 = prop
	value2 =  ArrVal[2]
	prop2 = prop
end

	local check = true;
	if #DrainageReserveGrp == 0 then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"Drainage Reserve not provided.")
	end

	if #AccessRoadGrp == 0 then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"Access Road not provided.")
	end

	BuildingElementProxyGrp:ForEach(function(bepEle)
		if FXUtility.HasPatterInString(bepEle:GetAttri(prop1),value1) == true then 
			bollardGrp:Add(bepEle)
		end

		if FXUtility.HasPatterInString(bepEle:GetAttri(prop2),value2) == true then 
			chainGrp:Add(bepEle)
		end
	end)

	if check then
		local IsComplaint = true
		local ARRObjDrainage = {}
		local ARRGRPbollard = {}
		local ARRGRPChain = {}
		local i = 0
		DrainageReserveGrp:ForEach(function(DRele)
			if #bollardGrp <2 or #chainGrp <2 then
				FXUtility.DisplaySolid_Error(DRele:GetParent(),DRele:GetAttri(space1Prop) .. ":Access from road not provided.")
				CheckReport.AddRelatedObj(DRele,DRele:GetAttri(space1Prop))
			else
				local connectedSpaces = DRele:GetConnectedSpaces()
				local elementsInSpaceGrp=FXGroup.new()
				local AccessRoad;
				connectedSpaces:ForEach(function(connectedEle)
					if FXUtility.HasPatterInString(connectedEle:GetAttri(space2Prop),space2Value) == true then
		      			elementsInSpaceGrp = connectedEle:GetInSpaceElement()
		      			AccessRoad = connectedEle;
		     		end
				end)

				local bollardGrp2 = FXGroup.new()
				local chainGrp2 = FXGroup.new()
				elementsInSpaceGrp:ForEach(function(ele)
					if FXUtility.HasPatterInString(ele:GetAttri(prop1),value1) == true then 
						bollardGrp2:Add(ele)
					end

					if FXUtility.HasPatterInString(ele:GetAttri(prop2),value2) == true then 
						chainGrp2:Add(ele)
					end
				end)
				
				if #bollardGrp2 >= 2 and #chainGrp2 >= 2 then
					--when compliant
					i = i + 1
					ARRObjDrainage[i] = DRele
					ARRGRPbollard[i] = bollardGrp2
					ARRGRPChain[i] = chainGrp2
				else
					--when not complaint
					IsComplaint = false
					FXUtility.DisplaySolid_Error(DRele:GetParent(),DRele:GetAttri(space1Prop) .. ":Access from road provided.")
					CheckReport.AddRelatedObj(DRele,DRele:GetAttri(space1Prop))
				end
			end	
		end)
		
		if IsComplaint then
			for i,DRele in pairs(ARRObjDrainage) do
				FXUtility.DisplaySolid_Info(DRele:GetParent(),DRele:GetAttri(space1Prop) .. ":Access from road provided.")
				CheckReport.AddRelatedObj(DRele,DRele:GetAttri(space1Prop))
				ARRGRPbollard[i]:ForEach(function(bollardEle)
					CheckReport.AddRelatedObj(bollardEle,bollardEle:GetAttri(property))		
				end)

				ARRGRPChain[i]:ForEach(function(chainEle)
					CheckReport.AddRelatedObj(chainEle,chainEle:GetAttri(property))		
				end)
			end
		end		
	end
end 