local grpManhole = FXGroup:new()
local grpPipe = FXGroup:new()
local grpPipeCon1 = FXGroup:new()
local grpPipeCon2 = FXGroup:new()
local flag = true
function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_9_B_SEWER_AND_CONNECTIONS_TO_MANHOLES")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjsSystem) do
		
		if (k == 2) then
			grpManhole = grpManhole + v;
			grpManhole = grpManhole:Unique();
		end
		if (k == 3) then
			grpPipe = grpPipe + v;
			grpPipe = grpPipe:Unique();
		end
	end
end

function checkRule(Building)
		grpManhole:ForEach(function( Manhole )
			local CheckPipe = nil
			local grpCompliatPipes1 = FXGroup:new()
			local grpCompliatPipes2 = FXGroup:new()
			local compliantGrp = FXGroup:new()
			grpPipe:ForEach(function( Pipe )
				if FXClashDetection.IsCollided(Manhole,Pipe) then
					if CheckPipe == nil then
						CheckPipe = Pipe
					else
						local pipeDiam1 = FXPUB.GetDiameter(CheckPipe)
						local pipeDiam2 = FXPUB.GetDiameter(Pipe)
						local Pipe1HighPos = FXGeom.GetBoundingBox(CheckPipe):HighPos().z
						local Pipe2HighPos = FXGeom.GetBoundingBox(Pipe):HighPos().z
						local Pipe1LowPos = FXGeom.GetBoundingBox(CheckPipe):LowPos().z
						local Pipe2LowPos = FXGeom.GetBoundingBox(Pipe):LowPos().z

						if pipeDiam1 == 150 and pipeDiam2 == 200 then
							Pipe1LowPos = (math.floor(Pipe1LowPos/10)*10)
							Pipe2LowPos = (math.floor(Pipe2LowPos/10)*10)
							
							if Pipe1LowPos == Pipe2LowPos then
								grpCompliatPipes2:Add(Pipe)
							else
								FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on invert levels.");
								CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
								CheckReport.AddRelatedObj(CheckPipe, Pipe:GetAttri("Name"))
								flag = false
							end

						elseif pipeDiam1 == 200 and pipeDiam2 == 150 then
							Pipe1LowPos = (math.floor(Pipe1LowPos/10)*10)
							Pipe2LowPos = (math.floor(Pipe2LowPos/10)*10)
							
							if Pipe1LowPos == Pipe2LowPos then
								grpCompliatPipes2:Add(Pipe)
							else
								
								FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on invert levels.");
								CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
								CheckReport.AddRelatedObj(CheckPipe, Pipe:GetAttri("Name"))
								flag = false
							end
						else
							Pipe1HighPos = (math.floor(Pipe1HighPos/10)*10)
							Pipe2HighPos = (math.floor(Pipe2HighPos/10)*10)
							if Pipe1HighPos == Pipe2HighPos then
								grpCompliatPipes1:Add(Pipe)
							else
								FXUtility.DisplaySolid_Error(Manhole,"Sewer pipes are not aligned on soffit levels.");
								CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
								CheckReport.AddRelatedObj(CheckPipe, Pipe:GetAttri("Name"))
								flag = false
							end
						end
					end
				end
			end)

			if flag == true then
				grpCompliatPipes2:ForEach(function ( PipeCompliant2 )
					FXUtility.DisplaySolid_Info(Manhole,"Sewer pipes are aligned on invert levels.");
					CheckReport.AddRelatedObj(PipeCompliant2, PipeCompliant2:GetAttri("Name"))
					CheckReport.AddRelatedObj(CheckPipe, CheckPipe:GetAttri("Name"))
				end)
				grpCompliatPipes1:ForEach(function ( PipeCompliant1 )
					FXUtility.DisplaySolid_Info(Manhole,"Sewer pipes are aligned on soffit levels.");
					CheckReport.AddRelatedObj(PipeCompliant1, PipeCompliant1:GetAttri("Name"))
					CheckReport.AddRelatedObj(CheckPipe, CheckPipe:GetAttri("Name"))	
					
				end)
			end 
		end)
end
