local overflowPipe = FXGroup.new();
local floorTrap = FXGroup.new();
local waterTank = FXGroup.new();
local spaceType = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser( Building )
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_19_E_DISCHARGE_OF_OVERFLOW_PIPES")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			overflowPipe = overflowPipe + v;
			overflowPipe = overflowPipe:Unique();
		end

		if (k == 3) then
			floorTrap = floorTrap + v;
			floorTrap = floorTrap:Unique();
		end

		if (k == 4) then
			waterTank = waterTank + v;
			waterTank = waterTank:Unique();
		end

		if (k == 5) then
			spaceType = spaceType + v;
			spaceType = spaceType:Unique();
		end
	end
end

function CheckRule( Building )
	local flag = true;
	local OverflowPipe = {};
	local FloorTrap = {};

	if (#spaceType ~= 0) then
		spaceType : ForEach(function ( space )
			if (#waterTank ~= 0) then
				local bottomFace = FXMeasure.GetBottomFace(space);
				local Box = FXGeom.GetBoundingBox(space);
				local extrudeFace = bottomFace:ExtrudedFace(Vector(0,0,Box:HighPos().z - Box:LowPos().z));
				local node = FXUtility.CreateNodeFrom(extrudeFace);
				waterTank : ForEach(function ( tank )
					if (FXClashDetection.IsCollided(tank,node)) then
						if (#floorTrap ~= 0) then
							overflowPipe : ForEach(function ( pipe )
								if (FXPUB.IsObjsConnected(tank , pipe , 10)) then
									if (FXClashDetection.IsCollided(pipe,node)) then
										floorTrap : ForEach(function ( floortrap )
											if (FXClashDetection.IsCollided(floortrap,node)) then
												table.insert(OverflowPipe, pipe);
												table.insert(FloorTrap, floortrap);
											end
										end)
									else
										flag = false;
										FXUtility.DisplaySolid_Error(pipe, pipe:GetAttri("ObjectType") .. " : Protrudes outside potable water tank /pump room.");
									end
								end
							end)
						else
							flag = false;
							FXUtility.DisplaySolid_Error(space, space:GetAttri("LongName") .. " : Proper drainage is not provided.");
						end
					end
				end)
			else
				flag = false;
				FXUtility.DisplaySolid_Error(space,"Water Tank is not provided.");
			end
		end)
	else
		flag = false;
		FXUtility.DisplaySolid_Warning(Building,"Tank/Pump Room is not provided.");
	end

	if (flag) then
		for i = 1, #OverflowPipe do
			FXUtility.DisplaySolid_Info(OverflowPipe[i], OverflowPipe[i]:GetAttri("ObjectType") .. " : Discharge within the potable water tank/pump room.")
		end

		for x = 1, #FloorTrap do
			FXUtility.DisplaySolid_Info(FloorTrap[x], "Potable water tank/pump room : Floor waste is provided.");
		end
	end
end