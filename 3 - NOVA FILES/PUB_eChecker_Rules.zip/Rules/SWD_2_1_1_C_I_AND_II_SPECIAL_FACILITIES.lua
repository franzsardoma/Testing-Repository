--[[
		Implemented by: Aldrin Lacorte
]]--

local dischargeGrp = FXGroup.new();
local roadGrp = FXGroup.new();
local bldGrp = FXGroup.new();
local storeyGrp = FXGroup.new();
local sitePropTbl = {};
local siteValTbl = {};

local levelObjType;
local levelObjProp;
local levelObjValue;

local roadTypeTbl = {};
local roadPropTbl = {};
local roadValueTbl = {};


local minSouth;
local minNorth;
local minRoad;


local RESULT = "Platform Level:%.2fm; %s; %s; Road Level:%.2fm "
local C_MRL = "Platform Level is above required SHD."
local NC_MRL = "Platform Level is below required SHD."
local C_NC_ROAD = "Platform Level is %.0fmm from Road."
local PL_NO_MATCH = "Project Location does not match.";

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "SWD_2_1_1_C_I_AND_II_SPECIAL_FACILITIES")
	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building)
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition2")
	local ConditionValues2 = FXRule.ParseValues(parsedXml, "Condition3")
	local ConditionValues3 = FXRule.ParseValues(parsedXml, "Condition5")
	local tblValues = FXRule.filterTableValues(parsedXml, Building)

	minSouth = ConditionValues[3]
	minNorth = ConditionValues2[3]
	minRoad = ConditionValues3[3]

	for k,v in pairs(GrpObjs) do 

		if (k == 4) then
			dischargeGrp = dischargeGrp + v
			dischargeGrp = dischargeGrp:Unique()
		end

		if (k == 5) then
			roadGrp = roadGrp + v
			roadGrp = roadGrp:Unique()
		end
	end
	print("roadGrp " .. #roadGrp)
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if (k == 1) then
				levelObjType = v1["type"]
				levelObjProperty = v1["property"]
				levelObjValue = v1["value"]
			end	
			if (k == 2) then
				ObjProperty = v1["property"]
				ObjValue = v1["value"]
				table.insert(sitePropTbl, ObjProperty)
				table.insert(siteValTbl, ObjValue)
			end	
			-- if (k == 4) then
			-- 	ObjType = v1["type"]
			-- 	ObjProperty = v1["property"]
			-- 	ObjValue = v1["value"]
			-- 	table.insert(roadTypeTbl, ObjType)
			-- 	table.insert(roadPropTbl, ObjProperty)
			-- 	table.insert(roadValueTbl, ObjValue)
			-- end	
		end
	end
end

function checkRule(Building)

	local isPassed = true;

	local StoreyAr = {};
	local Requirement = {};
	local SlabAr = {};
	local RoadDiff = {};
	local k = 0;

	local bldgNamePara1 = siteValTbl[3]
	local bldgNamePara2 = siteValTbl[4]
	local bldgProjectAddressPara = {siteValTbl[2], siteValTbl[1]}
	print(siteValTbl[1] .. " " .. siteValTbl[2])
	local Site = Building:GetParent();
	-- local Project = Building:GetParent():GetParent();
	local bldgPDT = FXPUB.GetProjDevelopmentType(Site) --GetPDT(Site)
	if bldgPDT == nil then

		FXUtility.DisplaySolid_Warning(Site, "Project Development Type is not specified.");
		-- return;
		isPassed = false
	elseif not( (FXUtility.HasPatterInString(bldgPDT,bldgNamePara1)) or (FXUtility.HasPatterInString(bldgPDT,bldgNamePara2)) ) then 

		local msg = "Project Development Type does not match.";
		FXUtility.DisplaySolid_Warning(Site, msg);
		-- return;
		isPassed = false
	end

	local bldgPL = FXPUB.GetProjLocation(Site) --GetPL(Site) 
	if bldgPL == nil then
		FXUtility.DisplaySolid_Warning(Site, "Project Location is not specified.");
		isPassed = false
		-- return;
	end
	-- print("ProjDevelopmentType " .. bldgPDT .. " Project Location " .. bldgPL)
	local minMRL;
	if (FXUtility.HasPatterInString(bldgPL,bldgProjectAddressPara[1])) then
		minMRL = minSouth
		-- print(bldgProjectAddressPara[1] .. minSouth)
	elseif (FXUtility.HasPatterInString(bldgPL,bldgProjectAddressPara[2])) then
		minMRL = minNorth
		-- print(bldgProjectAddressPara[2] .. minNorth)
	else
		print("else")
		local msg = "Project Location does not match.";
		FXUtility.DisplaySolid_Warning(Site, msg);
		isPassed = false
		-- return;
	end

	-- //Getting the 1st storey and elevation (temp)
	local storeys = Building:GetChildren("BuildingStorey")
	storeys:ForEach(function(storey)
		if ( FXUtility.HasPatterInString(storey:GetAttri("Name"), levelObjValue)) then
			firstStSlabGrp = storey:GetDescendants(levelObjType)
			LevelElev = storey:Elevation()
		end
	end)
	--[[
		Grouping of Road based from Building Storey "Road" and Slab "Road"
		local road = Building:GetChildren(roadTypeTbl[2])
		local slab = Building:GetDescendants(roadTypeTbl[1])
		road:ForEach(function(storey)
			if ( FXUtility.HasPatterInString(storey:GetAttri(roadPropTbl[2]), roadValueTbl[2])) then
				slab:ForEach(function(slabs)
				if ( FXUtility.HasPatterInString(slabs:GetAttri(roadPropTbl[1]), roadValueTbl[1])) then
					roadGrp:Add(slabs)
				end
				end)
			end
		end)
	]]
	if #firstStSlabGrp == 0 then
		FXUtility.DisplaySolid_Warning(Site, "No First Storey found.");
		isPassed = false
	end
	if #roadGrp == 0 then
		FXUtility.DisplaySolid_Warning(Site, "No Road Storey found.");
		isPassed = false
	end
	if #dischargeGrp == 0 then
		FXUtility.DisplaySolid_Warning(Site, "No Vertical Grating found.");
		isPassed = false
	end

	if isPassed then
		local isCompliant = true

		local lowestSlabElev, lowestSlab;
		firstStSlabGrp:ForEach(function (slab)
			local slabElev = FXGeom.GetBoundingBox(slab):HighPos().z;
			if lowestSlabElev == nil then
				lowestSlabElev = slabElev
			elseif lowestSlabElev > slabElev then
				lowestSlabElev = slabElev
				lowestSlab = slab
			end
		end)
		print("Platform lvl " .. lowestSlabElev)
		-- FXPUB.DisplayTest(lowestSlab, "lowestSlab")

		local storeys = Building:GetChildren("BuildingStorey")
		storeys:ForEach(function (storey)
			if ( FXUtility.HasPatterInString(storey:GetAttri("Name"), levelObjValue) or 
				FXUtility.HasPatterInString(storey:GetAttri("Name"), "storey 01")) then
				-- // COMPARE TIME \\

				local platformLvl = lowestSlabElev

				-- MRL computation
				local SiteRefElev = Building:GetParent()
				local calculatedMRL = (minMRL - (SiteRefElev:GetAttri("RefElevation") + LevelElev)) + LevelElev

				local roadElev = FXPUB.GetRoadElevation(dischargeGrp, roadGrp)
				-- local roadElev = newDistance:GetEndPoint().z
				minRoad = minRoad + roadElev 

				local platform = FXPUB.SetStandardMrl(platformLvl)
				local roadElevation = FXPUB.SetStandardMrl(roadElev)

				RESULT = string.format(RESULT, 
					platform, bldgPL, bldgPDT, roadElevation )
				print(RESULT)
				
				local roadDiff = platformLvl - roadElev

				--[[ platform should be above the mrl or road
						local requirement, str, roadDiff;
						the platform should be above the mrl or road (whichever is the highest) 
						if calculatedMRL >= minRoad then
							requirement = calculatedMRL
						else
							requirement = minRoad 
							roadDiff = platformLvl - roadElev
						end

						if platformLvl >= requirement then
							print("COMPLIANT")

						else
							print("NON COMPLIANT")
							if roadDiff == nil then print("roadDiff is nil.") end
							DisplayResult(storey, requirement, lowestSlab, false, roadDiff)
						end
				]]--

				-- platform should be above the mrl and road 
				if platformLvl >= calculatedMRL and platformLvl >= minRoad then 
					-- check the highest between calculatedMRL and minRoad
					print("COMPLIANT")
					if calculatedMRL >= minRoad then --COMPLIANT MRL
						print("calculatedMRL " .. calculatedMRL)
						StoreyAr[k] = storey
						Requirement[k] = calculatedMRL
						SlabAr[k] 	= lowestSlab
					else --COMPLIANT ROAD
						print(minRoad .. "minRoad")
						StoreyAr[k] =storey
						Requirement[k] = minRoad
						SlabAr[k] = lowestSlab
						RoadDiff[k] = roadDiff	
					end
					k = k + 1;
				else
					isCompliant = false;
					if platformLvl < calculatedMRL then --NONCOMPLIANT MRL
						DisplayResult(storey, calculatedMRL, lowestSlab, false)
					elseif platformLvl < minRoad then --NONCOMPLIANT ROAD
						DisplayResult(storey, minRoad, lowestSlab, false, roadDiff)
					end
				end
				return false
			end
		end)
	
		if isCompliant then
			for j,storey in pairs(StoreyAr) do
				if RoadDiff[j] == nil then print("roadDiff is nil.") else print("roadDiff " .. RoadDiff[j]) end
				DisplayResult(storey, Requirement[j], SlabAr[j], true, RoadDiff[j])
			end
		end	
	else
		return;
	end
end

function DisplayResult(storey, mRL, lowestSlab, isPassed, roadDiff)

	local storeyOBB = FXGeom.GetBoundingBox(storey)
	local roadNode = FXUtility.CreateNodeFrom(storeyOBB);
	local prj = FXMeasure.GetObjProjection(roadNode, mRL)
	FXClashDetection.DeleteNode(roadNode);

	-- DisplayTest(storey, "mrlPrj", mrlPrj)

	if isPassed then
		FXUtility.DisplaySolid_Info(storey, RESULT);
		CheckReport.AddRelatedGeometry_SupportedInfo(prj)
		if roadDiff == nil then -- mrlDiff
			CheckReport.AddRelatedObj( lowestSlab, C_MRL );
		else -- roadDiff
			CheckReport.AddRelatedObj( lowestSlab, string.format(C_NC_ROAD, roadDiff));
		end
	else
		FXUtility.DisplaySolid_Error(storey, RESULT);
		if roadDiff == nil then -- mrlDiff
			CheckReport.AddRelatedObj( lowestSlab, NC_MRL );
			CheckReport.AddRelatedGeometry_SupportedInfo(prj)
		else -- roadDiff
			CheckReport.AddRelatedObj( lowestSlab, string.format(C_NC_ROAD, roadDiff));
			CheckReport.AddRelatedGeometry_SupportedInfo(prj)			
		end

		local prjNode = FXUtility.CreateNodeFrom(prj);
		local distance = FXMeasure.Distance(prjNode, lowestSlab)
		FXClashDetection.DeleteNode(prjNode);
		print("dist Prj to lowestSlab " .. distance:Length())
		if distance:Length() >= 5 then
	   		local arrow = DoubleArrow(distance:GetStartPoint(), distance:GetEndPoint());
			CheckReport.AddRelatedGeometry_Error(arrow, "")
		end
	end
end