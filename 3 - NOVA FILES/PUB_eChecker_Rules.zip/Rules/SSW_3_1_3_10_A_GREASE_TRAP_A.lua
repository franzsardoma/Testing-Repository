-- Modified by: Lawrence Roy R. Quiling 1/4/2019

local GrpSpace = FXGroup.new();
local FlowTerminalName = {"grease trap"};
local grpFlowTerminal = FXGroup:new();
local isPassedPool = true;
local isPassedStorage = true;
local SpaceVal, SpaceProp
local FlowTerminalVal, FlowTerminalProp

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath());
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_10_A_GREASE_TRAP_A");
    local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				GrpSpace =  GrpSpace + v;
				GrpSpace =  GrpSpace:Unique();
			end	
		end
	end

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 3) then	
				grpFlowTerminal = grpFlowTerminal + v;
				grpFlowTerminal =  grpFlowTerminal:Unique();
			end	
		end
	end

	local Values1 = {}
	local Values2 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
				SpaceProp = (v1["property"])
			end
			if(k == 2) then
				table.insert(Values2, v1["value"])
				FlowTerminalProp = (v1["property"])
			end
		end
	end

	SpaceVal = getValue(Values1)
	FlowTerminalVal = getValue(Values2)
end

function getValue( tab )
	local value = tab[1]
	local length = #tab

	for k,v in pairs(tab) do
		if k ~= 1 and k ~= length then
			value = value..", "..v
		end
		if k == length then
			value = value.." or "..v
		end
	end
	return value
end

function CheckWarning( Building )
	local flg = true
	if(#grpFlowTerminal == 0) then
		FXUtility.DisplaySolid_Warning(Building, FlowTerminalVal.." is not provided.");
		flg= false
	end
	if(#GrpSpace == 0) then
		FXUtility.DisplaySolid_Warning(Building, SpaceVal.." is not provided.");
		flg= false
	end
	return flg
end

function checkRule(Building)
	if not CheckWarning( Building ) then
		return;
	end

	local msgComp = true;
	local Com_obj1 = {}
	local IsErrorNotFound = true

	grpFlowTerminal:ForEach(function (FlowTerminal)
		local wasteProj =  FXMeasure.GetObjProjection(FlowTerminal, 0);

		GrpSpace:ForEach(function (Space)
			local parentObj = Space:GetParent();

			if FXUtility.IsFirstStorey(parentObj) then
				local spaceProj =  FXMeasure.GetObjProjection(Space, 0);
				local tempprjCoverdGrp = FXMeasure.IntersectTwoProjection(spaceProj,wasteProj, 0);
				local area = FXUtility.Round(FXMeasure.GetProjectionArea(tempprjCoverdGrp)/1000000, 2);
				if( area ~= 0 ) then
					msgComp = false;
				end
			end
		end)

		if( msgComp ) then
			if not CheckIfNearSpace(parentObj, GrpSpace, grpFlowTerminal ) then
				table.insert(Com_obj1,FlowTerminal)
			end
		else
			IsErrorNotFound = false
			FXUtility.DisplaySolid_Error(FlowTerminal, FlowTerminal:GetAttri(FlowTerminalProp)..": Grease Trap is within food shop area.");
			CheckReport.AddRelatedObj(FlowTerminal, FlowTerminal:GetAttri(FlowTerminalProp))
		end
	end)

	if IsErrorNotFound then
		for k,FlowTerminal in pairs(Com_obj1) do
			FXUtility.DisplaySolid_Info(FlowTerminal, FlowTerminal:GetAttri(FlowTerminalProp)..": Grease Trap is outside food shop area.");
			CheckReport.AddRelatedObj(FlowTerminal, FlowTerminal:GetAttri(FlowTerminalProp))
		end
	end
end

function CheckIfNearSpace(BuildingStorey, grpSpace, grpGrease)
	local isNearSpace = false;
	grpSpace:ForEach(function(obj)
		local parentObj = obj:GetParent();
		if FXUtility.IsFirstStorey(parentObj) then
	
			local spaceObb = FXGeom.GetBoundingOBB(obj);
			local spaceHt = spaceObb:MaxPnt().z - spaceObb:MinPnt().z;
			local grpWalls = obj:GetConnectedWall();
			local grpColumns = obj:GetConnectedColumns();
			
			local grpWalls = grpWalls:Filter(function(obj1)
				local obb = FXGeom.GetBoundingOBB(obj1);
				local ht = obb:MaxPnt().z - obb:MinPnt().z;
				if( spaceHt <= 2100 ) then
					return true;
				end
			end)
			
			local allBarriers = grpWalls + grpColumns;
			allBarriers = allBarriers:Unique();
			local openings = obj:GetConnectedOpeningElements();
			
			local openingProj = FXMeasure.GetProjection(openings, 0);
			local barrierProj = FXMeasure.GetProjection(allBarriers, 0);
			
			prjSlab = FXMeasure.SubtractProjection(barrierProj, openingProj, 0);

			local faces = FXMeasure.GetBottomFace(obj);
			local solidObj = FXMeasure.CreateShellsolid(faces);
			local solidObj =  FXMeasure.ShrinkFace(solidObj, 4);
			local PolyLine = FXMeasure.GetOuterEdge(solidObj);
			
			local node = FXUtility.CreateNodeFrom(prjSlab);
			
			local polyline = faces:GetMainFace();
			local noOfPnt = polyline:GetPointNumber(); 
			
			local grpNearGrease = FXGroup:new();
			
			for i = 1, noOfPnt -1, 1  do
				local pnt1 = polyline:GetPoint(i-1);
				local pnt2 = polyline:GetPoint(i);
				local edgeLine = Line3D(pnt1,pnt2);
				
				local line = FXGFA.ShrinkageLine(edgeLine,100);
				local nodeTemp = FXUtility.CreateNodeFrom(line);
				
				local distance = FXMeasure.Distance(node, nodeTemp);
				
				if( distance:Length() > 0 ) then
					grpGrease:ForEach(function(objGrease)
						local extendedFace = FXMeasure.CreateFaceFromEdge(edgeLine,3000);
						local nodeTemp1 = FXUtility.CreateNodeFrom(extendedFace);
						local dist = FXMeasure.Distance(nodeTemp1, objGrease);
						if( dist:Length() < 200 ) then
							--FXUtility.DisplaySolid_Error(obj, obj:GetAttri("LongName").." and "..objGrease:GetAttri("Name").." are not separated by walls.", extendedFace);
							grpNearGrease:Add(objGrease);
						end
						FXClashDetection.DeleteNode(nodeTemp1);
					end)
				end
				
				FXClashDetection.DeleteNode(nodeTemp);
			end
			
			if( #grpNearGrease ~= 0 ) then
				isNearSpace = true;
				grpGrease:ForEach(function(objGrease)
					FXUtility.DisplaySolid_Error(obj, obj:GetAttri(SpaceProp).." and "..objGrease:GetAttri(FlowTerminalProp).." are not separated by walls.");
					CheckReport.AddRelatedObj(objGrease, objGrease:GetAttri(FlowTerminalProp))
					CheckReport.AddRelatedObj(obj, obj:GetAttri(SpaceProp))
				end)
			end
			
			FXClashDetection.DeleteNode(node);
		end
	end)
	
	return isNearSpace;
end