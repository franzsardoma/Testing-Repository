local grpFlowStorage = FXGroup.new();

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parse");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end



function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_9_VERTICAL_DISTANCE_OF_OVERFLOW_PIPES")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	-- local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 5 then
			grpFlowStorage = grpFlowStorage + v
 			grpFlowStorage = grpFlowStorage:Unique()			
		end			
	end
end

function CheckRule(Building)
	local WaterTank;

	if(#grpFlowStorage == 0)then 
		FXUtility.DisplaySolid_Warning(Building,"No Water Storage Tank Found");
		return;
	end
	
	grpFlowStorage:ForEach(function(Element)
		WaterTank = Element;
	end)

	local ConnectedPipes = FXGroup.new();
	local PipesGroup = WaterTank:GetConnectedSegment();
	local FittingsGroup = WaterTank:GetConnectedFitting();

	local InletPipe;
	local OutletPipe;
	local OverflowPipeTop;
	local OverFlowPipeBottom;
	local OverflowPipesGroup = FXGroup.new();
	local NormalPipesGroup = FXGroup.new();

	FittingsGroup:ForEach(function(Element)
		local Count = GetCount(Element, WaterTank);	
		
		if(Count > 2)then 
			NormalPipesGroup:Add(Element);
		else
			OverflowPipesGroup:Add(Element);
		end
	end)


	PipesGroup:ForEach(function(Element)
		local Count = GetCount(Element, WaterTank);	
		print(Element:GetAuxAttri("Entity.Description").." Count ="..Count)		

		if(Count <= 2)then 
			OverflowPipesGroup:Add(Element);
		else
			NormalPipesGroup:Add(Element);
		end
	end)

	
	local HighestObj;
	local TempCheck;
	OverflowPipesGroup:ForEach(function(Element)
		if(TempCheck == nil)then 
			TempCheck = Element;
		else
			local THighPos = FXGeom.GetBoundingBox(TempCheck):HighPos().z;
			local EHighPos = FXGeom.GetBoundingBox(Element):HighPos().z;

			if(THighPos > EHighPos)then 
				HighestObj = TempCheck;
			else
				TempCheck = Element;
				HighestObj = Element;
			end
		end
	end)

	local FurthestObj;
	OverflowPipesGroup:ForEach(function(Element)
		local DistanceCheck = FXMeasure.Distance(HighestObj, Element):Length();		
		if(DistanceCheck > 300)then 
			FurthestObj = Element;
		end
	end)

	OverflowPipesGroup:Sub(FurthestObj);

	print(#OverflowPipesGroup)
	print(#NormalPipesGroup)
	-- print(#NormalPipesGroup)
	if(#NormalPipesGroup == 2)then
		if(#OverflowPipesGroup >= 1)then
			if(#OverflowPipesGroup < 2)then 
				OverflowPipesGroup:ForEach(function(Element)
					OverFlowPipeBottom = Element;
				end)
				----------------------------------------------------------------------------------------
				-- OverflowPipeTop, OverFlowPipeBottom = GetTopAndBottom(OverflowPipesGroup);	
				----------------------------------------------------------------------------------------
				InletPipe, OutletPipe = GetTopAndBottom(NormalPipesGroup);
				----------------------------------------------------------------------------------------
				local OverFlowPipeDiameter = OverFlowPipeBottom:GetAuxAttri("Mechanical.Diameter");
				----------------------------------------------------------------------------------------
				local InletOBB = FXGeom.GetBoundingOBB(InletPipe);
				local CenterXInlet = (InletOBB:MaxPnt().x + InletOBB:MinPnt().x)/2;
				local CenterYInlet = (InletOBB:MaxPnt().y + InletOBB:MinPnt().y)/2;
				local InletZ = InletOBB:MinPnt().z;
				local PointInlet = Point3D(CenterXInlet, CenterYInlet, InletZ);
				----------------------------------------------------------------------------------------
				-- local OBB1 = FXGeom.GetBoundingOBB(OverflowPipeTop);
				local OBB2 = FXGeom.GetBoundingOBB(OverFlowPipeBottom);
				----------------------------------------------------------------------------------------
				local CenterX = (OBB1:MaxPnt().x + OBB1:MinPnt().x)/2;
				local CenterY = (OBB1:MaxPnt().y + OBB1:MinPnt().y)/2;
				----------------------------------------------------------------------------------------
				local Z1 = OBB1:MaxPnt().z;
				----------------------------------------------------------------------------------------
				local Point1 = Point3D(CenterX, CenterY, Z1);
				----------------------------------------------------------------------------------------
				local InletAndOverflowDistance = FXUtility.Round(Line3D(Point1, PointInlet):Length(),0);
				----------------------------------------------------------------------------------------
				-- print(InletAndOverflowDistance)
				print(InletAndOverflowDistance.." >= "..OverFlowPipeDiameter)
				if(InletAndOverflowDistance >= tonumber(OverFlowPipeDiameter))then 
					
				else
					FXUtility.DisplaySolid_Error(InletPipe,InletPipe:GetAuxAttri("Entity.Description").." Vertical distance = "..InletAndOverflowDistance.."; Vertical level is below "..OverFlowPipeBottom:GetAuxAttri("Entity.Description"));
				end

			else
				----------------------------------------------------------------------------------------
				OverflowPipeTop, OverFlowPipeBottom = GetTopAndBottom(OverflowPipesGroup);	
				----------------------------------------------------------------------------------------
				InletPipe, OutletPipe = GetTopAndBottom(NormalPipesGroup);
				----------------------------------------------------------------------------------------
				local OverFlowPipeDiameter = OverFlowPipeBottom:GetAuxAttri("Mechanical.Diameter");
				----------------------------------------------------------------------------------------
				local InsideDiameter;
				local OutsideDiameter;
				local PipeThickness;
				local InletDescription;
				----------------------------------------------------------------------------------------
				if(InletPipe.Type == "FlowSegment")then 
					InsideDiameter = InletPipe:GetAuxAttri("Dimensions.Inside Diameter");
					OutsideDiameter =  InletPipe:GetAuxAttri("Dimensions.Outside Diameter");
					PipeThickness = OutsideDiameter - InsideDiameter;
					------------------------------------------------------------------------------------
					InletDescription = InletPipe:GetAuxAttri("Entity.Description");
				else
					OutsideDiameter = InletPipe:GetAuxAttri("Dimensions.Maximum Size");
					InsideDiameter =  InletPipe:GetAuxAttri("Dimensions.Minimum Size");
					PipeThickness = OutsideDiameter - InsideDiameter;
					------------------------------------------------------------------------------------
				end
				----------------------------------------------------------------------------------------
				local OverFlowInsideDiameter = OverFlowPipeBottom:GetAuxAttri("Dimensions.Inside Diameter");
				local OverFlowOutsideDiameter = OverFlowPipeBottom:GetAuxAttri("Dimensions.Outside Diameter");
				local OverFlowPipeThickness = OverFlowOutsideDiameter - OverFlowInsideDiameter;
				----------------------------------------------------------------------------------------
				local InletOBB = FXGeom.GetBoundingOBB(InletPipe);
				local CenterXInlet = (InletOBB:MaxPnt().x + InletOBB:MinPnt().x)/2;
				local CenterYInlet = (InletOBB:MaxPnt().y + InletOBB:MinPnt().y)/2;
				local InletZ = InletOBB:MinPnt().z + PipeThickness;
				----------------------------------------------------------------------------------------
				local InletX;
				if(InletPipe.Type == "FlowFitting")then 
					InletX = InletOBB:MinPnt().x;
				else
					InletX = InletOBB:MaxPnt().x;
				end
				----------------------------------------------------------------------------------------
				local PointInlet = Point3D(InletX, CenterYInlet, InletZ);
				----------------------------------------------------------------------------------------
				local OBB1 = FXGeom.GetBoundingOBB(OverflowPipeTop);
				local CenterX = (OBB1:MaxPnt().x + OBB1:MinPnt().x)/2;
				local CenterY = (OBB1:MaxPnt().y + OBB1:MinPnt().y)/2;
				local Z1 = OBB1:MaxPnt().z + OverFlowPipeThickness;
				----------------------------------------------------------------------------------------
				local OBB2 = FXGeom.GetBoundingOBB(OverFlowPipeBottom);
				local CenterX2 = (OBB2:MaxPnt().x + OBB2:MinPnt().x)/2;
				local CenterY2 = (OBB2:MaxPnt().y + OBB2:MinPnt().y)/2;
				local Z2 = OBB2:MinPnt().z - OverFlowPipeThickness;
				----------------------------------------------------------------------------------------
				local Point1 = Point3D(InletX, CenterYInlet, Z1);
				local Point2 = Point3D(CenterX2,OBB2:MinPnt().y, Z2);
				----------------------------------------------------------------------------------------
				local Point11 = Point3D(CenterX, OBB1:MinPnt().y, Z1);
				----------------------------------------------------------------------------------------
				local Point22 = Point3D(InletX, CenterYInlet, Z1);				
				----------------------------------------------------------------------------------------
				local Distance = FXUtility.Round(Line3D(Point11, Point2):Length(),0);
				----------------------------------------------------------------------------------------
				local InletAndOverflowDistance = FXUtility.Round(Line3D(Point1, PointInlet):Length(),0);
				----------------------------------------------------------------------------------------
				local OverFlowDescription = OverFlowPipeBottom:GetAuxAttri("Entity.Description");
				----------------------------------------------------------------------------------------

				local Arrow = DoubleArrow(Point1, PointInlet);
				local PlyLine = PolyLine3D(TRUE);
				PlyLine:AddPoint(Point11);
				PlyLine:AddPoint(Point22);

				local ArrowOverFlow = DoubleArrow(Point11, Point2);

				if(InletPipe.Type == "FlowFitting")then
					local ConnectedPipeToInlet = InletPipe:GetConnectedSegment();
					ConnectedPipeToInlet:ForEach(function(Element)
						InletPipe = Element;
					end)
					------------------------------------------------------------------------------------
					InletDescription = InletPipe:GetAuxAttri("Entity.Description");	
				end

				-- print(InletAndOverflowDistance.." >= "..OverFlowPipeDiameter)
				if(InletAndOverflowDistance >= tonumber(OverFlowPipeDiameter))then 
					-- print(Distance.." >= "..OverFlowPipeDiameter)
					if(Distance >=  tonumber(OverFlowPipeDiameter))then
						FXUtility.DisplaySolid_Info(InletPipe,InletDescription.." Vertical Distance = "..math.floor(InletAndOverflowDistance).."mm; Distance between the two "..OverFlowDescription.." = "..Distance.."mm");
						------------------------------------------------------------------------------------
						CheckReport.AddRelatedGeometry_Solid(PlyLine);
						CheckReport.AddRelatedGeometry_Solid(Arrow);
						CheckReport.AddRelatedGeometry_Solid(ArrowOverFlow);
						------------------------------------------------------------------------------------
						CheckReport.AddRelatedObj(OverflowPipeTop,OverflowPipeTop:GetAttri("Name"));
						CheckReport.AddRelatedObj(OverFlowPipeBottom,OverFlowPipeBottom:GetAttri("Name"));
						CheckReport.AddRelatedObj(WaterTank,WaterTank:GetAttri("Name"));
						------------------------------------------------------------------------------------
					else
						FXUtility.DisplaySolid_Error(OverFlowPipeBottom,OverFlowDescription.." Distance is below "..OverFlowPipeDiameter.." Diameter");
					end
				else
					FXUtility.DisplaySolid_Error(InletPipe,InletDescription.." Vertical Distance = "..math.floor(InletAndOverflowDistance).."mm; Distance between the two "..OverFlowDescription.." = "..Distance.."mm");
					------------------------------------------------------------------------------------
					CheckReport.AddRelatedGeometry_Error(PlyLine);
					CheckReport.AddRelatedGeometry_Error(Arrow);
					CheckReport.AddRelatedGeometry_Error(ArrowOverFlow);
					------------------------------------------------------------------------------------
					CheckReport.AddRelatedObj(OverflowPipeTop,OverflowPipeTop:GetAttri("Name"));
					CheckReport.AddRelatedObj(OverFlowPipeBottom,OverFlowPipeBottom:GetAttri("Name"));
					CheckReport.AddRelatedObj(WaterTank,WaterTank:GetAttri("Name"));
				end
			end
		else
			FXUtility.DisplaySolid_Error(Building,"No Overflow Pipe is found");	
		end
	else
		FXUtility.DisplaySolid_Error(Building,"No Inlet Pipe is found");
	end



	-- FXUtility.DisplaySolid_Info(OverflowPipeTop,"OverflowPipeTop")
	-- FXUtility.DisplaySolid_Info(OverFlowPipeBottom,"OverFlowPipeBottom")
	-- FXUtility.DisplaySolid_Info(InletPipe,"InletPipe")
	-- FXUtility.DisplaySolid_Info(OutletPipe,"OutletPipe")
end


function GetCount( ConnObj, PrevObj )
	if(PrevObj == nil) then
		return;
	end
	local count = 0;
	local grpConnObjs = ConnObj:GetConnectedElement();
	grpConnObjs:Sub(PrevObj)

	grpConnObjs:ForEach(function ( ConnObjEle )
		count = 1;
		count = count + GetCount( ConnObjEle, ConnObj )
	end)
	return count;
end

function GetTopAndBottom(Group)
	local Temp;
	local Top;
	local Bottom;
	Group:ForEach(function(Element)
		if(Temp == nil)then 
			Temp = Element;
		else
			local OBB1 = FXGeom.GetBoundingOBB(Temp);
			local OBB2 = FXGeom.GetBoundingOBB(Element);
			local Mz1 = OBB1:MaxPnt().z;
			local Mz2 = OBB2:MaxPnt().z;
			if(Mz1 > Mz2)then 
				Top = Temp;
				Bottom = Element;
			else
				Top = Element;
				Bottom = Temp;
			end
		end
	end)

	return Top, Bottom;
end
