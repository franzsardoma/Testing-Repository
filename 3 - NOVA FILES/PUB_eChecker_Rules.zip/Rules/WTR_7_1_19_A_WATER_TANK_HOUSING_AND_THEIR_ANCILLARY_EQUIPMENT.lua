local SpaceGrp = FXGroup:new()
local SpaceGrp2 = FXGroup:new()
local FlowDevGrp = FXGroup:new()
local ElemGrp = FXGroup:new()
local systemTypes

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkPresentElements");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkTankPumpSpaces");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_19_A_WATER_TANK_HOUSING_AND_THEIR_ANCILLARY_EQUIPMENT")
	
	-- local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs1 = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes);
	
	-- isRemovable = ConditionValues[1]; -- for Condition Values 

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	-- print(#GrpObjs)		
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			SpaceGrp =   SpaceGrp + v;
			SpaceGrp = SpaceGrp:Unique()
		end	
		if (k == 3) then	
			SpaceGrp2 = SpaceGrp2 + v;
			SpaceGrp2 = SpaceGrp2:Unique()
		end	
		if (k == 5) then	
			ElemGrp = ElemGrp + v;
			ElemGrp = ElemGrp:Unique()
		end	
	end
	-- for k,v in pairs(GrpObjs1) do
	-- 	if (k == 4) then
	-- 		FlowDevGrp =   FlowDevGrp + v;
	-- 		FlowDevGrp = FlowDevGrp:Unique()
	-- 	end		
	-- end	
end

function checkRule(Building)

	local wallCounter = 0
	local wallCounter2 = 0	
	local Door, Door2
	local spaceEle, spaceEle2
	local connWall, connWall2
	local slabAbove, slabAbove2
	local SpaceName, SpaceName2
	local InSpaceElement = false
	local InSpaceElement2 = false
	local connSpace, connSpace2
	local connectedSpaces, connectedSpaces2
	local CheckSpace = 0
	local CheckSpace2 = 0
	local CheckElem = 0

	SpaceGrp:ForEach(function (SpaceObj)
		-- Tank Space

		SpaceName = SpaceObj:GetAttri("LongName")		

		if (FXUtility.HasPatterInString(SpaceName,"Tank")) then
			spaceEle = SpaceObj

			slabAbove = SpaceObj:GetSlabsAbove()				

			connWall = SpaceObj:GetConnectedWall()
			
			connWall:ForEach(function (elem)
				wallCounter = wallCounter + 1
			end)

			ConnDoor = SpaceObj:GetConnectedDoor()
			if (#ConnDoor ~= 0) then
				Door = true
			else
				Door = false
			end

			SpaceGrp2:ForEach(function ( spaceObj2 )
				SpaceName = spaceObj2:GetAttri("LongName")
				if (FXUtility.HasPatterInString(SpaceName,"Telecommunications") or FXUtility.HasPatterInString(SpaceName,"Lift") or FXUtility.HasPatterInString(SpaceName,"Fire Fighting")) then
					if (FXClashDetection.IsCollided(spaceObj2,spaceEle)) then
						connSpace = true
					else
						connSpace = false
					end
				end
			end)

			local aboveEle = SpaceObj:GetInSpaceElement()
			aboveEle:ForEach(function (elem)
				local aboveEleName =  elem:GetAttri("Name")

				if (FXUtility.HasPatterInString(aboveEleName,"Water Tank") or FXUtility.HasPatterInString(aboveEleName,"Water Pump") or FXUtility.HasPatterInString(aboveEleName,"Water Filter") or FXUtility.HasPatterInString(aboveEleName,"Water Heater")) then
					InSpaceElement = true
				end
			end)
			checkTankPumpSpaces( wallCounter, Door, spaceEle, connWall, slabAbove, connSpace, InSpaceElement  )
		-- Pump Space
		elseif (FXUtility.HasPatterInString(SpaceName,"Pump")) then	
			spaceEle2 = SpaceObj
			slabAbove2 = SpaceObj:GetSlabsAbove()
			connWall2 = SpaceObj:GetConnectedWall()
			
			connWall2:ForEach(function (elem)
				wallCounter2 = wallCounter2 + 1
			end)
			ConnDoor = SpaceObj:GetConnectedDoor()
			if (#ConnDoor ~= 0) then
				Door2 = true
			else
				Door2 = false
			end	

			SpaceGrp2:ForEach(function ( spaceObj2 )
				SpaceName2 = spaceObj2:GetAttri("LongName")
				if (FXUtility.HasPatterInString(SpaceName2,"Telecommunications") or FXUtility.HasPatterInString(SpaceName2,"Lift") or FXUtility.HasPatterInString(SpaceName2,"Fire Fighting")) then
					if (FXClashDetection.IsCollided(spaceObj2,spaceEle2)) then
						connSpace2 = true
					else
						connSpace2 = false
					end
				end
				CheckSpace2 = CheckSpace2 + 1
			end)

			local aboveEle2 = SpaceObj:GetInSpaceElement()
			aboveEle2:ForEach(function (elem)
				local aboveEleName =  elem:GetAttri("Name")
				if (FXUtility.HasPatterInString(aboveEleName,"Water Tank") or FXUtility.HasPatterInString(aboveEleName,"Water Pump") or FXUtility.HasPatterInString(aboveEleName,"Water Filter") or FXUtility.HasPatterInString(aboveEleName,"Water Heater")) then
					InSpaceElement2 = true				
				end
				CheckElem = CheckElem + 1
			end)
			checkTankPumpSpaces( wallCounter2, Door2, spaceEle2, connWall2, slabAbove2, connSpace2, InSpaceElement2  )
		end
		CheckSpace = CheckSpace + 1 
	end)

	checkPresentElements( CheckSpace, CheckSpace2, CheckElem, Building )
	
end

function checkPresentElements( CheckPresentSpace, CheckPresentSpace2, CheckPresentElem, Building )
	if (CheckPresentSpace == 0) then
		FXUtility.DisplaySolid_Warning(Building, "There's no Tank and Pump Space. ")
	end

	if (CheckPresentSpace2 == 0) then
		FXUtility.DisplaySolid_Warning(Building, "There's no Telecommunications, Lifts or Fire-Fighting Space. ")
	end

	if (CheckPresentElem == 0) then
		FXUtility.DisplaySolid_Warning(Building, "There's no Ancillary equipments. ")
	end
end

function checkTankPumpSpaces( cntr, door, SpaceEle, ConnWall, SlabAbove, connSpace, inSpaceElement )
	if (cntr == 4 and door == true) then
		FXUtility.DisplaySolid_Info(SpaceEle, SpaceEle:GetAttri("LongName") .." Room ".. SpaceEle:GetAttri("Name").. ": Tank/Pump room is enclosed and lockable.")
		ConnWall:ForEach(function (wallObj)
			CheckReport.AddRelatedObj(wallObj, wallObj:GetAttri("Name"))
		end)
		SlabAbove:ForEach(function (slabObj)
			CheckReport.AddRelatedObj(slabObj, slabObj:GetAttri("Name"))
		end)

	elseif (cntr ~= 4 and door == false) then
		FXUtility.DisplaySolid_Error(SpaceEle, SpaceEle:GetAttri("LongName") .." Room ".. SpaceEle:GetAttri("Name")..": Tank/Pump room cannot be enclosed and locked.")
		ConnWall:ForEach(function (wallObj)
			CheckReport.AddRelatedObj(wallObj, wallObj:GetAttri("Name"))
		end)
		SlabAbove:ForEach(function (slabObj)
			CheckReport.AddRelatedObj(slabObj, slabObj:GetAttri("Name"))
		end)

		if (connSpace == true) then
			FXUtility.DisplaySolid_Warning(SpaceEle, SpaceEle:GetAttri("LongName") .." Room ".. SpaceEle:GetAttri("Name").. ": Ancillary equipments shall be segregated from other services such as services for telecommunications, lifts or fire-fighting.")
			ConnWall:ForEach(function (wallObj)
				CheckReport.AddRelatedObj(wallObj, wallObj:GetAttri("Name"))
			end)
			SlabAbove:ForEach(function (slabObj)
				CheckReport.AddRelatedObj(slabObj, slabObj:GetAttri("Name"))
			end)
		else

		end
		if (inSpaceElement == false) then
			FXUtility.DisplaySolid_Warning(SpaceEle, SpaceEle:GetAttri("LongName") .." Room ".. SpaceEle:GetAttri("Name").. ": Ancillary equipments are not within an adequately secured and locked enclosure.")		
			ConnWall:ForEach(function (wallObj)
				CheckReport.AddRelatedObj(wallObj, wallObj:GetAttri("Name"))
			end)
			SlabAbove:ForEach(function (slabObj)
				CheckReport.AddRelatedObj(slabObj, slabObj:GetAttri("Name"))
			end)
		end

	end
end