local grpManhole = FXGroup.new()
local grpFlowSegment = FXGroup.new()
local minDepth;
local compliantManhole = {}
local compliantDist = {}
local compliantArrowGeom = {}
local isAllCompliant = true;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_7_C_DEPTH_OF_MANHOLE")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition0");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	minDepth = ConditionValues[3];

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpManhole = grpManhole + v;
			grpManhole = grpManhole:Unique();
		end
		if (k == 3) then
			grpFlowSegment = grpFlowSegment + v;
			grpFlowSegment = grpFlowSegment:Unique();
		end
	end
end


function checkRule(Building)
	local flowTermObb;
	if #grpManhole ~= 0 then
		if #grpFlowSegment ~= 0 then
			grpManhole:ForEach(function (Hole)
				local lastDist;
				local arrowGeom;
				local dist;
				local isCompliant = false;
				flowTermObb = FXGeom. GetBoundingBox(Hole)
				grpFlowSegment:ForEach(function (segEle)
					if FXPUB.CheckConnectedChamberElement(Building,Hole,segEle) then
						local invertLevelElevation = tonumber(segEle:GetAuxAttri("Mechanical.Invert Elevation")) + 2
						local flowSegObb = FXGeom. GetBoundingOBB(segEle)
						local flowSegBox = FXGeom. GetBoundingBox(segEle)
						local maxpnt = flowTermObb:HighPos()
						local minpnt = flowSegObb:GetPos()
						local radius = flowSegBox:z_range()/2
						local invertPoint = Point3D(minpnt.x,minpnt.y,minpnt.z - (radius-12)) 
						local newPnt = Point3D(minpnt.x,minpnt.y,maxpnt.z)
						local line = Line3D(invertPoint,newPnt)
						arrowGeom = DoubleArrow(invertPoint,newPnt)
						dist = line:Length()
						-- print(minpnt.z)

						dist = FXUtility.Round(dist)
						
						if dist >= tonumber(minDepth) then
							isCompliant = true
						end
					end
		
				end)

				checkResult( Hole, isCompliant, dist, arrowGeom )
			
			end)

			compliantResult()

		else
			FXUtility.DisplaySolid_Warning(Building,"Public Sewer is not provided.");
		end
	else
		FXUtility.DisplaySolid_Warning(Building,"Manhole is not provided.");
	end
end

function checkResult( Manhole, isCompliant, dist, arrowGeom )
	if isCompliant then
		table.insert(compliantManhole, Manhole)
		table.insert(compliantDist, dist)
		table.insert(compliantArrowGeom, arrowGeom)
	else
		FXUtility.DisplaySolid_Error(Manhole, Manhole:GetAttri("ObjectType").." Depth: "..dist.." mm",arrowGeom)
		isAllCompliant = false
	end
end

function compliantResult()
	if isAllCompliant then
		for i=1, #compliantManhole do
			FXUtility.DisplaySolid_Info(compliantManhole[i], compliantManhole[i]:GetAttri("ObjectType").." Depth: "..compliantDist[i].." mm",compliantArrowGeom[i])
		end
	end
end
