local SystemTypes;
local grpFlowSegment = FXGroup:new();
local parapetWallGrp = FXGroup:new();
local ventSystemPipes = FXGroup:new();
local grpRoof = FXGroup:new();
local minDistance;
local types = {}
local isErrorFound = false
local comObjArr = {}
local comPolyArr = {}
local comArrowArr = {}
local comDistanceArr = {}
local comColSpaceArr = {}
local comObjNameArr = {}
local comObjTypeArr = {}
local x = 0

-- local ventStacksAtSpace = FXGroup:new()

function main()
	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end



function XMLParser(Storey)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_3_4_G_III_VENTILATION_STACK_DISTANCE_FROM_ANY_WINDOW")
	
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml,Building)

	minDistanceParam = ConditionValues[2]
	minDistance = ConditionValues[3];

	for k,v in pairs(tblValues) do    
		for k1,v1 in pairs(v) do
			table.insert( types , v1["type"] )
		end
	end

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpFlowSegment = grpFlowSegment + v
			grpFlowSegment = grpFlowSegment:Unique()
		end
	end
end


function checkRule(Building)
	-- local BuildingStorey = Building:GetChildren("BuildingStorey")
	local otherBuildingWalls = FXGroup.new()

	if #grpFlowSegment ~= 0 then

		local roofSlabs = Building:GetDescendants("Slab")
		local grpWindow = Building:GetDescendants("Window")

		grpFlowSegment:ForEach(function ( pipe )
			local pipeName = pipe:GetAttri("Name")
			local pipeDesc = pipe:GetAuxAttri("Entity.ObjectType")
			local BuildingStorey = pipe:GetParent();
			local slabCollideAtVent;
			local ventStackTerminate = false;
			local isCompliant = false;
			local hasAdjacentWall = false;

			roofSlabs:ForEach(function ( slab )
				
				if FXClashDetection.IsCollided(pipe, slab) then
					-- local slabParent = slab:GetParent();
					local BuildingStorey;
					if FXUtility.HasPatterInString(slab:GetAttri("Name"),  types [2] ) then
						local slabParent = slab:GetParent();
						if FXUtility.HasPatterInString(slabParent:GetAttri("Name"),  types[2]) then
							BuildingStorey = slabParent:GetParent();
						else
							BuildingStorey = slabParent;
						end
						local wallGrp = BuildingStorey:GetDescendants( types [3] )
						local spaceGrp = BuildingStorey:GetDescendants("Space")
						
						local collidedSpace;
					
						slabCollideAtVent = slab
						ventStackTerminate = true;

						if spaceGrp ~= nil then
							spaceGrp:ForEach(function ( space )
								if FXClashDetection.IsCollided(pipe, space) then
									collidedSpace = space
								end
							end)
						end
						
						local pipeOBB = FXGeom. GetBoundingBox(pipe)
						local centerPnt = pipeOBB:MidPos()
						local maxPnt = pipeOBB:HighPos()
						local minPnt = pipeOBB:LowPos()
						local pipeCenterLine = Line3D(Point3D(centerPnt.x,centerPnt.y,maxPnt.z), Point3D(centerPnt.x,centerPnt.y,minPnt.z))
						local pipeCenterLineNode = FXUtility.CreateNodeFrom(pipeCenterLine)
						local arrowGeom;
						local poly = PolyLine3D(TRUE)
						local ShortestDistance;
						local shortestLine;
						
						wallGrp:ForEach(function ( wall )
							if not (FXClashDetection.IsCollided(slabCollideAtVent, wall)) then
								local hasWindow = false
								local range = FXGeom.GetBoundingBox(BuildingStorey):HighPos().z - FXGeom.GetBoundingBox(BuildingStorey):LowPos().z
								local topFace = FXMeasure.GetTopFace( wall )
								local extrudedFace = topFace:ExtrudedFace(Vector(0, 0, - range ));
								local nodeFace = FXUtility.CreateNodeFrom( extrudedFace )

								grpWindow : ForEach ( function ( window )
									if FXClashDetection.IsCollided( window, nodeFace ) then
										hasWindow = true 
									end
								end)

								FXClashDetection.DeleteNode( nodeFace )
								if hasWindow then
									hasAdjacentWall = true
									local distLine = FXMeasure.Distance(pipeCenterLineNode, wall)
									local Distance = distLine:Length()
									if ShortestDistance == nil then
										ShortestDistance = Distance
										shortestLine = distLine
									elseif ShortestDistance > Distance then
										ShortestDistance = Distance
										shortestLine = distLine
									end		
								end	
							end
						end)

						if hasAdjacentWall then
							FXClashDetection.DeleteNode(pipeCenterLineNode)
							ShortestDistance = FXUtility.Round(ShortestDistance, 2)
						
							if FXRule.EvaluateNumber( minDistanceParam ,ShortestDistance ,  tonumber(minDistance) ) then
								isCompliant = true;
							end
							local pnt1 = Point3D( shortestLine:GetStartPoint().x , shortestLine:GetStartPoint().y , maxPnt.z + 500 ) 
							local pnt2 = Point3D( shortestLine:GetEndPoint().x , shortestLine:GetEndPoint().y , maxPnt.z + 500 )
							arrowGeom = DoubleArrow( pnt1, pnt2 );
							poly:AddPoint ( shortestLine:GetStartPoint() )
							poly:AddPoint ( pnt1 )
							poly:AddPoint ( pnt2 )
							poly:AddPoint ( shortestLine:GetEndPoint() )

							if collidedSpace == nil then
								collidedSpace = Building;
							end
							
							CheckResult(collidedSpace, isCompliant, pipeName, pipeDesc, pipe, ShortestDistance, arrowGeom, poly);
						else
							FXUtility.DisplaySolid_Warning(Building, "No Adjacent wall of same level or higher than "..pipeDesc.." found")
							CheckReport.AddRelatedObj( pipe, pipe:GetAttri("Name") )
						end
					end
				end
			end)
			if ventStackTerminate == false then
				FXUtility.DisplaySolid_Warning(Building, pipeDesc.." does not terminate through a roof element.")
				CheckReport.AddRelatedObj( pipe, pipeName )
			end
		end)
		if isErrorFound == false then
			local y = 1 
			while y ~= x + 1 do
				print ("2")
				FXUtility.DisplaySolid_Info(comColSpaceArr[y] , comObjTypeArr[y].." = "..comDistanceArr[y].." mm");
				CheckReport.AddRelatedObj( comObjArr[y], comObjNameArr[y] )
				CheckReport.AddRelatedGeometry_Solid(comArrowArr[y], "Arrow3D")
				CheckReport.AddRelatedGeometry_Solid(comPolyArr[y], "Arrow3D")
				y = y + 1
			end
		end
	else
		FXUtility.DisplaySolid_Warning(Building, MSG_NO_VENT_STACK)
	end
end

function CheckResult(collidedSpace, isCompliant, pipeName, pipeDesc, pipe, Distance, arrowGeom, polyLine)
	if isCompliant then
		x = x + 1
		print ("1")
		comColSpaceArr[x] = collidedSpace
		comObjArr[x] = pipe
		comDistanceArr[x] = Distance
		comPolyArr[x] = polyLine
		comArrowArr[x] = arrowGeom
		comObjNameArr[x] = pipeName
		comObjTypeArr[x] = pipeDesc		
	else
		isErrorFound = true
		FXUtility.DisplaySolid_Error(collidedSpace, pipeDesc.." = "..Distance.." mm");
		CheckReport.AddRelatedObj( pipe, pipeName )
		CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
		CheckReport.AddRelatedGeometry_Error(polyLine, "Arrow3D")
	end
end

