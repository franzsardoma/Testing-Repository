--[[
	Implemented by: Lawrence Roy Quiling 1/31/2019
]]

local grpDischargePipes 	= FXGroup:new()
local grpRoadsideDrains 	= FXGroup:new()
local grpDropInletChambers 	= FXGroup:new()
local MinInternalDiameter 	= 0
local OperatorAngle
local ConditionDegree		= 0
local DischargePipe_Val, RoadsideDrain_Val, DropInletChamber_Val

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_8_3_DISCHARGE_PIPE_MINIMUM_DIAMETER_AND_CONNECTING_ANGLE")
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	MinInternalDiameter = tonumber(ConditionValues[2])
	OperatorAngle 		= ConditionValues[5]
	ConditionDegree 	= tonumber(ConditionValues[6])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpDischargePipes = grpDischargePipes + v;
				grpDischargePipes = grpDischargePipes:Unique();
			end
			if (k == 3) then
				grpRoadsideDrains = grpRoadsideDrains + v;
				grpRoadsideDrains = grpRoadsideDrains:Unique();
			end
			if (k == 4) then
				grpDropInletChambers = grpDropInletChambers + v;
				grpDropInletChambers = grpDropInletChambers:Unique();
			end
		end
	end

	local Values1 = {}
	local Values2 = {}
	local Values3 = {}
	for k,v in pairs(tblValues) do
		for k1,v1 in pairs(v) do
			if(k == 1) then
				table.insert(Values1, v1["value"])
			end
			if(k == 2) then
				table.insert(Values2, v1["value"])
			end
			if(k == 3) then
				table.insert(Values3, v1["value"])
			end
		end
	end

	DischargePipe_Val 	 = getValue( Values1 )
	RoadsideDrain_Val 	 = getValue( Values2 )
	DropInletChamber_Val = getValue( Values3 )
end

function getValue( tab )
	local value = tab[1]
	local length = #tab
	for k,v in pairs(tab) do
		if k ~= 1 then
			if k ~= length then
				value = value..", "..v
			
			elseif k == length then 
				value = value.." or "..v
			end
		end
	end
	return value
end

function CheckWarning( Building )
	local flag = isNotWarning( grpDischargePipes, Building, DischargePipe_Val, true )
	flag = isNotWarning( grpRoadsideDrains, Building, RoadsideDrain_Val, flag )
	return isNotWarning( grpDropInletChambers, Building, DropInletChamber_Val, flag )
end

function isNotWarning( grpObjs, Building, Value, currentResult )
	if(#grpObjs == 0) then
		CheckReport.Warning( Building, Value.." is not provided.")
		return false
	end
	return currentResult
end

function checkRule( Building )
	
	if(CheckWarning(Building)) then
		
		grpDischargePipes:ForEach(function ( DischargePipe )
			local IsWarningNotFound = true
			local ConnRoadside, ConnDropChamber = getConnectedTo( DischargePipe )

			if ConnRoadside == nil then
				CheckReport.Warning( DischargePipe, RoadsideDrain_Val.." is not detected.")
				IsWarningNotFound = false
			end
			if ConnDropChamber == nil then
				CheckReport.Warning( DischargePipe, DropInletChamber_Val.." is not detected.")
				IsWarningNotFound = false
			end

			if IsWarningNotFound then
				local DischargeDiameter = FXUtility.Round( FXPUB.GetDiameter ( DischargePipe ) )

				if DischargeDiameter >= MinInternalDiameter then
					FXUtility.DisplaySolid_Info(DischargePipe, "Internal diameter of the Discharge Pipe is at least 250 mm")
					CheckReport.AddRelatedObj(DischargePipe, DischargePipe:GetAttri("ObjectType").."; Internal Diameter "..DischargeDiameter.." mm")
				else
					FXUtility.DisplaySolid_Error(DischargePipe, "Internal diameter of the Discharge Pipe is less than 250 mm")
					CheckReport.AddRelatedObj(DischargePipe, DischargePipe:GetAttri("ObjectType").."; Internal Diameter "..DischargeDiameter.." mm")
				end

				local CenterLine = GetCenterline( ConnRoadside )
				local LowestPoint = getLowestPoint( CenterLine, ConnRoadside ) -- get Gradient

				if LowestPoint ~= nil then
					local AngleDeg = GetAngle( DischargePipe, ConnRoadside, LowestPoint)

					if FXRule.EvaluateNumber( OperatorAngle  , AngleDeg , ConditionDegree ) then
						FXUtility.DisplaySolid_Info(DischargePipe, "Angle of connection is greater than 90 degrees in the downstream direction")
						CheckReport.AddRelatedObj(DischargePipe, DischargePipe:GetAttri("ObjectType").."; "..ConnRoadside:GetAttri("ObjectType").."; "..AngleDeg.." degrees")
					else
						FXUtility.DisplaySolid_Error(DischargePipe, "Angle of connection is less than or equal to 90 degrees in the downstream direction")
						CheckReport.AddRelatedObj(DischargePipe, DischargePipe:GetAttri("ObjectType").."; "..ConnRoadside:GetAttri("ObjectType").."; "..AngleDeg.." degrees")
					end
				end
			end
		end)
	end
end

function getConnectedTo( DischargePipe ) -- Check if connected to Roadside Drain and Drop Inlet Chamber
	local tempRoadside, tempDropChamber

	grpRoadsideDrains:ForEach(function ( RoadsideDrain )
		if tempRoadside == nil then
			if(FXClashDetection.IsCollided(RoadsideDrain,DischargePipe))then
				tempRoadside = RoadsideDrain
			end
		end
	end)

	grpDropInletChambers:ForEach(function ( DropInletChamber )
		if tempDropChamber == nil then
			if(FXClashDetection.IsCollided(DropInletChamber,DischargePipe))then
				tempDropChamber = DropInletChamber
			end
		end
	end)
 
	if tempRoadside == nil then
		CheckReport.Warning( DischargePipe, RoadsideDrain_Val.." is not detected.")
	end

	if tempDropChamber == nil then
		CheckReport.Warning( DischargePipe, DropInletChamber_Val.." is not detected.")
	end
	return tempRoadside, tempDropChamber
end

function GetAngle( DischargePipe, ConnRoadside, LowestPoint)
	local DischargeLine = FXMeasure.GetPipeCenterLine(DischargePipe)
	local pntZ = FXGeom.GetBoundingBox(ConnRoadside):HighPos().z
	local Pnt1 = DischargeLine:GetStartPoint()
	local Pnt2 = DischargeLine:GetEndPoint()
	DischargeLine = Line3D(Point3D(Pnt1.x, Pnt1.y, pntZ), Point3D(Pnt2.x, Pnt2.y, pntZ))
	local DischargeLineNode = FXUtility.CreateNodeFrom(DischargeLine)
	local topFace = FXMeasure.GetTopFace(ConnRoadside);
	local topFaceNode = FXUtility.CreateNodeFrom(topFace)
	local distance =  FXRelation.Distance(DischargeLineNode, topFaceNode):Length();
	topFace = topFace:Move(Vector(distance,distance,0));

	if distance ~= 0 then
		topFace = topFace:Move(Vector(-(distance*2),-(distance*2),0));
	end

	local Vec1 = GetVectorFromExtrudedFace( topFace, DischargeLineNode, LowestPoint,ConnRoadside )
	local Vec2 = GetVectorFromDischargeLine( DischargeLine, topFace)

	FXClashDetection.DeleteNode(DischargeLineNode);
	FXClashDetection.DeleteNode(topFaceNode);
	return FXUtility.Round(math.deg(Vec1:Angle(Vec2)));
end

function GetVectorFromDischargeLine( DischargeLine, topFace)
	local topFaceNode = FXUtility.CreateNodeFrom(topFace)
	local tempLine1 = Line3D(DischargeLine:GetStartPoint(), Point3D(DischargeLine:GetStartPoint().x, DischargeLine:GetStartPoint().y, DischargeLine:GetStartPoint().z + 100))
	local LineNode = FXUtility.CreateNodeFrom(tempLine1)

	if FXUtility.Round(FXRelation.Distance(topFaceNode, LineNode):Length()) == 0 then
		DischargeLine = Line3D( DischargeLine:GetStartPoint(), DischargeLine:GetEndPoint() )
	else
		DischargeLine = Line3D( DischargeLine:GetEndPoint(), DischargeLine:GetStartPoint() )
	end

	FXClashDetection.DeleteNode(topFaceNode);
	FXClashDetection.DeleteNode(LineNode);
	return DischargeLine:GetVector()
end

function GetVectorFromExtrudedFace( topFace, DischargeLineNode, LowestPoint, ConnRoadside)
	local outerEdge = FXMeasure.GetOuterEdge(topFace);
	local PolyLinePointNumber = outerEdge:GetPointNumber()

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		local LineNode = FXUtility.CreateNodeFrom(Line)
		
		if FXRelation.Distance(DischargeLineNode, LineNode):Length() == 0 then
			FXClashDetection.DeleteNode(LineNode);
			local dist1 = LowestPoint:Distance_Pnt(Point1)
			local dist2 = LowestPoint:Distance_Pnt(Point2)

			if dist1 < dist2 then
				Line = Line3D(FXUtility.CenterPoint(Point1, Point2), Point1)
			else
				Line = Line3D(FXUtility.CenterPoint(Point1, Point2), Point2)
			end
			return Line:GetVector()
		end
		FXClashDetection.DeleteNode(LineNode);
	end
end

function GetCenterline( ConnRoadside )
	local outerEdge = FXMeasure.GetOuterEdge(FXMeasure.GetTopFace(ConnRoadside));
	local PolyLinePointNumber = outerEdge:GetPointNumber()
	local Line1, Line2
	local tempIndex
	local dist

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local TempLine = Line3D(Point1, Point2)
		
		if dist == nil or dist > TempLine:Length() then
			tempIndex = i
			dist = TempLine:Length()
			Line1 = TempLine
		end
	end

	dist = nil
	for i=0,(PolyLinePointNumber-2) do
		
		if tempIndex ~= i then
			local Point1 = outerEdge:GetPoint(i)
			local Point2 = outerEdge:GetPoint(i+1)
			local TempLine = Line3D(Point1, Point2)
			
			if dist == nil or dist > TempLine:Length() then
				dist = TempLine:Length()
				Line2 = TempLine
			end
		end
	end
	return Line3D(FXUtility.CenterPoint(Line1:GetStartPoint(),Line1:GetEndPoint()),FXUtility.CenterPoint(Line2:GetStartPoint(),Line2:GetEndPoint()))
end

function getLowestPoint( CenterLine, ConnRoadside )
	local RoadsideMidPos = FXGeom.GetBoundingBox(ConnRoadside):MidPos().z
	local StartPnt = Point3D(CenterLine:GetStartPoint().x,CenterLine:GetStartPoint().y,RoadsideMidPos)
	local EndPnt = Point3D(CenterLine:GetEndPoint().x,CenterLine:GetEndPoint().y,RoadsideMidPos)
	local StartPntDepth = getDepth( StartPnt, ConnRoadside )
	local EndPntDepth = getDepth( EndPnt, ConnRoadside )

	if StartPntDepth == EndPntDepth then
		CheckReport.Warning( ConnRoadside, ConnRoadside:GetAttri("ObjectType")" has no gradient.")
		return nil
	end
	if StartPntDepth < EndPntDepth then
		return EndPnt
	end
	return StartPnt
end

function getDepth( Point, ConnRoadside )
	local limit = tonumber(FXGeom.GetBoundingBox(ConnRoadside):HighPos().z - FXGeom.GetBoundingBox(ConnRoadside):LowPos().z)
	local depthPoint = Point

	while limit > 0 do
		limit = limit - 1
		depthPoint = Point3D(depthPoint.x , depthPoint.y, depthPoint.z - 1);
		local depthLine = Line3D(depthPoint , Point);
		local depthLineNode = FXUtility.CreateNodeFrom(depthLine);

		if(FXClashDetection.IsCollided(depthLineNode, ConnRoadside))then
			FXClashDetection.DeleteNode(depthLineNode);
			break;
		end
		FXClashDetection.DeleteNode(depthLineNode);
	end
	return FXUtility.Round(tonumber(Point.z - depthPoint.z),2)
end