local flowsegGrp = FXGroup.new()
--MPN is for Mosquito-Proof Net
local MPNGrp = FXGroup.new()
local waterTankGrp = FXGroup.new()
local airventGrp = FXGroup.new()
local overflowGrp = FXGroup.new()
local ARRObjType={}


function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_13_C_AIR_VENTS_AND_OVERFLOW_PIPES");
	local GrpBldgObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition3");
	materials = (ConditionValues[1]);
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml,Building)
	for k,v in pairs(tblValues) do    
		for k1,v1 in pairs(v) do
			table.insert( ARRObjType , v1["value"] )
		end
	end
	for k,v in pairs(GrpObjs) do
		if (k == 2) then
		flowsegGrp = flowsegGrp + v;
		flowsegGrp = flowsegGrp:Unique();
		end
		if (k == 4) then
		waterTankGrp = waterTankGrp + v;
		waterTankGrp = waterTankGrp:Unique();
		end
	end
	for k,v in pairs(GrpBldgObjs) do
		if (k == 3) then
			MPNGrp = MPNGrp + v;
			MPNGrp = MPNGrp:Unique();
		end
	end
end

function checkRule(Building)
	local string = split(materials,",")
	local IsComplaint = true;
	local check = true;
	local airventGrp = FXGroup.new()
	local overflowGrp = FXGroup.new()

	if flowsegGrp == nil or #flowsegGrp == 0 then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"No Air Vent / Overflow Pipe found.")
	else
		flowsegGrp:ForEach(function(flowsegEle)
			if FXUtility.HasPatterInString(flowsegEle:GetAuxAttri("Entity.ObjectType"),ARRObjType[1]) then
				airventGrp:Add(flowsegEle)
			else
				overflowGrp:Add(flowsegEle)
			end
		end)
	end

	if #airventGrp == 0 or airventGrp == nil or #overflowGrp == 0 or overflowGrp == nil then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"No Air Vent / Overflow Pipe found.")
	end

	if waterTankGrp == nil or #waterTankGrp == 0 then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"No Storage Tank found.")
	end

	-- if check then
		local ARRPipe={}
		local ARRNet={}
		local j = 0;
		if #flowsegGrp ~= 0 then
			flowsegGrp:ForEach(function(flowsegEle)
				local count = #string
				waterTankGrp:ForEach(function(tankEle)
					if FXPUB.IsTwoObjsConnected(flowsegEle,tankEle,20) then
						if #MPNGrp ~= 0 then
							local notProvided = true;
							local corrosive = true;
							MPNGrp:ForEach(function(mpnEle)
								if FXClashDetection.IsCollided(mpnEle,flowsegEle) then
									-- print("collided")
									notProvided = false;
									for i = 1,count,1 do 
										if FXUtility.HasPatterInString(mpnEle:GetAuxAttri("Material.Layer.0.material"),string[i]) then
											corrosive = false;
										end
									end
									if corrosive then
										IsComplaint = false;
										FXUtility.DisplaySolid_Error(flowsegEle,mpnEle:GetAttri("Name") .. " material is " .. mpnEle:GetAuxAttri("Material.Layer.0.material") )
										CheckReport.AddRelatedObj(mpnEle,mpnEle:GetAttri("Name"))
									else
										j = j + 1;
										ARRPipe[j] = flowsegEle
										ARRNet[j] = mpnEle
									end
								end
							end)

							if notProvided then
								local connectedFitting = flowsegEle:GetConnectedFitting()
								if #connectedFitting ~= 0 then
									connectedFitting:ForEach(function(fittingEle)
										MPNGrp:ForEach(function(mpnEle)
											if FXClashDetection.IsCollided(mpnEle,fittingEle) then
												isProvided = true;
												for i = 1,count,1 do
													if FXUtility.HasPatterInString(mpnEle:GetAuxAttri("Material.Layer.0.material"),string[i]) then
														corrosive = false;
													end
												end
												if corrosive then
													IsComplaint = false;
													FXUtility.DisplaySolid_Error(flowsegEle,mpnEle:GetAttri("Name") .. " material is " .. mpnEle:GetAuxAttri("Material.Layer.0.material") )
													CheckReport.AddRelatedObj(mpnEle,mpnEle:GetAttri("Name"))
												else
													j = j + 1;
													ARRPipe[j] = flowsegEle
													ARRNet[j] = mpnEle
												end
											end
										end)

										if isProvided == false then
											IsComplaint = false;
											FXUtility.DisplaySolid_Error(flowsegEle,"No Mosquito-proof net found in " .. flowsegEle:GetAttri("Name"))
										end
									end)
								else
									IsComplaint = false;
									FXUtility.DisplaySolid_Error(flowsegEle,"No Mosquito-proof net found in " .. flowsegEle:GetAttri("Name"))
								end
							end
						else
							IsComplaint = false;
							FXUtility.DisplaySolid_Error(flowsegEle,"No Mosquito-proof net found in " .. flowsegEle:GetAttri("Name"))
						end
					else
						-- warning if air vent or overflow pipe is not connected to tank
					end
				end)
			end)

			if IsComplaint then
				for j,pipeEle in pairs(ARRPipe) do
					FXUtility.DisplaySolid_Info(pipeEle,ARRNet[j]:GetAttri("Name") .. " material is " .. ARRNet[j]:GetAuxAttri("Material.Layer.0.material") )
					CheckReport.AddRelatedObj(ARRNet[j],ARRNet[j]:GetAttri("Name"))		
				end
			end		
		end
	-- end
end	

function split(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end