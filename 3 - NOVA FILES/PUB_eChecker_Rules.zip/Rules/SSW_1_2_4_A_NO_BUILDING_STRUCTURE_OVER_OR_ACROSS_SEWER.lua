--[[
	Implemented by: Jayson Barateta 1/24/19
	Modefied by: Jayson Barateta 2/1/19
]]
-- local Condition1;

local SewerPipeGroup = FXGroup.new();
local BuildingObjectGroup = FXGroup.new();
-- local ObjectsOverPipeGroup = FXGroup.new();

-- local Property = {};
-- local Values = {};
-- local AllowedBuildingObjs = {};

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("Parser");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function Parser(Building)
    local ok, path = pcall(FXPUB.GetFilePath());
	local parsedXml = FXPUB.ParseXml(path(), "SSW_1_2_4_A_NO_BUILDING_STRUCTURE_OVER_OR_ACROSS_SEWER");

    -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	local tblValues = FXRule.filterTableValues(parsedXml, proj);
	-- Condition1 = tostring(ConditionValues[2]);

	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	if(GrpObjs ~= nil)then		
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				SewerPipeGroup = SewerPipeGroup + v;
				SewerPipeGroup = SewerPipeGroup:Unique();
			end
			if (k == 3) then
				BuildingObjectGroup = BuildingObjectGroup + v;
				BuildingObjectGroup = BuildingObjectGroup:Unique();
			end				
		end
	end

	-- for k,v in pairs(tblValues) do
	-- 	for k1,v1 in pairs(v) do
	-- 		----------GET THE TABLE VALUES OF FLOWSEGMENT--------------------
	-- 		if(k == 1)then
	-- 			table.insert(Property,v1["property"]);
	-- 			table.insert(Values,v1["value"]);
	-- 		end
	-- 		----------GET THE TABLE VALUES OF EXCLUDED ELEMENTS--------------
	-- 		if(k == 2)then 
	-- 			if(v1["state"] == "Exclude" or v1["state"] == "Excluded")then 
	-- 				table.insert(Property,v1["property"]);
	-- 				table.insert(Values,v1["value"]);
	-- 			end

	-- 			if(v1["state"] == "Include" or v1["state"] == "Included")then 
	-- 				table.insert(AllowedBuildingObjs,v1["type"]); 
	-- 			end
	-- 		end
	-- 	end
	-- end	
end

function CheckRule(Building)
	if(#SewerPipeGroup > 0)then
		SewerPipeGroup:ForEach(function(SewerPipe)
			BuildingObjectGroup:Sub(SewerPipe);
		end)		

		SewerPipeGroup:ForEach(function(SewerPipe)
			------------------GET PIPE HIGHEST POINT-------------------------------------------
			local SewerBox = FXGeom.GetBoundingBox(SewerPipe);
			local HighestPoint = SewerBox:HighPos().z;
			-- local MidZ = SewerBox:MidPos().z;			
			------------------GET BUILDING HIGHEST ELEVATION-----------------------------------
			local HighestElevation = FXPUB.GetHighestElevation(Building);
			------------------GET THE HEIGHT TO EXTRUDE----------------------------------------
			local ExtrudedHeight = HighestElevation - HighestPoint;
			------------------GET ELEVATION----------------------------------------------------
			local Storey = FXUtility.GetStorey(SewerPipe);
			local Elevation = Storey:Elevation();
			------------------GET PROJECTION---------------------------------------------------
			local SewerProjection = FXMeasure.GetObjProjection(SewerPipe,HighestPoint);
			local OuterEdge = FXMeasure.GetOuterEdge(SewerProjection);
			local SewerFace = OuterEdge:Face3D();
			local ExtrudedFace = SewerFace:ExtrudedFace(Vector(0,0,ExtrudedHeight));
			local Node = FXUtility.CreateNodeFrom(ExtrudedFace);
			------------------GET PIPE CENTER LINE---------------------------------------------
			local CenterLine = FXMeasure.GetProjectionCenterLine(SewerPipe);
			local CenterLineZPoint = CenterLine:GetStartPoint().z;
			local CenterLineNode = FXUtility.CreateNodeFrom(CenterLine);
			-----------------------------------------------------------------------------------
			local CollidedGroup = FXGroup.new();
			-----------------------------------------------------------------------------------
			if(#BuildingObjectGroup > 0)then
				-- local ArrayOfProjection = {};
				-------------CHECK FOR COLLIDED OBJECTS ON EXTRUDED PROJECTION-----------------
				-- local tempObject = nil;
				-- local ShortestLine = nil;
				-------------GET THE NEAREST OBJECT--------------------------------------------
				BuildingObjectGroup:ForEach(function(Object)
					---------------------------------------------------------------------------
					if(FXClashDetection.IsCollided(Node,Object))then 
						CollidedGroup:Add(Object);
					end
					---------------------------------------------------------------------------
					-- if(tempObject == nil)then
					-- 	tempObject = Object;
					-- 	ShortestLine = FXMeasure.Distance(CenterLineNode,Object);
					-- else 
					-- 	local Line1 = FXMeasure.Distance(CenterLineNode,Object);
					-- 	local Line2 = FXMeasure.Distance(CenterLineNode,tempObject);
					-- 	-----------------------------------------------------------------------
					-- 	local Distance1 = Line1:Length();
					-- 	local Distance2 = Line2:Length();
					-- 	-----------------------------------------------------------------------
					-- 	if(Distance1 < Distance2)then 
					-- 		tempObject = Object;
					-- 		ShortestLine = Line1;
					-- 	end
					-- end
				end)
				-------------------------------------------------------------------------------
				-- local BuildingStorey = Building:GetDescendants("BuildingStorey");				
				-- BuildingStorey:ForEach(function(Storey)
				-- 	---------------------------------------------------------------------------
				-- 	local ObjectsGroup = Storey:GetChildren();
				-- 	---------------------------------------------------------------------------
				-- 	local ExCludedObjects = FXGroup.new();
				-- 	---------------------------------------------------------------------------
				-- 	ObjectsGroup:ForEach(function(Element)	
				-- 		for k,v in pairs(Property) do
				-- 			local ObjectValue = Element:GetAttri(v);
				-- 			if(FXUtility.HasPatterInString(ObjectValue,Values[k]))then
				-- 				ExCludedObjects:Add(Element);
				-- 			end	
				-- 		end
				-- 		------------------------------------------------------------------------
				-- 		local Result = false;
				-- 		for k,v in pairs(AllowedBuildingObjs) do
				-- 			if(Element.Type == v)then
				-- 				Result = true;
				-- 				break;								
				-- 			end
				-- 		end

				-- 		if(Result == false)then 
				-- 			ExCludedObjects:Add(Element);
				-- 		end
				-- 		------------------------------------------------------------------------
				-- 	end)					
				-- 	---REMOVE EXCLUDED OBJECTS FROM BUILDING STRUCTURES GROUP-------------------
				-- 	ExCludedObjects:ForEach(function(Element)
				-- 		ObjectsGroup:Sub(Element);
				-- 	end)
					
				-- 	if(#ObjectsGroup ~= 0)then
				-- 		---GET THE PROJECTION OF ALL BUILDING STRUCTURES------------------------
				-- 		local Projection = FXMeasure.GetProjection(ObjectsGroup,Elevation);						
				-- 		---INSERT PROJECTION INTO ARRAY-----------------------------------------
				-- 		table.insert(ArrayOfProjection,Projection);
				-- 	end
				-- end)
				-------BUILDING PROJECTION------------------------------------------------------
				-- local BuildingProjection = FXUtility.MergeProjection(ArrayOfProjection);
				local BuildingProjection = FXMeasure.GetProjection(BuildingObjectGroup,Elevation);
				if(BuildingProjection ~= nil)then
					if(#CollidedGroup > 0)then					
						FXUtility.DisplaySolid_Error(SewerPipe,"Building is placed over a sewer.",BuildingProjection);
						CheckReport.AddRelatedGeometry_Wire(ExtrudedFace);
					else
						-- local NewProjection = FXMeasure.MoveProjection(BuildingProjection,CenterLineZPoint);
						-- local Node1 = FXUtility.CreateNodeFrom(NewProjection);
						-- local Node2 = FXUtility.CreateNodeFrom(CenterLine);
						-- local Distance = FXMeasure.Distance(Node2,Node1);
						---CREATE THE PROJECTION BOX--------------------------------------------
						-- local ProjectionBox = FXPUB.CreateBox(SewerPipe,Distance, CenterLine, HighestElevation);
						-- ---RESULT MESSAGE----------------------------------------------------
						local Message = "Building is placed away from the sewer with required sewer setback distance.";
						FXUtility.DisplaySolid_Info(SewerPipe,Message,BuildingProjection);
						-- if(ProjectionBox ~= nil)then
						-- 	-- CheckReport.AddRelatedGeometry_Wire(ProjectionBox);
						-- end
					end
				end
			end

			FXClashDetection.DeleteNode(Node);
			FXClashDetection.DeleteNode(CenterLineNode);			
		end)
	else
		FXUtility.DisplaySolid_Warning(Building,"Sewer pipe is not provided.");
	end

end

