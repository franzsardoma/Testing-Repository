local msg ;
local meterChamberGrp = FXGroup:new();
local drainageGrp = FXGroup:new()
local isErrorFound = false;
local comMeterChamberArr={};
local comMsg = {};
local comSub = {};
local comMeterChamberNameArr = {};
local comDrainageArr = {};
local comDrainageNameArr = {};
local x = 0;



function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_5_6_5_METER_AND_SUB_METER_DRAINAGE")
	
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);


	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			meterChamberGrp = meterChamberGrp + v;
			meterChamberGrp = meterChamberGrp:Unique();
			
		end
		if (k == 5) then
			drainageGrp = drainageGrp + v;
			drainageGrp = drainageGrp:Unique();
		end
	end
	
end


function checkRule(Building)
	
	if #meterChamberGrp ~= 0 then
		meterChamberGrp:ForEach(function ( meterChamber )
			local sub; 
			local drainage = nil;
			local drainName;
			-- local msg = "";
			print (meterChamber.Type)
			local isCompliant = false;
			local meterChamberName = meterChamber:GetAttri("LongName") 

			if FXUtility.HasPatterInString(meterChamberName, "Sub") then
				sub = meterChamber;
				if #drainageGrp ~= 0 then
					drainageGrp:ForEach(function (drain)
						if FXClashDetection.IsCollided(meterChamber, drain) then
							drainage = drain;
							drainName = drain:GetAttri("Name")
							isCompliant = true;
							msg = "Provided with proper drainage."
						else
							msg = "Not provided with proper drainage."
						end
					end)
				else
					msg = "Not provided with proper drainage."
				end

			else
				local wallGrp = meterChamber:GetConnectedWall();
				local slabGrp = meterChamber:GetSlabsBelow();
				local chamberSlab;
				local hasWeepHole = false;
				drainName = "Weep hole"

				if slabGrp ~= nil then
					slabGrp:ForEach(function ( slab )
						if FXClashDetection.IsCollided(meterChamber, slab) then
							chamberSlab = slab
						end
					end)
				end

				wallGrp:ForEach(function ( wall )
					local holeGrp =  wall:GetChildren("OpeningElement")

					if #holeGrp > 0 then
						drainage = wall;
						hasWeepHole = true;
						holeGrp:ForEach(function ( hole )
							if chamberSlab ~= nil then
								if FXClashDetection.IsCollided(hole, chamberSlab) then
									isCompliant = true;
									drainage = wall;
									msg = "Weep hole is provided."
								else
									msg = "Weep hole is elevated from the slab of the "..meterChamberName
								end
							end
						end)

					else

						local chamberSlabOBB = FXGeom. GetBoundingOBB(chamberSlab);
						local slabMaxPntElevation = chamberSlabOBB:MaxPnt().z
						

						local wallProjection = FXMeasure.GetObjProjection(wall, slabMaxPntElevation)
						local wallPrjArea = FXUtility.Round(FXMeasure.GetProjectionArea( wallProjection), 2)
						local wallBottomFace = FXMeasure.GetBottomFace(wall)
						local wallBottomProjection = FXMeasure.CreateShellsolid(wallBottomFace)
						local wallBottomProjectionArea = FXUtility.Round(FXMeasure.GetProjectionArea( wallBottomProjection), 2)
						
						if wallPrjArea ~= wallBottomProjectionArea then
							isCompliant = true;
							hasWeepHole = true;
							drainage = wall;
							msg = "Weep hole is provided."
						end
					end
						
				end)
				if hasWeepHole == false then	
					msg = "Weep hole is not provided."
				end
			end
			CheckResult(Building, isCompliant, meterChamber, msg, drainage, drainName, meterChamberName,sub)
		end)

		if isErrorFound == false then
			local y = 1;
			while y ~= x + 1 do
				FXUtility.DisplaySolid_Info(comMeterChamberArr[y], comMsg[y]);

				if comSub[y] == nil then
					FXUtility.DisplaySolid_Info(comMeterChamberArr[y], "Weep hole drain is aligned on top of the slab of " .. comMeterChamberNameArr[y]);
				end

				CheckReport.AddRelatedObj( comMeterChamberArr[y], comMeterChamberNameArr[y] )
				CheckReport.AddRelatedObj( comDrainageArr[y], comDrainageNameArr[y] )
				y = y + 1;
			end
		end
	else
		FXUtility.DisplaySolid_Warning(Building, "No meter chamber/sub Meter Chamber found.")
	end

end

function CheckResult(Building, isCompliant, meterChamber, message, drainage, drainName, meterChamberName, sub)
	
	if isCompliant then
		x = x + 1;
		comMeterChamberArr[x] = meterChamber;
		comMsg[x] = msg;
		comSub[x] = sub;
		comMeterChamberNameArr[x] = meterChamberName;
		comDrainageArr[x] = drainage;
		comDrainageNameArr[x] = drainName;
	else
		isErrorFound = true
		FXUtility.DisplaySolid_Error(meterChamber, message);
		CheckReport.AddRelatedObj( meterChamber, meterChamberName )
		if drainage ~= nil then
			CheckReport.AddRelatedObj( drainage, drainName )
		end
	end
end


