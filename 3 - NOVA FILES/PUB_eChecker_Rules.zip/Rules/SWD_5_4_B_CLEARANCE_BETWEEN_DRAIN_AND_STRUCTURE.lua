--[[
	Implemented By: Joemar M. Alberto (DD/MM/YY: 03/01/2019)
--]]

local grpDrain = FXGroup.new()
local grpFooting = FXGroup.new();
local Vertical_Compliant = true;
local Horizontal_Compliant = true;
local vertical_Condition, horizontal_Condition

function main()
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("XMLParser");
	CheckEngine.RunCheckPipeline();
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser( Building )
	local ok, path = pcall(FXPUB.GetFilePath())
   	local parsedXml = FXPUB.ParseXml(path(), "SWD_5_4_B_CLEARANCE_BETWEEN_DRAIN_AND_STRUCTURE")
   	local Condition1 = FXRule.ParseValues(parsedXml, "Condition1");
	local Condition2 = FXRule.ParseValues(parsedXml, "Condition2");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	for k,v in pairs(GrpObjs) do
		if (k == 3) then
			grpDrain = grpDrain + v;
			grpDrain = grpDrain:Unique();
		end
	end
	-- Vertical
	for k,v in pairs(Condition1) do -- get the condition values
		if (k == 3) then
			vertical_Condition = tonumber(v); -- 100 Minimum Value
		end
	end
	-- Horizontal 
	for k,v in pairs(Condition2) do
		if (k == 3) then
			horizontal_Condition = tonumber(v); -- 300 Minimum Value
		end
	end
end

function CheckRule( Building )
	local Building_Storey = Building:GetDescendants("BuildingStorey")
	local grpSlabsStoreyOne = FXGroup.new();
	local grpAboveObj = FXGroup.new();
	local storeyOneElev;

	Building_Storey:ForEach(function ( s1 )
		if(FXUtility.HasPatterInString(s1:GetAttri("Name"), "Storey 1"))then
			storeyOneElev = FXGeom.GetBoundingBox(s1):HighPos().z
			local slab = s1:GetDescendants("Slab");

			slab:ForEach(function ( SLAB )
				if(FXUtility.HasPatterInString(SLAB:GetAttri("Name"), "Floor"))then
					grpSlabsStoreyOne:Add(SLAB);
				end
			end)
			slab:ForEach(function ( SLAB )
				if(FXUtility.HasPatterInString(SLAB:GetAttri("Name"), "FOOTING"))then
					grpFooting:Add(SLAB);
				end
			end)
		end
	end)

	grpDrain:ForEach(function ( drain )
		local DrainBox = FXGeom.GetBoundingBox(drain):HighPos().z
		local Max_Extrude_z = storeyOneElev - DrainBox; -- Maximum Extruded Face for the Projection Drain --
		local v_Projection = FXMeasure.GetObjProjection(drain, DrainBox);
		local v_OuterEdge = FXMeasure.GetOuterEdge(v_Projection);
		local v_Face = v_OuterEdge:Face3D()
		local v_ExtrudeFace = v_Face:ExtrudedFace(Vector(0, 0, Max_Extrude_z));
		local v_Node = FXUtility.CreateNodeFrom(v_ExtrudeFace);

		grpSlabsStoreyOne:ForEach(function ( floor )
			if(FXClashDetection.IsCollided(v_Node,floor))then
				grpAboveObj:Add(floor)
			end
		end)
	end)
	-- FXUtility.DisplaySolid_Info(drain, "EXTRUDE", vertical_ExtrudeFace)
	local v_Line, v_Distance, v_Clearance, v_Clearance, v_Point1, v_Point2, v_Arrow, v_AboveSlab;
	local h_LOWEST_FOOTING, Drain_LowPos, h_Projection, h_NodeProjection, h_Distance, h_NearestDistance, h_NearestFOOTING, h_Line, h_Clearance;
	local h_Point1, h_Point2, h_Arrow, h_PolyLine, h_newPoint1, h_newPoint2;

	if(#grpAboveObj ~= 0 or #grpFooting ~= 0)then
		--( Vertical Distance )--
		grpAboveObj:ForEach(function ( slab )
			if(#grpDrain ~= 0)then
				grpDrain:ForEach(function ( drain )
					v_Line = FXMeasure.Distance(slab, drain);
					v_Distance = v_Line:Length();
					v_Clearance = FXUtility.Round(v_Distance ,0)
					v_AboveSlab = slab; -- SLab only above from drain --
				end)
			else
				FXUtility.DisplaySolid_Warning(Building, "Drain is not provided.")
			end
		end)
		--( Horizontal Distance )--
		grpFooting:ForEach(function ( FOOTING )
			h_LOWEST_FOOTING = FXGeom.GetBoundingBox(FOOTING):LowPos().z
			if(#grpDrain ~= 0)then
				grpDrain:ForEach(function ( DRAIN )
					Drain_LowPos = FXGeom.GetBoundingBox(DRAIN):LowPos().z
					h_Projection = FXMeasure.GetObjProjection(DRAIN,h_LOWEST_FOOTING);
					h_NodeProjection = FXUtility.CreateNodeFrom(h_Projection);
					h_Distance = FXMeasure.Distance(FOOTING, h_NodeProjection);
					
					if(h_NearestDistance == nil or h_NearestDistance > h_Distance:Length())then
						h_NearestDistance = h_Distance:Length();
						h_NearestFOOTING = FOOTING;
						h_Line = h_Distance;
						h_Clearance = FXUtility.Round(h_NearestDistance ,0);
					end
				end)
			else
				FXUtility.DisplaySolid_Warning(Building, "Drain is not provided.")
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building, "Building Structure is not provided.")
		FXUtility.DisplaySolid_Warning(Building, "Drain is not provided.")
	end

	-- FXUtility.DisplaySolid_Info(h_NearestFOOTING,"FOOOTING")
	
	-- Vertical Distance --
	v_Point1 = v_Line:GetStartPoint();
	v_Point2 = v_Line:GetEndPoint();
	v_Arrow = DoubleArrow(v_Point1, v_Point2)
	-- Horizontal Distance --
	h_Point1 = h_Line:GetStartPoint();
	h_Point2 = h_Line:GetEndPoint();
	h_newPoint1 = Point3D(h_Point1.x,h_Point1.y,Drain_LowPos)
	h_newPoint2 = Point3D(h_Point2.x,h_Point2.y,Drain_LowPos)
	h_PolyLine = PolyLine3D(TRUE)
	h_PolyLine:AddPoint(h_newPoint2)
	h_PolyLine:AddPoint(h_Point2)
	h_PolyLine:AddPoint(h_Point1)
	h_PolyLine:AddPoint(h_newPoint1) 
	h_Arrow = DoubleArrow(h_Point1, h_Point2);

	-- Compliant Result for Vertical Clearance --
	if(v_Clearance >= vertical_Condition)then
		Vertical_Compliant = true;
	else
		Vertical_Compliant = false;
		grpDrain:ForEach(function ( _drain_ )
			FXUtility.DisplaySolid_Error(_drain_, "Vertical Clearance: "..v_Clearance.."mm", v_Arrow)
		end)
		CheckReport.AddRelatedObj(v_AboveSlab, v_AboveSlab:GetAttri("Name"))
		
	end

	if(Vertical_Compliant)then --( Compliant Result )--		
		grpDrain:ForEach(function ( _drain_ )
			FXUtility.DisplaySolid_Info(_drain_, "Vertical Clearance: "..v_Clearance.."mm", v_Arrow)
		end)
	end

	-- Compliant Result for Horizontal Clearance --
	if(h_Clearance >= horizontal_Condition)then
		Horizontal_Compliant = true
	else
		Horizontal_Compliant = false;
		grpDrain:ForEach(function ( _drain_ )
			FXUtility.DisplaySolid_Error(_drain_, "Horizontal Distance: "..h_Clearance.."mm", h_Arrow)
		end)
		CheckReport.AddRelatedObj(h_NearestFOOTING, h_NearestFOOTING:GetAttri("Name"))
		CheckReport.AddRelatedGeometry_Error(h_PolyLine)
	end

	if(Horizontal_Compliant)then --( Compliant Result )--
		grpDrain:ForEach(function ( _drain_ )
			FXUtility.DisplaySolid_Info(_drain_, "Horizontal Distance: "..h_Clearance.."mm", h_Arrow)
		end)
		CheckReport.AddRelatedGeometry_Solid(h_PolyLine)
	end
end