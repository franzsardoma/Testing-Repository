--Modified By: Lawrence Roy Quiling 1/2/2019

local grpManholes = FXGroup:new();
local grpPipes = FXGroup:new();
local grpFlowFittings = FXGroup:new();
local OPERATOR1
local DEG
local OUTGOINGPIPE

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_F_SEWER_JOINTS_AND_CONNECTIONS_ANGLE")
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition2");
	-- local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	if GrpObjsSystem ~= nil then
		for k,v in pairs(GrpObjsSystem) do
			if (k == 2) then
				grpManholes = grpManholes + v;
				grpManholes = grpManholes:Unique();
			end
			if (k == 3) then
				grpPipes = grpPipes + v;
				grpPipes = grpPipes:Unique();
			end
		end
	end
	grpFlowFittings = Building:GetDescendants("FlowFitting")

	OPERATOR1 = (ConditionValues[4])
	DEG = (ConditionValues[5])
	OUTGOINGPIPE = (ConditionValues[9])
end

function CheckWarning( Building )
	local flag = true
	-- print(#grpManholes)
	if(#grpManholes == 0) then
		CheckReport.Warning( Building, "Manhole is not provided." )
		flag = false
	end
	if(#grpPipes == 0) then
		CheckReport.Warning( Building, "Sewer pipe is not provided." )
		flag = false
	end
	return flag;
end

function checkRule(Building)

	if (CheckWarning(Building)) then
		-- print(#grpPipes)
		local IsNoWarning = true
		local IsNoErrorFound = true
		local ARRgrpComPipes = {}
		-- local ARRgrpComManholes = {}
		local ARROutgoingPipe = {}
		-- local ARRNonComManhole = {}
		local ARRNonComPipe = {}
		local ARRNonComOutgoing = {}
		local ARRCompAngel = {}
		local ARRNonAngel = {}
		local i = 0
		
		local GrpManhole = getManholes()
		if #GrpManhole == 0 then
			FXUtility.DisplaySolid_Warning( Building, "Outgoing sewer is not provided." )
			IsNoWarning = false
		end
		while( #GrpManhole ~= 0 )
		do
			local GRPObjs = FXGroup:new()
		   	GrpManhole:ForEach(function ( Manhole )
				-- i = i + 1
				local grpComPipes = FXGroup:new()
				local grpConnPipes, grpOutgoingPipes = getConnectedPipes(Manhole)
				-- grpPipes:Sub(OutgoingPipe)
				if #grpOutgoingPipes == 0 then
					FXUtility.DisplaySolid_Warning( Manhole, "Outgoing sewer is not provided." )
					IsNoWarning = false
				end

				grpConnPipes:ForEach(function ( Pipe )
					grpOutgoingPipes:ForEach(function ( OutgoingPipe )
						local angle = getAngle( Pipe, OutgoingPipe, Manhole )
						-- print( FXUtility.Round((angle * 180) / math.pi))
						-- print(OPERATOR1)
						if FXRule.EvaluateNumber(OPERATOR1, angle, DEG) then
						-- if FXUtility.Round((angle * 180) / math.pi) >= 90 then
							-- grpComPipes:Add(Pipe)
							
							-- table.insert(ARRgrpComManholes, Manhole)
							table.insert(ARRgrpComPipes, Pipe)
							table.insert(ARROutgoingPipe, OutgoingPipe)
							table.insert(ARRCompAngel, angle)
						else
							IsNoErrorFound = false
							-- table.insert(ARRNonComManhole, Manhole)
							table.insert(ARRNonComPipe, Pipe)
							table.insert(ARRNonComOutgoing, OutgoingPipe)
							table.insert(ARRNonAngel, angle)
							-- FXUtility.DisplaySolid_Error(Manhole, Pipe:GetAttri("Name").." angle is less than 90 degrees to "..OutgoingPipe:GetAttri("Name"))
							-- CheckReport.AddRelatedObj(Pipe, Pipe:GetAttri("Name"))
						end
					end)
				end)
				GRPObjs = GRPObjs + getManholesByOutGoingPipes( grpOutgoingPipes, Manhole)
				grpPipes = grpPipes - grpOutgoingPipes
				-- if IsNoErrorFound then
					-- i = i + 1
					-- ARRgrpComManholes[i] = Manhole
					-- ARRgrpComPipes[i] = grpComPipes
					-- ARROutgoingPipe[i] = grpOutgoingPipes
					-- ARRCompAngel[i] = ANGLE
				-- end
			end)
		   	GrpManhole = GRPObjs
		end
		
		if IsNoErrorFound then
			for k,Manhole in pairs(ARRgrpComPipes) do
				FXUtility.DisplaySolid_Info(ARRgrpComPipes[k], "Angle of "..ARRgrpComPipes[k]:GetAttri("ObjectType").." to "..ARROutgoingPipe[k]:GetAttri("ObjectType").." is "..ARRCompAngel[k])
				CheckReport.AddRelatedObj(ARRgrpComPipes[k], ARRgrpComPipes[k]:GetAttri("ObjectType"))
				CheckReport.AddRelatedObj(ARROutgoingPipe[k], ARROutgoingPipe[k]:GetAttri("ObjectType"))
			end
		else
			if IsNoWarning then
				for k=1, #ARRNonComPipe do
					FXUtility.DisplaySolid_Error(ARRNonComPipe[k], "Angle of "..ARRNonComPipe[k]:GetAttri("ObjectType").." to "..ARRNonComOutgoing[k]:GetAttri("ObjectType").." is "..ARRNonAngel[k])
					CheckReport.AddRelatedObj(ARRNonComPipe[k], ARRNonComPipe[k]:GetAttri("ObjectType"))
					CheckReport.AddRelatedObj(ARRNonComOutgoing[k], ARRNonComOutgoing[k]:GetAttri("ObjectType"))
				end
			end
		end
	end
end

function getManholesByOutGoingPipes( grpOutgoingPipes, Manhole )
	local grpObjs = FXGroup:new()
	
	grpOutgoingPipes:ForEach(function ( Pipe )
		grpManholes:ForEach(function ( ManholeEle )
			if ManholeEle.Id ~= Manhole.Id then
				if IsConnected(Pipe,ManholeEle)  then
					grpObjs:Add(ManholeEle)
				end
			end
		end)
	end)
	return grpObjs;
end

function getManholes() -- getmanhole that has only one Outgoing Pipe
	local grpObj = FXGroup:new();
	grpManholes:ForEach(function ( Manhole )
		local grpConnPipes, grpOutgoingPipes = getConnectedPipes(Manhole)
		if #grpOutgoingPipes == 1 then
			grpObj:Add(Manhole)
		end
	end)
	return grpObj;
end

function getAngle( Pipe, OutgoingPipe, Manhole )
	local angle = 0;
	local topFace = FXMeasure.GetTopFace(Manhole);
	local outerEdges = FXMeasure.GetOuterEdge(topFace);
	local Line = GetLongestLine2(outerEdges);
   	local CenterPnt = FXUtility.CenterPoint(Line:GetStartPoint(),Line:GetEndPoint())
	local PipePnt = getPointConnManhole(CenterPnt, Pipe)
	local OutgoingPipePnt = getPointConnManhole ( CenterPnt, OutgoingPipe)
	local vec1 = Line3D(CenterPnt, PipePnt):GetVector();
	local vec2 = Line3D(CenterPnt, OutgoingPipePnt):GetVector(); 
	local angle  = vec1:Angle(vec2);
	-- print(angle)
	return FXUtility.Round((angle * 180) / math.pi);
end

function getPointConnManhole( CenterPnt, Pipe )
	local Pnt;

	local topFace = FXMeasure.GetTopFace(Pipe);
	local outerEdges = FXMeasure.GetOuterEdge(topFace);
	local Line = GetLongestLine(outerEdges);
	local pnt1 = Line:GetStartPoint();
   	local pnt2 = Line:GetEndPoint();

   	if CenterPnt:Distance_Pnt(pnt1) < CenterPnt:Distance_Pnt(pnt2) then
   		-- Pnt = Point3D(pnt1.x, pnt1.y, CenterPnt.z)
   		Pnt = Point3D(pnt2.x, pnt2.y, CenterPnt.z)
  	else
  		-- Pnt = Point3D(pnt2.x, pnt2.y, CenterPnt.z)
  		Pnt = Point3D(pnt1.x, pnt1.y, CenterPnt.z)
  	end
	return Pnt
end

function getConnectedPipes( Manhole )
	local grpObjs = FXGroup:new()
	local grpObjs2 = FXGroup:new()
	-- print(#grpPipes)
	grpPipes:ForEach(function ( Pipe )
		if IsConnected(Pipe,Manhole)  then
			if FXUtility.HasPatterInString(Pipe:GetAttri("ObjectType"),OUTGOINGPIPE) then
				grpObjs2:Add(Pipe)
			else
				grpObjs:Add(Pipe)
			end
		end
	end)
	return grpObjs, grpObjs2;
end

function IsConnected( Manhole, Pipe )
	local flag = false

	if FXClashDetection.IsCollided(Pipe,Manhole)  then
		flag = true
	else
		local node = FXUtility.CreateNodeFrom(FXGeom.GetBoundingBox(Manhole));
		if (FXRelation.Distance(Pipe, node):Length() <= 0.5) then
			flag = true
		end
		FXClashDetection.DeleteNode(node);
	end

	if (flag == false) then
		grpFlowFittings:ForEach(function ( Fitting )
			if flag then
				return;
			end
			if FXClashDetection.IsCollided(Fitting,Manhole) and FXClashDetection.IsCollided(Fitting,Pipe) then
				flag = true
			else
				local node = FXUtility.CreateNodeFrom(FXGeom.GetBoundingBox(Manhole));
				local node2 = FXUtility.CreateNodeFrom(FXGeom.GetBoundingBox(Fitting));
				if (FXRelation.Distance(node2, node):Length() <= 0.5) and FXClashDetection.IsCollided(Fitting,Pipe) then
					flag = true
				end
				FXClashDetection.DeleteNode(node);
				FXClashDetection.DeleteNode(node2);
			end
		end)
	end
	return flag
end

function GetLongestLine( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetLongestLine2( outerEdge )
	local PolyLinePointNumber = outerEdge:GetPointNumber() --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i)
		local Point2 = outerEdge:GetPoint(1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end