local NON_COMPLIANT = "; Double check valve is not provided."
local COMPLIANT = "; Double check valve is provided."
local NO_APPLIANCE = "There is no kitchen equipment found."
local allAppliances 	= FXGroup.new();
local allDoubleCheck	= FXGroup.new();
local tblDoubleCheck = {}

function main()

	CheckEngine.SetCheckType("Site")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

-- function script_path() -- FOR CONSOLE
--     local str = debug.getinfo(2, "S").source:sub(2)
-- 	local str2 = string.gsub(str,str:match("^.*/(.*).lua$")..".lua","")
-- 	local str3 = string.gsub(str2,"/Rules","")
-- 	return string.gsub(str3,"/","\\")
-- end 

function script_path() -- FOR RULESET
    local var = FX_PATH.ConfigPath();
	return string.gsub(var,"\\Rules","")
end

function XMLParser(Site)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_4_3_8_KITCHEN_EQUIPMENT")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values

	local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	for k,v in pairs(tbl) do
		if k == 6 then
			tblDoubleCheck = v
		end
	end

	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building); --filter objs from Building
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Site, systemTypes) --filter objs from System
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 5 then
			v:ForEach(function(obj)
			end)

			allAppliances = allAppliances + v
			allAppliances = allAppliances:Unique()			
		end
		if k == 6 then
			allDoubleCheck = allDoubleCheck + v
			allDoubleCheck = allDoubleCheck:Unique()			
		end			
	end
end

function checkRule(Building)
	print(#allAppliances)
	if #allAppliances ~= 0 then
		allAppliances:ForEach(function (appliance)
			-- DisplayTest(appliance, appliance:GetAttri("Name"))
			for k,v in pairs(tblDoubleCheck) do
				-- DisplayTest(valve, valve:GetAttri("Name"))
				-- if FXPUB.IsObjsConnected2(appliance, valve, "FlowFitting", "Tee") then
				-- print("!!! " .. v)
				local doubleCheck = FXPUB.GetConnectedObj(appliance, "FlowController", "Name", v, 10)
				if doubleCheck ~= nil then
					print("PASSED " .. appliance:GetAttri("Name"))
					-- FXUtility.DisplaySolid_Info(Building, appliance:GetAttri("Name") .. "; " .. doubleCheck:GetAttri("Name"));
					FXUtility.DisplaySolid_Info(appliance, appliance:GetAttri("Name") .. COMPLIANT);
					CheckReport.AddRelatedObj( doubleCheck, doubleCheck:GetAttri("Name"));
				-- 	-- DisplayResult(Building, appliance, valve)
				else
					FXUtility.DisplaySolid_Error(appliance, appliance:GetAttri("Name") .. NON_COMPLIANT);
				end
			end
		end)
	else
		FXUtility.DisplaySolid_Warning(Building,NO_APPLIANCE);		
	end
end

function DisplayTest(obj1, msg, geom)
	FXUtility.DisplaySolid_Warning(obj1, msg, geom);
end