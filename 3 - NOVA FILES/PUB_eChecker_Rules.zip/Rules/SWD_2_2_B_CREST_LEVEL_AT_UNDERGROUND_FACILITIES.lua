local Group1 = FXGroup.new()
local level01SlabGrp = FXGroup.new()
local OpeningElementGrp = FXGroup.new()
local SpaceGrp = FXGroup.new()
local SiteProjDevGrp = FXGroup.new()
local ARRLowestSlab={}
local ARRHighestRamp={}
local ARRRounded={}
local ARRSlabProj={}
local ARRRampflightGrp={}
local ARRDriveway={}
local ARRArrow1={}
local ARRArrow2={}
local ARRLineSlab={}
local ARRLineRamp={}
				
function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SWD_2_2_B_CREST_LEVEL_AT_UNDERGROUND_FACILITIES");
  local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
  operator = tostring(ConditionValues[3])
  minimumCrestLevel = tonumber(ConditionValues[4])
  -- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  -- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2) then
      Group1 = Group1 + v;
      Group1 = Group1:Unique();
    end
    if (k == 3) then
      level01SlabGrp = level01SlabGrp + v;
      level01SlabGrp = level01SlabGrp:Unique();
    end
    if (k == 4) then
      OpeningElementGrp = OpeningElementGrp + v;
      OpeningElementGrp = OpeningElementGrp:Unique();
    end
    if (k == 5) then
      SiteProjDevGrp = SiteProjDevGrp + v;
      SiteProjDevGrp = SiteProjDevGrp:Unique();
    end
    if (k == 6) then
      SpaceGrp = SpaceGrp + v;
      SpaceGrp = SpaceGrp:Unique();
    end
  end
end

function checkRule(Building)
	local isCompliant = true;
	local check = true;
	local BuildingStoreyGrp = Building:GetDescendants("BuildingStorey")
	local level01Grp = FXGroup.new()
	BuildingStoreyGrp:ForEach(function(bldgstoreyEle)
		if FXUtility.HasPatterInString(bldgstoreyEle:GetAttri("Name"),"Storey 1") == true then
	    	level01Grp:Add(bldgstoreyEle)
		end
	end)

	if #level01Grp == 0 then
		FXUtility.DisplaySolid_Warning(Building,"No level 01")
		check = false;
	end
	local drivewaySlabGrp=FXGroup.new()
	local RampGrp = FXGroup.new()
	local site = Building:GetParent(); 
	local drivewayslabCollided;
	local openingCollided;
	if site:GetAuxAttri("Other.Project Development Type") == nil then 
		FXUtility.DisplaySolid_Warning(Building,"Project Development Type not specified or does not match.")
    	check = false;
    elseif FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Industrial") == false and
    	FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Institutional") == false and
    	FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Commercial") == false and
    	FXUtility.HasPatterInString(site:GetAuxAttri("Other.Project Development Type"),"Multi-Unit Residential") == false then
    	FXUtility.DisplaySolid_Warning(Building,"Project Development Type not specified or does not match.")
    	check = false;
   	end
    
    if #OpeningElementGrp == 0 then
    	FXUtility.DisplaySolid_Warning(Building,"Opening and exit element not provided.")
    	check = false;
    end

    if #SpaceGrp == 0 then
    	FXUtility.DisplaySolid_Warning(Building,"Basement not provided.")
    	check = false;
    end

    if check then
    	local i = 0;
    	local isCompliant = true
    	SpaceGrp:ForEach(function(spaceEle)
	    	Group1:ForEach(function(ele)
	    		if FXUtility.HasPatterInString(ele:GetAttri("Name"),"driveway") == true then
	    			drivewaySlabGrp:Add(ele)   			
	    		else
	    			RampGrp:Add(ele)
	    		end
	    	end)

	    	OpeningElementGrp:ForEach(function(openEle)
	    		drivewaySlabGrp:ForEach(function(slabEle)
	    			if FXClashDetection.IsCollided(openEle, slabEle) then
	    				openingCollided = openEle;
	                    drivewayslabCollided = slabEle;
	                end
	    		end)
	    	end)
	    	local RampObject;
	    	local basementRampFlightGrp=FXGroup.new()
	    	if openingCollided ~= nil then
				if RampGrp ~= nil or #RampGrp ~= 0 then
	    			RampGrp:ForEach(function(rampEle)
	    				local RampFlightGrp = rampEle:GetDescendants("RampFlight")
	    				RampFlightGrp:ForEach(function(rampEle2)
	    					basementRampFlightGrp:Add(rampEle2);
	    				end)

	    				if(RampObject == nil)then 
							RampObject = rampEle;
						else
							local RampObjectOBB = FXGeom.GetBoundingBox(RampObject);
							local RampElementOBB = FXGeom.GetBoundingBox(rampEle);

							if(RampObjectOBB:x_range() > RampObjectOBB:y_range())then 
								if(RampObjectOBB:x_range() < RampElementOBB:x_range())then 
									RampObject = rampEle;
								end
							else
								if(RampObjectOBB:y_range() < RampElementOBB:y_range())then 
									RampObject = rampEle;
								end
							end
						end
	    			end)
					local BuildingStoreyGrp = Building:GetDescendants("BuildingStorey")
					local lowestSlab;
					local highestRamp;
					level01Grp:ForEach(function(bldgstoreyEle)
			        	local SlabGrp = bldgstoreyEle:GetDescendants("Slab")
			        	local lowpos;
			        	SlabGrp:ForEach(function(slabEle)
		              		if FXUtility.HasPatterInString(slabEle:GetAttri("Name"),"driveway") == false then
				        		slabLowPos = FXGeom.GetBoundingBox(slabEle):LowPos().z
				        		if lowpos == nil then
				        			lowpos = slabLowPos;
				        			lowestSlab = slabEle;
				        		else
				        			if slabLowPos < lowpos then
				        				lowpos = slabLowPos;
				        				lowestSlab = slabEle;
				        			end
				        		end
				        	end
			        	end)
					end)

					local highpos;
				    basementRampFlightGrp:ForEach(function(flightEle)
				    	local rampHighPos = FXGeom.GetBoundingBox(flightEle):HighPos().z
				    	if lowpos == nil then
					        highpos = rampHighPos;
					        highestRamp = flightEle;
					    else
					        if rampHighPos < lowpos then
					        	highpos = rampHighPos;
					        	highestRamp = flightEle;
					        end
					    end
				    end)
					local rampHighPos = FXGeom.GetBoundingBox(highestRamp):HighPos().z
					local slabHighPos = FXGeom.GetBoundingBox(lowestSlab):HighPos().z
					local Distance = rampHighPos - slabHighPos;
					local rounded = FXUtility.Round(Distance,2)
					
					local RampZ = FXGeom.GetBoundingBox(RampObject):HighPos().z
					local RampX = FXGeom.GetBoundingBox(RampObject):LowPos().x
					local RampY = FXGeom.GetBoundingBox(RampObject):LowPos().y

					local RampHighX = FXGeom.GetBoundingBox(RampObject):HighPos().x
					local RampHighY = FXGeom.GetBoundingBox(RampObject):HighPos().y
					local RampHighestPoint = Point3D(RampX,RampY,RampZ)

					local SlabZ = FXGeom.GetBoundingBox(lowestSlab):HighPos().z
					local SlabX = FXGeom.GetBoundingBox(lowestSlab):LowPos().x
					local SlabY = FXGeom.GetBoundingBox(lowestSlab):HighPos().y
					local SlabHighestPoint = Point3D(RampX,RampHighY,SlabZ)

					local PointSlab = Point3D(RampX,RampHighY,RampZ)
					local LineSlab = Line3D(PointSlab,RampHighestPoint)
					local PointRamp = Point3D(RampX,RampY,SlabZ)
					local LineRamp = Line3D(PointRamp,SlabHighestPoint)

					local crestlevelArrow1 = DoubleArrow(PointRamp,RampHighestPoint)
					local crestlevelArrow2 = DoubleArrow(PointSlab,SlabHighestPoint)
					local SlabProj = FXMeasure.GetObjProjection(lowestSlab,lowestSlab:GetParent():Elevation())

					if FXRule.EvaluateNumber(operator,rounded,minimumCrestLevel) then
						i = i + 1;
						ARRLowestSlab[i]=lowestSlab
						ARRHighestRamp[i]=highestRamp
						ARRRounded[i]=rounded
						ARRSlabProj[i]=SlabProj
						ARRRampflightGrp[i]=basementRampFlightGrp
						ARRDriveway[i]=drivewayslabCollided
						ARRArrow1[i]=crestlevelArrow1
						ARRArrow2[i]=crestlevelArrow2
						ARRLineSlab[i]=LineSlab
						ARRLineRamp[i]=LineRamp
					else
						isCompliant = false;
						FXUtility.DisplaySolid_Error(lowestSlab,"The Crest Level is higher than the Platform Level by ".. rounded .. "mm",SlabProj);
						CheckReport.AddRelatedObj(highestRamp,"Crest Level: 104.79 m; Platform Level: 104.50 m")
						basementRampFlightGrp:ForEach(function(flightEle)
							CheckReport.AddRelatedObj(flightEle,flightEle:GetAttri("Name"))
						end)
						CheckReport.AddRelatedObj(drivewayslabCollided,drivewayslabCollided:GetAttri("Name"))
						CheckReport.AddRelatedGeometry_Error(crestlevelArrow1)
						CheckReport.AddRelatedGeometry_Error(crestlevelArrow2)
						CheckReport.AddRelatedGeometry_Error(LineSlab)
						CheckReport.AddRelatedGeometry_Error(LineRamp)
					end
				else
					FXUtility.DisplaySolid_Warning(Building, "Ramp is not provided.")
				end
			else
				FXUtility.DisplaySolid_Warning(Building, "Opening and exit element not provided.")
			end
		end)
		
		if isCompliant then

			for i,lowestSlab in pairs(ARRLowestSlab) do
				FXUtility.DisplaySolid_Info(lowestSlab,"The Crest Level is higher than the Platform Level by ".. ARRRounded[i] .. "mm",ARRSlabProj[i]);
				CheckReport.AddRelatedObj(ARRHighestRamp[i],"Crest Level: 104.80 m; Platform Level: 104.50 m")

				ARRRampflightGrp[i]:ForEach(function(flightEle)
					CheckReport.AddRelatedObj(flightEle,flightEle:GetAttri("Name"))
				end)

				CheckReport.AddRelatedObj(ARRDriveway[i],drivewayslabCollided:GetAttri("Name"))
				CheckReport.AddRelatedGeometry_Info(ARRArrow1[i])
				CheckReport.AddRelatedGeometry_Info(ARRArrow2[i])
				CheckReport.AddRelatedGeometry_Info(ARRLineSlab[i])
				CheckReport.AddRelatedGeometry_Info(ARRLineRamp[i])
			end
		end
	end
end