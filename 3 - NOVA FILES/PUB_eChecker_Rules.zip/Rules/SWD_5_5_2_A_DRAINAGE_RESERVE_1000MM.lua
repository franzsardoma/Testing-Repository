local drainReserve = FXGroup.new()
local linedDrain = FXGroup:new()
local sewerPipe = FXGroup:new()
local conDist
local condiOpe
	
function main()	
 	CheckEngine.SetCheckType("Building")	
 	CheckEngine.BindCheckFunc("XMLParser")				
 	CheckEngine.Run()

	CheckEngine.SetCheckType("Building")
 	CheckEngine.BindCheckFunc("CheckRule")		
 	CheckEngine.Run()							
end

function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_5_5_2_A_DRAINAGE_RESERVE_1000MM")
    local GrpObjs = FXRule.filterObjects(parsedXml, Building)
    local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

	condiOpe = Condition1[2]
    conDist = tonumber(Condition1[3])

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if ( k == 2 ) then
				drainReserve = drainReserve + v
				drainReserve = drainReserve:Unique()
			end
			if ( k == 3 ) then
				linedDrain = linedDrain + v
				linedDrain = linedDrain:Unique()
			end
			if ( k == 4 ) then
				sewerPipe = sewerPipe + v
				sewerPipe = sewerPipe - linedDrain
				sewerPipe = sewerPipe:Unique()
			end			
		end
	end
end

function CheckRule(Building)

	local lindrainArray = {}
	local sewpipeArray = {}
	local lineDrainTable
	local sewerPipeTable
	local isCompliant = true
	local disLength
	local arrowGeom
	local drainReservep

	if CheckWarning(Building) then

 		--Getting the low position of line drain
 		--Getting the projection of drainage reserve and lowest point of the lined drain
	 	--Creating node that will set as element for the projection
	 	--Calculating the distance between the lowest position of the line drain and the sewer pipe
 		linedDrain:ForEach(function( linedDrainele )	
  			sewerPipe:ForEach(function( sewerPipeele )
					
	 			local lineDrainlp = FXGeom.GetBoundingBox(linedDrainele):LowPos().z
	 			drainReservep = FXMeasure.GetProjection(drainReserve,lineDrainlp) 	
				local drainresNode = FXUtility.CreateNodeFrom(drainReservep)
				local Distance = FXMeasure.Distance(drainresNode,sewerPipeele)
						
				--Created node should be deleted if it will be used only on a certain part of the system
				FXClashDetection.DeleteNode(drainresNode)	
				disLength = FXUtility.Round(Distance:Length(),0)
				arrowGeom = DoubleArrow(Distance:GetStartPoint(), Distance:GetEndPoint())

				if ( FXRule.EvaluateNumber(condiOpe, disLength, conDist) ) == true then

					isCompliant = true
					lineDrainTable = linedDrainele
					sewerPipeTable = sewerPipeele
				else

					isCompliant = false
					FXUtility.DisplaySolid_Error(linedDrainele, linedDrainele:GetAuxAttri("Entity.ObjectType").. " to " ..sewerPipeele:GetAuxAttri("Entity.ObjectType").." " ,drainReservep)
					CheckReport.AddRelatedObj(sewerPipeele, disLength.. " mm")
					CheckReport.AddRelatedGeometry_Error(arrowGeom, "Arrow3D")
				end
			end)
		end)

		if isCompliant then

			table.insert(lindrainArray,lineDrainTable)
			table.insert(sewpipeArray,sewerPipeTable)
		end
		if isCompliant then

			for k=1, #lindrainArray do

				FXUtility.DisplaySolid_Info(lindrainArray[k], lindrainArray[k]:GetAuxAttri("Entity.ObjectType").. " to " ..sewpipeArray[k]:GetAuxAttri("Entity.ObjectType").." " ,drainReservep)
				CheckReport.AddRelatedObj(sewpipeArray[k], disLength.. " mm")
				CheckReport.AddRelatedGeometry_Solid(arrowGeom, "Arrow3D")
			end
		end
 	end
end

function CheckWarning(Building)
	
	local Warning = true

	if ( #drainReserve == 0 ) then

		FXUtility.DisplaySolid_Warning(Building,"Drainage Reserve is not provided")
		Warning = false
	end
	if ( #linedDrain == 0 ) then
		 		
 		FXUtility.DisplaySolid_Warning(Building,"Line Drain is not provided")
		Warning = false
	end
 	if ( #sewerPipe == 0 ) then

		FXUtility.DisplaySolid_Warning(Building,"Sewer Pipe is not provided")
		Warning = false
 	end

	return Warning
end