--Rafael 10/18/2018
local slabGrpOther = FXGroup:new();
local slabGrpRoadway = FXGroup:new();
local slabGrp = FXGroup:new();
local pipeGrp  =FXGroup:new();
local minVal;
local maxVal;
function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("BuildingStorey");
	CheckEngine.BindCheckFunc("CheckRuleGrp");
	CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end
function XMLParser(Storey)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_3_8_DEPTH_OF_MAINS_COVER")

	
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	minVal = tonumber(ConditionValues[2]);
	maxVal = tonumber(ConditionValues[4]);


	for k,v in pairs(GrpObjs) do
		-- if (k == 5) then
		-- 	roofSpacesGrp = roofSpacesGrp + v
		-- end
		if (k == 2) then
			pipeGrp = pipeGrp + v
			pipeGrp = pipeGrp:Unique()
		end
		if (k == 3) then
			slabGrpOther = slabGrpOther + v
			slabGrpOther = slabGrpOther:Unique()
		end
		if (k == 4) then
			slabGrpRoadway = slabGrpRoadway + v
			slabGrpRoadway = slabGrpRoadway:Unique()
		end
	end
end

function CheckRuleGrp(BuildingStorey)
	local Project = BuildingStorey:GetParent():GetParent():GetParent()
	local slabs = BuildingStorey:GetDescendants("Slab")
	local system = Project:GetChildren("System")

	if slabs ~= nil then
		slabGrp = slabGrp + slabs;
	end
end

function CheckRule(Building)
	-- print(#pipeGrp)
	if #pipeGrp == 0 then
		FXUtility.DisplaySolid_Warning(Building,"PUB Mains Pipe is not provided.")
	else
		pipeGrp:ForEach(function(pipe)
				local pipeBox = FXGeom.GetBoundingBox(pipe);
				local pipeOBB = FXGeom.GetBoundingOBB(pipe);
				local topPipe = pipeBox:HighPos();
				local centerPoint = pipeOBB:GetPos();
				
				slabGrp:ForEach(function(slab)
					if FXRule.IsOverlap(pipe,slab) == 1 then
						-- if FXUtility.HasPatterInString(slab:GetAttri("Name"),"Other Location") == true then
						-- 	local distance,rounded,arrowGeom = DistanceToSlab(slab,centerPoint,topPipe);
							
						-- 	if rounded >= 500 then
						-- 		FXUtility.DisplaySolid_Info(slab,"Main Pipe Cover Distance from the top of the pipe to the surface of the ground: "..rounded.." mm", arrowGeom);
						-- 	else
						-- 		FXUtility.DisplaySolid_Error(slab,"Main Pipe Cover Distance from the top of the pipe to the surface of the ground: "..rounded.." mm", arrowGeom);
						-- 	end
						if FXUtility.HasPatterInString(slab:GetAttri("ObjectType"),"Roadway") == true then
							local distance,rounded,arrowGeom = DistanceToSlab(slab,centerPoint,topPipe);

							if rounded >= maxVal then
								FXUtility.DisplaySolid_Info(pipe,slab:GetAttri("Name").." Cover ="..rounded.." mm", arrowGeom);
							else
								FXUtility.DisplaySolid_Error(pipe,slab:GetAttri("Name").." Cover ="..rounded.." mm", arrowGeom);
							end
						else
							local distance,rounded,arrowGeom = DistanceToSlab(slab,centerPoint,topPipe);
							
							if rounded >= minVal then
								FXUtility.DisplaySolid_Info(pipe,slab:GetAttri("Name").." Cover ="..rounded.." mm", arrowGeom);
							else
								FXUtility.DisplaySolid_Error(pipe,slab:GetAttri("Name").." Cover ="..rounded.." mm", arrowGeom);
							end
						end
					end
				end)
		
		end)
	end
	
end

function DistanceToSlab(Element,CenterPoint,TopPipe)
	if Element ~= nil then
		local slabBox = FXGeom.GetBoundingBox(Element)
		local topSlab = slabBox:HighPos();

		local Pnt1 = Point3D(CenterPoint.x, CenterPoint.y, topSlab.z)
		local Pnt2 = Point3D(CenterPoint.x, CenterPoint.y, TopPipe.z)
		local distance = Pnt1:Distance_Pnt(Pnt2);
		local rounded = FXUtility.Round(distance,0);
		local arrowGeom = DoubleArrow(Pnt1, Pnt2);

		return distance,rounded,arrowGeom;
	end
	return DistanceToSlab;
end