local allWaterCloset = FXGroup.new()
local allSpace = FXGroup.new()
local allCheck = FXGroup.new()
local allStop = FXGroup.new()
function main()
	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.Run()

	CheckEngine.SetCheckType("BuildingStorey")
	.BindCheckFunc("checkRule")
	.Run()
end


function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_4_2_6_CHECK_STOP_WATER_CLOSET")
	
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	-- local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);

	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjsSystem = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	for k,v in pairs(tbl) do
		if k == 2 then
			tblSpace = v
		end
	end
	-- local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	
	for k,v in pairs(GrpObjsSystem) do -- get the model objects
		if k == 3 then
			allWaterCloset = allWaterCloset + v
			allWaterCloset = allWaterCloset:Unique()			
		end
		if k == 4 then
			allCheck = allCheck + v
			allCheck = allCheck:Unique()			
		end	
		if k == 5 then
			allStop = allStop + v
			allStop = allStop:Unique()			
		end			
	end
end

function checkRule(BuildingStorey)
	local closet1 = {}
	local stop1 = {}
	local check1 = {}
	 -- print(#allStop.."stop")
	 -- print(#allCheck.."check")
	-- print(#allSpace.."Space")
	-- print(#allWaterCloset.."water")


local test = checkWaterClosetFlushValve(BuildingStorey)
	if test then
		
		local toiletSpace = FXGroup.new()
		allSpace = BuildingStorey:GetDescendants("Space")
		
		allSpace:ForEach(function (space)
			if (FXUtility.IsBelongToTableElement2(space, tblSpace)) then
				toiletSpace:Add(space)
			end
		end)
		if #toiletSpace ~= 0 then
			toiletSpace:ForEach(function (Toilet)
				local grpClosetNotServed = FXGroup.new()
				local grpcheck = FXGroup.new()
				local grpstop = FXGroup.new()
				local grpcloset = FXGroup.new()

				allStop:ForEach(function (Stop)
					if FXClashDetection.IsCollided(Toilet,Stop) then
						grpstop:Add(Stop)
					end
				end)
			
				allCheck:ForEach(function (check)
					if FXClashDetection.IsCollided(Toilet,check) then
						grpcheck:Add(check)
					end
				end)
			
				allWaterCloset:ForEach(function (closet)
					if FXClashDetection.IsCollided(Toilet,closet) then
						grpcloset:Add(closet)
					end
				end)

				if #grpcloset == 0 then
					FXUtility.DisplaySolid_Warning(Toilet,"No Water Closet flush valve found.");
				else
					if #grpstop == 0 and #grpcheck == 0 then
						FXUtility.DisplaySolid_Error(Toilet,"Check valve and stop valve is not provided in water closets flush valve.")
						grpcloset:ForEach(function(closet)
							CheckReport.AddRelatedObj(closet, closet:GetAttri("Name"))
						end)
					else
						local flag = 0
						local flag1 = false
						local flag2 = false
						local flag3 = false
						local grpclosetNonCom = FXGroup.new()

						grpcloset:ForEach(function (closet)
							if #grpcloset == 1 then
								if #grpstop == 0 then
									FXUtility.DisplaySolid_Error(Toilet,"Stop valve is not provided");
									CheckReport.AddRelatedObj(closet, closet:GetAttri("Name"))
								else
									if #grpcheck == 0 then
										FXUtility.DisplaySolid_Error(Toilet,"Check valve is not provided");
										CheckReport.AddRelatedObj(closet, closet:GetAttri("Name"))
									else
										grpstop:ForEach(function (Stop)
											grpcheck:ForEach(function (check)
												if FXPUB.IsTwoObjsConnected(Stop,check,2) then
													local obbCloset = FXGeom. GetBoundingOBB(closet)
													local boxCloset = FXGeom. GetBoundingBox(closet)
													local nodeobb = FXUtility.CreateNodeFrom(obbCloset)
													local prjobb = FXMeasure.GetObjProjection(nodeobb, BuildingStorey:Elevation())
													local closetEdge = FXMeasure.GetOuterEdge(prjobb)
													local closetLine = GetShortestLine(closetEdge)
													local closetpoint = FXUtility.CenterPoint(closetLine:GetStartPoint(), closetLine:GetEndPoint())
													local conPipes = Stop:GetConnectedSegment()
													local prjpipe
													FXClashDetection.DeleteNode(nodeobb)
													conPipes:ForEach(function (pipe)
														prjpipe = FXMeasure.GetObjProjection(pipe, BuildingStorey:Elevation())
														return false
													end)
													local pipeEdge = FXMeasure.GetOuterEdge(prjpipe)
													local pipeLine = GetLongestLine(pipeEdge)
												
													if FXUtility.IsPerpendicular(closetLine,pipeLine) == true then
														FXUtility.DisplaySolid_Error(closet,"Common pipe serving a water closets does have a check valve and stop valve, yet it's in wrong location.");
													else
														FXUtility.DisplaySolid_Info(closet,"Check valve and Stop valve are provided.")
														CheckReport.AddRelatedObj(Stop, Stop:GetAttri("Name"))
														CheckReport.AddRelatedObj(check, check:GetAttri("Name"))
													end
												end
											end)
										end)
									end
								end
							elseif #grpcloset > 1 then
								if #grpstop == 0 then
									flag2 = true
									-- FXUtility.DisplaySolid_Error(Toilet,"Stop valve is not provided in group of water closets flush valve.");
									-- CheckReport.AddRelatedObj(closet, closet:GetAttri("Name"))
								else
									if #grpcheck == 0 then
										flag3 = true
										-- FXUtility.DisplaySolid_Error(Toilet,"Check valve is not provided in group of water closets flush valve.");
										-- CheckReport.AddRelatedObj(closet, closet:GetAttri("Name"))
									else
										grpstop:ForEach(function (Stop)
											grpcheck:ForEach(function (check)
												if FXPUB.IsTwoObjsConnected(Stop,check,2) then
													local obbCloset = FXGeom. GetBoundingOBB(closet)
													local boxCloset = FXGeom. GetBoundingBox(closet)
													local nodeobb = FXUtility.CreateNodeFrom(obbCloset)
													local prjobb = FXMeasure.GetObjProjection(nodeobb, BuildingStorey:Elevation())
													local closetEdge = FXMeasure.GetOuterEdge(prjobb)
													local closetLine = GetShortestLine(closetEdge)
													local closetpoint = FXUtility.CenterPoint(closetLine:GetStartPoint(), closetLine:GetEndPoint())
													local conPipes = Stop:GetConnectedSegment()
													local prjpipe
													FXClashDetection.DeleteNode(nodeobb)
													conPipes:ForEach(function (pipe)
														prjpipe = FXMeasure.GetObjProjection(pipe, BuildingStorey:Elevation())
														return false
													end)
													local pipeEdge = FXMeasure.GetOuterEdge(prjpipe)
													local pipeLine = GetLongestLine(pipeEdge)

													if FXUtility.IsPerpendicular(closetLine,pipeLine) == true then
													
														flag1 = true
													else
													if flag ~= 2 then
														table.insert(closet1,closet)
														table.insert(stop1,Stop)
														table.insert(check1,check)
														flag = 1
													end
														local obbstop = FXGeom. GetBoundingOBB(Stop)
														local obbcheck = FXGeom. GetBoundingOBB(check)
														local stopPoint = obbstop:GetPos()
														local checkPoint = obbcheck:GetPos()
														if boxCloset:y_range() < boxCloset:x_range() then
															if stopPoint.y > checkPoint.y then
																if closetpoint.y > stopPoint.y then
																	table.insert(closet1,closet)
																	table.insert(stop1,Stop)
																	table.insert(check1,check)
																	-- grpClosetNotServed:Add(closet)
																	flag = 2
																	
																end
															else
																if closetpoint.y < stopPoint.y then
																	table.insert(closet1,closet)
																	table.insert(stop1,Stop)
																	table.insert(check1,check)
																	-- grpClosetNotServed:Add(closet)
																	flag = 2
																	
																end
															end
														else
															if stopPoint.x > checkPoint.x then
																if closetpoint.x > stopPoint.x then
																	table.insert(closet1,closet)
																	table.insert(stop1,Stop)
																	table.insert(check1,check)
																	-- grpClosetNotServed:Add(closet)
																	flag = 2
																	
																end
															else
																if closetpoint.x < stopPoint.x then
																	table.insert(closet1,closet)
																	table.insert(stop1,Stop)
																	table.insert(check1,check)
																	-- grpClosetNotServed:Add(closet)
																	flag = 2
																	
																end
															end
														end
													end
												end
											end)
										end)
									end
								end
							end
						end)
						if flag == 2 then
							for i = 1, #closet1 do
								FXUtility.DisplaySolid_Error(Toilet,"Check valve and stop valve are provided in group of water closets flush valve, yet doesn't serve all.");
								CheckReport.AddRelatedObj( closet1[i], closet1[i]:GetAttri("ObjectType") )
								CheckReport.AddRelatedObj( stop1[i], stop1[i]:GetAttri("ObjectType") )
								CheckReport.AddRelatedObj( check1[i], check1[i]:GetAttri("ObjectType") )
							end

						elseif flag == 1 then
								for i = 1, #closet1 do
								FXUtility.DisplaySolid_Info(Toilet,"Check valve and Stop valve are provided in group of water closets flush valve.")
								CheckReport.AddRelatedObj( closet1[i], closet1[i]:GetAttri("ObjectType") )
								CheckReport.AddRelatedObj( stop1[i], stop1[i]:GetAttri("ObjectType") )
								CheckReport.AddRelatedObj( check1[i], check1[i]:GetAttri("ObjectType") )
							end
						end
					
						if flag1 == true then
							-- return false
							FXUtility.DisplaySolid_Error(Toilet,"Check valve and Stop valve are provided in group of water closets flush valve, yet it's in wrong location.");
							grpcloset:ForEach(function (Non)
								CheckReport.AddRelatedObj(Non, Non:GetAttri("Name"))
							end)
							grpstop:ForEach(function (Sto)
								CheckReport.AddRelatedObj(Sto, Sto:GetAttri("Name"))
							end)
							grpcheck:ForEach(function (che)
								CheckReport.AddRelatedObj(che, che:GetAttri("Name"))
							end)
						end
						if flag2 == true then
							-- return false
							FXUtility.DisplaySolid_Error(Toilet,"Stop valve is not provided in group of water closets flush valve.");
							grpcloset:ForEach(function (Non)
								CheckReport.AddRelatedObj(Non, Non:GetAttri("Name"))
							end)
							grpstop:ForEach(function (Sto)
								CheckReport.AddRelatedObj(Sto, Sto:GetAttri("Name"))
							end)
							grpcheck:ForEach(function (che)
								CheckReport.AddRelatedObj(che, che:GetAttri("Name"))
							end)
						end
						if flag3 == true then
							-- return false
							FXUtility.DisplaySolid_Error(Toilet,"Check valve is not provided in group of water closets flush valve.");
							grpcloset:ForEach(function (Non)
								CheckReport.AddRelatedObj(Non, Non:GetAttri("Name"))
							end)
							grpstop:ForEach(function (Sto)
								CheckReport.AddRelatedObj(Sto, Sto:GetAttri("Name"))
							end)
							grpcheck:ForEach(function (che)
								CheckReport.AddRelatedObj(che, che:GetAttri("Name"))
							end)
						end
					end
				end
			 	-- print(#grpcloset.."closet")
			 	-- print(#grpcheck.."check")
				 -- print(#grpstop.."stop")
			end)
		-- else
		-- 	FXUtility.DisplaySolid_Warning(BuildingStorey,"No Water Closet flush valve found.");
		end
	end
end



function GetShortestLine( route )

	local PolyLinePointNumber = route:GetPointNumber()    --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = route:GetPoint(i)
		local Point2 = route:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() > Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetLongestLine( route )

	local PolyLinePointNumber = route:GetPointNumber()    --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = route:GetPoint(i)
		local Point2 = route:GetPoint(i+1)
		local Line = Line3D(Point1, Point2)
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function checkWaterClosetFlushValve(BuildingStorey)
	if #allWaterCloset == 0 then
		FXUtility.DisplaySolid_Warning(BuildingStorey	,"No Water Closet flush valve found.");
		return false;
	end
	return true;
end

-- if flag == true then
-- 														FXUtility.DisplaySolid_Error(Toilet,"Check valve and stop valve are provided in group of water closets flush valve, yet doesn’t serve all.");								
-- 														grpClosetNotServed:ForEach(function (Not)
-- 															CheckReport.AddRelatedObj(Not, Not:GetAttri("Name"))
-- 														end)
-- 														grpstop:ForEach(function (Sto)
-- 															CheckReport.AddRelatedObj(Sto, Sto:GetAttri("Name"))
-- 														end)
-- 														grpcheck:ForEach(function (che)
-- 															CheckReport.AddRelatedObj(che, che:GetAttri("Name"))
-- 														end)
						
-- 													else
-- 														flag2 = true
-- 													end