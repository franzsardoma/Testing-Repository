local SystemTypes;
local grpFlowSegment = FXGroup:new();
local InspectionChamberGrp = FXGroup:new()
local pipeName;
local pipeDescription;
local connectedDrain = FXGroup:new()




function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end




function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_1_3_2_B_MAIN_DRAIN_LINE")
	
	
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjsBuilding) do
		if (k == 2) then
			grpFlowSegment = grpFlowSegment + v;
			grpFlowSegment = grpFlowSegment:Unique();
		end
		if (k == 3) then
			InspectionChamberGrp = InspectionChamberGrp + v;
			InspectionChamberGrp = InspectionChamberGrp:Unique();
		end
	end
end


function checkRule(Building)

	local connectingObject;
	local checkedChambers = FXGroup.new()
	if #grpFlowSegment ~= 0 then
	

		local FlowFittingGrp = Building:GetDescendants("FlowFitting")
		FlowFittingGrp = FlowFittingGrp:Unique()
		if #FlowFittingGrp > 0 then

			FlowFittingGrp:ForEach(function ( flowfitting )
				local isCompliant = false;
				local isConnectedtoMainDrain = false;
				if not (FXUtility.HasPatterInString(flowfitting:GetAttri("Name"), "coupling" )) then
					local connectedPipes = FXGroup.new();
					-- local connectedChamber = FXGroup.new();
					local mainDrain;
					local pipe1;
					local pipe2;

					grpFlowSegment:ForEach(function ( pipe )
						
						local distance = FXMeasure.Distance(flowfitting, pipe)
						if (distance:Length() <= 10) then
						-- if FXClashDetection.IsCollided(flowfitting, pipe) then
						-- if FXPUB.IsObjsConnected(flowfitting, pipe) then
					
							connectingObject = flowfitting;
							isConnectedtoMainDrain = true;
							connectedPipes:Add(pipe)
							
							pipe1 = pipe;
							if mainDrain == nil then
								mainDrain = pipe;
							end
						end
				
					
						InspectionChamberGrp:ForEach(function ( chamber )
							-- local distance = FXMeasure.Distance(flowfitting, chamber)
							-- if (distance:Length() <= 10) then
							if FXClashDetection.IsCollided(flowfitting, chamber) then
								-- connectedChamber:Add(chamber)
								checkedChambers:Add(chamber)
								if FXClashDetection.IsCollided(pipe, chamber) then 
									isCompliant = true;
									connectingObject = chamber;
									pipe2 = pipe;
								end
							end
						end)
					end)
					
					if (#connectedPipes > 1)then
						isCompliant = false;
						pipe1 = nil;
						connectedPipes:ForEach(function (connPipe)
							if pipe1 == nil then
								pipe1 = connPipe;
							else
								pipe2 = connPipe;
							end
						end)
					end
					
					if isConnectedtoMainDrain then
						CheckResult(Building, isCompliant, pipe1, pipe2, flowfitting, mainDrain, connectedPipes, connectingObject, pipe1, pipe2)
					end
				end
			end)
		end

		if #InspectionChamberGrp > 0 then
			InspectionChamberGrp = InspectionChamberGrp - checkedChambers;
			InspectionChamberGrp:ForEach(function ( chamber )
				local connectedPipes = FXGroup.new();
				local connectingObject;
				local mainDrain;
				local pipe1;
				local pipe2;

				grpFlowSegment:ForEach(function ( pipe )
				local isCompliant = false;


					local distance = FXMeasure.Distance(chamber, pipe)
					if (distance:Length() <= 10) then
						connectingObject = chamber;
						connectedPipes:Add(pipe)
						if mainDrain == nil then
							mainDrain = pipe;
						end
					end
				
				end)

				if #connectedPipes > 1 then
					
					isCompliant = true;
					connectedPipes:ForEach(function (connPipe)
						if pipe1 == nil then
							pipe1 = connPipe;
						else
							pipe2 = connPipe;
						end
					end)

					CheckResult(Building, isCompliant, pipe1, pipe2, flowfitting, mainDrain, connectedPipes, connectingObject, pipe1, pipe2)

				else
					FXUtility.DisplaySolid_Warning(Building, "Only one main drain-line is connected to inspection chamber.")
				end
				
			end)
		end

		if #FlowFittingGrp == 0 and #InspectionChamberGrp == 0 then
			FXUtility.DisplaySolid_Warning(Building, "Main drain-line is not provided.")
		end
			

	else
		FXUtility.DisplaySolid_Warning(Building, "Main drain-line is not provided.")
	end
end

function detectChanges(firstPipe, secondPipe, connectingElement, Building)
	local change = "";

	local firstPipeSlope = firstPipe:GetAuxAttri("Constraints.Slope")
	local secondPipeSlope = secondPipe:GetAuxAttri("Constraints.Slope")
	local firstPipeSlope2 = firstPipe:GetAuxAttri("AC_Pset_Pipe_Straight_21.Slope Angle")
	local secondPipeSlope2 = secondPipe:GetAuxAttri("AC_Pset_Pipe_Straight_21.Slope Angle")

	if firstPipeSlope ~= nil and secondPipeSlope ~= nil then
		if firstPipeSlope ~= secondPipeSlope then
			change = "change in gradient"
		end
	elseif firstPipeSlope2 ~= nil and secondPipeSlope2 ~= nil then
		if firstPipeSlope2 ~= secondPipeSlope2 then
			change = "change in gradient"
		end
	end

	local firstPipeDiameter = firstPipe:GetAuxAttri("Mechanical.Diameter")
	local secondPipeDiameter = secondPipe:GetAuxAttri("Mechanical.Diameter")
	local firstPipeDiameter2 = firstPipe:GetAuxAttri("AC_Pset_Pipe_Straight_21.Nominal Size")
	local secondPipeDiameter2 = secondPipe:GetAuxAttri("AC_Pset_Pipe_Straight_21.Nominal Size")

	if firstPipeDiameter ~= nil and secondPipeDiameter ~= nil then
		if firstPipeDiameter ~= secondPipeDiameter then
			change = "change in diameter"
		end
	elseif firstPipeDiameter2 ~= nil and secondPipeDiameter2 ~= nil then
		if firstPipeDiameter2 ~= secondPipeDiameter2 then
			change = "change in diameter"
		end
	end

	local firstPipeMaterial = firstPipe:GetAuxAttri("Identity Data(Type).Type Name")
	local secondPipeMaterial = secondPipe:GetAuxAttri("Identity Data(Type).Type Name")
	local firstPipeMaterial2 = firstPipe:GetAttri("Name")
	local secondPipeMaterial2 = secondPipe:GetAttri("Name")
	
	if firstPipeMaterial ~= nil and secondPipeMaterial ~= nil then
		if firstPipeMaterial ~= secondPipeMaterial then
			change = "change in material"
		end
	elseif firstPipeMaterial2 ~= nil and secondPipeMaterial2 ~= nil then
		if firstPipeMaterial2 ~= secondPipeMaterial2 then
			change = "change in material"
		end
	end

	local firstPipeDirection = FXMeasure.GetProjectionCenterLine(firstPipe)
	local secondPipeDirection = FXMeasure.GetProjectionCenterLine(secondPipe)
	if FXUtility.IsParallel(firstPipeDirection, secondPipeDirection, 0.1) == false then
		change = "bend"
	end

	if connectingElement ~= nil then
		local connectingEleType = connectingElement.Type
		if connectingEleType == "FlowFitting" then
			local connectedPipes = connectingElement:GetConnectedElement();
			local temp = connectingElement:GetParent();
			local grpPipes = temp:GetChildren("FlowSegment");
			if #connectedPipes ~= nil and #connectedPipes > 2 then
				connectedDrain = connectedPipes
				change = "junction"
			else
				local grpCon = FXGroup:new();
				grpPipes:ForEach(function(pipe)
					if FXClashDetection.IsCollided(pipe,connectingElement) then
						grpCon:Add(pipe);
					end
				end)
				if grpPipes ~= nil and #grpCon > 2 then
					connectedDrain = connectedPipes
					change = "junction"
				end
			end
		else
			local FlowSegments = Building:GetDescendants("FlowSegment")
			local connectedPipes = FXGroup.new()
			FlowSegments:ForEach(function ( pipe )

				local distance = FXMeasure.Distance(connectingElement, pipe)
				if (distance:Length() <= 10) then
					connectedPipes:Add(pipe)
					connectedDrain:Add(pipe)
				end

			end)

			if #connectedPipes > 2 then
				change = "junction"
			end
		end
	end

	return change;
end

function CheckResult(Building, isCompliant, pipe1, pipe2, flowfitting, mainDrain, connectedPipes, connectingObject, pipe1, pipe2)
	if isCompliant then
		FXUtility.DisplaySolid_Info(Building, mainDrain:GetAttri("ObjectType").." has Inspection Chamber at "..detectChanges(pipe1, pipe2, connectingObject, Building));
		CheckReport.AddRelatedObj( connectingObject, connectingObject:GetAttri("Name") )
		if #connectedPipes >  1 then
			connectedPipes:ForEach(function (connPipe)
				CheckReport.AddRelatedObj( connPipe, connPipe:GetAttri("Name") )
			end)
		else
			CheckReport.AddRelatedObj( pipe1, pipe1:GetAttri("Name") )
			CheckReport.AddRelatedObj( pipe2, pipe2:GetAttri("Name") )
		end

		if #connectedDrain ~= 0 then
			connectedDrain = connectedDrain - connectedPipes;
			connectedDrain:ForEach(function (connDrain)
				CheckReport.AddRelatedObj( connDrain, connDrain:GetAttri("Name") )
			end)
		end 
		
	else
		FXUtility.DisplaySolid_Error(Building, mainDrain:GetAttri("ObjectType").." has no Inspection Chamber at "..detectChanges(pipe1, pipe2, flowfitting, Building));
		if #connectedPipes >  1 then
			connectedPipes:ForEach(function (connPipe)
				CheckReport.AddRelatedObj( connPipe, connPipe:GetAttri("Name") )
			end)
		else
			CheckReport.AddRelatedObj( pipe1, pipe1:GetAttri("Name") )
			CheckReport.AddRelatedObj( pipe2, pipe2:GetAttri("Name") )
		end

		if connectingObject ~= nil then
			CheckReport.AddRelatedObj( connectingObject, connectingObject:GetAttri("Name") )
		end

		if #connectedDrain ~= 0 then
			connectedDrain = connectedDrain - connectedPipes;
			connectedDrain:ForEach(function (connDrain)
				CheckReport.AddRelatedObj( connDrain, connDrain:GetAttri("Name") )
			end)
		end
	end
end


