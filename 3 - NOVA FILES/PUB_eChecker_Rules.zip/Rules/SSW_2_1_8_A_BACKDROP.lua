local grpManhole = FXGroup.new()
local grpIncomingSewer = FXGroup.new()
local grpPublicSewer = FXGroup.new()
local grpBackdrop = FXGroup.new()
local operator
local condiValue

function main()

	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("checkRule")
	CheckEngine.RunCheckPipeline()
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_2_1_8_A_BACKDROP")
	local GrpObjs = FXRule.filterObjects(parsedXml, Building)
	local Condition1 = FXRule.ParseValues(parsedXml, "Condition1")

	operator = Condition1[2]
	condiValue = tonumber(Condition1[3])

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpManhole = grpManhole + v;
			grpManhole = grpManhole:Unique()
		end
		if (k == 3) then
			grpIncomingSewer = grpIncomingSewer + v
			grpIncomingSewer = grpIncomingSewer:Unique()
		end
		if (k == 4) then
			grpPublicSewer = grpPublicSewer + v
			grpPublicSewer = grpPublicSewer:Unique()
		end
		if (k == 5) then
			grpBackdrop = grpBackdrop + v
			grpBackdrop = grpBackdrop:Unique()
		end
	end
end

function checkRule(Building)

	if CheckWarning(Building) then

		grpManhole:ForEach(function(Manhole)

			local incomingSewerCenterLineZ
			local publicSewerCenterLineZ
			local incomingSewer
			local isCompliant = false
			local isConnectedToSewerConnection = false
			local isConnectedToPublicSewer = false
			local manholeName = Manhole:GetAttri("Name")
			local backdrop1
			local verticalDistance

			grpIncomingSewer:ForEach(function(sewer)

				if ( FXPUB.CheckConnectedChamberElement(Building,Manhole, sewer) ) then

					incomingSewer = sewer
					incomingSewerCenterLineZ = FXUtility.Round(FXGeom.GetBoundingBox(sewer):LowPos().z,2)
					isConnectedToSewerConnection = true
				end
			end)

			grpPublicSewer:ForEach(function(sewer)

				if ( FXClashDetection.IsCollided(Manhole, sewer) ) then

					publicSewerCenterLineZ = FXUtility.Round(FXGeom.GetBoundingBox(sewer):LowPos().z,2)
					isConnectedToPublicSewer = true
				end
			end)
		
			verticalDistance = FXUtility.Round(incomingSewerCenterLineZ - publicSewerCenterLineZ, 2)

			if ( isConnectedToSewerConnection == false ) then

				FXUtility.DisplaySolid_Warning(Building, "Sewer Connection not connected to Manhole")
			elseif ( isConnectedToPublicSewer == false ) then

				FXUtility.DisplaySolid_Warning(Building, "Public Sewer not connected to Manhole")
			else

				if ( FXRule.EvaluateNumber(operator,verticalDistance,condiValue) ) == true then

					vDistance = FXUtility.Round(verticalDistance/1000, 2)

					if ( #grpBackdrop ~= 0 )  then

						grpBackdrop:ForEach(function(backdrop)

							backdrop1 = backdrop

							if ( FXPUB.CheckConnectedChamberElement(Building, Manhole, backdrop) )then

								if ( FXPUB.IsObjsConnected(backdrop, incomingSewer) ) then

									isCompliant  = true
								end
							end							
						end)
					else

						isCompliant = false
						FXUtility.DisplaySolid_Error(Manhole, manholeName..":  Backdrop connection is not found.")
						CheckReport.AddRelatedObj(Manhole, "Vertical Distance: "..vDistance.." m")		
					end
				else

					FXUtility.DisplaySolid_Warning(Building, "Vertical Distance between Incoming Sewer and Public Sewer is less than 1.5m")
				end

				CheckResult(isCompliant, manholeName, Manhole, vDistance, backdrop1)
			end
		end)
	end
end

function CheckResult(isCompliant, manholeName, Manhole, verticalDistance, backdrop1)
	
	if isCompliant then

		FXUtility.DisplaySolid_Info(Manhole, Manhole:GetAttri("Name")..":  Backdrop connection is found.")
		CheckReport.AddRelatedObj(Manhole,"Vertical Distance: "..vDistance.." m")
		CheckReport.AddRelatedObj(backdrop1,backdrop1:GetAttri("ObjectType"))
	end
end

function CheckWarning(Building)

	local noWarning = true

	if (#grpManhole == 0) then

		FXUtility.DisplaySolid_Warning(Building, "No Manhole found.")
		noWarning = false
	end

	if (#grpIncomingSewer == 0) then

		FXUtility.DisplaySolid_Warning(Building, "No Sewer Connection found.")
		noWarning = false
	end

	if (#grpPublicSewer == 0) then

		FXUtility.DisplaySolid_Warning(Building, "No Public Sewer found.")
		noWarning = false
	end

	return noWarning
end
