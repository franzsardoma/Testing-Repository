local grpFlowStorageDevice = FXGroup:new();
local grpFlowTerminal = FXGroup:new();
local grpFlowSegment = FXGroup:new();
local ConditionValues
local siteValTbl = {}
local isCheckable = true

function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_2_6_A_WATER_SUPPLY_FITTING")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType");-- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local tblValues = FXRule.filterTableValues(parsedXml, Building)
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	print(xmlObjs)
	if xmlObjs ~= nil then
		for k,v in pairs(xmlObjs) do -- get the model objects
			if k == 2 then
				grpFlowTerminal = grpFlowTerminal + v
	 			grpFlowTerminal = grpFlowTerminal:Unique()			
			end
	 		if k == 4 then
	 			grpFlowStorageDevice = grpFlowStorageDevice + v
	 			grpFlowStorageDevice = grpFlowStorageDevice:Unique()			
	 		end	
	 		if k == 5 then
	 			grpFlowSegment = grpFlowSegment + v
	 			grpFlowSegment = grpFlowSegment:Unique()			
	 		end				
		end

		for k,v in pairs(tblValues) do		
			for k1,v1 in pairs(v) do
				if (k == 2) then
					--site
					ObjValue = v1["value"]
					table.insert(siteValTbl, ObjValue)
				end	
				if (k == 3) then
					--flow Storage
					ObjProp2 = v1["property"]				
				end		
				if (k == 4) then
					--pipe segment
					ObjProp3 = v1["property"]
				end
			end
		end
	else
		isCheckable = false	
	end
end

function checkRule(Building)
	

	local desiredMRL = tonumber(ConditionValues[1])
	local grpFlowSeg = Building:GetDescendants("FlowSegment")
	local HighestPipe = GetHighestObj(grpFlowSeg)
	local grpTerminalToCheck = FXGroup.new()
	grpNonC = FXGroup.new()
	local highestStorey = GetHighestStorey(Building)
	-- local slabs = highestStorey:GetChildren("Slab")
	local SiteRefElev, LevelElev
	local bldgStorey = Building:GetChildren("BuildingStorey")
	local slab = Building:GetDescendants("Slab")

	slab:ForEach(function ( slabObj )
		Slab = slabObj
	end)
	
	bldgStorey:ForEach(function ( bldgStoreyObj )
		if ( FXUtility.HasPatterInString(bldgStoreyObj:GetAttri("Name"), "level 01") or FXUtility.HasPatterInString(bldgStoreyObj:GetAttri("Name"), "storey 01") or FXUtility.HasPatterInString(bldgStoreyObj:GetAttri("Name"), "level 1")) then
			LevelElev = bldgStoreyObj:Elevation()
			print("x")
		end
		-- slabs = bldgStoreyObj
	end)

	local SiteRefElev = Building:GetParent()
	local minMRL = (desiredMRL - (SiteRefElev:GetAttri("RefElevation") + LevelElev)) + LevelElev
	-- local maxMRL = (137000 - (SiteRefElev:GetAttri("RefElevation") + LevelElev)) + LevelElev

	local prjMinMRL = FXMeasure.GetObjProjection(Slab, minMRL)
	-- local prjMaxMRL = FXMeasure.GetProjection(slabs, maxMRL)

	if isCheckable == false then
		FXUtility.DisplaySolid_Warning(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
		CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)

		FXUtility.DisplaySolid_Warning(Building,"No fitting found");
		FXUtility.DisplaySolid_Warning(Building,"No pipe found.");
		return
	end


		grpFlowTerminal:ForEach(function (terminal)
			local termHPoint = FXGeom.GetBoundingOBB(terminal):MaxPnt().z;
			if termHPoint < minMRL then
				grpTerminalToCheck:Add(terminal)
			else
				grpNonC:Add(terminal)
			end
		end)
		local site = Building:GetParent("Site")
		local name = site:GetAuxAttri("Other.Project Development Type");

		if FXUtility.HasPatterInString(name, siteValTbl[1]) or FXUtility.HasPatterInString(name, siteValTbl[2]) then

			local flag
			local grpNonCom = FXGroup.new()
			if #grpTerminalToCheck ~= 0 then
				grpTerminalToCheck:ForEach(function ( term )
					if #grpFlowStorageDevice ~= 0 then
						grpFlowStorageDevice:ForEach(function ( storage )
							if FXPUB.IsObjsConnected(storage,term,100) == true then
								if flag ~= false then
									if #grpFlowSegment ~= 0 then

										grpFlowSegment:ForEach(function ( pipe )
											if FXPUB.IsObjsConnected(storage,pipe,100) == true then
												if flag ~= true then
													FXUtility.DisplaySolid_Info(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
													CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)
													FXUtility.DisplaySolid_Info(site,"Project Development Type: "..name);
												end
												flag = true
												FXUtility.DisplaySolid_Info(term,term:GetAttri("Name")..": connected to "..storage:GetAttri(ObjProp2));
											end
											return false
										end)
									else
										FXUtility.DisplaySolid_Warning(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
										CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)		
										FXUtility.DisplaySolid_Warning(Building,"No fitting found");
										FXUtility.DisplaySolid_Warning(Building,"No pipe found.");
									end
								end
							else
								if flag == false then
									FXUtility.DisplaySolid_Error(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
									CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)
									FXUtility.DisplaySolid_Error(site,"Project Development Type: "..name);
								end
								flag = false
								FXUtility.DisplaySolid_Error(term,term:GetAttri("Name")..": Not connected to "..storage:GetAttri(ObjProp2));
							end
						end)
					else
						if flag ~= false then
							FXUtility.DisplaySolid_Error(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
							CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)
							FXUtility.DisplaySolid_Error(site,"Project Development Type: "..name);
						end
						flag = false
						FXUtility.DisplaySolid_Error(term,term:GetAttri("Name")..": Not connected to HL Water Tank");
					end 
				end)
			else
			end
	local flag1
			grpNonC:ForEach(function ( non )
				
				if flag1 ~= false then
					FXUtility.DisplaySolid_Error(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
					CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)

					FXUtility.DisplaySolid_Error(site,"Project Development Type: "..name);
				end
				flag1 = false
				FXUtility.DisplaySolid_Error(non,non:GetAttri("Name")..": Above 25.0 SHD");
			end)
			if flag == true and flag ~= nil then

				grpFlowStorageDevice:ForEach(function (storage)
					FXUtility.DisplaySolid_Info(HighestPipe,HighestPipe:GetAttri("Name")..": connected to "..storage:GetAttri(ObjProp2));
					return false
				end)

			elseif flag == false and flag ~= nil then
				FXUtility.DisplaySolid_Error(HighestPipe,HighestPipe:GetAttri("Name")..": Not connected to HL Water Tank");	
			end
		else
			local flag
			if #grpFlowSegment ~= 0 then
				grpFlowSegment:ForEach(function ( pipe )
					if #grpNonC == 0 then
						grpTerminalToCheck:ForEach(function ( term )
							if FXPUB.IsObjsConnected(term,pipe,100) == true then
								if flag ~= false then
									if flag ~= true then
										-- FXUtility.DisplaySolid_Info(HighestPipe,HighestPipe:GetAttri("Name")..": connected to "..pipe:GetAttri("Name"));
										FXUtility.DisplaySolid_Info(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
										CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)
									end
									flag = true
									FXUtility.DisplaySolid_Info(term,term:GetAttri("Name")..": connected to "..pipe:GetAttri(ObjProp3));
								end
							else
								if flag ~= false then
									-- FXUtility.DisplaySolid_Error(HighestPipe,HighestPipe:GetAttri("Name")..": Not connected to Pub Main");
									FXUtility.DisplaySolid_Error(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
									CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)
								end
								flag = false
								FXUtility.DisplaySolid_Error(term,term:GetAttri("Name")..": Not connected to "..pipe:GetAttri(ObjProp3));
							end
						end)
					else
						FXUtility.DisplaySolid_Error(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
						CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)

						grpNonC:ForEach(function ( non )
							FXUtility.DisplaySolid_Error(non,non:GetAttri("Name")..": Above 25.0 SHD");
						end)
						FXUtility.DisplaySolid_Error(HighestPipe,HighestPipe:GetAttri("Name")..": connected to "..pipe:GetAttri(ObjProp3));
					end
					if flag == true and flag ~= nil then
						FXUtility.DisplaySolid_Info(HighestPipe,HighestPipe:GetAttri("Name")..": connected to "..pipe:GetAttri(ObjProp3));
						
					elseif flag == false and flag ~= nil then
						FXUtility.DisplaySolid_Error(HighestPipe,HighestPipe:GetAttri("Name")..": Not connected to Pub Main");
					end
					return false
				end)
			else	
				FXUtility.DisplaySolid_Warning(Building, FXPUB.SetStandardMrl(minMRL).." SHD");
				CheckReport.AddRelatedGeometry_SupportedInfo(prjMinMRL)			
				FXUtility.DisplaySolid_Warning(Building,"No fitting found");
				FXUtility.DisplaySolid_Warning(Building,"No pipe found.");				
			end		
		end
end


function GetHighestStorey(Building)
	local HighStorey
	grpStorey = Building:GetDescendants("BuildingStorey")
	grpStorey:ForEach(function (Storey)
		if #FXUtility.GetAllUpperStorey(Storey) == 0 then
			HighStorey = Storey
		end
	end)
	return HighStorey
end
function GetHighestObj(	grp )
	local high
	grp:ForEach(function ( ele )
		if high == nil then
			high = ele
		else
			local highBox = FXGeom. GetBoundingBox(high)
			local eleBox = FXGeom. GetBoundingBox(ele)
			local hpoint = highBox:HighPos()
			local epoint = eleBox:HighPos()
			if hpoint.z < epoint.z then
				high = ele
			end
		end
	end)
	return high
end

