-- Created By: Lawrence Roy Quiling 1/3/2019
-- Modified By: Lawrence Roy Quiling 1/4/2019
-- Modified By: Jayson Barateta 1/31/2019

local grpPipesAndFittings = FXGroup:new()
local ConditionMATERIALS

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "WTR_6_2_1_PROHIBITED_MATERIALS_FOR_PIPING")
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	-- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
	
	ConditionMATERIALS = ConditionValues[2]
	ConditionMATERIALS = string.gsub(ConditionMATERIALS, ", ", ",")

	if GrpObjs ~= nill then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				grpPipesAndFittings = grpPipesAndFittings + v;
				grpPipesAndFittings = grpPipesAndFittings:Unique();
			end
		end
	end

	
end

function checkRule( Building )
	if(#grpPipesAndFittings ~= 0) then
		grpPipesAndFittings:ForEach(function ( PipeFitting )
			local flg, attriPipeFitting = FXPUB.CheckObjMaterial(PipeFitting, ConditionMATERIALS)

			if not flg then
				if attriPipeFitting ~= nil then
					FXUtility.DisplaySolid_Error(PipeFitting,"Pipe material and fitting: "..attriPipeFitting)
				else
					FXUtility.DisplaySolid_Warning(PipeFitting,"Pipe material and fitting are not provided.")
				end
			else
				FXUtility.DisplaySolid_Info(PipeFitting,"Pipe material and fitting: "..attriPipeFitting)
			end

			CheckReport.AddRelatedObj(PipeFitting, PipeFitting:GetAttri("ObjectType"))
		end)
	else
		FXUtility.DisplaySolid_Warning(PipeFitting,"Pipes and fittings are not provided.")
	end
end
