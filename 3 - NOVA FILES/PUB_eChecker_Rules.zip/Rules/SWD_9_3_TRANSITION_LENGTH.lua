--[[-----------------------------------------------------

Author: Monalyn L. Rueda

Rule ID: SWD 9.3 
Rule Name: Minimum Transition Length

All copyrights to novasolutions 
--]]-----------------------------------------------------
local DrainGrp = FXGroup:new()
local CompareDrains = FXGroup:new()
local transition, transition2, line

local TransitionGrp = FXGroup:new()
local CommonDrainGrp = FXGroup:new()

local formula = 0


function main()

	CheckEngine.SetCheckType("Building")
	.BindCheckFunc("XMLParser")
	.RunCheckPipeline()

	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("Storey")
	CheckEngine.RunCheckPipeline()

end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_3_TRANSITION_LENGTH")

	-- local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");

	formula = tonumber(ConditionValues[2] );

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			TransitionGrp = TransitionGrp + v;
			TransitionGrp = TransitionGrp:Unique();			    
		end

		if (k == 3) then
			CommonDrainGrp = CommonDrainGrp + v;
			CommonDrainGrp = CommonDrainGrp:Unique();			    
		end
	end
end

function Storey(BuildingStorey)
	local widest = 0
	local temp = 0

	local widerdrain = 0
	local widestdrain, tempdrain

	if #TransitionGrp == 0 then
		CheckReport.Warning(BuildingStorey,"Drain Transition is not provided.")
		return;
	end

	if #CommonDrainGrp == 0 then
		CheckReport.Warning(BuildingStorey,"Common Drain is not provided.")
		return;
	end

	if CommonDrainGrp ~= 0 then
		CommonDrainGrp:ForEach(function(drain)
			local DrainName = drain:GetAttri('Name')
			local DrainObb = FXGeom.GetBoundingOBB(drain);
			local DrainBox = FXGeom.GetBoundingBox(drain);
			local DrainCenterPnt = DrainObb:GetPos();
			local i = 1;
			local width = 0;

			local Pnt1 = Point3D(DrainCenterPnt.x+10, DrainCenterPnt.y,DrainCenterPnt.z-100)
			local Pnt2 = Point3D(DrainCenterPnt.x-10, DrainCenterPnt.y,DrainCenterPnt.z-100)
			line = Line3D(Pnt1, Pnt2);

			while i > 0 do
				width = width + 1 ;
				local extended = FXMeasure.CreateFaceFromEdge(line, width);
				local extendedNode = FXUtility.CreateNodeFrom(extended);
				if FXClashDetection.IsCollided ( extendedNode , drain ) then
						i = i - 1 	
						FXClashDetection.DeleteNode ( extendedNode );				
				end
				FXClashDetection.DeleteNode ( extendedNode );							
			end

			local widthOfDrain = width * 2

			if temp == 0 then
				temp = widthOfDrain
				tempdrain = drain
			else
				if temp > widthOfDrain then
					widest = temp
					widestdrain = tempdrain
				else
					widest = widthOfDrain
					widestdrain = drain
				end
			end
		end)

		TransitionGrp:ForEach(function(transition)

			if widest ~= 0 then
				local GetTransitionLengthFunc = GetTransitionLength(widest, transition, BuildingStorey, widestdrain, formula)
			end

		end)
	end

end

function GetTransitionLength(widest, transition, storey, widestdrain, formula)

	local TransProj =  FXMeasure.GetObjProjection(transition, storey:Elevation());
	local outer = FXMeasure.GetOuterEdge(TransProj);
	local noOfPnt = outer:GetPointNumber(); 

	for j = 1, noOfPnt -3, 1  do
		local pnt1 = outer:GetPoint(j);
		local pnt2 = outer:GetPoint(j+1);
		local line 	= Line3D(pnt1,pnt2);
		local linedistance = pnt1:Distance_Pnt(pnt2)
		local temp = 0


		local Point1 = Point3D(line:GetEndPoint().x, line:GetEndPoint().y,line:GetEndPoint().z+1000)
		local Point2 = Point3D(line:GetStartPoint().x, line:GetEndPoint().y,line:GetEndPoint().z+1000)
		local distance = Point1:Distance_Pnt(Point2)
		print("--> D" .. distance)
		print("--> LD " .. linedistance)

		if distance <= linedistance and distance ~= 0 then
			local arrowGeom = DoubleArrow(Point1, Point2);
			local polyline = PolyLine3D(TRUE);
			polyline:AddPoint(line:GetStartPoint())
			polyline:AddPoint(Point2)
			polyline:AddPoint(Point1)
			polyline:AddPoint(line:GetEndPoint())

			-- local CompareValue = FXUtility.Round(widest*(1.5), 2); 
			local CompareValue = FXUtility.Round(widest*(formula), 2); 

			-- local NCompareValue = FXUtility.Round(widest*(1.25), 2); 

			local roundeddistance = FXUtility.Round(distance, 2);

			-- print(roundeddistance .. " -- " .. CompareValue)
			
			if 	roundeddistance >= CompareValue then
				FXUtility.DisplaySolid_Info(transition, roundeddistance .. " mm is equal or greater than " .. formula ..  " x " .. widest .. "mm.")
				-- FXUtility.DisplaySolid_Info(transition, roundeddistance .. " mm is greater than or equal to the " .. widestdrain:GetAttri('Name') .. " " .. widest .. " mm x 1.5 = " .. CompareValue .. " mm");
				CheckReport.AddRelatedObj(widestdrain, widestdrain:GetAttri('Name'));
				CheckReport.AddRelatedGeometry_Solid(arrowGeom);
				CheckReport.AddRelatedGeometry_Solid(polyline)

			else

				FXUtility.DisplaySolid_Error(transition, roundeddistance .. " mm is less than " .. formula .. " x " .. widest .. "mm.")
				-- FXUtility.DisplaySolid_Error(transition, roundeddistance .. " mm is less than the " .. widestdrain:GetAttri('Name') .. " " .. widest .. " mm x 1.5 = " .. CompareValue .. " mm");
				CheckReport.AddRelatedObj(widestdrain, widestdrain:GetAttri('Name'));
				-- CheckReport.AddRelatedObj(widestdrain, widestdrain:GetAttri('Name') .. " " .. widest .. " mm x 1.25 = 2000 Not Minimum ");

				-- FXUtility.DisplaySolid_Error(transition, "The minimum length of a transition has less than 1.5 times the width of the wider drain section")
				CheckReport.AddRelatedGeometry_Error(arrowGeom);
				CheckReport.AddRelatedGeometry_Error(polyline) 

			end
		end
	
	end
end 




