local SystemType = "sanitary";
local SpaceName = "swimming pool";
local StorageDeviceName = "balancing tank";
local minDist = 100;
local grpFlowSegment = FXGroup:new();
local grpSlabsGrp = FXGroup:new();
local isPassedPool = true;
local isPassedStorage = true;
local arrProj = {};
local isPoolExist = false;
local isBalancingTankExist = false;
local grpStorageDevices = FXGroup:new()
local grpSpaces = FXGroup:new()
local isCompliant = true;

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("System")
	-- CheckEngine.BindCheckFunc("getSystems")
	-- CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckResult");
	CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_2_2_G_SWIMMING_POOLS")
	
	
	local GrpObjsBuilding = FXRule.filterObjects(parsedXml, Building);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjsBuilding) do
		
	end
	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjsBuilding) do
			if (k == 2) then
				grpFlowSegment = grpFlowSegment + v;
				grpFlowSegment = grpFlowSegment:Unique();
			end
			if (k == 3) then
				grpStorageDevices = grpStorageDevices + v;
				grpStorageDevices = grpStorageDevices:Unique();
			end
			if (k == 4) then
				grpSpaces = grpSpaces + v;
				grpSpaces = grpSpaces:Unique();
			end
		end
	end

end

function getStoreyProjections(Building)

	grpSlabsGrp = Building:GetDescendants("Slab");
	
	return arrProj;
end

function CheckLevel( objEle1, objEle2 ) 
	local objEle1Lvl = string.lower(objEle1:GetParent():GetAttri("Name"));
	local objEle2Lvl = string.lower(objEle2:GetParent():GetAttri("Name"));
	local isSameLvl = FXRule.EvaluateString("Contains", objEle2Lvl, objEle1Lvl);
	
	return isSameLvl;
end

function CheckObj( objEle1, objEle2 )
	
	local isSameLvl = CheckLevel( objEle1, objEle2 );
	
	if( isSameLvl ) then
		return true;
	end
	
	local res = true;
	local cnt = 0;
	local obj1 =  FXGeom.GetBoundingOBB(objEle1);
	local obj1Proj = FXMeasure.GetObjProjection(objEle1, 0);
	local obj1Elev = obj1:MinPnt().z;
	local obj2 =  FXGeom.GetBoundingOBB(objEle2);
	local obj2Proj = FXMeasure.GetObjProjection(objEle2, 0);
	local obj2Elev = obj2:MinPnt().z;
	local grpSlabs = FXGroup:new();
	
	grpSlabsGrp:ForEach(function (slab)
		local obbSlab =  FXGeom.GetBoundingOBB(slab);
		local slabElev = obbSlab:MinPnt().z;
		-- print(obj1Elev.." < "..slabElev.." and "..obj2Elev.." > "..slabElev)
		if( obj1Elev < slabElev and obj2Elev > slabElev ) then
			grpSlabs:Add(slab);
		end
	end)
	
	if( #grpSlabs == 0 ) then
		return true;
	else
		grpSlabs:ForEach(function (slab)
			local obbSlab =  FXGeom.GetBoundingOBB(slab);
			local slabElev = obbSlab:MinPnt().z;
			local slabProj = FXMeasure.GetObjProjection(slab, slabElev);
			local PrjFinal = FXMeasure.SubtractProjection(obj2Proj, slabProj)
			--[[if( slab.Id == 2684365624 ) then
				FXUtility.DisplaySolid_Warning(slab, "PrjFinal A: ",obj1Proj);
				FXUtility.DisplaySolid_Warning(slab, "PrjFinal B: ",obj2Proj);
				FXUtility.DisplaySolid_Warning(slab, "PrjFinal C: ",slabProj);
				FXUtility.DisplaySolid_Warning(slab, "PrjFinal D: ",PrjFinal);
			end]]
			if( PrjFinal == nil ) then
				res = false;
			end
		end)
		
		return res;
	end
			
	return res;
end

function checkRule(Building)
	getStoreyProjections(Building);

	if #grpFlowSegment == 0 then
		FXUtility.DisplaySolid_Warning(Building, "No sanitary pipe found");
		return;
	end

	-- grpSpaces = Building:GetDescendants("Space");
	-- grpStorageDevices = Building:GetDescendants("FlowStorageDevice");
	local strName = "LongName";
	grpSpaces:ForEach(function (Space)
		-- local tempName = Space:GetAttri(strName);
		-- bRet = FXRule.EvaluateString("Contains", string.lower(tempName), SpaceName);
		-- if not bRet then
		-- 	return;
		-- end
		-- print("isPoolExist");
		isPoolExist = true;
		if #grpFlowSegment ~= 0 then
			grpFlowSegment:ForEach(function (FlowSegment)
			
				local isCheckObj = CheckObj( Space, FlowSegment );
				if isCheckObj and Space ~= nil and FlowSegment ~= nil then
					if( isPassedPool  ) then
						isPassedPool = compareObjs(Space, FlowSegment, strName);
					else
						compareObjs(Space, FlowSegment, strName);
					end
				end
			end)
		end
		--------------------------------------------------
		-- if #grpStorageDevices ~= 0 then
		-- 	grpStorageDevices:ForEach(function (FlowStorageDevice)
		-- 		local isCheckObj = CheckObj( Space, FlowStorageDevice );
		-- 		if isCheckObj and Space ~= nil and FlowStorageDevice ~= nil then
		-- 			if( isPassedPool  ) then
		-- 				isPassedPool = compareObjs(Space, FlowStorageDevice, strName);
		-- 			else
		-- 				compareObjs(Space, FlowStorageDevice, strName);
		-- 			end
		-- 		end
		-- 	end)
		-- end
	end)
	
	strName = "Name";
	grpStorageDevices:ForEach(function (FlowStorageDevice)
		-- local tempName = FlowStorageDevice:GetAttri(strName);
		-- bRet = FXRule.EvaluateString("Contains", string.lower(tempName), StorageDeviceName);
		-- if not bRet then
		-- 	return;
		-- end
		
		-- print("isBalancingTankExist");
		isBalancingTankExist = true;
		grpFlowSegment:ForEach(function (FlowSegment)
		
			local isCheckObj = CheckObj( FlowStorageDevice, FlowSegment );

			if isCheckObj and FlowStorageDevice ~= nil and FlowSegment ~= nil then
				if isPassedStorage then
					isPassedStorage = compareObjs(FlowStorageDevice, FlowSegment, strName);
				else
					compareObjs(FlowStorageDevice, FlowSegment, strName);
				end
			end
		end)
	end)
	
end

function CheckResult(Building)

	if( isPoolExist == false ) then
		FXUtility.DisplaySolid_Warning(Building, "No swimming pool found");
	end
	if( isBalancingTankExist == false ) then
		FXUtility.DisplaySolid_Warning(Building, "No balancing tank found");
	end

	if isCompliant then
		if isPassedPool and isPoolExist then
			FXUtility.DisplaySolid_Info(Building, "No Sanitary Pipe above Swimming Pool");
		end

		
		if isPassedStorage and isBalancingTankExist then
			FXUtility.DisplaySolid_Info(Building, "No Sanitary Pipe above Balancing Tank");
		end
	end

end

function compareObjs(Space, FlowSegment, strName)

	local isPassed = true;
	local obb1 =  FXGeom.GetBoundingOBB(Space);
	local Node =  FXClashDetection.CreateNode()
  	FXClashDetection.AddGeometry(Node, obb1)
	local zValue1 = obb1:MinPnt().z;
	local obb2 =  FXGeom.GetBoundingOBB(FlowSegment);
	local zValue2 = obb2:MinPnt().z;
			
	if zValue1 > zValue2 then
		--FXUtility.DisplaySolid_Warning(Space, FlowSegment:GetAttri("Name")..Space:GetAttri(strName));
		--CheckReport.AddRelatedObj(Space, Space.Id);
		--CheckReport.AddRelatedObj(FlowSegment, FlowSegment.Id);
		return true;
	end

	local isOverlap = FXRelation.IsOverlap(Space, FlowSegment);
	local isCollided = FXClashDetection.IsCollided(Node, FlowSegment);
	if isOverlap == -1 or isCollided == true then
		isPassed = false;
		FXUtility.DisplaySolid_Error(Space, FlowSegment:GetAttri("Name").." in "..Space:GetAttri(strName));
		CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("Name"));
		isCompliant = false;
	else
		local nodeContainer	= FXUtility.CreateNodeFrom(obb1);
		local SpaceProj =  FXMeasure.GetObjProjection(nodeContainer, 0.0);
		local FlowSegmentProj =  FXMeasure.GetObjProjection(FlowSegment, 0.0);
		
		if( SpaceProj ~= nil and FlowSegmentProj ~=  nil ) then
			SpaceProj = FXMeasure.MoveProjection(SpaceProj,0);
			FlowSegmentProj = FXMeasure.MoveProjection(FlowSegmentProj,0)
			local node1		= FXUtility.CreateNodeFrom(SpaceProj);
			local node2		= FXUtility.CreateNodeFrom(FlowSegmentProj);

			local distance =  FXRelation.Distance(node1, node2);				
			if distance:Length() < minDist then
				isPassed = false;
				FXUtility.DisplaySolid_Error(Space, FlowSegment:GetAttri("Name").." in "..Space:GetAttri(strName));
				CheckReport.AddRelatedObj(FlowSegment, FlowSegment:GetAttri("Name"));
				isCompliant = false;
			end			
			FXClashDetection.DeleteNode(node1);
			FXClashDetection.DeleteNode(node2);
		end
		
		FXClashDetection.DeleteNode(nodeContainer);
	end
	FXClashDetection.DeleteNode(Node);
	return isPassed;
end