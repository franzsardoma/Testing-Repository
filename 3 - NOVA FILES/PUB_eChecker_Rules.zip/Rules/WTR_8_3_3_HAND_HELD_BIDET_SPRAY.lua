local BidetHoseGrp = FXGroup.new()
local VacBreakerGrp = FXGroup.new()
local CheckValveGrp = FXGroup.new()
local FlexHoseGrp = FXGroup.new()
local BidetGrp = FXGroup.new()
function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "WTR_8_3_3_HAND_HELD_BIDET_SPRAY");
  -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  -- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
  SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 5) then
      BidetHoseGrp = BidetHoseGrp + v;
      BidetHoseGrp = BidetHoseGrp:Unique();
    end
    if (k == 6) then
      VacBreakerGrp = VacBreakerGrp + v;
      VacBreakerGrp = VacBreakerGrp:Unique();
    end
    if (k == 7) then
      CheckValveGrp = CheckValveGrp + v;
      CheckValveGrp = CheckValveGrp:Unique();
    end
  end
end

function checkRule(Building)
	BidetHoseGrp:ForEach(function(bidethoseEle)
	  if FXUtility.HasPatterInString(bidethoseEle:GetAttri("Name"),"flexible hose") == true then
	    FlexHoseGrp:Add(bidethoseEle);
	  end

	  if FXUtility.HasPatterInString(bidethoseEle:GetAttri("Name"),"hand held bidet spray") == true then
	   BidetGrp:Add(bidethoseEle);
	  end
	end)
	if #BidetGrp ~= 0 then
		BidetGrp:ForEach(function(bidetEle)
			local withBreaker = false;
			local withCheckValve = false;
			local VacuumBreaker;
			local CheckValve;
			local hose;
			FlexHoseGrp:ForEach(function(flexhoseEle)
				if FXPUB.IsObjsConnected(bidetEle, flexhoseEle,50) then
					hose = flexhoseEle
					if #VacBreakerGrp ~= 0 then
						VacBreakerGrp:ForEach(function(breakerEle)
							if FXPUB.IsObjsConnected(flexhoseEle, breakerEle,50) then
								withBreaker = true;
								VacuumBreaker = breakerEle
							end
						end)
					end
					if #CheckValveGrp ~= 0 then
						CheckValveGrp:ForEach(function(valveEle)
							if FXPUB.IsObjsConnected(flexhoseEle, valveEle,50) then
								withCheckValve = true;
								CheckValve = valveEle
							end
						end)
					end
				else
					
				end 
			end)

			if withCheckValve == true and withBreaker == true then
				FXUtility.DisplaySolid_Info(bidetEle,"Check valve and Vacuum breaker are provided.")
				CheckReport.AddRelatedObj(CheckValve,CheckValve:GetAttri("Name"))
				CheckReport.AddRelatedObj(VacuumBreaker,VacuumBreaker:GetAttri("Name"))
				CheckReport.AddRelatedObj(hose,hose:GetAttri("Name"))
			elseif withCheckValve == false and withBreaker == true then
				FXUtility.DisplaySolid_Error(bidetEle,"Check valve is not provided.")
				CheckReport.AddRelatedObj(VacuumBreaker,VacuumBreaker:GetAttri("Name"))
				CheckReport.AddRelatedObj(hose,hose:GetAttri("Name"))
			elseif withCheckValve == true and withBreaker == false then
				FXUtility.DisplaySolid_Error(bidetEle,"Vacuum breaker is not provided.")
				CheckReport.AddRelatedObj(CheckValve,CheckValve:GetAttri("Name"))
				CheckReport.AddRelatedObj(hose,hose:GetAttri("Name"))
			else
				FXUtility.DisplaySolid_Error(bidetEle,"Check valve and Vacuum breaker are not provided.")
				CheckReport.AddRelatedObj(hose,hose:GetAttri("Name"))
			end
		end)
	else 
		FXUtility.DisplaySolid_Warning(Building,"Hand Held Bidet Spray is not provided.")
	end
end