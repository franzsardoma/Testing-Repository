-- Author:Mohammad Derick Pauig
local grpTank = FXGroup.new()
local grpHeadTank = FXGroup.new()
local grpDevice = FXGroup.new()
local grpOverflow = FXGroup.new()
local grpDrain = FXGroup.new()



function main()
CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("Parse");
CheckEngine.RunCheckPipeline();

CheckEngine.SetCheckType("Building");
CheckEngine.BindCheckFunc("checkRule");
CheckEngine.RunCheckPipeline();
end

function Parse(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
	-- print("LUA " .. path())
	local parsedXml = FXPUB.ParseXml(path(), "WTR_7_1_10_PROVISION_OF_WATER_STORAGE_TANK_SERIES_COMPARTMENT")

	local systemTypes = FXRule.ParseValues(parsedXml, "SystemType"); -- parse the system type/s
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition"); -- parse the condition values
	-- local tbl = FXPUB.ParseTblValue(parsedXml) -- parse column VALUE only in XML 
	-- for k,v in pairs(tbl) do
	-- 	if k == 5 then
	-- 		tblSpace = v
	-- 	end
	-- end
	local xmlObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, systemTypes)
	--local xmlObjs = FXRule.filterObjects(parsedXml, Building);
	for k,v in pairs(xmlObjs) do -- get the model objects
		if k == 2 then
			grpTank = grpTank + v
			grpTank = grpTank:Unique()			
		end
		if k == 3 then
			grpHeadTank = grpHeadTank + v
			grpHeadTank = grpHeadTank:Unique()			
		end	
		if k == 4 then
			grpDevice = grpDevice + v
			grpDevice = grpDevice:Unique()			
		end		
		if k == 5 then
			grpOverflow = grpOverflow + v
			grpOverflow = grpOverflow:Unique()			
		end	
		if k == 6 then
			grpDrain = grpDrain + v
			grpDrain = grpDrain:Unique()			
		end		
	end
end

function checkRule(Building)
-- print(#grpTank.."tank")
-- print(#grpHeadTank.."head")
-- print(#grpDevice.."dev")
-- print(#grpOverflow.."over")
-- print(#grpDrain.."drain")
	grpTank = grpTank - grpHeadTank
print(#grpTank)
	
	local check = checkParseObj(Building)
	if checkParseObj then
		grpTank:ForEach(function ( tank )
			local tOBB = FXGeom. GetBoundingOBB(tank)
			local IsCompliant
			local grpCompliant = FXGroup.new()
			local grpNonCompliant = FXGroup.new()
			local volume = GetVolume(tank)
			print(volume)
			if volume >= 5000 then
				if #grpHeadTank ~= 0 then
					grpHeadTank:ForEach(function ( head )
						local hOBB = FXGeom. GetBoundingOBB(head)
						if hOBB:GetPos().z > tOBB:GetPos().z then
							if IsCompliant ~= true then
								if FXPUB.IsObjsConnected(tank,head,30) then
									if #grpDevice ~= 0 then
										grpDevice:ForEach(function ( device )
											local count
											if IsCompliant ~= true then
												if FXPUB.IsObjsConnected(tank,device,5) then
													if #grpOverflow ~= 0 then
														grpOverflow:ForEach(function ( flow )
															local count
															if IsCompliant ~= true then
																if FXPUB.IsObjsConnected(tank,flow,5) then
																	if #grpDrain ~= 0 then
																		grpDrain:ForEach(function ( drain )
																			local count
																			if IsCompliant ~= true then
																				if FXPUB.IsObjsConnected(tank,drain,5) then
																					IsCompliant = true
																					grpCompliant:Add(head)
																					grpCompliant:Add(tank)
																					grpCompliant:Add(device)
																					grpCompliant:Add(flow)
																					grpCompliant:Add(drain)
																					-- FXUtility.DisplaySolid_Info(tank,"Header Tank is found connected in the Water Storage Tank")
																				else
																					if count == nil then
																						count = #grpHeadTank
																					else
																						if count ~= 0 then
																							count = count-1
																						else
																							FXUtility.DisplaySolid_Error(tank,"Draining Valve connected in the Water Storage Tank is not provided.")
																						end
																					end
																				end
																			end
																		end)
																	else
																		IsCompliant = false
																		-- grpNonCompliant:Add(tank)
																		FXUtility.DisplaySolid_Error(tank,"Draining Valve connected in the Water Storage Tank is not provided.")
																	end
																else
																	IsCompliant = false
																	grpNonCompliant:Add(tank)
																	if count == nil then
																		count = #grpHeadTank
																	else
																		if count ~= 0 then
																			count = count-1
																		else
																			FXUtility.DisplaySolid_Error(tank,"Overflow Pipe connected in the Water Storage Tank is not provided.")
																		end
																	end
																	-- FXUtility.DisplaySolid_Error(tank,"No Overflow Pipe is found connected in the Water Storage Tank")
																end
															end
														end)
													else
														IsCompliant = false
														-- grpNonCompliant:Add(tank)
														FXUtility.DisplaySolid_Error(tank,"Overflow Pipe connected in the Water Storage Tank is not provided.")
													end
												else
													IsCompliant = false
													grpNonCompliant:Add(tank)
													if count == nil then
														count = #grpHeadTank
													else
														if count ~= 0 then
															count = count-1
														else
															FXUtility.DisplaySolid_Error(tank,"Level Control Device is found connected in the Water Storage Tank is not provided.")
														end
													end
													-- FXUtility.DisplaySolid_Error(tank,"No Level Control Device is found connected in the Water Storage Tank")
												end
											end
										end)
									else
										IsCompliant = false
										-- grpNonCompliant:Add(tank)
										FXUtility.DisplaySolid_Error(tank,"Level Control Device connected in the Water Storage Tank is not provided.")
									end
								else
									IsCompliant = false
									grpNonCompliant:Add(tank)
									if count == nil then
										count = #grpHeadTank
									else
										if count ~= 0 then
											count = count-1
										else
											FXUtility.DisplaySolid_Error(tank,"Header Tankconnected in the Water Storage Tank is not provided.")
										end
									end
								end
							end
						else
							FXUtility.DisplaySolid_Error(tank,"Header Tank is lower than the main Tank")
						end
					end)
				else
					IsCompliant = false
					-- grpNonCompliant:Add(tank)
					FXUtility.DisplaySolid_Error(tank,"Header Tank connected in the Water Storage Tank is not provided.")
				end
				print(IsCompliant)
				if IsCompliant == true then
					print("gh")
					FXUtility.DisplaySolid_Info(tank,"Header Tank is found connected in the Water Storage Tank" .. volume .. " liters")
					grpCompliant:ForEach(function (com)
			 			CheckReport.AddRelatedObj( com, com:GetAttri("Name"));
			 		end)
				end
			else
				FXUtility.DisplaySolid_Error(tank,"Tank is below minimum ".. volume .. " liters")
			end
		end)
	end
end

function GetVolume( OBJ )
		local width
		local length
		local height

	if (OBJ:GetAuxAttri("Dimensions.Width")) == nil then
		width = tonumber(OBJ:GetAuxAttri("Dimensions(Type).Width")) / 1000
		length = tonumber(OBJ:GetAuxAttri("Dimensions(Type).Length")) / 1000 
		height = tonumber(OBJ:GetAuxAttri("Dimensions(Type).Height")) / 1000 
	else
		width = tonumber(OBJ:GetAuxAttri("Dimensions.Width")) / 1000
		length = tonumber(OBJ:GetAuxAttri("Dimensions.Length")) / 1000 
		height = tonumber(OBJ:GetAuxAttri("Dimensions.Height")) / 1000 
	end

	local volume = (width * length * height)/ 0.0010000
	return volume
end

function checkParseObj( Building )
	if #grpTank == 0 or #grpTank == nil then
		FXUtility.DisplaySolid_Warning(Building,"Water Storage Tank is not provided.")
		return false
	end
	return true
end

