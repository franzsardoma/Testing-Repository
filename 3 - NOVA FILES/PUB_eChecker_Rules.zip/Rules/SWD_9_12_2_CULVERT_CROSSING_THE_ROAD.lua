local grpCulvert = FXGroup:new();
local grpSump = FXGroup:new();
local grpGrating = FXGroup:new();
local grpRoad = FXGroup.new();
local compliantCulvert = {}
local compliantSump = {}
local compliantGrating = {}
local compliantHasAdjacentCulvert = {}
local compliantCheckedCulvert = {}
local isAllCompliant = true;


function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()
	
	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("checkRule");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)

	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_9_12_2_CULVERT_CROSSING_THE_ROAD")
	
	--local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	local GrpObjs = FXRule.filterObjects(parsedXml, Building);

	-- SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	-- local SystemType = SystemTypes[1];
	-- local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	for k,v in pairs(GrpObjs) do
		if (k == 2) then
			grpCulvert = grpCulvert + v;
			grpCulvert = grpCulvert:Unique();
		end

		if (k == 3) then
			grpGrating = grpGrating + v;
			grpGrating = grpGrating:Unique();
		end

		if (k == 4) then
			grpSump = grpSump + v;
			grpSump = grpSump:Unique();
		end

		if (k == 5) then
			grpRoad = grpRoad + v;
			grpRoad = grpRoad:Unique();
		end
	end
end


function checkRule( Building )

	if #grpCulvert == 0 then
		CheckReport.Warning(Building,"culvert is not provided.")
		return;
	end

	if #grpSump == 0 then
		CheckReport.Warning(Building,"sump is not provided.")
		return;
	end

	local hasAdjacentCulvert = false;
	if #grpCulvert > 1 then
		grpSump:ForEach(function ( sump )
			local connectedCulvert = FXGroup.new()

			grpCulvert:ForEach(function ( culvert )
				if (FXClashDetection.IsCollided(culvert,sump)) then
					connectedCulvert:Add(culvert)
				elseif (FXRelation.Distance(culvert, sump):Length() < 0.1 ) then
					connectedCulvert:Add(culvert)
				end
			end)

			if #connectedCulvert == 2 then
				hasAdjacentCulvert = true;
				checkCulvertSump(connectedCulvert,  hasAdjacentCulvert)
			end
			
		end)

		if hasAdjacentCulvert == false then
			checkCulvertSump(grpCulvert, hasAdjacentCulvert)
		end

	elseif #grpRoad > 1 then
		local culvertToCheck = FXGroup.new()
		local connectedRoad = FXGroup.new()
	
		grpCulvert:ForEach(function ( culvert )
			grpRoad:ForEach(function ( road )
				if FXRule.IsOverlap(culvert, road) == 1 then
					connectedRoad:Add(road)
					culvertToCheck:Add(culvert)
				end
			end)
		end)

		if #connectedRoad == 2 then
			hasAdjacentCulvert = true;
			checkCulvertSump(culvertToCheck,  hasAdjacentCulvert)
		end

		if hasAdjacentCulvert == false then
			checkCulvertSump(grpCulvert, hasAdjacentCulvert)
		end

	else

		checkCulvertSump(grpCulvert, hasAdjacentCulvert)
			
	end

	finalResult()
end


function checkCulvertSump(culvertGrp, hasAdjacentCulvert)
	local connectedSump = FXGroup.new()
	local sumpHasgrating = FXGroup.new()
	local sumpNograting = FXGroup.new()
	local connectedGrating
	local sumpWithNoGrating
	-- local eachSumpHasGrating
	local isCompliant
	
	if hasAdjacentCulvert then
		local checkedCulvert = FXGroup.new()
		local culvert;

		if #culvertGrp > 1 then
			culvertGrp:ForEach(function ( culvertEle )
				grpSump:ForEach(function ( sump )

					if (FXClashDetection.IsCollided(culvertEle,sump)) then
						connectedSump:Add(sump)
						checkedCulvert:Add(culvertEle)
						culvert = culvertEle
					elseif (FXRelation.Distance(culvertEle, sump):Length() < 0.1 ) then
						connectedSump:Add(sump)
					end
					
				end)
			end)

			connectedSump = connectedSump:Unique()

			isCompliant, connectedGrating, sumpWithNoGrating = checkSumpGrating( connectedSump)
				
			if #sumpWithNoGrating > 0 then
				connectedSump = sumpWithNoGrating
			end

			checkResult(Building, isCompliant, culvert, hasAdjacentCulvert, connectedSump, connectedGrating, checkedCulvert)

		else
			isCompliant = false;

			culvertGrp:ForEach(function ( culvertEle )
				grpSump:ForEach(function ( sump )

					if (FXClashDetection.IsCollided(culvertEle,sump)) then
						connectedSump:Add(sump)
						checkedCulvert:Add(culvertEle)
						culvert = culvertEle
					elseif (FXRelation.Distance(culvertEle, sump):Length() < 0.1 ) then
						connectedSump:Add(sump)
					end
					
				end)
			end)

			checkResult(Building, isCompliant, culvert, hasAdjacentCulvert, connectedSump, connectedGrating)
		end

	else

		culvertGrp:ForEach(function ( culvert )
			grpSump:ForEach(function ( sump )

				if (FXClashDetection.IsCollided(culvert,sump)) then
					connectedSump:Add(sump)
				elseif (FXRelation.Distance(culvert, sump):Length() < 0.1 ) then
					connectedSump:Add(sump)
				end
				
			end)

			isCompliant, connectedGrating, sumpWithNoGrating = checkSumpGrating( connectedSump)

			if #sumpWithNoGrating > 0 then
				connectedSump = sumpWithNoGrating
			end

			checkResult(Building, isCompliant, culvert, hasAdjacentCulvert, connectedSump, connectedGrating)
		end)
		
	end
end


function checkSumpGrating( connectedSump )
	local isCompliant = false
	local eachSumpHasGrating = true;
	local connectedGrating = FXGroup.new()
	local sumpWithNoGrating = FXGroup.new()
	if #connectedSump > 1 then
		if #grpGrating > 0 then
			connectedSump:ForEach(function ( sump )
				local sumpHasGrating = false;
				grpGrating:ForEach(function ( grating )
					if (FXClashDetection.IsCollided(grating,sump)) then
						connectedGrating:Add(grating)
						sumpHasGrating = true;
					end
				end)
			
				if sumpHasGrating == false then
					sumpWithNoGrating:Add(sump)
					eachSumpHasGrating = false
				end

			end)

			if eachSumpHasGrating == true then
				isCompliant = true;
			end

		else
			isCompliant = false
		end
	else 
		isCompliant = false;
	end

	return isCompliant, connectedGrating, sumpWithNoGrating
end


function checkResult( Building, isCompliant, culvert, hasAdjacentCulvert, connectedSump, connectedGrating, checkedCulvert )
	if isCompliant then
		table.insert(compliantCulvert, culvert);
		table.insert(compliantSump, connectedSump);
		table.insert(compliantGrating, connectedGrating);
		table.insert(compliantCheckedCulvert, checkedCulvert);
		table.insert(compliantHasAdjacentCulvert, hasAdjacentCulvert);
	else
		isAllCompliant = false;

		if hasAdjacentCulvert then
			FXUtility.DisplaySolid_Error(culvert:GetParent(), "Sump with galvanised heavy duty mild steel grating is not provided at the centre divider.");
			AddRelatedObj(culvert, connectedSump, connectedGrating, checkedCulvert, hasAdjacentCulvert)
		else
			FXUtility.DisplaySolid_Error(culvert:GetParent(), "Galvanised mild steel grating is not provided at the two side-tables of the road.");
			AddRelatedObj(culvert, connectedSump, connectedGrating)
		end
	end
end

function finalResult()

	if isAllCompliant then
		for i=1, #compliantCulvert do
			if compliantHasAdjacentCulvert[i] then
				FXUtility.DisplaySolid_Info(compliantCulvert[i]:GetParent(), "Sump with galvanised heavy duty mild steel grating is provided at the centre divider.");
				AddRelatedObj(compliantCulvert[i], compliantSump[i], compliantGrating[i], compliantCheckedCulvert[i], compliantHasAdjacentCulvert[i])
			else
				FXUtility.DisplaySolid_Info(compliantCulvert[i]:GetParent(), "Sump and Grating is provided at the two side-tables of the road.");
				AddRelatedObj(compliantCulvert[i], compliantSump[i], compliantGrating[i])
			end
		end
	end
	
end


function AddRelatedObj(culvert, connectedSump, connectedGrating, checkedCulvert, hasAdjacentCulvert)
	if hasAdjacentCulvert and checkedCulvert ~= nil then
		checkedCulvert:ForEach(function ( culvert )
			CheckReport.AddRelatedObj( culvert, culvert:GetAttri("Name") )
		end)
	else
		CheckReport.AddRelatedObj( culvert, culvert:GetAttri("Name") )
	end

	if connectedSump ~= nil then
		connectedSump:ForEach(function ( sump )
			CheckReport.AddRelatedObj( sump, sump:GetAttri("Name") )
		end)
	end

	if connectedGrating ~= nil then
		connectedGrating:ForEach(function ( grating )
			CheckReport.AddRelatedObj( grating, grating:GetAttri("Name") )
		end)
	end
end