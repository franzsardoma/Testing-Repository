local nonCompliantInodoro = FXGroup:new()

function main()
	CheckEngine.SetCheckType("Building")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	CheckEngine.SetCheckType("Site");
	CheckEngine.BindCheckFunc("CheckRuleSystem");
	CheckEngine.RunCheckPipeline();
end


function XMLParser(Building)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_3_4_A_FLUSH_VALVE_USAGE")

	
	local GrpBuildingObjs = FXRule.filterObjects(parsedXml, Building);
	-- local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);

	-- maximumDis = ConditionValues[2]; -- for Condition Values 

	for k,v in pairs(GrpBuildingObjs) do -- Checking in System
		if (k == 6) then
			nonCompliantInodoro = nonCompliantInodoro + v
		end	
	end

	-- for k,v in pairs(GrpObjs) do -- Checking in System
	-- 	if (k == 6) then
	-- 		nonCompliantInodoro = nonCompliantInodoro + v
	-- 	end	
	-- end
end


function CheckRuleSystem( Site )
	print (#nonCompliantInodoro)
	local siteProjectDevelopmentType = Site:GetAuxAttri("Other.Project Development Type")	
		
	if FXUtility.HasPatterInString(siteProjectDevelopmentType ,"Residential") then
		local grpFlowTerminal = Site:GetDescendants("FlowTerminal")
		local isThereWaterCloset = false

		grpFlowTerminal:ForEach ( function ( obj )		
		
			if FXUtility.HasPatterInString( obj:GetAttri("Name") ,"WC") or FXUtility.HasPatterInString( obj:GetAttri("Name") ,"UR") then
				isThereWaterCloset = true

				if #nonCompliantInodoro > 0  then
					nonCompliantInodoro:ForEach (function ( inodoro )
						
						if inodoro.Id == obj.Id then
							FXUtility.DisplaySolid_Error ( obj , siteProjectDevelopmentType..": "..obj:GetAttri("Name").." is provided.")
						else
							FXUtility.DisplaySolid_Info ( obj , siteProjectDevelopmentType..": "..obj:GetAttri("Name").." is provided.")
						end
					end)		
				else 
					FXUtility.DisplaySolid_Info ( obj , siteProjectDevelopmentType..": "..obj:GetAttri("Name").." is provided.")
				end
			end
		end)

		if isThereWaterCloset == false then
			FXUtility.DisplaySolid_Warning ( Site , siteProjectDevelopmentType..":No Water Closet found.")
		end
	else
		FXUtility.DisplaySolid_Warning ( Site , "Project Development Type not Residential.")
	end
end