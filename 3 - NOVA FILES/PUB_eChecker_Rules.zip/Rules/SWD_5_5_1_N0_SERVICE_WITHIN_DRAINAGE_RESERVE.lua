local DrainageReserve = FXGroup:new()
local publicDrain = FXGroup:new()
local Others = FXGroup:new()
local lowestElevation;
local highestElevation;
local minVal;
local isErrorFound = false;
function main()

	CheckEngine.SetCheckType("BuildingStorey")
	CheckEngine.BindCheckFunc("XMLParser")
	CheckEngine.RunCheckPipeline()

	-- CheckEngine.SetCheckType("BuildingStorey");
	-- CheckEngine.BindCheckFunc("CheckRuleGrp");
	-- CheckEngine.RunCheckPipeline();

	CheckEngine.SetCheckType("Building");
	CheckEngine.BindCheckFunc("CheckRule");
	CheckEngine.RunCheckPipeline();

end
function XMLParser(Storey)
	local ok, path = pcall(FXPUB.GetFilePath())
    local parsedXml = FXPUB.ParseXml(path(), "SWD_5_5_1_N0_SERVICE_WITHIN_DRAINAGE_RESERVE")

	
	local GrpObjs = FXRule.filterObjects(parsedXml, Storey);
	local ConditionValues = FXRule.ParseValues(parsedXml, "Condition1");
	SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
	local GrpObjSystem = FXPUB.ParseObjectsInSystem(parsedXml, Storey, SystemTypes);
	
	minVal = tonumber(ConditionValues[3]);
	if GrpObjSystem ~= nil then
		for k,v in pairs(GrpObjSystem) do
			if (k == 2) then
				publicDrain = publicDrain + v
				publicDrain = publicDrain:Unique()
			end
			if (k == 3) then
				Others = Others + v
				Others = Others:Unique()
			end
			if (k == 4) then
				DrainageReserve = DrainageReserve + v
				DrainageReserve = DrainageReserve:Unique()
			end
		end
	end
	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if (k == 2) then
				publicDrain = publicDrain + v
				publicDrain = publicDrain:Unique()
			end
			if (k == 3) then
				Others = Others + v
				Others = Others:Unique()
			end
			if (k == 4) then
				DrainageReserve = DrainageReserve + v
				DrainageReserve = DrainageReserve:Unique()
			end
		end
	end
end

function CheckRule(Building)
	if #DrainageReserve == 0 and #publicDrain == 0 then
		FXUtility.DisplaySolid_Warning(Building,"Drainage Reserve and Public Drain is not provided.")
	else
		local storeys = Building:GetChildren();
		storeys:ForEach(function(storey)
			local below = storey:GetBelowStorey()
			if below <=0 then
				local box = FXGeom.GetBoundingBox(storey);
				local lowPos = box:LowPos().z;
				lowestElevation = lowPos;
			elseif #FXUtility.GetAllUpperStorey(storey) == 0  then
				local highestStorey = storey;
				if highestStorey ~= nil then
					local Grpobj = storey:GetDescendants("All")
					local sub;
					Grpobj:ForEach(function(obj)
						if sub == nil then
							sub = obj
						else
							if FXGeom.GetBoundingBox(obj):HighPos().z > FXGeom.GetBoundingBox(sub):HighPos().z then
								highestElevation = FXGeom.GetBoundingBox(obj):HighPos().z
							end
						end
					end)
				end
			end
		end)
		------------------------------------------------------------------------
		if #DrainageReserve ~= 0 then
			DrainageReserve:ForEach(function(dr)
				local drProjection = FXMeasure.GetObjProjection(dr,lowestElevation);
				local outer = FXMeasure.GetOuterEdge(drProjection);
				local face = outer:Face3D();
				local extrudeFace = face:ExtrudedFace(Vector(0,0,highestElevation-lowestElevation))
				local node = FXUtility.CreateNodeFrom(extrudeFace)
				
				if #publicDrain ~= 0 then
					publicDrain:ForEach(function(pd)
						if FXClashDetection.IsCollided(node,pd) then
							Others:ForEach(function(ele)
								if FXClashDetection.IsCollided(node,ele) then
									DistanceofTwoObjs(pd,ele);
								end
							end)
							if isErrorFound == false then
								Others:ForEach(function(ele)
									if FXClashDetection.IsCollided(node,ele) then
										DistanceofTwoObjs1(pd,ele);
									end
								end)
							end
						end
					end)
				else
					if #publicDrain == 0 then
						Others:ForEach(function(ele)
							if FXClashDetection.IsCollided(node,ele)then
								local desc = ele:GetAttri("Description")
								if desc ~= nil then
									FXUtility.DisplaySolid_Error(ele,ele:GetAttri("Description").." is within "..dr:GetAttri("LongName"))
								else
									FXUtility.DisplaySolid_Error(ele,ele:GetAttri("Name").." is within "..dr:GetAttri("LongName"))
								end
							end
						end)
					end
				end
				FXClashDetection.DeleteNode(node);
			end)
		else
			if #publicDrain ~= 0 then
				publicDrain:ForEach(function(pd)
					Others:ForEach(function(ele)
						DistanceofTwoObjs(pd,ele);
					end)
				end)

				if isErrorFound == false then
					publicDrain:ForEach(function(pd)
						Others:ForEach(function(ele)
							DistanceofTwoObjs1(pd,ele);
						end)
					end)
				end
			end
		end
	end
end

function DistanceofTwoObjs(Element1,Element2)
	local Distance = FXMeasure.Distance(Element1,Element2)
	local dist = FXUtility.Round(Distance:Length(),0);
	local Pnt1 = Point3D(Distance:GetStartPoint().x, Distance:GetStartPoint().y, Distance:GetStartPoint().z+2000)
	local Pnt2 = Point3D(Distance:GetEndPoint().x, Distance:GetEndPoint().y, Distance:GetEndPoint().z+2000)

	local arrow = DoubleArrow(Pnt1,Pnt2)
	local plyline = PolyLine3D(TRUE);
	plyline:AddPoint(Distance:GetStartPoint());
	plyline:AddPoint(Pnt1);
	plyline:AddPoint(Pnt2);
	plyline:AddPoint(Distance:GetEndPoint());
	if dist < minVal then
		isErrorFound = true
		FXUtility.DisplaySolid_Error(Element2,Element1:GetAttri("Name").." to "..Element2:GetAttri("Name"),arrow)
		CheckReport.AddRelatedObj(Element2,dist.."mm")
		CheckReport.AddRelatedGeometry_Error(plyline);
	-- else
	-- 	FXUtility.DisplaySolid_Info(Element2,Element1:GetAttri("Name").." to "..Element2:GetAttri("Name"),arrow)
	-- 	CheckReport.AddRelatedObj(Element2,dist.."mm")
	-- 	CheckReport.AddRelatedGeometry_Solid(plyline);
	end
end

function DistanceofTwoObjs1(Element1,Element2)
	local Distance = FXMeasure.Distance(Element1,Element2)
	local dist = FXUtility.Round(Distance:Length(),0);
	local Pnt1 = Point3D(Distance:GetStartPoint().x, Distance:GetStartPoint().y, Distance:GetStartPoint().z+2000)
	local Pnt2 = Point3D(Distance:GetEndPoint().x, Distance:GetEndPoint().y, Distance:GetEndPoint().z+2000)

	local arrow = DoubleArrow(Pnt1,Pnt2)
	local plyline = PolyLine3D(TRUE);
	plyline:AddPoint(Distance:GetStartPoint());
	plyline:AddPoint(Pnt1);
	plyline:AddPoint(Pnt2);
	plyline:AddPoint(Distance:GetEndPoint());
	if dist < minVal then
		-- isErrorFound = true
		-- FXUtility.DisplaySolid_Error(Element2,Element1:GetAttri("Name").." to "..Element2:GetAttri("Name"),arrow)
		-- CheckReport.AddRelatedObj(Element2,dist.."mm")
		-- CheckReport.AddRelatedGeometry_Error(plyline);
	else
		FXUtility.DisplaySolid_Info(Element2,Element1:GetAttri("Name").." to "..Element2:GetAttri("Name"),arrow)
		CheckReport.AddRelatedObj(Element2,dist.."mm")
		CheckReport.AddRelatedGeometry_Solid(plyline);
	end
end