-- Implemented By: Elcar Zarcilla 01/03/2019

local pumpingMainGrp = FXGroup.new()
local AccessChamberGrp = FXGroup.new()

function main()
  CheckEngine.SetCheckType("Building")
  CheckEngine.BindCheckFunc("XMLParser")
  CheckEngine.RunCheckPipeline()
  
  CheckEngine.SetCheckType("Building");
  CheckEngine.BindCheckFunc("checkRule");
  CheckEngine.RunCheckPipeline();
end

function XMLParser(Building)
  local ok, path = pcall(FXPUB.GetFilePath())
  local parsedXml = FXPUB.ParseXml(path(), "SSW_3_3_4_C_I_ACCESS_CHAMBER_FOR_PUMPING_MAINS");
  -- local GrpObjs = FXRule.filterObjects(parsedXml, Building);
  local ConditionValues = FXRule.ParseValues(parsedXml, "Condition");
  SystemTypes = FXRule.ParseValues(parsedXml, "SystemType");
  local GrpObjs = FXPUB.ParseObjectsInSystem(parsedXml, Building, SystemTypes);
  for k,v in pairs(GrpObjs) do
    if (k == 2) then
      pumpingMainGrp = pumpingMainGrp + v;
      pumpingMainGrp = pumpingMainGrp:Unique();
    end
    if (k == 3) then
      AccessChamberGrp = AccessChamberGrp + v;
      AccessChamberGrp = AccessChamberGrp:Unique();
    end
  end
end

function checkRule(Building)
	local check = true;

	if #pumpingMainGrp == 0 or pumpingMainGrp == nil then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"Pumping Main is not detected.")
	end

	if #AccessChamberGrp == 0 or AccessChamberGrp == nil then
		check = false;
		FXUtility.DisplaySolid_Warning(Building,"Access Chamber is not detected.")
	end

	local checkedGrp = FXGroup.new()
	if check then
		local IsComplaint = true
		local ARRObjChamber = {}
		local ARRGrpPump = {}
		local ARRGRPChamber = {}
		local ARRGRPArrow = {}
		local ARRGRPLine = {}
		local ARRGRPRounded = {}
		local i = 0
		local ArrpipeNAME = {}
		local distance = 0;
		AccessChamberGrp:ForEach(function(chamberEle)
			
			pumpingMainGrp:ForEach(function(pumpingELe)
				local relatedPumpGrp = FXGroup.new()
				if FXClashDetection.IsCollided(chamberEle,pumpingELe) or FXMeasure.Distance ( chamberEle , pumpingELe ):Length() <0.1 then
					relatedPumpGrp:Add(pumpingELe)
					if FXUtility.IsBelongToTableElement2(pumpingELe, ArrpipeNAME) == false then
						local flag = true;
						AccessChamberGrp:ForEach(function(chamberEle2)
							if chamberEle.Id ~= chamberEle2.Id then
								if FXClashDetection.IsCollided(chamberEle2,pumpingELe) or FXMeasure.Distance ( chamberEle2 , pumpingELe ):Length() <0.1 then
									flag = false;
									local chamberGrp = FXGroup.new()
									chamberGrp:Add(chamberEle2)
									table.insert(ArrpipeNAME, pumpEle:GetAttri("Name"))
									local chamberEleOBB = FXGeom.GetBoundingOBB(chamberEle)
									local chamberEle2OBB = FXGeom.GetBoundingOBB(chamberEle2)
									local pnt1 = chamberEleOBB:GetPos();
									local pnt2 = chamberEle2OBB:GetPos();
									local arrow = DoubleArrow(pnt1,pnt2)
									local line;
									if pnt1.z ~= pnt2.z then
										if pnt1.z > pnt2.z then
											local newpnt= Point3D(pnt1.x,pnt1.y,pnt2.z)
											line = Line3D(pnt1,newpnt)
											pnt1 = newpnt
										else
											local newpnt= Point3D(pnt2.x,pnt2.y,pnt1.z)
											line = Line3D(pnt2,newpnt)
											pnt2 = newpnt
										end
									end
									distance = pnt1:Distance_Pnt(pnt2);
									local rounded = math.floor(FXUtility.Round(distance):Length())
									if rounded >= 200000 then
										IsComplaint = false;
										FXUtility.DisplaySolid_Error(chamberEle,chamberEle:GetAttri("Name") .. " - " .. chamberEle2:GetAttri("Name") .. ": Distance: " .. rounded .. "mm")
										CheckReport.AddRelatedObj(chamberEle,chamberEle:GetAttri("Name"))

										relatedPumpGrp:ForEach(function(relatedEle)
											CheckReport.AddRelatedObj(relatedEle,relatedEle:GetAttri("Name"))
										end)

										CheckReport.AddRelatedObj(chamberEle2,chamberEle2:GetAttri("Name"))
										CheckReport.AddRelatedGeometry_Error(arrow)
									else
										i = i + 1
										ARRObjChamber[i] = chamberEle
										ARRGrpPump[i] = relatedPumpGrp
										ARRGRPChamber[i] = chamberEle2	
										ARRGRPArrow[i] = arrow
										ARRGRPRounded[i] = rounded
										ARRGRPLine[i] = line
									end
								end
							end
						end)
						if flag then
							pumpingMainGrp:ForEach(function(pumpEle)
								if pumpingELe.Id ~= pumpEle.Id then
									if FXPUB.IsTwoObjsConnected(pumpingELe,pumpEle,20) then
										relatedPumpGrp:Add(pumpEle)
										AccessChamberGrp:ForEach(function(accessEle)
											if chamberEle.Id ~= accessEle.Id then
												if FXClashDetection.IsCollided(pumpEle,accessEle) or FXMeasure.Distance ( pumpEle , accessEle ):Length() <1 then
													local chamberGrp = FXGroup.new()
													chamberGrp:Add(accessEle)
													table.insert(ArrpipeNAME, pumpEle:GetAttri("Name"))
													local chamberEleOBB = FXGeom.GetBoundingOBB(chamberEle)
													local chamberEle2OBB = FXGeom.GetBoundingOBB(accessEle)
													local pnt1 = chamberEleOBB:GetPos();
													local pnt2 = chamberEle2OBB:GetPos();
													local arrow = DoubleArrow(pnt1,pnt2)
													local line;
													if pnt1.z ~= pnt2.z then
														if pnt1.z > pnt2.z then
															local newpnt= Point3D(pnt1.x,pnt1.y,pnt2.z)
															line = Line3D(pnt1,newpnt)
															pnt1 = newpnt
														else
															local newpnt= Point3D(pnt2.x,pnt2.y,pnt1.z)
															line = Line3D(pnt2,newpnt)
															pnt2 = newpnt
														end
													end
													distance = pnt1:Distance_Pnt(pnt2);
													local arrow = DoubleArrow(pnt1,pnt2)
													local rounded = math.floor(FXUtility.Round(distance))
													if rounded >= 200000 then
														IsComplaint = false;
														FXUtility.DisplaySolid_Error(chamberEle,chamberEle:GetAttri("Name") .. " - " .. accessEle:GetAttri("Name") .. ": Distance: " .. rounded .. "mm")
														CheckReport.AddRelatedObj(chamberEle,chamberEle:GetAttri("Name"))

														relatedPumpGrp:ForEach(function(relatedEle)
															CheckReport.AddRelatedObj(relatedEle,relatedEle:GetAttri("Name"))
														end)

														CheckReport.AddRelatedObj(accessEle,accessEle:GetAttri("Name"))
														CheckReport.AddRelatedGeometry_Error(arrow)
														CheckReport.AddRelatedGeometry_Error(line)
													else
														i = i + 1
														ARRObjChamber[i] = chamberEle
														ARRGrpPump[i] = relatedPumpGrp
														ARRGRPChamber[i] = accessEle	
														ARRGRPArrow[i] = arrow
														ARRGRPRounded[i] = rounded
														ARRGRPLine[i] = line
													end
												end
											end
										end)
									end
								end
							end)
						end
					end

				end
			end)
		end)

		--checking
		if IsComplaint then
			for i,chamberEle in pairs(ARRObjChamber) do
				FXUtility.DisplaySolid_Info(chamberEle,chamberEle:GetAttri("Name") .. " - " .. ARRGRPChamber[i]:GetAttri("Name") .. ": Distance: " .. ARRGRPRounded[i] .. "mm")
				CheckReport.AddRelatedGeometry_Info(ARRGRPArrow[i])
				CheckReport.AddRelatedGeometry_Info(ARRGRPLine[i])

				ARRGrpPump[i]:ForEach(function(pumpEle)
					CheckReport.AddRelatedObj(pumpEle,pumpEle:GetAttri("Name"))		
				end)

				CheckReport.AddRelatedObj(ARRGRPChamber[i],ARRGRPChamber[i]:GetAttri("Name"))		
			end
		end		
	end
end