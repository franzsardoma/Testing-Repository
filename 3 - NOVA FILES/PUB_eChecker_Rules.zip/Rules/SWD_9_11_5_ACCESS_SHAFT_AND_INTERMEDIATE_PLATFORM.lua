--[[
	Title			: SWD 9.11.5 - ACCESS SHAFT AND INTERMEDIATE PLATFORM (LUA Code)
	Implemented by	: Wilcelle Tapagñan (DEV/LUA)
	Committed(Date)	: __/__/__
	Sprint 			: Sprint 4.2
	Modified by		: ? ?
]]--

local roadSide 			= FXGroup.new();	-- Group for Roadside Drain
local accessShaft 		= FXGroup.new();	-- Group for Access Shaft
local interPlatform 	= FXGroup.new();	-- Group for Intermediate Platform
local rdepthOpe;							-- Variable for the operator of depth of Roadside Drain
local rdepthVal;							-- Variable for the value of depth of Roadside Drain
local adepthOpe;							-- Variable for the operator of depth of Access Shaft
local adepthVal;							-- Variable for the value of depth of Access Shaft
local lengthOpe;							-- Variable for the operator of depth of Length of Access Shaft
local lengthVal;							-- Variable for the value of depth of Length of Access Shaft
local widthOpe;								-- Variable for the operator of depth Width of Access Shaft
local widthVal;								-- Variable for the value of depth of Width of Access Shaft


function main()	
 	CheckEngine.SetCheckType("Building");	
 	CheckEngine.BindCheckFunc("XMLParser");				
 	CheckEngine.Run();

	CheckEngine.SetCheckType("Building");
 	CheckEngine.BindCheckFunc("CheckRule");	
 	CheckEngine.Run();						
end

function XMLParser(Building)

    local ok, path 			= pcall(FXPUB.GetFilePath());
    local parsedXml 		= FXPUB.ParseXml(path(), "SWD_9_11_5_ACCESS_SHAFT_AND_INTERMEDIATE_PLATFORM");
    local GrpObjs 			= FXRule.filterObjects(parsedXml, Building);
	local ConditionValues 	= FXRule.ParseValues(parsedXml, "Condition1");
	local ConditionValues2 	= FXRule.ParseValues(parsedXml, "Condition2");

	-- Start Parsing the operator and value from the universal template
	rdepthOpe = ConditionValues[2];
	rdepthVal = tonumber(ConditionValues[3]);
	adepthOpe = ConditionValues2[2];
	adepthVal = tonumber(ConditionValues2[3]);	
	lengthOpe = ConditionValues2[7];
	lengthVal = tonumber(ConditionValues2[8]);	
	widthOpe  = ConditionValues2[11];
	widthVal  = tonumber(ConditionValues2[12]);	
	-- End Parsing the operator and value from the universal template

	if GrpObjs ~= nil then
		for k,v in pairs(GrpObjs) do
			if ( k == 2 ) then
				roadSide = roadSide + v;
				roadSide = roadSide:Unique();
			end
			if ( k == 3 ) then
				accessShaft = accessShaft + v;
				accessShaft = accessShaft:Unique();
			end
		end
	end
end

function CheckRule(Building)

	-- Conditions of the : SSW 9.11.5
	-- Get the inside depth of roadside drain to check if it is >= 3000mm
	-- Check if the access shaft is provided when the depth of the roadside drain is greater than 3000mm
	-- Check the dimension of the access shaft
	-- Get the inside depth of access shaft to check if it is >= 4000mm
	-- Check if the intermediate platform is provided when the depth of the access shaft is greater than 4000mm

	local slab 				= Building:GetDescendants("slab")
	local interPlatform 	= FXGroup.new();					
	local closedDrain 		= FXGroup.new();					
	local accessShaftb 		= FXGroup.new();					
	local isnotCollided		= false

	if ChekWarning(Building) then
		
		slab:ForEach(function(slabEle)
			
			if FXUtility.HasPatterInString(slabEle:GetAttri("ObjectType"), "Intermediate Platform") then

				interPlatform:Add(slabEle)
			end
		end)

		roadSide:ForEach(function(roadside)
			accessShaft:ForEach(function(access)

	    		local centerline 		= FXMeasure.GetProjectionCenterLine(roadside);
	    		local startPnt 			= centerline:GetEndPoint();
				local box 				= FXGeom.GetBoundingBox(roadside);								-- BoundingBox the closedDrain
				local point 			= box:MidPos();	
				local newcpoint 		= Point3D(startPnt.x,startPnt.y,point.z)
				local rsline  			= GetCloseDrainDepth(newcpoint,roadside);						-- Getting the return value from the function GetRoadSideDepth
				local roadsideDepth 	= rsline:GetStartPoint():Distance_Pnt(rsline:GetEndPoint());	-- Getting the Distance using the point that is get on the GetRoadSideDepth function
				local rdepthRound 		= math.floor(FXUtility.Round(roadsideDepth, 0))					-- Rounding the Distance result
				local roadDarrow 		= DoubleArrow(rsline:GetStartPoint(), rsline:GetEndPoint());	-- Depth of Roadside Drain using Double Arrow for the display result
																		
				if ( FXRule.EvaluateNumber(rdepthOpe, roadsideDepth, rdepthVal) ) == true then --The depth is greater than 3000 (Passed)

					FXUtility.DisplaySolid_Info(roadside,roadside:GetAttri("ObjectType")..": depth: "..rdepthRound.."mm.");
					CheckReport.AddRelatedGeometry_Solid(roadDarrow, "Arrow3D");

					if FXClashDetection.IsCollided(roadside,access) then --The Access Shaft is provided (Passed)
					
						FXUtility.DisplaySolid_Info(roadside,roadside:GetAttri("ObjectType")..": depth: "..rdepthRound.."mm: "..access:GetAttri("ObjectType").." is provided");
						CheckReport.AddRelatedGeometry_Solid(roadDarrow, "Arrow3D");
						CheckReport.AddRelatedObj(access, access:GetAttri("ObjectType"));

						local box2				= FXGeom.GetBoundingBox(access);										-- BoundingBox the Access Shaft
						local point2 			= box2:MidPos();														-- Getting the Midpoint of Access Shaft
						local lengthline  		= GetInternalElementLength(point2, access);								-- Getting the Length of the Access Shaft
						local widthLine 		= GetInternalElementWidth(point2, access);								-- Getting the Width of the Access Shaft
						local aclengthDis		= lengthline:GetStartPoint():Distance_Pnt(lengthline:GetEndPoint());	-- Distance of the length of Access Shaf
						local aclengthRound 	= math.floor(FXUtility.Round(aclengthDis, 0))							-- Rounding the distance of the length of Access Shaft
						local aclengthDarrow 	= DoubleArrow(lengthline:GetStartPoint(), lengthline:GetEndPoint());	-- Length of Access Shaft using Double Arrow for the display result			
						local acwidthDis		= widthLine:GetStartPoint():Distance_Pnt(widthLine:GetEndPoint());		-- Distance of the width of Access Shaf
						local acwidthRound 		= math.floor(FXUtility.Round(acwidthDis, 0)) 							-- Rounding the distance of the width of Access Shaft
						local acwidthDarrow 	= DoubleArrow(widthLine:GetStartPoint(), widthLine:GetEndPoint());		-- Width of Access Shaft using Double Arrow for the display result

						if ( (FXRule.EvaluateNumber(lengthOpe, aclengthDis, lengthVal)) and (FXRule.EvaluateNumber(widthOpe, acwidthDis, widthVal)) ) == true then -- The length and width of the access Shaft is 2000x1500 mm (Passed)

							FXUtility.DisplaySolid_Info(access,access:GetAttri("ObjectType")..": opening: "..aclengthRound.."mm".." x "..acwidthRound.."mm.");
							CheckReport.AddRelatedGeometry_Solid(aclengthDarrow, "Arrow3D");
							CheckReport.AddRelatedGeometry_Solid(acwidthDarrow, "Arrow3D");
						else

							FXUtility.DisplaySolid_Error(access,access:GetAttri("ObjectType")..": opening: "..aclengthRound.."mm".." x "..acwidthRound.."mm.");
							CheckReport.AddRelatedGeometry_Error(aclengthDarrow, "Arrow3D");
							CheckReport.AddRelatedGeometry_Error(acwidthDarrow, "Arrow3D");
						end

						local point3 			= Point3D(FXGeom.GetBoundingBox(access):MidPos().x, FXGeom.GetBoundingBox(access):MidPos().y, FXGeom.GetBoundingBox(access):HighPos().z) 																												  
						local accessDepth 		= GetAcceessShaftDepth(point3, roadside);																						
						local adepthDis 		= accessDepth:GetStartPoint():Distance_Pnt(accessDepth:GetEndPoint());																		  
						local adepthRound 		= math.floor(FXUtility.Round(adepthDis, 0))																							 
						local accessDarrow 		= DoubleArrow(accessDepth:GetStartPoint(), accessDepth:GetEndPoint());																				
																																	
						if ( FXRule.EvaluateNumber(adepthOpe, adepthDis, adepthVal) ) == true then	-- The depth of the access shaft through the bottom of the roadside drain is greater than 4000 (Passed)

							if #interPlatform ~= 0 then

								interPlatform:ForEach(function(slab)

									if FXClashDetection.IsCollided(roadside,slab) then -- The intermediate platform is provided (passed)
												
										if FXUtility.HasPatterInString(slab:GetAttri("ObjectType"), "Intermediate Platform") then

											FXUtility.DisplaySolid_Info(roadside,roadside:GetAttri("ObjectType")..": depth: "..adepthRound.." mm: "..slab:GetAttri("ObjectType").." is provided.");
											CheckReport.AddRelatedObj(slab, slab:GetAttri("ObjectType"));
											CheckReport.AddRelatedGeometry_Solid(accessDarrow, "Arrow3D");
										else

											FXUtility.DisplaySolid_Info(roadside,roadside:GetAttri("ObjectType")..": depth: "..adepthRound.." mm: "..slab:GetAttri("ObjectType").." is not an Intermediate Platform.");
											CheckReport.AddRelatedObj(slab, slab:GetAttri("ObjectType"));
											CheckReport.AddRelatedGeometry_Solid(accessDarrow, "Arrow3D");
										end					
									end
								end)
							else

								FXUtility.DisplaySolid_Error(roadside,roadside:GetAttri("ObjectType")..": depth: "..adepthRound.." mm: Intermediate Platform is not provided");
								CheckReport.AddRelatedGeometry_Error(accessDarrow, "Arrow3D");
							end
						else -- The depth of the access shaft through the bottom of the roadside drain is less than 4000 (Failed)
															
							FXUtility.DisplaySolid_Error(roadside,roadside:GetAttri("ObjectType")..": depth: "..adepthRound.." mm: Intermediate Platform is not provided");
							CheckReport.AddRelatedGeometry_Error(accessDarrow, "Arrow3D");
						end																			
					end
				else

					FXUtility.DisplaySolid_Error(roadside,roadside:GetAttri("ObjectType")..": depth: "..rdepthRound.."mm.");
					CheckReport.AddRelatedGeometry_Error(roadDarrow, "Arrow3D");
				end
			end)
		end)
	end
end

function ChekWarning(Building)
	local noWarning = true;

	if (#roadSide == 0) then

		FXUtility.DisplaySolid_Warning(Building,"Roadside Drain is not detected");
		noWarning = false;
	end

	if (#accessShaft == 0) then

		FXUtility.DisplaySolid_Warning(Building,"Access Shaft is not detected");
		noWarning = false;
	end

	return noWarning
end

function GetCloseDrainDepth(Point,Element)
	local y 			= 10; 	-- iterate for the loops
	local i 			= 1; 	-- condition for point 1
	local j				= 1; 	-- condition for point 2
	local highzPoint 	= FXGeom.GetBoundingBox(Element):HighPos().z;
	local point1;
	local point2;

	while i > 0 do 	-- it will draw a line going up from mid point
		
		y = y + .2; -- iteration for y axis line
		-- print("------"..y)
		local upPoint3D = Point3D(Point.x, Point.y, Point.z + y);
		local upLine3D 	= Line3D(Point,upPoint3D);
		local upNode 	= FXUtility.CreateNodeFrom(upLine3D);
		local dis3D 	= upPoint3D.z;

		if ( FXClashDetection.IsCollided(upNode, Element) ) then 

			point1 = upPoint3D;
			FXClashDetection.DeleteNode(upNode);
			break;
		end

		FXClashDetection.DeleteNode(upNode);
	end

	while j > 0 do -- it will draw a line going down from mid point
		-- print("------"..y)
		y = y + .2; -- iteration for y axis line
		-- print("------"..y)
		local downPoint3D 	= Point3D(Point.x, Point.y, Point.z - y);
		local downLine3D 	= Line3D(Point,downPoint3D);
		local downNode 		= FXUtility.CreateNodeFrom(downLine3D);

		if ( FXClashDetection.IsCollided(downNode, Element) ) then 	

			point2 = downPoint3D;
			FXClashDetection.DeleteNode(downNode);
			break;
		end

		FXClashDetection.DeleteNode(downNode);
	end

	local rsline = Line3D(point1,point2)

	return rsline;
end

function GetLongestLine(outerEdge)
	local PolyLinePointNumber = outerEdge:GetPointNumber(); --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i);
		local Point2 = outerEdge:GetPoint(i+1);
		local Line   = Line3D(Point1, Point2);
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end


function GetReallyLongestLine(outerEdge)
	local PolyLinePointNumber = outerEdge:GetPointNumber(); --PolyLine3D's points number
	local dist;

	for i=0,(PolyLinePointNumber-2) do
		local Point1 = outerEdge:GetPoint(i);
		local Point2 = outerEdge:GetPoint(1);
		local Line   = Line3D(Point1, Point2);
		if( dist == nil or dist:Length() < Line:Length() ) then
			dist = Line;
		end
	end
	return dist;
end

function GetInternalElementLength(Point, Element)
	local i 		= 1;
	local y 		= 1;
	local length 	= 0;
	local Pnt1;
	local Pnt2;
	local eleBox 	= FXGeom.GetBoundingBox(Element);

	if  eleBox:y_range() < eleBox:x_range() then
		Pnt1 = Point3D(Point.x, Point.y+y, Point.z);
		Pnt2 = Point3D(Point.x, Point.y-y, Point.z);
	else
		Pnt1 = Point3D(Point.x+y, Point.y, Point.z);
		Pnt2 = Point3D(Point.x-y, Point.y, Point.z);
	end

	local Line = Line3D(Pnt1, Pnt2);
	
	while i > 0 do 																-- To get the internal length of the Access Shaft 			
		length = length + 1; 
		local extended 		= FXMeasure.CreateFaceFromEdge(Line, length); 		-- Makes the line fatter everyloop incrementing 1mm
		local extendedNode 	= FXUtility.CreateNodeFrom(extended); 				-- Node for the face, to make it work with IsCollided 
			if FXClashDetection.IsCollided(extendedNode, Element) then
				i = i - 1;	
				FXClashDetection.DeleteNode(extendedNode);			
			end
		FXClashDetection.DeleteNode(extendedNode);  							-- Always delete a node after using
	end

	-- local ElementLength = length * 2;
	local showLength 	= FXMeasure.CreateFaceFromEdge(Line, length);
	local outer 		= FXMeasure.GetOuterEdge(showLength);
	local lengthLine 	= GetLongestLine(outer);
	return lengthLine;
end

function GetInternalElementWidth(Point, Element)
	local i 		= 1;
	local x 		= 1;
	local width 	= 0;
	local Pnt1;
	local Pnt2;
	local eleBox 	= FXGeom.GetBoundingBox(Element);

	if eleBox:x_range() > eleBox:y_range() then
		Pnt1 = Point3D(Point.x+x, Point.y,Point.z);
		Pnt2 = Point3D(Point.x-x, Point.y,Point.z);
	else
		Pnt1 = Point3D(Point.x, Point.y+x,Point.z);
		Pnt2 = Point3D(Point.x, Point.y-x,Point.z);
	end
	
	local Line = Line3D(Pnt1, Pnt2);

	while i > 0 do -- to get the width of the trench 			
		width = width + 1 ;
		local extended 		= FXMeasure.CreateFaceFromEdge(Line, width); -- makes the line fatter everyloop incrementing 1mm
		local extendedNode 	= FXUtility.CreateNodeFrom(extended); -- node for the face, to make it work with IsCollided 
			if FXClashDetection.IsCollided(extendedNode, Element) then
				i = i - 1 	
				FXClashDetection.DeleteNode(extendedNode);				
			end
		FXClashDetection.DeleteNode(extendedNode);  -- always delete a node after using
	end

	-- local ElementWidth 	= width * 2;
	local showWidth 	= FXMeasure.CreateFaceFromEdge(Line, width);
	local outer 		= FXMeasure.GetOuterEdge(showWidth);
	local widthLine 	= GetLongestLine(outer);
	return widthLine;
end

function GetAcceessShaftDepth(Point, Element)

	local y 		= 1; 	-- iterate for the loops
	local yAxis 	= 1; 	-- condition for point 2

	local point;

	while yAxis > 0 do -- it will draw a line going down from mid point

		y = y + .2; -- iteration for y axis line

		local downPoint3D 	= Point3D(Point.x, Point.y, Point.z - y);
		local downLine3D 	= Line3D(Point,downPoint3D);
		local downNode 		= FXUtility.CreateNodeFrom(downLine3D);

		if ( FXClashDetection.IsCollided (downNode, Element) ) then 	

			point = downLine3D;
			FXClashDetection.DeleteNode(downNode);
			break;
		end

		FXClashDetection.DeleteNode(downNode);
	end

	local accessDepth = Line3D(point:GetStartPoint(), point:GetEndPoint());

	return accessDepth;
end